# SnowCup — Build-an-Agent Lab

A self-paced, 3–4 hour Snowflake workshop that teaches Cortex Code end to end on a fictional
football tournament: explore raw data, model a semantic view, ground it with Cortex Search,
assemble a Cortex Agent, publish it in Snowflake CoWork, evaluate it, and beat an
auto-graded 8-question challenge worth 120 points.

This folder is **self-contained**. Everything needed to stand the workshop up in any
Snowflake account is here — no other downloads.

---

> ## Keep this repository private
>
> **This folder contains the answer key.** `assets/snowcup-grader-setup.sql` seeds the
> hidden `CHALLENGE_KEY` table, and `assets/snowcup-facilitator-guide.html` prints all
> eight answers in plain text.
>
> - Restrict access to facilitators. Anyone who can read this repo can win the challenge.
> - **Never** send learners this folder, the repo link, or the facilitator guide.
> - Learners receive **one thing**: the lab app URL (see [Hand-off](#hand-off)).

---

## Prerequisites

| Requirement | Why |
|---|---|
| `ACCOUNTADMIN` on the target account | Creates databases, roles, warehouses, and account parameters |
| **A paid account** | Trial accounts cannot run Snowflake App Runtime, and the lab itself is a deployed app. The workshop cannot be delivered on a trial. |
| A shell — Cortex Code Desktop or CLI | `snow app deploy` builds a container image; there is no Snowsight equivalent |
| Node 20+ and the `snow` CLI | `node --version` and `snow --version` should both answer |
| Gen2 warehouses available in the region | The data setup requires them. Preflight checks this and stops if unavailable. |

## Deploy

```bash
./deploy.sh --connection <your-connection> --yes \
            --learners "JSMITH, jane.doe@acme.com" < /dev/null
```

That runs every step in order and stops at the first failed gate.

| Flag | Notes |
|---|---|
| `--connection` | Required. A `snow` CLI connection name (`snow connection list`). |
| `--yes` | Authorises the App Runtime account defaults, which are set **only if unset**. Without it the run stops there rather than silently altering the account. Separately, `CORTEX_ENABLED_CROSS_REGION` is changed only when it is `DISABLED` (Cortex orchestration models must be reachable) — never narrowed, and the run prints the old value and the statement to restore it. |
| `--learners` | Optional, comma-separated. Add people later instead if you prefer. |
| `--skip-apps` | SQL only, no Node needed. Useful for a dry run — but the lab app *is* the learner deliverable, so the workshop is not deliverable until it is deployed. |
| `--role` | Defaults to `ACCOUNTADMIN`. |

**Always include `< /dev/null`.** Without it the script can block indefinitely at step 0 or
step 8 waiting on stdin, showing no output and no error.

Expect roughly 15 minutes for the SQL steps, then 15–20 minutes per app on a cold
container build (about a minute each once cached).

## Verify

Every gate must read `PASS`. The run stops at the first failure — a half-configured account
is harder to diagnose than a clean stop.

The gate that matters most is **`8/8 answers MATCH`**. It recomputes every answer from the
loaded data and compares it to the hidden key, so if the data generator and the grader ever
disagree it fails here rather than in front of your learners. `tied=1` proves each question
has exactly one winner, so nobody can be marked wrong for a defensible answer.

If any gate fails, **stop**. Do not provision learners or send invitations.

## Add learners

```sql
CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS('JSMITH, jane.doe@acme.com');
```

Accepts either a Snowflake username or an email address (matched against `name`,
`login_name`, or `email`). Anything that matches no user returns `PARTIAL` with a warning
instead of failing the batch. Idempotent, so re-running is safe — and re-running is also the
repair path if a learner reports an empty schema, because it hands ownership of anything in
their schema back to their own role.

Read the schema and role from the procedure's output rather than predicting them: email
addresses are sanitised, so `jane.doe@acme.com` becomes `WS_JANE_DOE`.

## Hand-off

Give learners **only** the lab app URL:

```bash
cd assets/snowcup-lab-node && snow app open --print-only
```

Also tell them:

- Their build schema `SNOWCUP_BUILDS.WS_<NAME>` and role `SNOWCUP_WS_<NAME>`, copied from
  the provisioning output.
- To run `USE ROLE SNOWCUP_WS_<NAME>;` if they already had a default role — provisioning
  deliberately does not overwrite an existing one.
- Submissions to the Referee use the format `Q1: <answer>`.
- Modules 0–8 and 10 need only the shared data and their build schema, so they can start
  before you finish the admin console. The grader must be live before **Module 9**.

The facilitator console (roster, lab progress, environment health) is a separate URL:

```bash
cd assets/snowcup-admin-node && snow app open --print-only
```

### Finding either URL later, from any worksheet

`snow app open` needs the package directory. This does not:

```sql
SHOW APPLICATION SERVICES LIKE 'SNOWCUP%' IN SCHEMA SNOWFLAKE_APPS.PUBLIC;
SELECT "name" AS APP, 'https://' || "url" AS URL, "status"
  FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())) ORDER BY 1;
```

`status` should read `RUNNING`. Both URLs are stable unless an app is torn down and
redeployed, so they are safe to put in a calendar invite.

### The admin console

Opens for `ACCOUNTADMIN` and for anyone holding `SNOWCUP_FACILITATOR`, so you can
delegate without handing out account admin:

```sql
GRANT ROLE SNOWCUP_FACILITATOR TO USER <person>;
```

| Tab | What it is for |
|---|---|
| **Add learners** | Usernames or email addresses, comma separated. Idempotent — and re-running is the repair path for a learner reporting an empty schema, because it returns ownership of anything in their build schema to their own role. |
| **Roster** | Who is provisioned, with their role and build schema. A missing row means they cannot start. |
| **Remove** | Offboarding. Revoking the role keeps their work; ticking **also drop their build schema** deletes it and additionally requires typing `REMOVE`. The only destructive action in the console. |
| **Lab progress** | Per learner: checkpoints, challenge answers, quiz answers, points out of 120, and whether they are complete. No separate leaderboard tab — for a ranked view query `SNOWCUP_WORKSHOP.GRADING.LEADERBOARD`. Each row has a **Reset scores** button that clears that learner's checkpoints, quiz answers, challenge answers and completion stamp **for that training only** — it never touches what they built, their role or their schema. Worksheet equivalent: `CALL SNOWCUP_WORKSHOP.ADMIN.RESET_LEARNER_PROGRESS('<learner>', 'SNOWCUP');` |
| **Environment health** | The deploy's invariants re-checked live, including **learners own their own work**, which lists any mis-owned object and offers **Repair ownership**. If it reports *could not run `ADMIN.AUDIT_BUILD_OWNERSHIP`*, ownership is **unverified, not broken** — re-run `assets/snowcup-data-setup.sql` and reload. |

> **`HANDOFF.md` in this folder has the full facilitator checklist** — what to confirm
> before deploying, at each gate, before learners arrive, during the session, and
> afterwards. Read it before running a workshop for the first time.

## What gets created

| Object | Purpose |
|---|---|
| `SNOWCUP_WH` | X-Small Gen2, 1–10 clusters |
| `SNOWCUP_SHARED.TOURNAMENT` | Shared read-only data — 48 players, 323 stat rows |
| `SNOWCUP_BUILDS.WS_<NAME>` | One build schema per learner |
| `SNOWCUP_WORKSHOP.ADMIN` | Provisioning procedures |
| `SNOWCUP_WORKSHOP.GRADING` | Hidden answer key, grading procedures, score views |
| `SNOWCUP_REFEREE` | The grading agent |
| `SNOWCUP_PARTICIPANT`, `SNOWCUP_FACILITATOR`, `SNOWCUP_WS_<NAME>` | Roles |
| `SNOWFLAKE_APPS.PUBLIC.SNOWCUP_LAB_APP` | The learner lab (required) |
| `SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP` | Facilitator console (optional) |

`SNOWFLAKE_APPS` is shared account infrastructure that may host other apps. Create it if
absent; never drop it.

## Three things that will bite you

**1. Never create a Snowflake CoWork object.** If `SHOW SNOWFLAKE INTELLIGENCES` returns no
rows, leave it alone. Creating one flips the account from "list every agent I can access" to
"list only what was added" — which hides every agent your learners build. `deploy.sh`
deliberately refuses to touch this. If a CoWork object already exists, the Referee must be
added to it explicitly or it will not appear in the picker.

**2. Give learners users without `ACCOUNTADMIN`.** They can otherwise read the hidden answer
key, making the challenge meaningless. `DEFAULT_SECONDARY_ROLES = ALL` keeps `ACCOUNTADMIN`
active even when their primary role is `SNOWCUP_WS_<NAME>`, so this is invisible in normal
use. The deploy warns you when it detects it.

**3. Never pipe `snow app deploy` through `tail` or `head`.** It emits nothing until the pipe
closes, so a healthy two-minute deploy is indistinguishable from a hang. To check liveness
use `pgrep -f "app deploy"` — note that `ps -ef | grep snow` is useless here, because Chrome
helper processes carry `enrollment-domain=snowflake.com` and flood the results.

## Layout

```
deploy.sh                              One-command deploy; stops at the first failed gate
SKILL.md                               Cortex Code skill definition (step-by-step runbook)
HANDOFF.md                             Facilitator deployment walkthrough
README.md                              This file
assets/
  snowcup-data-setup.sql               Warehouse, roles, shared data, provisioning procs
  snowcup-grader-setup.sql             Answer key, grading procs, Referee agent  [SECRET]
  snowcup-facilitator-guide.html       Prints all 8 answers                      [SECRET]
  snowcup-lab-node/                    Learner lab app (Next.js)
  snowcup-admin-node/                  Facilitator console (Next.js)
  verify/                              Verification gates
    verify_answers.sql                 The 8/8 answer-integrity gate
    check_roles.sql                    Role-model gates
    check_build_ownership.sh           Ownership across all 7 creatable object kinds
    check_lab_progress.sql             Lab-progress and reinforcement-quiz gates
    test_completion_gate.sql           Proves completion needs checkpoints + answers + quizzes
    run_all.sh                         Authoring checks (shell only)
  README.md                            Workshop content detail and manual runbook
```

Both SQL scripts are idempotent and safe to re-run.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `invalid identifier 'MODULE_SEQ'` | An older `LAB_STEPS` shape exists; `CREATE TABLE IF NOT EXISTS` never adds columns | The script migrates this automatically — make sure you are running **this** version, not an older copy |
| Deploy fails on the access integration | Ran as the connection's default role | Use `--role ACCOUNTADMIN` |
| App cannot be granted to any role | It deployed into a personal database `USER$<login>` | Set the App Runtime account defaults, then redeploy |
| Learner sees a blank or broken app | Missing `USAGE` on the app database *or* schema | Both are required, not just the app service |
| Learner's schema looks empty, no error | An object was created by a different role, so they hold no privilege on it | Re-run `PROVISION_LEARNERS` for them |
| Agent or Analyst: `code 399502: The Cortex Search Service does not exist or access is not authorized` | Same wrong-owner cause, but for a Cortex Search Service. `check_roles.sql` cannot see it — `SHOW CORTEX SEARCH SERVICES` has no `owner` column | `./verify/check_build_ownership.sh <connection>` names it; re-run `PROVISION_LEARNERS` or `CALL SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP('<name>');`. Test the fix with `USE SECONDARY ROLES NONE;` or you are re-testing the admin role |
| Admin console: `Learners own their own work — could not run ADMIN.AUDIT_BUILD_OWNERSHIP` | Ownership is **UNVERIFIED, not clean** — the console could not run the audit | Re-run `assets/snowcup-data-setup.sql` (idempotent; it creates the audit procedures), then reload the card |
| Learner "not authorized" on shared data | Their `SNOWCUP_WS_<name>` role is not granted, or does not inherit `SNOWCUP_PARTICIPANT` | Re-run provisioning |
| Referee missing from the CoWork picker | A CoWork object exists and does not list the agent | Add the agent to it explicitly |
| `invalid identifier 'NICKNAME'` (learner) | Intended — nicknames live in `PLAYER_PROFILES` | Module 4 requires Cortex Search; the shortcut is closed on purpose |

## Contributing

There is no build step: `deploy.sh` reads `assets/` directly. Edit the files in place.

If you keep a copy installed as a Cortex Code skill, re-install it after any change, and
exclude build output:

```bash
rsync -a --exclude node_modules --exclude .next \
      ./ ~/.snowflake/cortex/skills/snowcup-deploy/
```

Skipping that step means the skill keeps running an older copy of the SQL than the one in
this repo — a silent failure mode, since both look identical from the outside. Confirm with:

```bash
md5 -q assets/snowcup-data-setup.sql \
       ~/.snowflake/cortex/skills/snowcup-deploy/assets/snowcup-data-setup.sql
```

Never commit `node_modules` — `npm install` in either app directory produces about 1 GB.
