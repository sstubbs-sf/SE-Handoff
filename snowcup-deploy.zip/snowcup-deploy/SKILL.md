---
name: snowcup-deploy
description: "Self-contained deployment package for the SnowCup Build-an-Agent Lab. Use this skill to stand up the entire training in a Snowflake account you have just been handed: readiness checks, shared data, grader and Referee agent, learner provisioning, the learner lab app and admin console, facilitator delegation, and the learner hand-off. All artifacts travel inside this skill, so nothing else needs to be downloaded. Triggers: deploy snowcup, install the snowcup training, stand up the workshop in this account, set up the lab from the package, snowcup deployment package, bootstrap a new account for snowcup, hand-off, roll out the training. For ongoing operations in an account where the workshop already exists (adding learners later, health checks, delegation, teardown) prefer the snowcup-admin skill."
---

# SnowCup Deployment Package

Single purpose: take a Snowflake account from nothing to a running SnowCup
Build-an-Agent Lab, then hand it off. Everything needed ships in `assets/`.

## This package contains the answer key — treat it as admin-only

`assets/snowcup-grader-setup.sql` seeds `CHALLENGE_KEY`, and
`assets/snowcup-facilitator-guide.html` prints the answers outright. That is
unavoidable for a deployment package, and it means:

- **Never** give this skill folder or anything in `assets/` to a learner.
- Learners receive only the **lab app URL**. There is no learner file any more.
- If asked to "send the materials", send the app URL only and say why.

## Prerequisites

| Requirement | Why |
|---|---|
| `ACCOUNTADMIN` | Creates databases, roles, warehouses, and account params |
| A paid account | Trial accounts cannot run Snowflake App Runtime (the admin console). The SQL training still works. |
| Shell (Desktop/CLI) | **Required.** The lab itself is now a deployed app, and `snow app deploy` builds a container image through the Snowflake CLI with no SQL equivalent. Snowsight alone cannot stand up the training. |

The SQL steps run in CoCo Snowsight, but the two app deploys need a shell, so a
full deployment has to finish from Desktop or the CLI. In Snowsight, `assets/`
must be reachable from the Workspace.

Trial accounts cannot run App Runtime at all, so the training cannot be
delivered on one -- there is no longer an HTML fallback.

Refer to bundled files as `<SKILL_DIRECTORY>/assets/<name>`. Resolve
`<SKILL_DIRECTORY>` once at the start and reuse it, because relative paths
resolve against the user's working directory rather than the skill.

## Fast path: deploy the whole thing with one command

From a shell in this package directory:

```bash
./deploy.sh --connection <your-connection> --yes --learners "jane@acme.com, JSMITH"
```

That runs every step below in order, stops at the first failed gate, and prints
the hand-off with the real lab URL. `--yes` authorizes the one account-wide
change it needs (App Runtime defaults). Drop `--learners` to provision later.

## Blast radius: what this touches outside its own objects

Tell the user this before running it on an account they do not own. Everything
created lives under `SNOWCUP_*` plus `SNOWFLAKE_APPS`, and nothing changes silently.

- **Re-running is safe and expected.** No `DROP DATABASE`, no `DROP SCHEMA`, no
  `TRUNCATE`, and no `CREATE OR REPLACE` on any database or schema — every one uses
  `IF NOT EXISTS`. Re-running never destroys work a learner has already built.
- **`CORTEX_ENABLED_CROSS_REGION`** is the only account-level setting that may
  change, and only when it is currently `DISABLED` (the Referee agent's model must
  be reachable). It is never narrowed, an explicit region list is left untouched,
  and when it does change the deploy prints an `ACCOUNT-LEVEL CHANGE` warning with
  the old value and the exact restore statement. Some accounts refuse to narrow it
  again afterwards (AI_SETTINGS guardrails), so flag this to the user if their
  organisation set it deliberately.
- **App Runtime defaults** are set only if unset, and only with `--yes`.
- **Learner `DEFAULT_ROLE` / `DEFAULT_WAREHOUSE`** are set only if the user has none
  (unset or `PUBLIC`). An existing default is reported and left alone, and the
  output then says to have that learner run `USE ROLE SNOWCUP_WS_<NAME>;`.
- **Nothing is deleted for the user.** Teardown statements ship commented out. The
  only destructive path is the admin console's Deprovision with "also drop their
  build schema", which additionally requires typing `REMOVE`.

It deliberately refuses to decide three things for you, because each has a
consequence you would not see until the workshop was underway:

| Situation | What it does | Why not automatic |
|---|---|---|
| Gen2 unavailable in the region | Stops | The data setup requires Gen2; silently dropping it changes the performance profile with nobody aware |
| A CoWork object already exists | Reports, does not touch it | Adding one flips the account to "only listed agents appear", hiding every agent your learners build |
| App Runtime defaults unset | Needs `--yes` | `ALTER ACCOUNT` affects everyone else's apps in the account |

Use `--skip-apps` for a SQL-only run (no Node needed), but the lab app **is** the
learner deliverable, so the training is not deliverable until it is deployed.

Prefer the step-by-step below when you are working in Snowsight, when a gate
fails and you need to see the SQL, or when you want to understand what changed.

## Deployment sequence

Run in order. Steps 1–7 are required; 8 is optional. Work sequentially and
stop at the first failure rather than continuing — a half-configured account is
harder to diagnose than a clean stop.

**Provision learners BEFORE verifying.** The role-model gates check per-learner
roles and build schemas, so on a fresh account with nobody provisioned there is
nothing to verify: the scope gate aborts because its probe role does not exist,
and the pairing and coverage gates fail by design rather than report a vacuous
pass. Verifying first makes a fresh deploy stop for no real reason.

```
1 Preflight ──→ 2 Data ──→ 3 Grader ──→ 4 Learners ──→ 5 VERIFY (gate) ──→ 6 CoWork
                                                              │
                                                              └─ FAIL → stop, invite nobody
                                                        7 Deploy apps (required, shell)
                                                        8 Facilitator delegation (optional)
```

### Step 1: Preflight

Probe **capabilities**, not version strings: `SYSTEM$GET_ACCOUNT_EDITION()` does
not exist, `SNOWFLAKE.ORGANIZATION_USAGE.ACCOUNTS` returns no rows in many
accounts, and region availability lists go stale. A warehouse created
`INITIALLY_SUSPENDED` never runs a query, so this costs nothing.

```sql
SELECT CURRENT_REGION() AS region, CURRENT_ACCOUNT_NAME() AS account,
       CURRENT_USER() AS whoami, CURRENT_ROLE() AS active_role;

EXECUTE IMMEDIATE $$
BEGIN
  LET gen2 VARCHAR := '';
  LET mc   VARCHAR := '';
  BEGIN
    CREATE OR REPLACE WAREHOUSE SNOWCUP_PROBE_WH
      WITH GENERATION = '2' WAREHOUSE_SIZE = 'XSMALL'
      INITIALLY_SUSPENDED = TRUE AUTO_SUSPEND = 60;
    gen2 := 'PASS  Gen2 supported in this region';
  EXCEPTION WHEN OTHER THEN
    gen2 := 'FAIL  Gen2 NOT available here - ' || SQLERRM;
  END;
  BEGIN
    CREATE OR REPLACE WAREHOUSE SNOWCUP_PROBE_WH
      WAREHOUSE_SIZE = 'XSMALL' INITIALLY_SUSPENDED = TRUE
      AUTO_SUSPEND = 60 MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2;
    mc := 'PASS  Multi-cluster supported (Enterprise or higher)';
  EXCEPTION WHEN OTHER THEN
    mc := 'WARN  Multi-cluster NOT supported (Standard edition)';
  END;
  BEGIN DROP WAREHOUSE IF EXISTS SNOWCUP_PROBE_WH; EXCEPTION WHEN OTHER THEN NULL; END;
  RETURN gen2 || ' || ' || mc;
END
$$;
```

| Result | What to do |
|---|---|
| Gen2 **FAIL** | `snowcup-data-setup.sql` sets `GENERATION = '2'` as a deliberate hard requirement and will fail. **Stop and tell the user.** Do not quietly strip the clause — that silently changes the workshop's performance profile. Their choices: deploy in another region, or consciously accept Gen1 by editing the script. |
| Multi-cluster **WARN** | Standard edition. `max_cluster_count` stays 1, capping concurrency near 8 queries. Fine for a small cohort; above roughly 50 concurrent learners raise `WAREHOUSE_SIZE`, split cohorts across warehouses, or run in waves. |

### Step 2: Shared data, roles, and the warehouse

```
<SKILL_DIRECTORY>/assets/snowcup-data-setup.sql
```

Creates `SNOWCUP_WH` (X-Small Gen2, 1–10 clusters, STANDARD scaling, 300s
statement timeout), enables Cortex cross-region inference, loads
`SNOWCUP_SHARED.TOURNAMENT` (48 players, 323 stat rows), creates
`SNOWCUP_PARTICIPANT` and `SNOWCUP_FACILITATOR`, creates `SNOWCUP_BUILDS`,
defines the `SNOWCUP_WORKSHOP.ADMIN` provisioning procedures, and provisions
whoever runs it.

It prints which multi-cluster path it took — surface that, since it confirms
whether concurrency headroom actually exists.

### Step 3: Grader and Referee agent

```
<SKILL_DIRECTORY>/assets/snowcup-grader-setup.sql
```

Creates the hidden answer key, the owner's-rights submission procedures, the
learner-readable score views, and the `SNOWCUP_REFEREE` agent. Confirm the
agent's orchestration model is `claude-sonnet-5`.

### Step 4: Provision learners

```sql
CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS('a@x.com, b@x.com, CJONES');
```

Idempotent, so re-running for someone is harmless. Report the schema and role
per person **from the procedure's output** rather than predicting them:
email-style names are sanitised (`jane.doe@acme.com` → `WS_JANE_DOE`), so a
guessed schema name sends the learner to a place that does not exist.

Provisioning also **repairs build-schema ownership** for that learner. If anything
in `WS_<NAME>` is owned by another role — a facilitator who built something while
helping, or a reference solution authored on `ACCOUNTADMIN` — it is handed back,
and the output names each object and its previous owner. This matters because the
learner otherwise holds no privilege on it and **gets no error**: the schema just
looks empty, or their agent reports its search service does not exist. Provisioning
cannot prevent it (the objects do not exist yet on a first run), so re-running
provisioning is the repair path.

### Step 5: Verification — this is a gate, not a formality

```
<SKILL_DIRECTORY>/assets/verify/verify_answers.sql
<SKILL_DIRECTORY>/assets/verify/check_roles.sql
<SKILL_DIRECTORY>/assets/verify/check_build_ownership.sh
<SKILL_DIRECTORY>/assets/verify/check_lab_progress.sql
<SKILL_DIRECTORY>/assets/verify/test_completion_gate.sql
```

Expect from `verify_answers.sql`: all 8 answers `MATCH` with `tied=1`, and both
nickname gates `PASS`. From `check_roles.sql`: all 6 role gates `PASS`. From
`check_build_ownership.sh`: `PASS` — every object in every build schema owned by
its learner's role, across all seven creatable kinds. From
`check_lab_progress.sql`: all 14 lab-progress and quiz gates `PASS` (step and quiz
registries seeded, no orphaned rows, learners unable to reach the raw tables, the
answer key or the writer procedures, and completion stamps that are honest in both
directions). From `test_completion_gate.sql`: all four phases `PASS`, proving a
*new* completion stamp requires checkpoints, challenge answers and quizzes
together.

`check_build_ownership.sh` is the authoritative ownership check. `check_roles.sql`
check 6 reads an `owner` column, which `SHOW CORTEX SEARCH SERVICES` and
`SHOW PROCEDURES` do not have — so a PASS there is not proof that every object is
correctly owned.

**Why this gate matters more here than anywhere else.** This package carries its
own copy of the data generator, so in principle a bundled generator could drift
from the grader's key. `verify_answers.sql` recomputes every answer from the
loaded data and compares it to `CHALLENGE_KEY`, so drift cannot pass silently —
it fails here. That makes the package self-proving, but only if you actually run
it. `tied=1` is the column that matters: it proves each question has exactly one
winner, so no learner can be marked wrong for a defensible answer.

If anything fails, **stop**. Do not provision learners or send invitations
against an unverified environment.

Optional, and only useful if someone edited the lab or the key: the authoring
checks in `assets/verify/` (`check_leaks.py`, `check_key.py`, `check_roster.py`,
`check_names.py`, `check_html.py`, or `run_all.sh` for all five). These guard
against a scored answer leaking into the learner file. They need a shell, so
they are unavailable in Snowsight — say they were skipped rather than implying
full verification.

### Step 6: CoWork visibility — read carefully, this one is a trap

```sql
SHOW SNOWFLAKE INTELLIGENCES;
```

- **No rows → do nothing.** Creating the object flips the account from "list
  every agent I can access" to "list only what was added", which would hide
  every agent the learners build. This is the common mistake.
- **A row exists** → the Referee must be added or it never appears in the picker:

```sql
ALTER SNOWFLAKE INTELLIGENCE SNOWFLAKE_INTELLIGENCE_OBJECT_DEFAULT
  ADD AGENT SNOWCUP_WORKSHOP.GRADING.SNOWCUP_REFEREE;
```

Then grant `USAGE` on that object to `SNOWCUP_PARTICIPANT`, plus `MODIFY` so
learners can add their own agents in Module 7.

Report which branch applied. The per-agent "Preview in Snowflake CoWork" link
works either way.

### Step 7: Deploy the apps — Desktop or CLI only

Two apps. `SNOWCUP_LAB_APP` is the **learner deliverable** and is required.
`SNOWCUP_ADMIN_APP` is the facilitator roster console and is optional, though it
is where lab progress is reported.

**Account setup first, or delegation breaks invisibly.** Until these defaults
exist, `snow app deploy` *succeeds* but lands in the personal database
`USER$<login>`, where an Application Service **cannot be granted to any role** —
so nobody but the deployer can ever open it.

```sql
SHOW PARAMETERS LIKE 'DEFAULT_SNOWFLAKE_APPS%' IN ACCOUNT;
```

If the destination database, schema, or query warehouse are empty:

```sql
CREATE DATABASE IF NOT EXISTS SNOWFLAKE_APPS;
CREATE WAREHOUSE IF NOT EXISTS SNOWFLAKE_APPS_QUERY_WH
  WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE;
ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_DATABASE = 'SNOWFLAKE_APPS';
ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_SCHEMA   = 'PUBLIC';
ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_QUERY_WAREHOUSE      = 'SNOWFLAKE_APPS_QUERY_WH';
```

`SNOWFLAKE_APPS` is shared account infrastructure that may host other apps —
create it if absent, never drop it.

Then deploy from the bundled source. The lab app first, since nobody can start
without it:

```bash
cd <SKILL_DIRECTORY>/assets/snowcup-lab-node
npm install && snow app deploy --role ACCOUNTADMIN     # the learner lab (required)

cd ../snowcup-admin-node
npm install && snow app deploy --role ACCOUNTADMIN     # roster console (optional)
```

Grant learners the lab app. All THREE object grants are required -- the database
and schema pair is the one that gets forgotten, and without it the app simply
will not open, which looks like a broken app rather than a missing grant:

```sql
GRANT USAGE ON DATABASE SNOWFLAKE_APPS        TO ROLE SNOWCUP_PARTICIPANT;
GRANT USAGE ON SCHEMA   SNOWFLAKE_APPS.PUBLIC TO ROLE SNOWCUP_PARTICIPANT;
GRANT USAGE ON APPLICATION SERVICE SNOWFLAKE_APPS.PUBLIC.SNOWCUP_LAB_APP
  TO ROLE SNOWCUP_PARTICIPANT;
GRANT USAGE ON WAREHOUSE SNOWFLAKE_APPS_QUERY_WH TO ROLE SNOWCUP_PARTICIPANT;
```

`--role ACCOUNTADMIN` is required: otherwise the deploy runs as the connection's
default role and service creation fails with *"Insufficient privileges to operate
on integration"* even though the remote build already succeeded. A cold build
takes 15–20 minutes; later deploys are cached and take about a minute. If a
deploy half-fails, retry one phase (`--upload-only` / `--build-only` /
`--deploy-only`) and drop a partial repository with
`DROP ARTIFACT REPOSITORY SNOWCUP_ADMIN_APP_REPO` (note the space — 
`ARTIFACT_REPOSITORY` is rejected).

Confirm: `SHOW APPLICATION SERVICES LIKE 'SNOWCUP_ADMIN_APP' IN SCHEMA
SNOWFLAKE_APPS.PUBLIC;` shows status `RUNNING`.

### Step 8 (optional): Facilitator delegation

Lets a co-facilitator run the roster without `ACCOUNTADMIN`. Requires Step 7.

The app authorises on roles a person **holds**, not their active role. So someone
who holds `ACCOUNTADMIN` is authorised via `ACCOUNTADMIN` and the facilitator
path never executes — a "successful" test of such a user proves nothing. Check
first:

```sql
SHOW GRANTS TO USER <PERSON>;   -- must NOT include ACCOUNTADMIN, direct or inherited
```

Then grant all of this. **The database and schema grants are the commonly missed
pair** — without them the app will not open at all, and it presents as a broken
app rather than a missing grant:

```sql
GRANT USAGE ON DATABASE SNOWFLAKE_APPS        TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON SCHEMA   SNOWFLAKE_APPS.PUBLIC TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE, MONITOR ON APPLICATION SERVICE
  SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP     TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON WAREHOUSE SNOWFLAKE_APPS_QUERY_WH TO ROLE SNOWCUP_FACILITATOR;
GRANT ROLE SNOWCUP_FACILITATOR TO USER <PERSON>;
```

Never grant the application service to `PUBLIC`. Provisioning runs with the app
*owner's* rights because restricted caller's rights forbids `GRANT`, so
application code is the security boundary and the grant list is what keeps it
honest.

Tell facilitators they do **not** need to switch roles, and that a banner naming
a held-but-inactive role is expected rather than an error.

## Hand-off

Produce this for the user once Steps 1–6 pass:

1. The Snowsight URL:
   `SELECT CURRENT_ORGANIZATION_NAME(), CURRENT_ACCOUNT_NAME();` →
   `https://app.snowflake.com/<org>/<account>/` (lower-case).
2. Per learner: their schema `SNOWCUP_BUILDS.WS_<NAME>` and role
   `SNOWCUP_WS_<NAME>`, copied from the provisioning output.
3. The lab app URL (`snow app open --print-only` in `assets/snowcup-lab-node`).
4. A reminder that the grader must be live before anyone reaches **Module 9**
   (the challenge). Modules 0–8 and 10 need only the shared data and their build
   schema, so learners can start while you finish the console.

Also tell them the workshop takes 3–4 hours, and that the Referee grades
submissions like `Q1: <answer>` for 120 points total.

## Stopping points

- Gen2 **FAIL** at preflight → stop; present the options; do not edit the script.
- Before any `ALTER ACCOUNT` → show the statements and confirm; account-wide.
- `SHOW SNOWFLAKE INTELLIGENCES` returns rows → confirm before altering a shared
  object other agents depend on.
- Any Step 5 gate fails → stop; do not invite anyone.
- Target user holds `ACCOUNTADMIN` in Step 8 → stop; delegation test is invalid.

## Output

Report: region and capability results, which steps ran, the multi-cluster path,
the CoWork branch, verification verdicts, per-learner schema and role, the app
URL if deployed, grants applied, and anything deferred because a shell was
unavailable.

## Adding a second training

The schema is keyed by training (`MODULE_ID`), so a learner gets **one row per
training** in `LAB_PROGRESS_BY_LEARNER` and in the admin console. Adding another
training does not disturb SnowCup's results.

A training is **complete** only when both halves are satisfied: every active
checkpoint ticked *and* every challenge question answered correctly. Points are
not the test, so partial credit cannot finish a training with a question still
wrong. Completion is stamped once in `LAB_ACTIVITY.COMPLETED_AT` and never
cleared, so adding a checkpoint later cannot un-complete a signed-off cohort.

To add one:

1. Register it, or its checkpoints are orphans and the deploy health check fails:
   ```sql
   INSERT INTO SNOWCUP_WORKSHOP.GRADING.MODULES (MODULE_ID, TITLE, SEQUENCE, IS_ACTIVE)
     VALUES ('COST_LAB', 'Cost & Governance Lab', 2, TRUE);
   ```
2. Seed its checkpoints into `LAB_STEPS` under the new `MODULE_ID`, and its
   questions into `CHALLENGE_KEY`. Both are keyed by training, so reusing a step
   key like `m0.checkpoint` is safe.
3. In that app's `content/index.mjs`, set `TRAINING = { id: "COST_LAB", ... }`.
   That single constant is what routes every progress write.
4. **Give it its own grader agent.** `SUBMIT_ANSWER` is hardcoded to `SNOWCUP`;
   a second training must call `SUBMIT_MODULE_ANSWER('COST_LAB', ...)`. Do not add
   a second procedure named `SUBMIT_ANSWER` — the agent tool identifier is
   unsigned and would become ambiguous.
5. Deploy that lab app and apply the same three grants (database, schema,
   application service) that the SnowCup lab app needs.

`GET_PROGRESS`, `LEADERBOARD`, `LEADERBOARD_BY_MODULE` and the admin console pick
the new training up automatically. To retire one without deleting history, set
`IS_ACTIVE = FALSE` on its `MODULES` row.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `invalid identifier 'MATCHES.STAGE'` (learner) | Semantic-view metric cannot reach across a relationship | Pre-compute cross-table flags in a SQL view first; Module 3 teaches this |
| `invalid identifier 'NICKNAME'` (learner) | Intended — nickname lives in `PLAYER_PROFILES`, not `PLAYERS` | Tier 4 requires Cortex Search; this proves the shortcut is closed |
| Agent: "tool … missing execution_environment in tool_resources" | Analyst and custom tools each need a warehouse | Set `execution_environment` to `{"type":"warehouse","warehouse":"SNOWCUP_WH"}` and redeploy the agent |
| Learner "not authorized" on shared data | Their `SNOWCUP_WS_<name>` role is not granted, or does not inherit `SNOWCUP_PARTICIPANT` | Re-run provisioning (idempotent) |
| Referee missing from the CoWork picker | A CoWork object exists and lacks the agent | Step 6, second branch |
| Role-model gates fail or abort on a fresh account | They were run before anyone was provisioned, so there is no per-learner role to check and the probe role does not exist | Provision first (Step 4), then re-run `check_roles.sql`. `deploy.sh` skips them automatically when no learner roles exist |
| Facilitator sees a broken or blank app | Missing `USAGE` on the app database or schema | Apply all four object grants in Step 8 |
| App can't be granted to any role | Deployed to a personal database | Step 7 account setup, then drop and redeploy |
| Deploy fails on the access integration | Ran as the connection's default role | `snow app deploy --role ACCOUNTADMIN` |
| Learners can see the answer key / everyone shares one score row | They are signing in as a user that holds `ACCOUNTADMIN`, or as a shared hands-on-lab user. With `DEFAULT_SECONDARY_ROLES = ALL`, `ACCOUNTADMIN` stays active even when their primary role is `SNOWCUP_WS_<name>`, so `SELECT * FROM CHALLENGE_KEY` succeeds and nothing looks wrong | Give each learner their own user with no `ACCOUNTADMIN`. `deploy.sh` prints a `CHALLENGE INTEGRITY` warning naming any learner who holds it. Grants are not the problem — the privilege arrives through the user's other roles, which is why no gate can catch it |
| Checkpoint ticks silently fail to save | The app's `TRAINING.id` and the `LAB_STEPS` seed disagree, so `SET_LAB_STEP` refuses the pair as an unknown step | `python3 verify/check_lab_steps.py` names both values. They must match a registered, active `MODULES` row |
| Admin console health card: `Learners own their own work — FAIL — could not run ADMIN.AUDIT_BUILD_OWNERSHIP` | The console could not run the ownership audit, so it reports **UNVERIFIED rather than clean** — this is the check refusing to lie, not a finding about ownership. Usually `AUDIT_BUILD_OWNERSHIP_JSON` is missing because `snowcup-data-setup.sql` predates it, or the app was deployed before that script was re-run | Re-run `snowcup-data-setup.sql` (idempotent — it creates both audit procedures), then reload the card. Confirm from a worksheet with `CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP_JSON(NULL);` — `[]` means everything is correctly owned. Note the console must use the `_JSON` form: the table-returning form needs `CALL` plus `RESULT_SCAN(LAST_QUERY_ID())`, which breaks over a connection pool because the two statements can land on different sessions |
| A learner who finished everything shows "in progress" | `COMPLETED_AT` was never stamped | Re-run `snowcup-grader-setup.sql`; the completion sweep at the end is idempotent and stamps anyone already qualifying |
| Everything times out — even `COUNT(*)` on an 11-row table — with `000630 (57014) … statement or warehouse timeout` | The warehouse is stuck in `RESUMING` with `started_clusters = 0`, so the query never got compute. Nothing is wrong with the SQL, and `SUSPEND`/`RESUME` does not clear it. This is the signature of a **regional Snowflake incident** affecting warehouse start/resume | **Check <https://status.snowflake.com> first** — it names this symptom directly and will save you an hour of misdiagnosis. Then `SHOW WAREHOUSES` and read `state` + `started_clusters`; several stuck at once confirms it is region-wide. There is usually no client-side workaround. Already-running warehouses often keep working, so wait it out or use a warehouse that is already `STARTED`. **Check `SNOWFLAKE_APPS_QUERY_WH` too** — if that is stuck, both apps show `RUNNING` but serve no data, which looks like a broken deploy. The same incident also degrades login, surfacing as `Unable to receive the OAuth message within a given timeout`, which looks like an expired token |
| Learner's schema looks empty, or an agent reports `code 399502: The Cortex Search Service does not exist or access is not authorized for the current role` | An object in `WS_<NAME>` was created by another role — usually a facilitator on `ACCOUNTADMIN`, or whoever authored the reference solution. The learner holds no privilege on it and **nothing errors**. It also stays hidden while `DEFAULT_SECONDARY_ROLES = ALL` keeps `ACCOUNTADMIN` active in the tester's session, because the object resolves through the admin role; it surfaces the moment secondary roles are disabled, or for any learner who never held `ACCOUNTADMIN` — which is every real learner | **Repair it:** admin console → Environment health → **Repair ownership**, or `CALL SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP('name');` (omit the name for all learners). Re-running provisioning repairs it too. **Detect it:** `./verify/check_build_ownership.sh <connection>`, which `deploy.sh` runs after the role gates and which covers all seven creatable kinds. Note `check_roles.sql` check 6 reads an `owner` column and therefore **cannot** see search services, procedures or functions — a PASS there is not proof. Verify any fix with `USE SECONDARY ROLES NONE;` or you are re-testing the admin role. Never add `COPY CURRENT GRANTS` to a manual fix |
