import { querySnowflake } from "@/lib/snowflake"
import { TRAINING } from "@/content/index.mjs"

/**
 * Learner identity for the SnowCup Lab app.
 *
 * WHY THIS FILE IS THE SECURITY BOUNDARY
 * Progress is stored per learner, so everything depends on answering "who is
 * this?" correctly. Two constraints shape the design:
 *
 * 1. Snowflake's restricted caller's rights FORBIDS `CALL`, so the app cannot
 *    invoke SET_LAB_STEP as the learner.
 * 2. Under owner's rights, CURRENT_USER() inside the procedure would return the
 *    service owner, so every learner's progress would collide on one row.
 *
 * So the app resolves the learner with a caller's-rights SELECT -- their real
 * Snowflake session, not a request header or a request body -- and passes that
 * identity to the owner's-rights procedure.
 *
 * THE RULE THAT KEEPS THIS SAFE: no route may accept a participant from the
 * client. Every write uses the value returned by identifyLearner(). The
 * procedures are deliberately NOT granted to SNOWCUP_PARTICIPANT, so even a
 * learner with a worksheet cannot call them with somebody else's name.
 */

export interface Learner {
  /** The Snowflake login name, upper-cased to match how it is stored. */
  user: string
  /** Active role, shown in the UI purely so an odd session is diagnosable. */
  activeRole: string
}

/**
 * Resolve the signed-in learner. Only touches session functions -- no tables --
 * so it needs no caller grants on any database object.
 */
export async function identifyLearner(): Promise<Learner> {
  const rows = await querySnowflake(
    `SELECT CURRENT_USER() AS USER_NAME, CURRENT_ROLE() AS ROLE_NAME`,
    { callersRights: true },
  )
  const r = rows[0] ?? {}
  const user = String(r.USER_NAME ?? "").trim()
  if (!user) {
    // Failing closed matters: a blank identity would either write to a bogus
    // participant row or, worse, collide learners together.
    throw new NoIdentity()
  }
  return { user: user.toUpperCase(), activeRole: String(r.ROLE_NAME ?? "unknown") }
}

/**
 * Malformed input from the client. Distinct from NoIdentity and from a genuine
 * server fault, so a bad step key returns 400 rather than 500 -- a 500 would
 * imply the app broke when in fact it correctly refused bad input, which sends
 * whoever is debugging down the wrong path.
 */
export class BadRequest extends Error {
  constructor(message: string) {
    super(message)
    this.name = "BadRequest"
  }
}

export class NoIdentity extends Error {
  constructor() {
    super(
      "Could not determine who you are signed in as, so your progress cannot be " +
        "saved. Reload the page; if it persists, sign out of Snowflake and back in.",
    )
    this.name = "NoIdentity"
  }
}

/** Map an error to a response. 401 for identity, 500 otherwise. */
export function errorResponse(e: unknown, context: string) {
  if (e instanceof NoIdentity) {
    return Response.json({ error: e.message }, { status: 401 })
  }
  if (e instanceof BadRequest) {
    return Response.json({ error: e.message }, { status: 400 })
  }
  console.error(new Date().toISOString(), `[${context}] failed`, e)
  return Response.json(
    { error: e instanceof Error ? e.message : `Failed: ${context}` },
    { status: 500 },
  )
}

/** Fully-qualified grading schema. */
export const GRADING = "SNOWCUP_WORKSHOP.GRADING"

/**
 * The training this app writes progress for.
 *
 * Taken from the content model, NEVER from a request. It is the key that
 * separates one training's results from another's, so accepting it from a client
 * would let a learner write into a training they are not enrolled in -- the same
 * class of problem as accepting a participant name.
 */
export const MODULE_ID: string = TRAINING.id
export const MODULE_TITLE: string = TRAINING.title

/**
 * Step keys are an allowlist in LAB_STEPS and the procedure re-checks them
 * against the training, so this only rejects obviously malformed input before it
 * reaches SQL.
 *
 * Deliberately NOT anchored to "m<number>": that was SnowCup's section naming,
 * and a future training numbering its sections differently would have had every
 * checkpoint rejected as malformed with nothing to explain why. The real
 * authority is the LAB_STEPS pair check, not this shape test.
 */
const STEP_KEY = /^[a-z0-9][a-z0-9-]{0,15}\.[a-z0-9-]{1,40}$/

export function assertStepKey(key: unknown): string {
  const s = String(key ?? "").trim()
  if (!STEP_KEY.test(s)) {
    throw new BadRequest(
      `Rejected step key ${JSON.stringify(s)}: expected something like "m3.checkpoint".`,
    )
  }
  return s
}

/** Single-quote escaping for values we build into SQL literals. */
export function sqlLiteral(value: string): string {
  return `'${value.replace(/'/g, "''")}'`
}

/**
 * Quiz references are an allowlist in QUIZ_KEY and the procedure re-checks them
 * against the training, so this only rejects obviously malformed input before it
 * reaches SQL. Same reasoning as assertStepKey.
 */
const QUIZ_REF = /^m\d{1,2}\.q\d{1,2}$/

export function assertQuizRef(ref: unknown): string {
  const s = String(ref ?? "").trim()
  if (!QUIZ_REF.test(s)) {
    throw new BadRequest(
      `Rejected quiz reference ${JSON.stringify(s)}: expected something like "m3.q1".`,
    )
  }
  return s
}

/**
 * The chosen option index. Bounded here as well as graded server-side, so a
 * nonsense value is a 400 rather than a silently wrong answer.
 */
export function assertChoice(choice: unknown, optionCount = 3): number {
  const n = Number(choice)
  if (!Number.isInteger(n) || n < 0 || n >= optionCount) {
    throw new BadRequest(
      `Rejected choice ${JSON.stringify(choice)}: expected an integer 0-${optionCount - 1}.`,
    )
  }
  return n
}
