import { querySnowflake } from "@/lib/snowflake"
import { TRAINING } from "@/content/index.mjs"

/**
 * Learner identity for the SnowCup Lab app.
 *
 * WHY THIS FILE IS THE SECURITY BOUNDARY
 * Progress is stored per learner, so everything depends on answering "who is
 * this?" correctly. Two constraints shape the design:
 *
 * 1. SET_LAB_STEP is never granted to SNOWCUP_PARTICIPANT: it takes the
 *    participant as an argument and does not check CURRENT_USER(), so a learner
 *    who could call it directly could write to another learner's progress. (Note
 *    restricted caller's rights does NOT forbid CALL -- it forbids USE ROLE,
 *    GRANT/REVOKE, session operations and CREATE of rights-bearing objects. See
 *    app.yml. That is why MY_LAB_DEFAULTS_* can be called on the caller path.)
 * 2. Under owner's rights, CURRENT_USER() inside the procedure would return the
 *    service owner, so every learner's progress would collide on one row.
 *
 * So the app resolves the learner with a caller's-rights SELECT -- their real
 * Snowflake session, not a request header or a request body -- and passes that
 * identity to the owner's-rights procedure.
 *
 * THE RULE THAT KEEPS THIS SAFE: no route may accept a participant from the
 * client. Every write uses the value returned by identifyLearner(). The
 * procedures are deliberately NOT granted to SNOWCUP_PARTICIPANT, so even a
 * learner with a worksheet cannot call them with somebody else's name.
 */

export interface Learner {
  /** The Snowflake login name, upper-cased to match how it is stored. */
  user: string
  /** Active role, shown in the UI purely so an odd session is diagnosable. */
  activeRole: string
  /**
   * The learner's own workshop role, or null when it could not be confirmed.
   * Null is a meaningful answer -- see resolveBuildSpace.
   */
  buildRole: string | null
  /** Fully qualified build schema, e.g. SNOWCUP_BUILDS.WS_JDOE, or null. */
  buildSchema: string | null
  /**
   * WHY a null buildRole/buildSchema, because the two causes need opposite
   * advice and the panel cannot tell them apart from null alone.
   *
   * "not-workshop-role" is not a fault at all for an admin or facilitator, and
   * for them "Set my defaults" is a dead end: APPLY_LAB_DEFAULTS deliberately
   * skips anyone holding ACCOUNTADMIN or SNOWCUP_FACILITATOR, so the button that
   * the alert points at returns "defaults left unchanged" and the warning never
   * clears. Telling them to sign out and back in sends them round that loop.
   */
  buildSpaceStatus: BuildSpaceStatus
  /** Expected-vs-actual for every session default the lab depends on. */
  defaults: SessionDefault[]
  /** True only when every default matches. */
  defaultsOk: boolean
}

/**
 * Why the build space could not be resolved. "ok" means it was.
 *
 * - not-workshop-role: the session is not on a SNOWCUP_WS_ role at all, so there
 *   is nothing to look up. Expected for an admin or facilitator.
 * - schema-unconfirmed: the session IS on a workshop role, but the schema could
 *   not be confirmed under caller's rights -- absent, or not reachable. That one
 *   is a real provisioning problem.
 */
export type BuildSpaceStatus = "ok" | "not-workshop-role" | "schema-unconfirmed"

interface BuildSpace {
  buildRole: string | null
  buildSchema: string | null
  buildSpaceStatus: BuildSpaceStatus
}

/** Everything a learner builds lives in one database. */
const BUILDS_DB = "SNOWCUP_BUILDS"
const ROLE_PREFIX = "SNOWCUP_WS_"
const SCHEMA_PREFIX = "WS_"

/**
 * Work out which build space belongs to this learner, so the lab can print
 * their real schema and role instead of a `WS_<yourname>` placeholder.
 *
 * WHY THE ACTIVE ROLE IS THE ANCHOR
 * Provisioning sets DEFAULT_ROLE to the learner's own SNOWCUP_WS_<NAME> role,
 * and Cortex Code and this app both open their session on that default. So the
 * caller's-rights CURRENT_ROLE() *is* their workshop role, with no lookup and
 * no guessing.
 *
 * WHY NOT DERIVE THE NAME FROM THE USERNAME
 * PROVISION_LEARNER derives the suffix by collapsing non-alphanumerics, and that
 * sanitiser already exists in three places. A fourth copy here would drift, and
 * the failure mode would be worse than a placeholder: a confidently WRONG schema
 * name pasted into a learner's prompt, creating objects in someone else's space
 * or nowhere at all. Reading the session is authoritative; deriving is a guess.
 *
 * WHY THE SECOND CHECK
 * Holding the role does not prove the schema is there -- provisioning can create
 * a role and then fail, and a facilitator's session has every WS_ role available.
 * INFORMATION_SCHEMA is privilege-filtered, so asking for the schema under
 * CALLER's rights confirms both that it exists AND that this learner can reach
 * it. That is exactly the claim the lab makes when it prints the name.
 *
 * FAILING TO NULL IS THE POINT. An unprovisioned learner, or one whose defaults
 * never applied, keeps the loud placeholder and gets told to see their
 * facilitator -- rather than being handed a plausible name that quietly does
 * nothing.
 */
async function resolveBuildSpace(activeRole: string): Promise<BuildSpace> {
  const role = activeRole.trim().toUpperCase()
  if (!role.startsWith(ROLE_PREFIX) || role.length <= ROLE_PREFIX.length) {
    // Not running as a workshop role: an admin, a facilitator who switched, or
    // a learner whose defaults were never applied. Nothing safe to print -- but
    // which of those it is decides the advice, so say so rather than just null.
    return { buildRole: null, buildSchema: null, buildSpaceStatus: "not-workshop-role" }
  }

  const none: BuildSpace = {
    buildRole: null,
    buildSchema: null,
    buildSpaceStatus: "schema-unconfirmed",
  }

  const schemaName = SCHEMA_PREFIX + role.slice(ROLE_PREFIX.length)

  try {
    const rows = await querySnowflake(
      `SELECT COUNT(*) AS N FROM ${BUILDS_DB}.INFORMATION_SCHEMA.SCHEMATA
        WHERE SCHEMA_NAME = ${sqlLiteral(schemaName)}`,
      { callersRights: true },
    )
    if (Number(rows[0]?.N ?? 0) < 1) return none
  } catch (e) {
    // A lookup failure is not proof of absence, but it is not proof of presence
    // either, and the placeholder is the safe render.
    console.warn(
      new Date().toISOString(),
      `[session] could not confirm ${BUILDS_DB}.${schemaName}`,
      e instanceof Error ? e.message : e,
    )
    return none
  }

  return { buildRole: role, buildSchema: `${BUILDS_DB}.${schemaName}`, buildSpaceStatus: "ok" }
}

/** Shared for every learner: not per-person, but still worth showing them. */
const LAB_WAREHOUSE = "SNOWCUP_WH"

export interface SessionDefault {
  label: string
  /** What this lab needs it to be. Null when we could not work it out. */
  expected: string | null
  /** What the learner's session actually has right now. */
  actual: string | null
  ok: boolean
}

/**
 * Resolve the signed-in learner. Only touches session functions -- no tables --
 * so it needs no caller grants on any database object.
 */
export async function identifyLearner(): Promise<Learner> {
  const rows = await querySnowflake(
    `SELECT CURRENT_USER() AS USER_NAME, CURRENT_ROLE() AS ROLE_NAME,
            CURRENT_WAREHOUSE() AS WH, CURRENT_DATABASE() AS DB,
            CURRENT_SCHEMA() AS SCH`,
    { callersRights: true },
  )
  const r = rows[0] ?? {}
  const user = String(r.USER_NAME ?? "").trim()
  if (!user) {
    // Failing closed matters: a blank identity would either write to a bogus
    // participant row or, worse, collide learners together.
    throw new NoIdentity()
  }
  const activeRole = String(r.ROLE_NAME ?? "unknown")
  const build = await resolveBuildSpace(activeRole)

  const norm = (v: unknown) => {
    const s = String(v ?? "").trim()
    return s === "" ? null : s
  }
  const actualSchema = norm(r.SCH)
  const actualDb = norm(r.DB)
  const expectedSchema = build.buildSchema ? build.buildSchema.split(".")[1] : null
  const expectedDb = build.buildSchema ? build.buildSchema.split(".")[0] : null

  const defaults: SessionDefault[] = [
    mk("Role", build.buildRole, norm(r.ROLE_NAME)),
    mk("Warehouse", LAB_WAREHOUSE, norm(r.WH)),
    mk("Database", expectedDb, actualDb),
    mk("Schema", expectedSchema, actualSchema),
  ]

  return {
    user: user.toUpperCase(),
    activeRole,
    ...build,
    defaults,
    defaultsOk: defaults.every((d) => d.ok),
  }
}

/**
 * One row of the defaults panel. Unknown expected means we cannot judge it, so it
 * is reported as not-ok rather than quietly passing -- the whole point of this
 * panel is that a wrong session is visible before the learner starts Module 1.
 */
function mk(label: string, expected: string | null, actual: string | null): SessionDefault {
  const ok =
    expected !== null && actual !== null && expected.toUpperCase() === actual.toUpperCase()
  return { label, expected, actual, ok }
}

/**
 * Malformed input from the client. Distinct from NoIdentity and from a genuine
 * server fault, so a bad step key returns 400 rather than 500 -- a 500 would
 * imply the app broke when in fact it correctly refused bad input, which sends
 * whoever is debugging down the wrong path.
 */
export class BadRequest extends Error {
  constructor(message: string) {
    super(message)
    this.name = "BadRequest"
  }
}

export class NoIdentity extends Error {
  constructor() {
    super(
      "Could not determine who you are signed in as, so your progress cannot be " +
        "saved. Reload the page; if it persists, sign out of Snowflake and back in.",
    )
    this.name = "NoIdentity"
  }
}

/** Map an error to a response. 401 for identity, 500 otherwise. */
export function errorResponse(e: unknown, context: string) {
  if (e instanceof NoIdentity) {
    return Response.json({ error: e.message }, { status: 401 })
  }
  if (e instanceof BadRequest) {
    return Response.json({ error: e.message }, { status: 400 })
  }
  console.error(new Date().toISOString(), `[${context}] failed`, e)
  return Response.json(
    { error: e instanceof Error ? e.message : `Failed: ${context}` },
    { status: 500 },
  )
}

/** Fully-qualified grading schema. */
export const GRADING = "SNOWCUP_WORKSHOP.GRADING"

/**
 * The training this app writes progress for.
 *
 * Taken from the content model, NEVER from a request. It is the key that
 * separates one training's results from another's, so accepting it from a client
 * would let a learner write into a training they are not enrolled in -- the same
 * class of problem as accepting a participant name.
 */
export const MODULE_ID: string = TRAINING.id
export const MODULE_TITLE: string = TRAINING.title

/**
 * Step keys are an allowlist in LAB_STEPS and the procedure re-checks them
 * against the training, so this only rejects obviously malformed input before it
 * reaches SQL.
 *
 * Deliberately NOT anchored to "m<number>": that was SnowCup's section naming,
 * and a future training numbering its sections differently would have had every
 * checkpoint rejected as malformed with nothing to explain why. The real
 * authority is the LAB_STEPS pair check, not this shape test.
 */
const STEP_KEY = /^[a-z0-9][a-z0-9-]{0,15}\.[a-z0-9-]{1,40}$/

export function assertStepKey(key: unknown): string {
  const s = String(key ?? "").trim()
  if (!STEP_KEY.test(s)) {
    throw new BadRequest(
      `Rejected step key ${JSON.stringify(s)}: expected something like "m3.checkpoint".`,
    )
  }
  return s
}

/** Single-quote escaping for values we build into SQL literals. */
export function sqlLiteral(value: string): string {
  return `'${value.replace(/'/g, "''")}'`
}

/**
 * Quiz references are an allowlist in QUIZ_KEY and the procedure re-checks them
 * against the training, so this only rejects obviously malformed input before it
 * reaches SQL. Same reasoning as assertStepKey.
 */
const QUIZ_REF = /^m\d{1,2}\.q\d{1,2}$/

export function assertQuizRef(ref: unknown): string {
  const s = String(ref ?? "").trim()
  if (!QUIZ_REF.test(s)) {
    throw new BadRequest(
      `Rejected quiz reference ${JSON.stringify(s)}: expected something like "m3.q1".`,
    )
  }
  return s
}

/**
 * The chosen option index. Bounded here as well as graded server-side, so a
 * nonsense value is a 400 rather than a silently wrong answer.
 */
export function assertChoice(choice: unknown, optionCount = 3): number {
  const n = Number(choice)
  if (!Number.isInteger(n) || n < 0 || n >= optionCount) {
    throw new BadRequest(
      `Rejected choice ${JSON.stringify(choice)}: expected an integer 0-${optionCount - 1}.`,
    )
  }
  return n
}
