import { MODULES } from "@/content/index.mjs"
import { extractText } from "@/content/validate.mjs"
import type { Module } from "@/content/types"

/**
 * The lab's navigable outline: modules, and the headings inside them.
 *
 * WHY THIS LIVES IN lib/ AND NOT IN content/
 * `stepsOf()` in content/validate.mjs is compared field-for-field against the
 * LAB_STEPS seed by verify/check_lab_steps.py, and content/index.mjs feeds the
 * leak scanner through scripts/dump-content.mjs. Deriving navigation here keeps
 * the content model untouched, so this stays a pure UI concern and both of those
 * guarantees continue to mean what they claim.
 *
 * Nothing here is persisted. Checkpoint state is server-backed in LAB_PROGRESS;
 * this module only describes structure.
 */

export interface OutlineStep {
  /** Anchor id, e.g. "m6-s3". */
  id: string
  /** Plain text for the nav label — inline markup stripped. */
  title: string
  /** Index into module.blocks, so the renderer can id the right heading. */
  blockIndex: number
}

export interface OutlineModule {
  id: string
  seq: number
  phase: string
  /** Inline markup preserved; the section heading renders it richly. */
  title: string
  /** Plain text, for the nav and for aria labels. */
  plainTitle: string
  /**
   * The module's checkpoint key, e.g. "m6.checkpoint", or null if it has none.
   * Read from the checkpoint block rather than composed from the module id: the
   * key is the contract with LAB_PROGRESS and must never be derived from
   * position or naming convention.
   */
  checkpointKey: string | null
  steps: OutlineStep[]
  /** blockIndex -> step id, for putting anchors on heading blocks. */
  stepIdByBlock: Map<number, string>
}

/**
 * Step ids are `<moduleId>-s<n>`, numbered by the heading's ordinal within its
 * module — the same scheme the retired HTML used, so any links written against
 * the old lab still resolve.
 *
 * These ARE positional, which is safe precisely because nothing persists them:
 * inserting a heading renumbers later anchors, and the only cost is a stale
 * bookmark. Checkpoint keys, which do persist, are never derived this way.
 */
function stepsOfModule(mod: Module): {
  steps: OutlineStep[]
  stepIdByBlock: Map<number, string>
} {
  const steps: OutlineStep[] = []
  const stepIdByBlock = new Map<number, string>()
  let n = 0
  mod.blocks.forEach((block, blockIndex) => {
    if (block.kind !== "heading") return
    n += 1
    const id = `${mod.id}-s${n}`
    steps.push({ id, title: extractText(block.text), blockIndex })
    stepIdByBlock.set(blockIndex, id)
  })
  return { steps, stepIdByBlock }
}

export const OUTLINE: OutlineModule[] = (MODULES as Module[]).map((mod) => {
  const { steps, stepIdByBlock } = stepsOfModule(mod)
  const checkpoint = mod.blocks.find((b) => b.kind === "checkpoint")
  return {
    id: mod.id,
    seq: mod.seq,
    phase: mod.phase,
    title: mod.title,
    plainTitle: extractText(mod.title),
    checkpointKey:
      checkpoint && checkpoint.kind === "checkpoint" ? checkpoint.key : null,
    steps,
    stepIdByBlock,
  }
})

/** Every anchor the outline can target, for validating a location hash. */
export const ANCHOR_IDS: ReadonlySet<string> = new Set(
  OUTLINE.flatMap((m) => [m.id, ...m.steps.map((s) => s.id)]),
)

/** Lookup by module id, so the renderer can pair a Module with its outline. */
export const OUTLINE_BY_ID: ReadonlyMap<string, OutlineModule> = new Map(
  OUTLINE.map((m) => [m.id, m]),
)

/** Which module owns an anchor, so a deep link can expand it before scrolling. */
export function moduleIdForAnchor(anchor: string): string | null {
  for (const m of OUTLINE) {
    if (m.id === anchor) return m.id
    if (m.steps.some((s) => s.id === anchor)) return m.id
  }
  return null
}

/**
 * Where a returning learner should land: the first module whose checkpoint is
 * not yet ticked. Falls back to the first module, so a learner who has finished
 * everything still opens on something rather than a fully collapsed page.
 */
export function firstIncompleteModuleId(doneKeys: ReadonlySet<string>): string {
  const next = OUTLINE.find(
    (m) => !m.checkpointKey || !doneKeys.has(m.checkpointKey),
  )
  return (next ?? OUTLINE[0]).id
}
