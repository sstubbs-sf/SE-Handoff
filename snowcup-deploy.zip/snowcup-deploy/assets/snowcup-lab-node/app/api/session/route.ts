import { querySnowflake } from "@/lib/snowflake"
import {
  errorResponse,
  identifyLearner,
  sqlLiteral,
  GRADING,
  MODULE_ID,
  MODULE_TITLE,
} from "@/lib/lab-session"

export const dynamic = "force-dynamic"

/**
 * Who is reading the lab, and record that they were here.
 *
 * The activity touch runs with owner's rights and is passed the caller's-rights
 * identity. It is best-effort: a facilitator wanting to know who has started is
 * useful, but not worth failing the page load over, so a failure here is logged
 * and swallowed rather than blocking the lab.
 */
export async function GET() {
  try {
    const learner = await identifyLearner()

    try {
      await querySnowflake(
        `CALL ${GRADING}.TOUCH_LAB_VISIT(${sqlLiteral(learner.user)}, ${sqlLiteral(MODULE_ID)})`,
      )
    } catch (e) {
      console.warn(
        new Date().toISOString(),
        `[session] activity touch failed for ${learner.user}`,
        e instanceof Error ? e.message : e,
      )
    }

    return Response.json({
      user: learner.user,
      activeRole: learner.activeRole,
      training: { id: MODULE_ID, title: MODULE_TITLE },
    })
  } catch (e) {
    return errorResponse(e, "session")
  }
}
