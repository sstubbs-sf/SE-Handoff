import { querySnowflake } from "@/lib/snowflake"
import {
  errorResponse,
  identifyLearner,
  sqlLiteral,
  GRADING,
  MODULE_ID,
} from "@/lib/lab-session"

export const dynamic = "force-dynamic"

/**
 * This learner's challenge score, so the lab can show module progress and scored
 * progress side by side.
 *
 * Reads CHALLENGE_PROGRESS with owner's rights filtered to the resolved learner,
 * for the same reason as the progress route: no caller grants required. The
 * answer key itself is never read here -- only points already awarded to this
 * person, so there is nothing to leak.
 */
export async function GET() {
  try {
    const learner = await identifyLearner()
    const me = sqlLiteral(learner.user)
    const training = sqlLiteral(MODULE_ID)
    const rows = await querySnowflake(
      `SELECT COUNT(*)                          AS ATTEMPTED,
              COUNT_IF(BEST_CORRECT)            AS CORRECT,
              COALESCE(SUM(POINTS_AWARDED), 0)  AS POINTS,
              MAX(LAST_SUBMITTED_AT)            AS LAST_SUBMITTED_AT
         FROM ${GRADING}.CHALLENGE_PROGRESS
        WHERE PARTICIPANT = ${me} AND MODULE_ID = ${training}`,
    )
    const r = rows[0] ?? {}

    // Total available comes from the key's point values, not a hardcoded 120, so
    // adding or reweighting a question does not silently make this wrong. Scoped
    // to this training, or a second training's questions would inflate the target
    // a learner is measured against.
    const totals = await querySnowflake(
      `SELECT COUNT(*) AS QUESTIONS, COALESCE(SUM(POINTS), 0) AS MAX_POINTS
         FROM ${GRADING}.CHALLENGE_KEY
        WHERE MODULE_ID = ${training}`,
    )
    const t = totals[0] ?? {}

    // Completion spans both halves, so it is read from the stamp rather than
    // inferred from points here.
    const done = await querySnowflake(
      `SELECT COMPLETED_AT FROM ${GRADING}.LAB_ACTIVITY
        WHERE PARTICIPANT = ${me} AND MODULE_ID = ${training}`,
    )

    return Response.json({
      attempted: Number(r.ATTEMPTED ?? 0),
      correct: Number(r.CORRECT ?? 0),
      points: Number(r.POINTS ?? 0),
      lastSubmittedAt: r.LAST_SUBMITTED_AT ?? null,
      questions: Number(t.QUESTIONS ?? 0),
      maxPoints: Number(t.MAX_POINTS ?? 0),
      completedAt: done[0]?.COMPLETED_AT ?? null,
    })
  } catch (e) {
    return errorResponse(e, "score")
  }
}
