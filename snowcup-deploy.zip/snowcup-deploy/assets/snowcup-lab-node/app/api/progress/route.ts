import { querySnowflake } from "@/lib/snowflake"
import {
  assertStepKey,
  errorResponse,
  identifyLearner,
  sqlLiteral,
  GRADING,
  MODULE_ID,
} from "@/lib/lab-session"

export const dynamic = "force-dynamic"

/**
 * Read this learner's checkpoint progress.
 *
 * Reads with OWNER's rights and filters on the caller's-rights identity, rather
 * than reading MY_LAB_PROGRESS under caller's rights. Both are correct; this way
 * needs no caller grants on the workshop database, which is one less thing to
 * get wrong when the workshop is deployed into a fresh account.
 */
export async function GET() {
  try {
    const learner = await identifyLearner()
    const me = sqlLiteral(learner.user)
    const training = sqlLiteral(MODULE_ID)
    const rows = await querySnowflake(
      `SELECT s.STEP_KEY, s.SECTION_ID, s.SECTION_SEQ, s.SECTION_TITLE, s.PHASE,
              COALESCE(p.DONE, FALSE) AS DONE, p.FIRST_DONE_AT, p.UPDATED_AT
         FROM ${GRADING}.LAB_STEPS s
         LEFT JOIN ${GRADING}.LAB_PROGRESS p
                ON p.MODULE_ID   = s.MODULE_ID
               AND p.STEP_KEY    = s.STEP_KEY
               AND p.PARTICIPANT = ${me}
        WHERE s.IS_ACTIVE AND s.MODULE_ID = ${training}
        ORDER BY s.SECTION_SEQ`,
    )
    return Response.json({
      user: learner.user,
      training: MODULE_ID,
      steps: rows.map((r) => ({
        stepKey: String(r.STEP_KEY),
        sectionId: String(r.SECTION_ID),
        sectionSeq: Number(r.SECTION_SEQ),
        done: r.DONE === true || String(r.DONE).toLowerCase() === "true",
        firstDoneAt: r.FIRST_DONE_AT ?? null,
        updatedAt: r.UPDATED_AT ?? null,
      })),
    })
  } catch (e) {
    return errorResponse(e, "progress-read")
  }
}

/**
 * Tick or untick one checkpoint.
 *
 * The body carries the step key and the desired state and NOTHING ELSE. Both the
 * participant and the training are resolved server-side, so a learner cannot
 * write to another learner's progress -- or into another training -- by editing a
 * request. The step key is shape-checked here and re-checked against the
 * LAB_STEPS allowlist inside the procedure, as a pair with the training.
 */
export async function POST(request: Request) {
  try {
    const learner = await identifyLearner()
    const body = await request.json().catch(() => ({}))
    const stepKey = assertStepKey(body?.stepKey)
    const done = body?.done === true

    const rows = await querySnowflake(
      `CALL ${GRADING}.SET_LAB_STEP(${sqlLiteral(learner.user)}, ${sqlLiteral(MODULE_ID)}, ` +
        `${sqlLiteral(stepKey)}, ${done})`,
    )
    const result = String(Object.values(rows[0] ?? {})[0] ?? "")

    // The procedure reports refusals rather than throwing, so surface them as a
    // client error instead of pretending the write succeeded.
    if (result.startsWith("rejected")) {
      return Response.json({ error: result, stepKey, done }, { status: 400 })
    }

    console.log(
      new Date().toISOString(),
      `[progress] ${learner.user} ${done ? "done" : "cleared"} ${stepKey}`,
    )
    return Response.json({ ok: true, stepKey, done, result })
  } catch (e) {
    return errorResponse(e, "progress-write")
  }
}
