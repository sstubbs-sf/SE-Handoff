import { querySnowflake } from "@/lib/snowflake"
import {
  assertStepKey,
  errorResponse,
  identifyLearner,
  sqlLiteral,
  GRADING,
  MODULE_ID,
} from "@/lib/lab-session"

export const dynamic = "force-dynamic"

/**
 * Read this learner's checkpoint progress.
 *
 * Reads MY_LAB_PROGRESS under CALLER's rights. The view already does the
 * LAB_STEPS/LAB_PROGRESS join and pins the rows to CURRENT_USER(), and it is the
 * only progress object granted to SNOWCUP_PARTICIPANT -- the LAB_PROGRESS base
 * table is granted to ACCOUNTADMIN alone, so joining it directly fails for every
 * learner identity.
 */
export async function GET() {
  try {
    const learner = await identifyLearner()
    const training = sqlLiteral(MODULE_ID)
    const rows = await querySnowflake(
      `SELECT STEP_KEY, SECTION_ID, SECTION_SEQ, SECTION_TITLE, PHASE,
              DONE, FIRST_DONE_AT, UPDATED_AT
         FROM ${GRADING}.MY_LAB_PROGRESS
        WHERE MODULE_ID = ${training}
        ORDER BY SECTION_SEQ`,
      { callersRights: true },
    )
    return Response.json({
      user: learner.user,
      training: MODULE_ID,
      steps: rows.map((r) => ({
        stepKey: String(r.STEP_KEY),
        sectionId: String(r.SECTION_ID),
        sectionSeq: Number(r.SECTION_SEQ),
        done: r.DONE === true || String(r.DONE).toLowerCase() === "true",
        firstDoneAt: r.FIRST_DONE_AT ?? null,
        updatedAt: r.UPDATED_AT ?? null,
      })),
    })
  } catch (e) {
    return errorResponse(e, "progress-read")
  }
}

/**
 * Tick or untick one checkpoint.
 *
 * The body carries the step key and the desired state and NOTHING ELSE. Both the
 * participant and the training are resolved server-side, so a learner cannot
 * write to another learner's progress -- or into another training -- by editing a
 * request. The step key is shape-checked here and re-checked against the
 * LAB_STEPS allowlist inside the procedure, as a pair with the training.
 */
export async function POST(request: Request) {
  try {
    const learner = await identifyLearner()
    const body = await request.json().catch(() => ({}))
    const stepKey = assertStepKey(body?.stepKey)
    const done = body?.done === true

    const rows = await querySnowflake(
      `CALL ${GRADING}.SET_LAB_STEP(${sqlLiteral(learner.user)}, ${sqlLiteral(MODULE_ID)}, ` +
        `${sqlLiteral(stepKey)}, ${done})`,
    )
    const result = String(Object.values(rows[0] ?? {})[0] ?? "")

    // The procedure reports refusals rather than throwing, so surface them as a
    // client error instead of pretending the write succeeded.
    if (result.startsWith("rejected")) {
      return Response.json({ error: result, stepKey, done }, { status: 400 })
    }

    console.log(
      new Date().toISOString(),
      `[progress] ${learner.user} ${done ? "done" : "cleared"} ${stepKey}`,
    )
    return Response.json({ ok: true, stepKey, done, result })
  } catch (e) {
    return errorResponse(e, "progress-write")
  }
}
