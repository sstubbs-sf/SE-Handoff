import { querySnowflake } from "@/lib/snowflake"
import {
  assertChoice,
  assertQuizRef,
  errorResponse,
  identifyLearner,
  sqlLiteral,
  GRADING,
  MODULE_ID,
} from "@/lib/lab-session"

export const dynamic = "force-dynamic"

/**
 * Read this learner's quiz results.
 *
 * Returns only which questions they have already got right, never the correct
 * option. The answer key lives in QUIZ_KEY and must not reach the browser -- a
 * learner reading the network response would otherwise have every answer.
 */
export async function GET() {
  try {
    const learner = await identifyLearner()
    const rows = await querySnowflake(
      `SELECT k.QUIZ_REF, COALESCE(p.BEST_CORRECT, FALSE) AS BEST_CORRECT,
              COALESCE(p.ATTEMPTS, 0) AS ATTEMPTS
         FROM ${GRADING}.QUIZ_KEY k
         LEFT JOIN ${GRADING}.QUIZ_PROGRESS p
                ON p.MODULE_ID   = k.MODULE_ID
               AND p.QUIZ_REF    = k.QUIZ_REF
               AND p.PARTICIPANT = ${sqlLiteral(learner.user)}
        WHERE k.IS_ACTIVE AND k.MODULE_ID = ${sqlLiteral(MODULE_ID)}
        ORDER BY k.SECTION_ID, k.QUESTION_NO`,
    )
    return Response.json({
      answers: rows.map((r) => ({
        ref: String(r.QUIZ_REF),
        correct: r.BEST_CORRECT === true || String(r.BEST_CORRECT).toLowerCase() === "true",
        attempts: Number(r.ATTEMPTS ?? 0),
      })),
    })
  } catch (e) {
    return errorResponse(e, "quiz-read")
  }
}

/**
 * Submit one answer and have the SERVER grade it.
 *
 * The body carries the quiz reference and the chosen option index and NOTHING
 * else. Both the participant and the training are resolved server-side, so a
 * learner cannot answer on somebody else's behalf or write into another
 * training. Correctness is decided by the procedure against QUIZ_KEY, never by
 * the client -- which is what lets quiz results gate training completion without
 * that gate being self-asserted.
 */
export async function POST(request: Request) {
  try {
    const learner = await identifyLearner()
    const body = await request.json().catch(() => ({}))
    const ref = assertQuizRef(body?.ref)
    const choice = assertChoice(body?.choice)

    const rows = await querySnowflake(
      `CALL ${GRADING}.SUBMIT_QUIZ_ANSWER(${sqlLiteral(learner.user)}, ` +
        `${sqlLiteral(MODULE_ID)}, ${sqlLiteral(ref)}, ${choice})`,
    )
    const raw = String(Object.values(rows[0] ?? {})[0] ?? "{}")
    const result = JSON.parse(raw) as {
      error?: string
      correct?: boolean
      already_correct?: boolean
      attempts?: number
      explanation?: string | null
    }

    // The procedure reports refusals rather than throwing, so surface them as a
    // client error instead of pretending the answer was graded.
    if (result.error) {
      return Response.json({ error: result.error, ref }, { status: 400 })
    }

    console.log(
      new Date().toISOString(),
      `[quiz] ${learner.user} ${ref} ${result.correct ? "correct" : "incorrect"}`,
    )
    return Response.json({
      ref,
      correct: result.correct === true,
      alreadyCorrect: result.already_correct === true,
      attempts: Number(result.attempts ?? 0),
      // Returned only after a submission, so it cannot be read to infer the answer.
      explanation: result.explanation ?? null,
    })
  } catch (e) {
    return errorResponse(e, "quiz-write")
  }
}
