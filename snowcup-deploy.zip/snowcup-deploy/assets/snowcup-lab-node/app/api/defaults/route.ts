import { querySnowflake } from "@/lib/snowflake"
import { errorResponse, identifyLearner, GRADING } from "@/lib/lab-session"

export const dynamic = "force-dynamic"

/**
 * Apply or revert the session defaults this lab needs, for the signed-in learner.
 *
 * THE RULE THIS ROUTE OBEYS: it never accepts a participant from the client. Both
 * procedures take NO parameter and derive their target from CURRENT_USER(), so even
 * a crafted request can only ever change the caller's own defaults.
 *
 * THEREFORE THE CALL MUST USE CALLER'S RIGHTS. On the owner path CURRENT_USER() is
 * the app's own service identity, not the learner -- in SPCS that is ACCOUNTADMIN,
 * which these procedures refuse outright, so the buttons would silently do nothing
 * for everyone. This is invisible locally, where the owner connection happens to be
 * the developer's own user and CURRENT_USER() therefore looks correct. The USAGE
 * grants on both procedures are held by SNOWCUP_PARTICIPANT, which only means
 * anything on the caller path.
 *
 * identifyLearner() is called first purely as a gate: it fails closed when the
 * session cannot be identified, which is the same guarantee every write route in
 * this app relies on.
 */
export async function POST(request: Request) {
  try {
    await identifyLearner()

    let action = ""
    try {
      action = String(((await request.json()) as { action?: string })?.action ?? "")
    } catch {
      action = ""
    }

    if (action !== "apply" && action !== "revert") {
      return Response.json(
        { error: "action must be 'apply' or 'revert'" },
        { status: 400 },
      )
    }

    const proc =
      action === "apply" ? "MY_LAB_DEFAULTS_APPLY" : "MY_LAB_DEFAULTS_RESTORE"

    const rows = await querySnowflake(`CALL ${GRADING}.${proc}()`, {
      callersRights: true,
    })
    const message = String(Object.values(rows[0] ?? {})[0] ?? "").trim()

    // The procedures report refusals as text rather than throwing -- "you hold
    // ACCOUNTADMIN", "no build space is granted to you". Those are not errors, but
    // they are not successes either, so the flag is derived from the wording and
    // the UI can colour it accordingly.
    const changed =
      /^defaults set|^RESTORED/i.test(message) === true
    return Response.json({ action, changed, message })
  } catch (e) {
    return errorResponse(e, "defaults")
  }
}
