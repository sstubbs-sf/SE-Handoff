import { Lab } from "@/components/lab"

// Required: Snowflake is not reachable during docker build.
export const dynamic = "force-dynamic"

export default function Home() {
  return (
    // Wider than the old max-w-4xl to make room for the outline sidebar. The
    // prose column itself is held to a readable measure by the grid in <Lab>,
    // so text does not stretch to 6xl.
    <main className="mx-auto w-full max-w-6xl px-4 py-10">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold tracking-tight">
          SnowCup — Build an Agent
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Go from a shared dataset to a working Cortex Agent by prompting Cortex Code.
          Tick each checkpoint as you finish it — your progress is saved against your
          Snowflake user, so it follows you between sessions and devices.
        </p>
      </div>
      <Lab />
    </main>
  )
}
