#!/usr/bin/env node
/**
 * Emit lab content as JSON on stdout.
 *
 * This is the bridge for verify/check_leaks.py. Python asks node for the content
 * rather than parsing .mjs source, so extraction is exact and there is no
 * generated file that can drift from what the app actually renders.
 *
 * Usage:
 *   node scripts/dump-content.mjs            # full content + steps
 *   node scripts/dump-content.mjs --text     # per-module extracted prose only
 *   node scripts/dump-content.mjs --steps    # LAB_STEPS seed rows only
 *
 * Exits non-zero with the validation error if any module is malformed, so a
 * broken content tree fails the verification suite instead of scanning nothing
 * and reporting success.
 */
import { MODULES, STEPS, TRAINING } from "../content/index.mjs"
import { blockText, extractText } from "../content/validate.mjs"

const arg = process.argv[2] ?? ""

if (arg === "--steps") {
  // The training travels with the steps so check_lab_steps.py can assert the
  // LAB_STEPS seed is filed under the same MODULE_ID this app writes to. A
  // mismatch there means every tick is rejected as an unknown step.
  process.stdout.write(
    JSON.stringify({ training: TRAINING, steps: STEPS }, null, 2) + "\n",
  )
} else if (arg === "--training") {
  process.stdout.write(JSON.stringify(TRAINING, null, 2) + "\n")
} else if (arg === "--text") {
  // Shape the scanner wants: every learner-visible string, tagged with the
  // block kind it came from and whether scored answers are permitted there.
  const out = MODULES.map((mod) => ({
    id: mod.id,
    seq: mod.seq,
    title: extractText(mod.title),
    blocks: mod.blocks.map((b, i) => ({
      index: i,
      kind: b.kind,
      allowScoredAnswers: b.allowScoredAnswers === true,
      text: blockText(b),
    })),
  }))
  process.stdout.write(JSON.stringify(out, null, 2) + "\n")
} else {
  process.stdout.write(
    JSON.stringify({ training: TRAINING, modules: MODULES, steps: STEPS }, null, 2) + "\n",
  )
}
