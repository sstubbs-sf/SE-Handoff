/**
 * Module 5 — Seed a verified query.
 *
 * Deliberately uses xG overperformance grouped by POSITION, not by nation: the
 * scored Q6 asks for the nation, so demonstrating on position teaches the pattern
 * without handing over an answer.
 */

/** @type {import("./types").Module} */
export const m5 = {
  id: "m5",
  seq: 5,
  phase: "Phase · Seed",
  title: "Seed a verified query",
  blocks: [
    {
      kind: "prose",
      text:
        "{{skill:/semantic-view}} Verified queries are worked examples that teach Analyst your " +
        "hardest questions by example — the fastest way to lock in a correct answer permanently.",
    },
    {
      kind: "callout",
      text:
        "**Behind the scenes:** this runs through the `/semantic-view` skill again — the same " +
        "expert workflow that built your model now attaches the worked example to it.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "I want to lock in a known-good answer on SNOWCUP_ANALYTICS. Take the question " +
        "\u201cWhich position has the highest xG overperformance?\u201d, write the SQL using the xG " +
        "overperformance metric grouped by position, run it so we can confirm the result looks " +
        "right, then save it as a verified query on the model so Analyst reuses this pattern " +
        "next time.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**Habit for real work:** every time an agent gets a hard question wrong, the fix is a " +
        "verified query. Your verified-query set becomes living documentation of \u201ccorrect.\u201d",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**Which single answer must never be wrong?** Revenue recognized this quarter, " +
        "headcount, safety incidents, inventory on hand, a dosage. Whatever it is, that's your " +
        "first verified query — the one you lock in *before* someone important asks it.",
    },
    {
      kind: "quiz",
      ref: "m5.q1",
      text:
        "What is a verified query?",
      options: [
        "A worked example that teaches Analyst a hard question by example",
        "A query that has been performance-tuned by Snowflake",
        "A query only an administrator is allowed to run",
      ],
    },
    {
      kind: "quiz",
      ref: "m5.q2",
      text:
        "An agent answers a hard question wrong. Which fix is still working after you have left the project?",
      options: [
        "Switch to a larger orchestration model",
        "Remove the tool that produced the answer",
        "Add a verified query for that question",
      ],
    },
    {
      kind: "checkpoint",
      key: "m5.checkpoint",
      text: "**Checkpoint:** at least one verified query is saved on `SNOWCUP_ANALYTICS`.",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[Cortex Analyst Verified Query Repository](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst/verified-query-repository) — the reference for what you just seeded",
          "[Cortex Analyst](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst) — how natural language becomes SQL against your model",
          "[Custom instructions in Cortex Analyst](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst/custom-instructions) — steering SQL generation in plain language",
        ],
      },
  ],
}
