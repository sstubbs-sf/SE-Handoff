/**
 * Module 7 — Make it great in Snowflake CoWork.
 *
 * The multi-turn drill deliberately uses the 2018 edition. Q1 is scored on 2026,
 * so 2018 exercises the same conversational behaviour without touching an answer.
 */

/** @type {import("./types").Module} */
export const m7 = {
  id: "m7",
  seq: 7,
  phase: "Phase · Publish",
  title: "Make it great in Snowflake CoWork",
  blocks: [
    {
      kind: "prose",
      text:
        "{{skill:/cortex-agent}} You've built a capable agent. The last mile is turning it into " +
        "something a teammate could *trust* and *hold a conversation with* — a sharp profile, " +
        "starter questions that teach its range, and conversational polish. An agent nobody can " +
        "figure out how to prompt never gets used.",
    },
    {
      kind: "callout",
      text:
        "**Behind the scenes:** setting the profile and sample questions still runs " +
        "through the `/cortex-agent` skill — the same workflow that wired your tools now " +
        "readies the agent for real users.",
    },
    {
      kind: "callout",
      text:
        "**Where you'll test: Preview in Snowflake CoWork.** Open **AI & ML » Agents » " +
        "SNOWCUP_AGENT » Preview in Snowflake CoWork**. That is the full CoWork chat surface, " +
        "running your agent \u2014 same threads, same charts, same everything your users get. " +
        "**Every step in this module happens there.** Your agent is deliberately *not* added to the " +
        "account-wide CoWork list at `ai.snowflake.com`, and nobody's will be \u2014 the reason is " +
        "below, and it costs you nothing.",
    },
    { kind: "heading", text: "Give it a face people can read" },
    {
      kind: "prose",
      text:
        "In CoWork, users pick an agent from a list and lean on its **sample questions** to know " +
        "what to ask. A sharp name, a one-line description, and a few great starter questions are " +
        "the on-ramp — most first prompts are a sample question, lightly edited.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Set SNOWCUP_AGENT up for CoWork: give it a clear display name (\u201cSnowCup Analyst\u201d), a " +
        "one-line description of what it's great at, and an avatar color. Then add four sample " +
        "questions that each show off a different tool — one stats leaderboard, one lore/nickname " +
        "question, one \u201cwrite a scouting report on…\u201d, and one \u201cchart the top…\u201d. Show me the profile " +
        "before you apply it.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**Why sample questions matter more than they look:** they're the fastest way a new user " +
        "learns what your agent can do. Pick four that span its range — a number, a story, a " +
        "report, a chart — and you've taught the whole toolset in one glance, without writing a " +
        "word of documentation.",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**What four questions would your colleagues type first?** Make those your sample " +
        "questions. If you can't name four, you don't yet know who the agent is *for* — and " +
        "that's worth settling before you hand it to anyone.",
    },
    { kind: "heading", text: "Have a real conversation" },
    {
      kind: "prose",
      text:
        "CoWork isn't a one-shot query box — it's a thread. A great agent carries context from " +
        "turn to turn and asks before it guesses. Open **Preview in Snowflake CoWork** on your " +
        "agent and try a genuine back-and-forth:",
    },
    {
      kind: "prompt",
      label: "In the agent, ask in sequence",
      text:
        "1 · \u201cWho scored the most goals in the 2018 edition?\u201d → 2 · \u201cNow just for Cirrus.\u201d → " +
        "3 · \u201cChart the top 5.\u201d → 4 · \u201cWho covered the most distance?\u201d *(deliberately vague on " +
        "edition)*",
    },
    {
      kind: "callout",
      text:
        "**What to watch for:** on turns 2 and 3 it should *carry the context* (\u201cthat edition\u201d, " +
        "\u201cthose players\u201d) instead of making you repeat yourself; on turn 4 it should **ask a " +
        "clarifying question** rather than silently picking an edition. That conversational polish " +
        "is what your Module 6 response instructions buy you — it's the difference between an " +
        "agent that feels like a colleague and one that feels like a form.",
    },
    { kind: "heading", text: "Who else can reach it" },
    {
      kind: "prose",
      text:
        "An agent is only useful if your team can reach it \u2014 and reaching it takes more than " +
        "one grant. Access is layered: `USAGE` on the **database**, `USAGE` on the **schema**, then " +
        "`USAGE` on the **agent**. Your build schema deliberately grants none of the first two to " +
        "other participants, which is exactly the isolation that keeps twenty learners out of each " +
        "other's work. So your agent is yours alone today, and that is the correct default.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**The guardrail you get for free:** an agent runs as the *querying user's* role. Masking " +
        "and row-access policies on the base tables flow through automatically, so a shared agent " +
        "cannot leak data a user isn't allowed to see. \u201cShared\u201d never means " +
        "\u201cexposed.\u201d (You'll harden this further in Module 10.)",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Your agent is not published to** `ai.snowflake.com`**, and that is by design.** Grants " +
        "decide whether someone *can* query an agent. A separate account-level object \u2014 the " +
        "**CoWork object** \u2014 decides which agents CoWork *lists*, and in this account it lists " +
        "only the Referee. There is one such object for the whole account with no per-agent scoping, " +
        "so anyone who can add an agent can also remove everyone else's \u2014 including the Referee " +
        "you need in Module 9. **Nobody's agent gets published in this lab.** " +
        "**Preview in Snowflake CoWork** is where you test, and it is the complete CoWork " +
        "experience \u2014 you are not missing anything.",
    },
    {
      kind: "quiz",
      ref: "m7.q1",
      text:
        "Why do sample questions matter more than they look?",
      options: [
        "Most first prompts are a sample question, so four good ones teach the whole toolset",
        "An agent cannot be published without them",
        "They are used to score the agent's accuracy",
      ],
    },
    {
      kind: "quiz",
      ref: "m7.q2",
      text:
        "You granted usage on your agent, but a colleague still cannot see it in CoWork. Why?",
      options: [
        "Agent grants take up to 24 hours to propagate",
        "They need ACCOUNTADMIN to open CoWork",
        "A CoWork object exists, and it lists only the agents added to it",
      ],
    },
    {
      kind: "checkpoint",
      key: "m7.checkpoint",
      text:
        "**Checkpoint:** SNOWCUP_AGENT has a display name, description, and four tool-spanning " +
        "sample questions; you've run a multi-turn conversation in **Preview in Snowflake CoWork** " +
        "where it carried context and asked a clarifying question; and you can explain the three " +
        "layers of access an agent needs, and why CoWork lists what it lists.",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[Overview of Snowflake CoWork](https://docs.snowflake.com/en/user-guide/snowflake-cortex/snowflake-cowork) — the surface your colleagues will actually use",
          "[CREATE AGENT](https://docs.snowflake.com/en/sql-reference/sql/create-agent) — where display_name and sample_questions are specified",
        ],
      },
  ],
}
