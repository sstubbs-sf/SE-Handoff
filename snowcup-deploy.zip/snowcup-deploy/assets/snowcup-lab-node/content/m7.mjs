/**
 * Module 7 — Make it great in Snowflake CoWork.
 *
 * The multi-turn drill deliberately uses the 2018 edition. Q1 is scored on 2026,
 * so 2018 exercises the same conversational behaviour without touching an answer.
 */

/** @type {import("./types").Module} */
export const m7 = {
  id: "m7",
  seq: 7,
  phase: "Phase · Publish",
  title: "Make it great in Snowflake CoWork",
  blocks: [
    {
      kind: "prose",
      text:
        "{{skill:/cortex-agent}} You've built a capable agent. The last mile is turning it into " +
        "something a teammate can *find*, *trust*, and *hold a conversation with* in Snowflake " +
        "CoWork — the chat surface where real users meet your agent. An agent nobody can discover " +
        "or figure out how to prompt never gets used.",
    },
    {
      kind: "callout",
      text:
        "**Behind the scenes:** setting the profile, sample questions, and grants still runs " +
        "through the `/cortex-agent` skill — the same workflow that wired your tools now " +
        "publishes the agent for consumers.",
    },
    {
      kind: "callout",
      text:
        "**Where CoWork actually lives.** CoWork is its own chat surface, *not* the agent page in " +
        "Snowsight. Open it at `https://ai.snowflake.com` and sign in to this account, or get a " +
        "direct link from **AI & ML » Agents » SNOWCUP_AGENT » Preview in Snowflake CoWork**. The " +
        "Snowsight agent page is where you *configure and test*; CoWork is where your users *live*.",
    },
    { kind: "heading", text: "Publish it so people can find it" },
    {
      kind: "prose",
      text:
        "In CoWork, users pick an agent from a list and lean on its **sample questions** to know " +
        "what to ask. A sharp name, a one-line description, and a few great starter questions are " +
        "the on-ramp — most first prompts are a sample question, lightly edited.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Set SNOWCUP_AGENT up for CoWork: give it a clear display name (\u201cSnowCup Analyst\u201d), a " +
        "one-line description of what it's great at, and an avatar color. Then add four sample " +
        "questions that each show off a different tool — one stats leaderboard, one lore/nickname " +
        "question, one \u201cwrite a scouting report on…\u201d, and one \u201cchart the top…\u201d. Show me the profile " +
        "before you apply it.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**Why sample questions matter more than they look:** they're the fastest way a new user " +
        "learns what your agent can do. Pick four that span its range — a number, a story, a " +
        "report, a chart — and you've taught the whole toolset in one glance, without writing a " +
        "word of documentation.",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**What four questions would your colleagues type first?** Make those your sample " +
        "questions. If you can't name four, you don't yet know who the agent is *for* — and " +
        "that's worth settling before you share it with anyone.",
    },
    { kind: "heading", text: "Have a real conversation" },
    {
      kind: "prose",
      text:
        "CoWork isn't a one-shot query box — it's a thread. A great agent carries context from " +
        "turn to turn and asks before it guesses. Open your agent in CoWork " +
        "(`https://ai.snowflake.com`, then pick **SnowCup Analyst** from the agent list) and try a " +
        "genuine back-and-forth:",
    },
    {
      kind: "prompt",
      label: "In the agent, ask in sequence",
      text:
        "1 · \u201cWho scored the most goals in the 2018 edition?\u201d → 2 · \u201cNow just for Cirrus.\u201d → " +
        "3 · \u201cChart the top 5.\u201d → 4 · \u201cWho covered the most distance?\u201d *(deliberately vague on " +
        "edition)*",
    },
    {
      kind: "callout",
      text:
        "**What to watch for:** on turns 2 and 3 it should *carry the context* (\u201cthat edition\u201d, " +
        "\u201cthose players\u201d) instead of making you repeat yourself; on turn 4 it should **ask a " +
        "clarifying question** rather than silently picking an edition. That conversational polish " +
        "is what your Module 6 response instructions buy you — it's the difference between an " +
        "agent that feels like a colleague and one that feels like a form.",
    },
    { kind: "heading", text: "Share it — and let governance do its job" },
    {
      kind: "prose",
      text:
        "An agent is only useful if your team can reach it. Grant it to a role, then confirm the " +
        "guardrails hold: an agent runs as the *querying user's* role, so masking and row-access " +
        "policies on the base tables flow through automatically — a shared agent can't leak data " +
        "a user isn't allowed to see.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Grant usage on SNOWCUP_AGENT to the role my facilitator uses for participants (or to a " +
        "test role), so a teammate can open it in CoWork. Then help me confirm the sharing worked, " +
        "and explain what that role can and can't see given the agent runs with the caller's " +
        "privileges.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Test as the other user before you trust it.** Switch to the restricted role and ask the " +
        "same questions. If a masking or row-access policy is in play, the answers should respect " +
        "it automatically — proof that \u201cshared\u201d doesn't mean \u201cexposed.\u201d (You'll harden this further " +
        "in Module 10.)",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Granted it but still can't see it in CoWork?** Grants control whether a user *can* " +
        "query your agent; a separate account-level object controls which agents CoWork *lists*. " +
        "If your account has a CoWork object, only agents added to it appear in the picker. Check " +
        "and fix with CoCo: *\u201cDoes this account have a Snowflake CoWork object? If so, add " +
        "SNOWCUP_AGENT to it.\u201d* — that runs `SHOW SNOWFLAKE INTELLIGENCES;` and, if one exists, " +
        "`ALTER SNOWFLAKE INTELLIGENCE SNOWFLAKE_INTELLIGENCE_OBJECT_DEFAULT ADD AGENT " +
        "<db>.<schema>.SNOWCUP_AGENT;`. If no such object exists, every agent you have access to " +
        "is listed automatically and there's nothing to do. Adding an agent needs privileges your " +
        "facilitator may hold — ask them if it fails. In the meantime the direct **Preview in " +
        "Snowflake CoWork** link always works.",
    },
    {
      kind: "quiz",
      ref: "m7.q1",
      text:
        "Why do sample questions matter more than they look?",
      options: [
        "Most first prompts are a sample question, so four good ones teach the whole toolset",
        "An agent cannot be published without them",
        "They are used to score the agent's accuracy",
      ],
    },
    {
      kind: "quiz",
      ref: "m7.q2",
      text:
        "You granted usage on your agent, but a colleague still cannot see it in CoWork. Why?",
      options: [
        "Agent grants take up to 24 hours to propagate",
        "They need ACCOUNTADMIN to open CoWork",
        "A CoWork object exists, and it lists only the agents added to it",
      ],
    },
    {
      kind: "checkpoint",
      key: "m7.checkpoint",
      text:
        "**Checkpoint:** SNOWCUP_AGENT has a display name, description, and four tool-spanning " +
        "sample questions; you've run a multi-turn conversation where it carried context and asked " +
        "a clarifying question; and you've shared it to a role and confirmed what that role can see.",
    },
  ],
}
