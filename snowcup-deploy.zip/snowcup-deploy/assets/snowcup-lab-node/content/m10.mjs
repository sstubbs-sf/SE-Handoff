/**
 * Module 10 — Keep it accurate over time.
 *
 * Closing module. Note the framing in "Turn the challenge into your regression
 * set": it tells learners to reuse answers the Referee already confirmed, which
 * is why it can reference the challenge without containing any answer itself.
 */

/** @type {import("./types").Module} */
export const m10 = {
  id: "m10",
  seq: 10,
  phase: "Phase · Operate",
  title: "Keep it accurate over time",
  blocks: [
    {
      kind: "prose",
      text:
        "{{skill:/agent-optimization}} Launch is the *start* of the workflow, not the end. Four " +
        "moves keep accuracy compounding instead of quietly decaying as data and questions change:",
    },
    {
      kind: "callout",
      text:
        "**Behind the scenes:** reviewing suggestions and tuning the agent invokes the " +
        "`/agent-optimization` skill — the workflow for monitoring usage, harvesting Suggestions, " +
        "and iterating safely.",
    },
    {
      kind: "list",
      ordered: true,
      items: [
        "**Monitor & collect feedback.** Watch usage history and traces, and wire the thumbs-up / " +
          "thumbs-down feedback signal so real misses surface.",
        "**Harvest Suggestions.** Snowflake mines your real query history to propose new verified " +
          "queries, synonyms, metrics, and filters — review and accept the good ones.",
        "**Version everything.** Keep the semantic view and agent specs in Git and deploy via " +
          "CI/CD, so every change is reviewable and reversible.",
        "**Gate deploys on evals.** Re-run your Module 8 eval set before each change so an " +
          "improvement in one area never silently regresses another.",
      ],
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Show me the current Suggestions Snowflake has generated for SNOWCUP_ANALYTICS — the " +
        "proposed new verified queries, synonyms, and metrics it mined from real usage. Walk me " +
        "through each one in plain English and help me accept the ones that make sense.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Review how SNOWCUP_AGENT has been behaving lately and propose concrete improvements to " +
        "its tool descriptions, its instructions, or the underlying semantic view. Make one change " +
        "at a time, then help me re-run my evaluation set so I can confirm it actually helped and " +
        "didn't break anything else.",
    },
    {
      kind: "callout",
      text:
        "**The habit that matters:** a running monitor-and-fix loop like this is what separates a " +
        "one-off demo from a durable, trusted agent.",
    },
    { kind: "heading", text: "Turn the challenge you just ran into your regression set" },
    {
      kind: "prose",
      text:
        "You just ran a real UAT round without realizing it: **8 hard questions, each graded by " +
        "the Referee**, so you now hold a confirmed-correct answer for every one. That's the best " +
        "regression set there is — real questions with known answers. Your Module 8 eval set was " +
        "an optimistic sample *you* wrote; the challenge is the tougher, truer distribution. Lock " +
        "it in before anything drifts:",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Take the 8 SnowCup challenge questions I just answered — I know each Referee-confirmed " +
        "correct answer now. For every one, save the question and its confirmed answer as a " +
        "permanent evaluation/regression case, and write the correct SQL as a verified query on " +
        "SNOWCUP_ANALYTICS. For any question my agent got wrong, needed retries on, or picked the " +
        "wrong tool for, propose the specific fix — a missing synonym, an undefined metric, or a " +
        "sharper tool description — apply it one change at a time, and re-run the eval set to " +
        "confirm the lift.",
    },
    { kind: "prose", text: "Then keep the same loop running as real users arrive:" },
    {
      kind: "list",
      items: [
        "**Mine actual usage.** Pull the real questions users asked from usage history, and flag " +
          "every thumbs-down or wrong answer.",
        "**Promote misses to permanent cases.** Add each real failure to the eval set as a " +
          "*regression case*, with its confirmed correct answer.",
        "**Weight by reality.** Prioritize by frequency × impact, so your accuracy score reflects " +
          "what users actually ask — not your seed questions. Re-baseline against this hardened set.",
      ],
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Pull the real questions people asked SNOWCUP_AGENT and any responses they marked with a " +
        "thumbs-down. For each failure, help me confirm the correct answer, add it to my " +
        "evaluation set as a permanent regression case, and save the fixed version as a verified " +
        "query so it can't quietly break again.",
    },
    { kind: "heading", text: "Let evals drive your configuration choices" },
    {
      kind: "prose",
      text:
        "Treat the eval set as the instrument you tune the agent against. When a whole *category* " +
        "of questions scores low, the failure pattern tells you which configuration knob to turn:",
    },
    {
      kind: "table",
      head: ["Failure pattern in the evals", "Configuration change it points to"],
      rows: [
        [
          "Right data exists, but the agent picks the wrong tool",
          "Sharpen tool **descriptions** (scope + when NOT to use); prune or merge overlapping tools.",
        ],
        [
          "Wrong or inconsistent SQL in one domain",
          "Add **synonyms / metrics**. If the *meaning or grain* truly differs, split into a second " +
            "**semantic view** and let the agent route across both.",
        ],
        [
          "Agent guesses on vague questions",
          "Add **clarify / question-categorization** instructions so it asks before answering.",
        ],
        [
          "Multi-part questions only half-answered",
          "Add **planning instructions** to decompose and call multiple tools before responding.",
        ],
        [
          "Correct, but too slow or expensive",
          "Adjust the **orchestration model** (the car) and set a **fuel + time budget** — the " +
            "**speed limit** you set in Module 6. Check the road (your semantic view) before " +
            "reaching for a bigger engine.",
        ],
      ],
    },
    {
      kind: "prose",
      text:
        "**Change one thing, then re-run the eval set** and keep whichever configuration scores " +
        "higher — you're A/B-testing your agent's design with data instead of guessing.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Using SNOWCUP_AGENT's evaluation results and the real questions from UAT, tell me which " +
        "single configuration change would raise accuracy the most — sharper tool descriptions, " +
        "splitting into a second semantic view, adding a clarify-before-answering behavior, or a " +
        "different orchestration model or budget. Recommend one, explain why, help me apply it, " +
        "and re-run the evals to confirm it helped.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Governance is part of accuracy.** Agents run as the querying user's role, so a user " +
        "needs `SELECT` on both the semantic view and its base tables; masking and row-access " +
        "policies on the base tables flow through automatically. Before you ship, test with a " +
        "restricted role so the agent never exposes data it shouldn't.",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**Which columns must an agent never expose?** Salaries, national IDs, patient " +
        "identifiers, unannounced financials, customer PII, competitor pricing. Name them now and " +
        "prove your masking and row-access policies hold while the agent answers — not after " +
        "someone screenshots the wrong number.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**That's the fundamentals, start to finish.** You explored a shared dataset, modeled a " +
        "semantic view with real metrics, grounded it with search, seeded a verified query, " +
        "assembled an agent, measured it with evaluations, proved it against a scored challenge, " +
        "and set up the loop to keep it accurate — all by talking to Cortex Code. The exact same " +
        "workflow builds agents on real business data.",
    },
    {
      kind: "quiz",
      ref: "m10.q1",
      text:
        "Where does the best regression set come from?",
      options: [
        "Synthetic questions generated by the agent itself",
        "The challenge questions you just answered, each with a confirmed correct answer",
        "The column list of your semantic view",
      ],
    },
    {
      kind: "quiz",
      ref: "m10.q2",
      text:
        "Evaluations show the right data exists, but the agent keeps choosing the wrong tool. Which knob does that point to?",
      options: [
        "Increase the token and duration budget",
        "Add a second semantic view",
        "Sharpen the tool descriptions and prune overlapping tools",
      ],
    },
    {
      kind: "checkpoint",
      key: "m10.checkpoint",
      text:
        "**Final checkpoint:** you can name the four moves — monitor, harvest Suggestions, " +
        "version, gate on evals — you've reviewed at least one Suggestion, turned your challenge " +
        "answers into eval cases, and can point to one configuration choice your eval results " +
        "would drive.",
    },
  ],
}
