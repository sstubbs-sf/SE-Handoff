import type { Block, Module } from "./types"
import type { Step } from "./index.d.mts"

/**
 * Type declarations for validate.mjs.
 *
 * Declarations only — the runtime stays plain .mjs so that both Next.js and bare
 * `node` can import the content model (see the note at the top of types.d.ts).
 * Adding this file lets TypeScript consumers such as lib/outline.ts use the text
 * extraction helpers without duplicating them.
 */

/** The orange placeholder a learner replaces with their own schema name. */
export const FILLIN: string

/** Strip the inline markup subset down to the plain text a learner reads. */
export function extractText(inline: string): string

/** All learner-visible text in a block, joined. Used by the leak scanner. */
export function blockText(block: Block): string

export function validateModule(mod: Module): Module
export function validateAll(modules: Module[]): Module[]
export function stepsOf(modules: Module[]): Step[]
