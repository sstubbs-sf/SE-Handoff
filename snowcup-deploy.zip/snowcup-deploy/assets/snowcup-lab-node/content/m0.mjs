/**
 * Module 0 — Meet Cortex Code.
 *
 * Sets up the four moves the whole lab depends on, so the table here is load
 * bearing rather than decorative.
 */

/** @type {import("./types").Module} */
export const m0 = {
  id: "m0",
  seq: 0,
  phase: "Fundamentals",
  title: "Meet Cortex Code",
  blocks: [
    {
      kind: "prose",
      text:
        "Cortex Code (CoCo) is Snowflake's AI coding assistant. You describe what you want in " +
        "plain language; CoCo writes the SQL/DDL, shows you a **diff or the SQL to review**, and " +
        "only runs it when you approve. Four things to know before you start:",
    },
    {
      kind: "table",
      head: ["Move", "How", "Why it matters"],
      rows: [
        [
          "**Open CoCo**",
          "The Cortex Code panel (icon, bottom-right of Snowsight) or Cortex Code Desktop.",
          "This is your whole workspace for the lab.",
        ],
        [
          "**Add context with `@`**",
          "Type `@` to attach a table, view, or file so CoCo \u201csees\u201d it.",
          "Grounds CoCo in your real objects instead of guessing.",
        ],
        [
          "**Invoke a skill with `/`**",
          "Type `/` to pick a packaged skill like `/semantic-view`.",
          "Skills are expert workflows — you'll use one per phase.",
        ],
        [
          "**Review before running**",
          "Read the diff/SQL CoCo proposes, then Run.",
          "Nothing changes in your account without your approval.",
        ],
      ],
    },
    {
      kind: "callout",
      text:
        "**You rarely type the slash yourself.** The `/` menu lets you pick a skill explicitly, " +
        "but most of the time you just describe what you want in plain language and **CoCo " +
        "recognizes the job and invokes the right skill automatically** — you'll see it load in " +
        "the panel (e.g. \u201c`/semantic-view` loading…\u201d). Throughout this lab, watch for those " +
        "moments: each phase names the skill doing the heavy lifting, and a **Behind the scenes** " +
        "note flags when it fires.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**CoCo runs as your default role.** If something fails on privileges, ask CoCo to " +
        "*\u201cswitch to the <role> role\u201d* or check with your facilitator. Keep this in mind if a " +
        "step can't create objects in your build schema.",
    },
    {
      kind: "quiz",
      ref: "m0.q1",
      text:
        "When CoCo writes SQL for you, what happens before it runs?",
      options: [
        "It runs immediately and shows you the result",
        "It shows you a diff or the SQL to review, and runs only when you approve",
        "It saves it to a worksheet for you to run yourself",
      ],
    },
    {
      kind: "quiz",
      ref: "m0.q2",
      text:
        "A skill loaded in the panel without you choosing anything from the / menu. How was it invoked?",
      options: [
        "You have to type the slash command yourself every time",
        "The facilitator enables it for each module",
        "CoCo recognised the job and invoked the right skill automatically",
      ],
    },
    {
      kind: "checkpoint",
      key: "m0.checkpoint",
      text:
        "**Checkpoint:** open CoCo and say hello — *\u201cWhat can you help me build in Snowflake?\u201d* " +
        "— just to confirm the panel is live.",
    },
  ],
}
