/**
 * Module 0 — Meet Cortex Code.
 *
 * Sets up the four moves the whole lab depends on, so the table here is load
 * bearing rather than decorative.
 */

/** @type {import("./types").Module} */
export const m0 = {
  id: "m0",
  seq: 0,
  phase: "Fundamentals",
  title: "Meet Cortex Code",
  blocks: [
    {
      kind: "prose",
      text:
        "Cortex Code (CoCo) is Snowflake's AI coding assistant. You describe what you want in " +
        "plain language; CoCo writes the SQL/DDL and, **by default**, shows you a **diff or " +
        "the SQL to review** and only runs it once you approve. That review step is a " +
        "**setting, not a law** — you can widen what CoCo is allowed to run without asking. " +
        "Leave it as it is for this lab: approving each step is how you learn what the agent " +
        "is actually doing. Four things to know before you start:",
    },
    {
      kind: "table",
      head: ["Move", "How", "Why it matters"],
      rows: [
        [
          "**Open CoCo**",
          "The Cortex Code panel (icon, bottom-right of Snowsight) or Cortex Code Desktop.",
          "This is your whole workspace for the lab.",
        ],
        [
          "**Add context** with `@`",
          "Type `@` to attach a table, view, or file so CoCo \u201csees\u201d it.",
          "Grounds CoCo in your real objects instead of guessing.",
        ],
        [
          "**Invoke a skill** with `/`",
          "Type `/` to pick a packaged skill like `/semantic-view`.",
          "Skills are expert workflows — you'll use one per phase.",
        ],
        [
          "**Review before running**",
          "Read the diff/SQL CoCo proposes, then Run.",
          "Nothing changes in your account without your approval.",
        ],
      ],
    },
    {
      kind: "callout",
      text:
        "**You rarely type the slash yourself.** The `/` menu lets you pick a skill explicitly, " +
        "but most of the time you just describe what you want in plain language and **CoCo " +
        "recognizes the job and invokes the right skill automatically** — you'll see it load in " +
        "the panel (e.g. \u201c`/semantic-view` loading…\u201d). Throughout this lab, watch for those " +
        "moments: each phase names the skill doing the heavy lifting, and a **Behind the scenes** " +
        "note flags when it fires.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**CoCo runs as your default role \u2014 and only your default role.** In Snowsight, " +
        "CoCo starts every session on your account **default role** and **ignores the role picker** " +
        "in the lower-left corner of Snowsight. Changing that picker does nothing to CoCo.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Asking CoCo to switch roles does not work here.** Your role, warehouse and database are " +
        "fixed at the moment the session is created, so no prompt can change them. If something is " +
        "wrong you change your **defaults** and then start a fresh session \u2014 both steps are " +
        "spelled out below. Don't spend the lab fighting this; it is a two-minute fix.",
    },
    {
      kind: "prompt",
      label: "Run this now, before Module 1",
      text:
        "Show me CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_DATABASE() and " +
        "CURRENT_SCHEMA().",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**What you should see:** role {{role}} \u00b7 warehouse `SNOWCUP_WH` \u00b7 " +
        "database and schema {{fillin}}. " +
        "If any of those differ, don't start Module 1 \u2014 fix it with the steps just below. " +
        "Nearly every \u201cCoCo can't find my schema\u201d problem is " +
        "this, and it costs minutes now instead of an hour later.",
    },
    {
      kind: "heading",
      text: "If something doesn't match: change your own defaults",
    },
    {
      kind: "prose",
      text:
        "`USE ROLE` and `USE WAREHOUSE` **only affect the session you type them in** \u2014 and CoCo " +
        "in Snowsight never sees them. What CoCo reads are your account **defaults**. So the fix is " +
        "always the same shape: change the defaults, then start a genuinely fresh session. You can " +
        "do this yourself \u2014 you don't need your facilitator.",
    },
    {
      kind: "prompt",
      label: "The easy way \u2014 in Cortex Code, type",
      text:
        "Call SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS_APPLY() for me, then show me the result.",
    },
    {
      kind: "prose",
      text:
        "That single call works out which build space is yours, sets all three defaults, and saves " +
        "your original values first. The same three procedures are there if you'd rather run the " +
        "SQL yourself \u2014 in a worksheet, or by asking CoCo:",
    },
    {
      kind: "code",
      lang: "sql",
      text:
        "-- Show your original values next to what you have now\n" +
        "CALL SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS();\n" +
        "\n" +
        "-- Set the three defaults this lab needs\n" +
        "CALL SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS_APPLY();\n" +
        "\n" +
        "-- Put your original values back (do this when you're done)\n" +
        "CALL SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS_RESTORE();",
    },
    {
      kind: "prose",
      text:
        "**Or set them directly.** Snowflake always lets you change your *own* user's defaults, " +
        "whatever role you hold \u2014 so this works even though you can't administer anyone else. " +
        "This is the version worth remembering, because it applies to any Snowflake account, not " +
        "just this lab. Note there's no username: `ALTER USER` with nothing after it means *you*, " +
        "so it can't touch a colleague by mistake. Replace the two `<yourname>` parts with your own " +
        "build space (shown as {{fillin}} above):",
    },
    {
      kind: "code",
      lang: "sql",
      text:
        "ALTER USER SET\n" +
        "  DEFAULT_ROLE      = SNOWCUP_WS_<yourname>,\n" +
        "  DEFAULT_WAREHOUSE = SNOWCUP_WH,\n" +
        "  DEFAULT_NAMESPACE = 'SNOWCUP_BUILDS.WS_<yourname>';",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Changing a default does nothing to the session you're already in \u2014 including CoCo in " +
        "Snowsight.** Defaults are read once, when a session is created. Running the SQL above and " +
        "then re-checking in the same window will show the OLD values and look like it failed. To " +
        "pick up the change you must sign out and back in \u2014 and that only works if every " +
        "Snowsight window is gone:",
      items: [
        "Run the change (procedure or `ALTER USER`).",
        "**Close every other Snowflake and Snowsight browser window and tab** \u2014 all of them, " +
          "including other accounts, worksheets, dashboards and any second browser profile. One " +
          "surviving tab keeps your old session alive, and signing back in silently rejoins it.",
        "Sign out of Snowsight in the last remaining window, then close that one too.",
        "Open Snowsight fresh, reopen CoCo, and run the check prompt above again.",
      ],
      after:
        "If it still doesn't match after a clean sign-in, that's a provisioning problem rather than " +
        "a session problem \u2014 tell your facilitator instead of retrying.",
    },
    {
      kind: "callout",
      text:
        "**Disclaimer \u2014 this lab changed three settings on your user.** To keep everyone's work " +
        "isolated and make CoCo behave predictably, provisioning set your **default role**, " +
        "**default warehouse** and **default database/schema**. These " +
        "are session defaults only \u2014 none of your data is touched and nothing outside this " +
        "account changes. **Your original values were saved first.** To see them, or to put them " +
        "back at any time, ask CoCo to run " +
        "`CALL SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS();` or " +
        "`CALL SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS_RESTORE();`. Restoring takes effect the next " +
        "time you sign in. If you do real work in this account, run the restore when you're done " +
        "\u2014 Module 10 reminds you.",
    },
    {
      kind: "quiz",
      ref: "m0.q1",
      text:
        "By default, when CoCo writes SQL for you, what happens before it runs?",
      options: [
        "It runs immediately and shows you the result",
        "It shows you a diff or the SQL to review, and runs only when you approve",
        "It saves it to a worksheet for you to run yourself",
      ],
    },
    {
      kind: "quiz",
      ref: "m0.q2",
      text:
        "A skill loaded in the panel without you choosing anything from the / menu. How was it invoked?",
      options: [
        "You have to type the slash command yourself every time",
        "The facilitator enables it for each module",
        "CoCo recognised the job and invoked the right skill automatically",
      ],
    },
    {
      kind: "checkpoint",
      key: "m0.checkpoint",
      text:
        "**Checkpoint:** open CoCo and say hello — *\u201cWhat can you help me build in Snowflake?\u201d* " +
        "— just to confirm the panel is live.",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[Overview of Snowflake CoCo](https://docs.snowflake.com/en/user-guide/cortex-code/cortex-code) — what CoCo is, and the three places it runs: Snowsight, Desktop and the CLI",
          "[Cortex Code in your code editor](https://docs.snowflake.com/en/user-guide/cortex-code/cortex-code-in-your-editor) — the Desktop and IDE surface, if you would rather not work in Snowsight",
          "[Data governance skills for Cortex Code](https://docs.snowflake.com/en/user-guide/governance-skills) — the built-in skills you did not have to install",
        ],
      },
  ],
}
