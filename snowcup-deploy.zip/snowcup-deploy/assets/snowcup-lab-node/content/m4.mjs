/**
 * Module 4 — Ground it with Cortex Search.
 *
 * Stands the service up but deliberately does NOT query it: the payoff is the
 * Module 6 wall, where the agent fails without it. Nils Vane ("The Snowplow") is
 * used as the example because he is not a scored answer.
 */

/** @type {import("./types").Module} */
export const m4 = {
  id: "m4",
  seq: 4,
  phase: "Phase · Ground",
  title: "Ground it with Cortex Search",
  blocks: [
    {
      kind: "prose",
      text:
        "{{skill:/search-optimization}} So far everything you've built is *structured* — tables, " +
        "joins, metrics you can compute. But some of the most interesting questions (\u201cwho's the " +
        "player they call the snowplow?\u201d) are answered by *text*, not math. Cortex Search is that " +
        "second kind of tool. You'll **stand it up now** and put it to work in Module 6 — where " +
        "you'll first watch your agent hit a wall without it.",
    },
    {
      kind: "callout",
      text:
        "**Behind the scenes:** asking for a Cortex Search service invokes the " +
        "`/search-optimization` skill — the packaged workflow that creates and indexes the " +
        "service correctly. Watch it load in the panel.",
    },
    {
      kind: "prose",
      text:
        "The lore lives in the free-text bios in `PLAYER_PROFILES` — build a Cortex Search " +
        "service over it, in your own build schema:",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Create a Cortex Search service called PLAYER_SEARCH in my build schema " +
        "(SNOWCUP_BUILDS.{{fillin}}) over the player bios in " +
        "SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES — index the BIO text and keep PLAYER_NAME, " +
        "NATION, POSITION and NICKNAME as attributes. Build it on my warehouse SNOWCUP_WH with a " +
        "target lag of 30 days (the data is static). Confirm when it has finished building. " +
        "(We'll test it through the agent in the next module, so you can feel the difference it " +
        "makes.)",
    },
    {
      kind: "callout",
      text:
        "**Why a search service, not just another column?** You can't filter a table for \u201ca " +
        "haunting poacher defenders never see coming\u201d — there's no such column, and the " +
        "descriptive bios aren't even in your semantic view. Search reads that free text and " +
        "finds a player by *meaning*. It's also how agents resolve messy, high-cardinality text " +
        "in the real world — customer names, SKUs, support tickets. Hold that thought; Module 6 " +
        "is where it pays off.",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**Where do your answers hide in free text?** Support tickets, contract clauses, " +
        "physician notes, inspection reports, customer reviews, incident write-ups, call " +
        "transcripts. Those are your player bios — the questions nobody can answer with a " +
        "`WHERE` clause.",
    },
    {
      kind: "quiz",
      ref: "m4.q1",
      text:
        "Why can a semantic view not answer a question like *who is described as a clinical poacher*?",
      options: [
        "The semantic view has no warehouse attached",
        "There is no such column - the description lives in free text that is not modelled",
        "Cortex Analyst cannot sort text values",
      ],
    },
    {
      kind: "quiz",
      ref: "m4.q2",
      text:
        "In your own work, what plays the role the player bios play here?",
      options: [
        "Your fact tables and their measures",
        "Your existing BI dashboards",
        "Free text - tickets, clinical notes, contracts, inspection reports, call transcripts",
      ],
    },
    {
      kind: "checkpoint",
      key: "m4.checkpoint",
      text:
        "**Checkpoint:** `PLAYER_SEARCH` exists in your build schema and has finished building. " +
        "(You won't query it directly yet — that's the reveal in Module 6.)",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[Cortex Search](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-search/cortex-search-overview) — how search reads meaning in prose that was never modelled",
          "[CREATE CORTEX SEARCH SERVICE](https://docs.snowflake.com/en/sql-reference/sql/create-cortex-search) — the DDL and its indexing options",
          "[Query a Cortex Search Service](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-search/query-cortex-search-service) — querying it directly, outside an agent",
        ],
      },
  ],
}
