/**
 * Module 6 — Assemble your agent.
 *
 * The largest module, and structured around a deliberate failure: the agent is
 * built with the semantic view as its ONLY source of answers, sent at a question
 * the numbers cannot reach, and only then given search. The wall is the lesson,
 * so do not "fix" the ordering by adding search earlier.
 *
 * Nils Vane ("The Snowplow") is used throughout because he is not a scored
 * answer. The same is true of the snow fox example near the end.
 */

/** @type {import("./types").Module} */
export const m6 = {
  id: "m6",
  seq: 6,
  phase: "Phase · Assemble",
  title: "Assemble your agent",
  blocks: [
    {
      kind: "prose",
      text:
        "{{skill:/cortex-agent}} Now wire your semantic view into an agent — with **one data tool " +
        "and nothing else**. (You'll attach the chart tool at the same time, but a chart only draws " +
        "what another tool fetched, so the semantic view is the agent's *only* way to reach an " +
        "answer.) You'll take it for a spin, find the question it *can't* answer, and only then add " +
        "a second *kind* of tool. That gap is the whole point of this module.",
    },
    {
      kind: "callout",
      text:
        "**Behind the scenes:** creating and editing the agent invokes the `/cortex-agent` skill — " +
        "it wires the tools, resources, and orchestration instructions for you. You'll see it load " +
        "each time you add or change a tool.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Create a Cortex Agent called SNOWCUP_AGENT with two tools: my SNOWCUP_ANALYTICS semantic " +
        "view for stats questions, and the built-in chart tool. Set its orchestration model to " +
        "claude-sonnet-5. Attach my warehouse (SNOWCUP_WH) to the semantic-view tool as its " +
        "execution environment so it can run the SQL it generates. First show me the plan — the " +
        "tools and the instructions — and wait for my OK. Then write plain-English tool " +
        "descriptions and orchestration so it sends number and stat questions to the semantic view " +
        "and draws a chart whenever I ask. (No search tool yet — that's deliberate.)",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Give the analyst tool a warehouse.** A Cortex Analyst (text-to-SQL) tool *runs* the SQL " +
        "it writes, so it needs a warehouse declared as its `execution_environment` in the agent " +
        "spec. If you skip it, the agent is created fine but fails at runtime with *\u201ctool … is " +
        "missing execution_environment in tool_resources.\u201d* Ask CoCo to set `execution_environment` " +
        "= `{ \u201ctype\u201d: \u201cwarehouse\u201d, \u201cwarehouse\u201d: \u201cSNOWCUP_WH\u201d }` on the semantic-view tool (your custom " +
        "tool needs the same).",
    },
    { kind: "heading", text: "Take it for a spin — then find the wall" },
    {
      kind: "prose",
      text:
        "Open your agent (in Snowsight: **AI & ML » Agents » SNOWCUP_AGENT**). First, the questions " +
        "it's built for — pure computation over your model:",
    },
    {
      kind: "list",
      items: [
        "*\u201cWho covered the most distance in the 2022 edition?\u201d* → it computes it.",
        "*\u201cWho made the most passes across all editions?\u201d* → a clean aggregate.",
      ],
    },
    {
      kind: "prose",
      text: "Now ask it something the numbers can't reach — a player defined by *story*, not a stat:",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type (or ask your agent)",
      text:
        "There's a forward they call the snowplow — the spearhead of the side that lifted the 2026 " +
        "trophy. Who is he, and what's the story behind that nickname? Just name the one player.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Watch it hit the wall.** Cortex Analyst writes SQL over your *modeled columns* — and " +
        "there is no nickname or bio anywhere in your semantic view, because that text lives only " +
        "in `PLAYER_PROFILES`. So watch carefully what it does with the half it can't reach. " +
        "Typically it will narrow down a *candidate* by elimination — \u201cCirrus's only forward in " +
        "2026\u201d — and then tell you plainly that the story behind the nickname isn't in the data it " +
        "has. Sometimes it goes further and substitutes the nearest metric it *does* have, naming " +
        "the wrong player with a confident statistical justification. Either way, notice what's " +
        "missing: **it cannot show you the sentence that actually answers the question**, because " +
        "it has never seen one. That's not a model problem — it's a *wrong-tool* problem.",
    },
    { kind: "heading", text: "Give it a second kind of tool" },
    { kind: "prose", text: "You already built the fix in Module 4. Now plug it in:" },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Add my PLAYER_SEARCH service to SNOWCUP_AGENT as a second tool. Update the orchestration " +
        "so stat, count, and ranking questions go to the SNOWCUP_ANALYTICS semantic view, and " +
        "description, story, or nickname questions go to PLAYER_SEARCH — and for a question that " +
        "mixes lore and stats, use search to find the player first, then the semantic view for the " +
        "number. Show me the change before you apply it.",
    },
    { kind: "prose", text: "Now ask the *exact same* snowplow question again:" },
    {
      kind: "prompt",
      label: "In Cortex Code, type (or ask your agent)",
      text:
        "Same question: who's the forward they call the snowplow — the spearhead of the side that " +
        "lifted the 2026 trophy — and what's the story behind the nickname? Just name the one player.",
    },
    {
      kind: "callout",
      variant: "green",
      // References challenge Q8 by nickname to teach why lore + stats need two
      // tools. The nickname IS the question (Q8 asks who is called this), and no
      // answer appears here -- Class A still applies to this block and passes.
      // Flagged permitted so the reference is deliberate rather than something a
      // future edit "fixes" by weakening the scanner.
      allowScoredAnswers: true,
      text:
        "**That's the reveal.** This time it routes to search, finds **Nils Vane**, and hands back " +
        "the actual bio — \u201cThe Snowplow of Cirrus… a powerful, clinical forward and a mainstay of " +
        "Cirrus's 2026 title run.\u201d Same agent, same question, completely different *kind* of value: " +
        "the semantic view **computes an answer from numbers**; search **retrieves the passage that " +
        "says it**. Neither replaces the other — and the agent's real skill is knowing which one a " +
        "question needs. (Challenge Q8, \u201cThe Iceman,\u201d needs *both*: search to catch the reputation, " +
        "the semantic view to confirm the numbers back it up.)",
    },
    { kind: "heading", text: "Give it a custom tool — package a workflow" },
    {
      kind: "prose",
      text:
        "Some things are neither a query nor a lookup — they're a *process* you'd run the same way " +
        "every time. A **custom tool** — a stored procedure or UDF you wire into the agent — wraps " +
        "that process into one call the agent can invoke. Here you'll build a `SCOUTING_REPORT` " +
        "procedure: given a player, it pulls their stats *and* their bio and writes a formatted " +
        "report — and it's how you fold generative AI into an agent *deliberately*, behind a prompt " +
        "you control instead of leaving it to improvise.",
    },
    {
      kind: "callout",
      text:
        "**Watch the vocabulary here.** A **custom tool** is your own procedure or function " +
        "attached to an agent — that's what you're building. Snowflake also has a separate feature " +
        "literally called an *agent skill* (a packaged `SKILL.md` bundle of instructions and " +
        "scripts), and CoCo's own `/semantic-view`-style **skills** are a third thing again. All " +
        "useful; all different. Say \u201ccustom tool\u201d for what you're about to create and you'll stay " +
        "aligned with the docs.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Create a stored procedure called SCOUTING_REPORT(player_name) in my build schema " +
        "SNOWCUP_BUILDS.{{fillin}}. It should pull that player's total goals, assists, shots, xG, " +
        "late goals and minutes from SNOWCUP_SHARED.TOURNAMENT.PLAYER_MATCH_STATS, plus their bio " +
        "from PLAYER_PROFILES, then call AI_COMPLETE (use the claude-sonnet-5 model) to write a " +
        "short markdown scouting report with sections Overview, Playing style, Standout number, and " +
        "a one-line Verdict. Tell it to use only the stats provided and never invent numbers, and " +
        "handle an unknown name gracefully. Show me the SQL before you run it.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Add SCOUTING_REPORT to SNOWCUP_AGENT as a custom tool. Describe it as generating a written " +
        "scouting report for a named player, and update the orchestration so requests like " +
        "\u201cscouting report on X\u201d, \u201cprofile of Y\u201d, or \u201cwrite up player Z\u201d call it. Because it's a stored " +
        "procedure, set its execution environment to my warehouse SNOWCUP_WH so the agent can run " +
        "it. Show me the change before you apply it.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type (or ask your agent)",
      text: "Give me a scouting report on Nils Vane.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**A third kind of value.** Analyst answers \u201chow many,\u201d search answers \u201cwho's described " +
        "as\u201d — a custom tool delivers \u201cgive me the finished thing.\u201d You've wrapped a repeatable, " +
        "governed workflow (fetch the numbers + fetch the text + synthesize) into one tool the " +
        "agent — and anyone — can reuse, with the AI prompt locked down so the output is consistent " +
        "instead of improvised. That's the leap from an agent that *answers* to one that *does " +
        "work*. (The SnowCup Referee that grades you in Module 9 is built exactly this way — a " +
        "stored procedure wired in as a custom tool.)",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**What write-up does someone rebuild by hand every week?** A QBR account summary, an " +
        "incident postmortem, a credit memo, a patient handoff, a supplier scorecard, a listing " +
        "description. That repeatable \u201cpull the numbers, pull the notes, write it up\u201d chore is your " +
        "first custom tool.",
    },
    { kind: "heading", text: "The rest of the toolbox — and knowing when to stop" },
    {
      kind: "prose",
      text:
        "Your agent now has four tools: the semantic view, charts, search, and your custom tool. " +
        "Cortex offers a couple more you didn't need here — worth knowing so you reach for them " +
        "*only* when a real question demands it:",
    },
    {
      kind: "table",
      head: ["Tool", "What it's for", "Reach for it when…"],
      rows: [
        [
          "**Code execution**",
          "Runs Python for math the semantic view can't express — regressions, custom stats, " +
            "what-if models.",
          "A question needs computation beyond SQL aggregates. Skip it if Analyst already covers " +
            "the math.",
        ],
        [
          "**Web search**",
          "Pulls live facts from the public web.",
          "The answer lives *outside* your data. **Off for the SnowCup** — it's a closed, " +
            "fictional dataset — and it needs account enablement.",
        ],
      ],
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Tool discipline:** every tool you add is another door the router can pick wrong. Add one " +
        "only when a real question needs it, give it a sharp \u201cwhen to use / when not\u201d description, " +
        "and prune tools that overlap. A lean, well-described toolset routes more accurately than a " +
        "kitchen sink.",
    },
    { kind: "heading", text: "Tell it how to answer" },
    {
      kind: "prose",
      text:
        "Tool routing decides *where* the agent looks; **response instructions** decide how it " +
        "behaves once it's there. This is where an agent goes from \u201cworks\u201d to trustworthy — how it " +
        "talks, what it does when a question is fuzzy, and what it does when the answer simply " +
        "isn't in the data.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Add response instructions to SNOWCUP_AGENT. Give it a concise, factual persona for SnowCup " +
        "analytics. It should answer only from its tools and never invent a stat — if the data can't " +
        "answer, say so plainly. When a question is ambiguous (a nickname it can't resolve, or no " +
        "edition specified), ask one clarifying question instead of guessing. For number answers, " +
        "state the figure and the player or nation it belongs to; when asked for a ranking, show the " +
        "top few, not just the winner. Make its answers **verifiable**: when it answers from the " +
        "semantic view, show the SQL it ran; when it answers from a bio, quote the exact phrase it " +
        "found. Show me the instructions before you apply them.",
    },
    {
      kind: "callout",
      text:
        "**Why this matters as much as the model:** a confident wrong answer and a \u201cjust guess\u201d " +
        "habit are how agents lose trust. Verified queries guard the SQL; these instructions guard " +
        "the *conversation* — grounding answers in the tools, and turning \u201cI'm not sure\u201d into a " +
        "clarifying question instead of a fabrication. And an answer that *shows its work* — the " +
        "SQL it ran, the bio line it quoted — is one a user can check, which is how trust gets " +
        "earned instead of assumed.",
    },
    { kind: "heading", text: "Make the charts sing" },
    {
      kind: "prose",
      text:
        "The chart tool is wired in — but a great agent doesn't wait to be asked. It *reaches* for " +
        "a chart whenever one makes the answer land, and picks the right kind. Teach it your " +
        "charting taste:",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Update SNOWCUP_AGENT's instructions so it visualizes proactively. When a question is a " +
        "ranking or \u201ctop N\u201d, return a **bar chart** alongside the number; for anything across the " +
        "three tournament editions, use a **line chart**; for a split by nation or position, a " +
        "grouped or stacked bar. Every chart should be sorted, titled, and axis-labeled, and capped " +
        "at the top ~10 rows so it stays readable. When a single number fully answers the question, " +
        "skip the chart rather than forcing one. Show me the change before applying it.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**Why proactive charts win in CoWork:** the people using your agent are reading, not " +
        "writing SQL — a sorted, labeled bar chart answers \u201cwho's on top?\u201d at a glance, where a " +
        "wall of rows makes them work for it. Choosing the view that makes the answer obvious is " +
        "part of what makes an agent feel great to use.",
    },
    { kind: "heading", text: "The car, the road, and the speed limit" },
    {
      kind: "prose",
      text:
        "A *fast* answer isn't a good answer — and the instinct when an agent feels slow is to reach " +
        "for a \u201cfaster car\u201d (a bigger model). Resist it. **How fast you can safely drive depends on " +
        "the road, not the car** — a sports car on a fogged-over dirt road still crawls and crashes " +
        "harder. The model is the car; your semantic view is the road, and unlike real life, **you " +
        "get to build the road.** Everything from Modules 3–5 *is* that road:",
    },
    { kind: "figure", name: "car-road" },
    {
      kind: "table",
      head: ["Road feature", "What you built", "What it buys the agent"],
      rows: [
        [
          "**Paved lanes**",
          "Tables modeled in the semantic view (M3)",
          "It stops off-roading across joins.",
        ],
        [
          "**Road signs**",
          "Synonyms — \u201ckeeper\u201d, \u201cnation\u201d (M3)",
          "It recognizes the destination in the user's own words.",
        ],
        [
          "**Guardrails on the curves**",
          "Verified queries (M5)",
          "It can't fly off the cliff on the questions that matter most.",
        ],
        [
          "**Gated metrics**",
          "\u201cClutch\u201d, \u201cxG overperformance\u201d defined once (M3)",
          "It computes the real metric, not one it invents.",
        ],
        ["**A working GPS**", "The semantic layer itself", "It always knows where it is and how things connect."],
        [
          "**The speed limit**",
          "`auto` or a pinned model + fuel & time budget (this module)",
          "You set how fast vs. how carefully it drives.",
        ],
      ],
    },
    { kind: "heading", text: "Set your speed limit" },
    {
      kind: "prose",
      text:
        "A speed limit is a deliberate governor you set based on the road. In an agent it's " +
        "**three dials**:",
    },
    {
      kind: "list",
      items: [
        "**Model choice** is the *car itself* — engine class *and* how far the headlights reach, " +
          "because the **context window comes bundled with the model**. Too small an engine and it " +
          "can't see enough road to plan the turn.",
        "**Token / spend budget** is the **gas in the tank** — how far it can travel before it " +
          "strands you mid-journey, and what the trip costs.",
        "**Duration / timeout** is **how long you'll let it drive** before it pulls over (too short " +
          "and it takes the first exit that looks right).",
      ],
    },
    {
      kind: "prose",
      text:
        "`auto` **is the usual answer — this workshop is a deliberate exception.** Snowflake's " +
        "recommended setting for an agent's orchestration model is literally `auto`: Cortex picks " +
        "the best model available to your account, and your agent improves as new models ship " +
        "without you touching the spec. Reach for a pin only when you have a concrete reason — a " +
        "cost ceiling, a latency target, or *reproducibility*. That last one is why you pinned " +
        "`claude-sonnet-5` a moment ago: everyone in this room is running the same engine, so when " +
        "we compare results the model isn't a variable, and nobody's agent quietly changes " +
        "behaviour mid-session because `auto` resolved differently. **The SnowCup Referee that " +
        "grades you is pinned to the same model, for the same reason.** Now notice how the " +
        "headlights come *with* the car:",
    },
    {
      kind: "table",
      head: ["Engine class", "Model", "Headlights (context)", "Best for"],
      rows: [
        [
          "**Let Snowflake pick**",
          "`auto`",
          "varies",
          "**The recommended default.** Highest-quality model available to your account, updated " +
            "for you.",
        ],
        [
          "**Compact**",
          "`claude-haiku-4-5`",
          "200K",
          "Low-latency, high-throughput. Cheapest sensible pin for a well-modeled semantic view.",
        ],
        [
          "**Mid-size**",
          "`openai-gpt-5.1`",
          "272K",
          "A non-Claude option if you want to compare families.",
        ],
        [
          "**Sports**",
          "`claude-sonnet-4-5`",
          "200K",
          "Solid agentic default — good tool use and reasoning.",
        ],
        [
          "**Sports**",
          "`claude-sonnet-5`",
          "1M",
          "**What this workshop pins — yours and the Referee's.** Strong agentic work and huge " +
            "inputs, cheaper/faster than Opus.",
        ],
        [
          "**Heavy hauler**",
          "`claude-opus-4-8`",
          "1M",
          "Deepest reasoning, long-horizon agentic workflows.",
        ],
      ],
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Three gotchas before you pick an engine.** **Not every Cortex model can orchestrate an " +
        "agent** — agents run on the Claude, GPT, Grok and Gemini families. Small open-source " +
        "models like `mistral-7b` and `llama3.1-8b` are great for an `AI_COMPLETE` call inside a " +
        "tool (your `SCOUTING_REPORT` procedure could use one), but they are *not* valid " +
        "orchestration models — so \u201cjust pick the tiniest engine\u201d isn't an option here. " +
        "**Availability varies by region** — the models above are reachable through *cross-region " +
        "inference*, which your facilitator already enabled. And **don't ship on a preview model**: " +
        "some of the very largest engines on the lot are still in preview, and preview models " +
        "aren't supported for production workloads. Ask CoCo for the current GA list before you " +
        "commit.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Show me SNOWCUP_AGENT's orchestration model and its token and max-duration settings, and " +
        "explain each one as a \u201cspeed limit\u201d — the model is the car (engine class plus the context " +
        "window its headlights reach), the token/spend budget is the gas in the tank, and the " +
        "timeout is how long it drives before pulling over. Confirm it is pinned to claude-sonnet-5 " +
        "rather than auto, and explain the trade-off between pinning for reproducibility and " +
        "leaving it on auto to inherit future improvements. Then, because SNOWCUP_ANALYTICS is " +
        "well-modeled, recommend the tightest token and duration budget that still answers my " +
        "warm-up questions correctly. Only suggest models that Cortex Agents actually supports for " +
        "orchestration. Show me the change and wait for my OK before applying it.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**The punchline:** the better the road, the lower you can set every dial and still arrive " +
        "on time. **You don't tune the speed limit to fix a bad road — you fix the road so the " +
        "speed limit stops mattering.**",
    },
    { kind: "heading", text: "Put it all together" },
    {
      kind: "prose",
      text:
        "With both tools wired and your speed limit set, confirm the agent routes cleanly across " +
        "every kind of question (in Snowsight: **AI & ML » Agents » SNOWCUP_AGENT**):",
    },
    {
      kind: "list",
      items: [
        "*\u201cChart the top 5 players by total passes.\u201d* — semantic view + the chart tool.",
        "*\u201cWho's the forward they call the snow fox — and has he ever played in a SnowCup?\u201d* — " +
          "search catches the nickname, then the semantic view honestly reports that he has no " +
          "tournament appearances at all.",
        "*\u201cWrite a scouting report on the 2018 top scorer.\u201d* — the semantic view finds who, then " +
          "your `SCOUTING_REPORT` custom tool composes stats + bio into the write-up.",
      ],
    },
    {
      kind: "quiz",
      ref: "m6.q1",
      text:
        "Your agent is created successfully but its Analyst tool fails when used. What is the most likely cause?",
      options: [
        "The orchestration model cannot orchestrate agents",
        "The Analyst tool has no warehouse declared as its execution environment",
        "The semantic view is missing synonyms",
      ],
    },
    {
      kind: "quiz",
      ref: "m6.q2",
      text:
        "What does *the road, not the car* mean when an agent feels slow or unreliable?",
      options: [
        "Raise the token budget until the behaviour settles",
        "Move to a bigger model first, then tune the data",
        "Improve the model, synonyms and verified queries - then even low settings arrive on time",
      ],
    },
    {
      kind: "checkpoint",
      key: "m6.checkpoint",
      text:
        "**Checkpoint:** your agent answered a pure stat question, hit the wall when the semantic " +
        "view was its only source of answers, and — once you added `PLAYER_SEARCH` and the " +
        "`SCOUTING_REPORT` custom tool — now computes numbers, retrieves lore, *and* produces a " +
        "written report, routing each question to the right tool.",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[Cortex Agents](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents) — how orchestration, tools and agent instructions fit together",
          "[CREATE AGENT](https://docs.snowflake.com/en/sql-reference/sql/create-agent) — the full agent spec in DDL, including display_name and sample_questions",
          "[Cortex Agents Run API](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-run) — where tool_resources and execution_environment are documented - the warehouse your Analyst tool needed",
        ],
      },
  ],
}
