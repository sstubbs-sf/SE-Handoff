/**
 * Content registry — the single source of truth for lab content.
 *
 * Consumed by three things that must never disagree:
 *   1. the Next.js renderer (what learners read)
 *   2. LAB_STEPS in Snowflake (what progress rows are allowed to exist)
 *   3. verify/check_leaks.py, via scripts/dump-content.mjs (leak scanning)
 *
 * Modules are added here as they are ported. `validateAll` runs at import time
 * so a malformed block fails fast at build, test and scan time rather than
 * rendering wrongly for a learner.
 */
import { validateAll, stepsOf } from "./validate.mjs"
import { m0 } from "./m0.mjs"
import { m1 } from "./m1.mjs"
import { m2 } from "./m2.mjs"
import { m3 } from "./m3.mjs"
import { m4 } from "./m4.mjs"
import { m5 } from "./m5.mjs"
import { m6 } from "./m6.mjs"
import { m7 } from "./m7.mjs"
import { m8 } from "./m8.mjs"
import { m9 } from "./m9.mjs"
import { m10 } from "./m10.mjs"

/**
 * Which training this app delivers.
 *
 * THE ONE CONSTANT A NEW TRAINING CHANGES. Every progress row, activity row and
 * challenge row is keyed by this id, so it is what separates one training's
 * results from another's. It matches MODULE_ID in SNOWCUP_WORKSHOP.GRADING and
 * must have a matching row in the MODULES registry, or the deploy's health check
 * will fail rather than let learners tick checkpoints into a void.
 *
 * It lives here, beside the content it describes, and is read server-side only --
 * never accepted from a request body, since forging it would write into another
 * training's results.
 */
export const TRAINING = Object.freeze({
  id: "SNOWCUP",
  title: "SnowCup — Build an Agent",
})

/** All 11 modules, ordered by seq. */
export const MODULES = validateAll([m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10])

/** Flat checkpoint registry: seeds LAB_STEPS and drives progress rendering. */
export const STEPS = stepsOf(MODULES)

export { validateAll, stepsOf }
