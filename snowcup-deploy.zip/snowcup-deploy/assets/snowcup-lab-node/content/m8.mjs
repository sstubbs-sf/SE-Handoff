/**
 * Module 8 — Evaluate, measure your accuracy.
 *
 * Note the deliberate instruction to ground-truth against questions the learner
 * can verify themselves, explicitly NOT the hidden challenge answers. Keep that
 * framing if this module is edited.
 */

/** @type {import("./types").Module} */
export const m8 = {
  id: "m8",
  seq: 8,
  phase: "Phase · Evaluate",
  title: "Evaluate — measure your accuracy",
  blocks: [
    {
      kind: "prose",
      text:
        "You can't improve accuracy you don't measure. Check two layers: **Cortex Analyst** (does " +
        "it write the *right SQL*?) and the **agent** (does it pick the *right tool* and answer " +
        "correctly?). You'll set both up by just asking CoCo in plain English, exactly like the " +
        "prompts below.",
    },
    {
      kind: "callout",
      text:
        "**No packaged skill for this one.** Every other phase names a CoCo skill doing the heavy " +
        "lifting; evaluation runs straight through the CoCo chat instead. Nothing is missing — " +
        "you're driving Snowflake's native evaluation features directly.",
    },
    { kind: "heading", text: "Step 1 · Build a small evaluation set" },
    {
      kind: "prose",
      text:
        "Pick 6–8 questions whose correct answer *you* can confirm with a quick query — e.g. " +
        "\u201chow many matches were played in 2026?\u201d, \u201cwhich nations scored the most total goals?\u201d, or " +
        "the verified query you saved in Module 5. (You're testing your *model* here, so use " +
        "questions you can ground-truth yourself — not the hidden challenge answers.)",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Help me build a small evaluation set for SNOWCUP_ANALYTICS. I'll give you a few " +
        "questions I can check the answers to myself (like \u201chow many matches were played in " +
        "2026?\u201d). For each one, write the correct SQL and save the question-and-answer pair as an " +
        "evaluation example. Keep every question pinned to a specific edition or nation — never " +
        "\u201crecently\u201d — so the correct answer can't drift over time.",
    },
    { kind: "heading", text: "Step 2 · Run the evaluations" },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Run an evaluation of SNOWCUP_ANALYTICS against its verified queries. Show me the overall " +
        "SQL-correctness score and, more importantly, list exactly which questions failed and " +
        "what the generated SQL got wrong.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Now evaluate the whole SNOWCUP_AGENT on my evaluation set. Check whether it picked the " +
        "right tool for each question and whether the final answer was correct, and show me the " +
        "cases where it went wrong and why.",
    },
    { kind: "heading", text: "Step 3 · Inspect, fix, re-run" },
    {
      kind: "prose",
      text:
        "For each failure, find the cause — a missing synonym, an undefined metric, a bad join, " +
        "or a vague tool description — fix it (often by adding a verified query), then re-run the " +
        "evaluation to confirm the score went up and nothing else regressed.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**The #1 evaluation mistake:** relative dates. \u201cThis tournament\u201d or \u201clast quarter\u201d makes " +
        "the correct answer move over time, so your evals silently lie. Always pin eval questions " +
        "to absolute values.",
    },
    {
      kind: "quiz",
      ref: "m8.q1",
      text:
        "Which two layers does the lab have you evaluate?",
      options: [
        "The warehouse size and the orchestration model",
        "Analyst's SQL correctness, and the agent's tool choice and final answer",
        "The semantic view and the search service",
      ],
    },
    {
      kind: "quiz",
      ref: "m8.q2",
      text:
        "What is the single most common evaluation mistake?",
      options: [
        "Relative dates, which make the correct answer move over time",
        "Using too few questions in the set",
        "Including questions the agent already gets right",
      ],
    },
    {
      kind: "checkpoint",
      key: "m8.checkpoint",
      text:
        "**Checkpoint:** you have an eval set, ran at least one evaluation, fixed one failing " +
        "question, and re-ran to confirm the lift.",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[Cortex Analyst evaluations](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst-evaluations) — the sql_correctness layer, including the absolute-dates warning",
          "[Cortex Agent evaluations](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-evaluations) — the tool-choice and final-answer layer",
          "[AI Observability in Snowflake Cortex](https://docs.snowflake.com/en/user-guide/snowflake-cortex/ai-observability) — tracing and comparing runs over time",
        ],
      },
  ],
}
