/**
 * Module 9 — Beat the challenge.
 *
 * The only module that legitimately contains scored question wording, which is
 * why every `question` block sets allowScoredAnswers. The submit example uses
 * "Sam Frostley", a name that is deliberately NOT one of the eight answers, so
 * the format can be shown without giving anything away.
 */

/** @type {import("./types").Module} */
export const m9 = {
  id: "m9",
  seq: 9,
  phase: "Prove it",
  title: "Beat the challenge",
  blocks: [
    {
      kind: "prose",
      text:
        "Time to score. Below are the **8 challenge questions** — 4 tiers, 120 points. You'll use " +
        "**two different agents**:",
    },
    {
      kind: "table",
      head: ["Agent", "Role"],
      rows: [
        [
          "**SNOWCUP_AGENT** (the one you built)",
          "Find each answer. Ask it the challenge question in plain language.",
        ],
        [
          "**SnowCup Referee** (pre-built, shared with you)",
          "Grade & record. Submit your answer to it and it tells you if you're right + your score.",
        ],
      ],
    },
    { kind: "heading", text: "The questions" },
    {
      kind: "prose",
      text:
        "Answer format is a single **player name** or **nation**; case, spacing, punctuation and " +
        "common short forms are forgiven (so `sam frostley`, `Sam Frostley` and `Frostley` would " +
        "all match).",
    },

    {
      kind: "tier",
      tier: 1,
      label: "Tier 1 · Warm-up",
      note: "Single-table lookups — 10 points each",
    },
    {
      kind: "question",
      id: "Q1",
      points: 10,
      allowScoredAnswers: true,
      text:
        "Who won the Golden Boot at the 2026 SnowCup — the player who scored the most goals in " +
        "the 2026 edition?",
      why: "**Why it matters:** gets you querying goals scoped to a single edition.",
      exercises: "Exercises · Explore + Model",
    },
    {
      kind: "question",
      id: "Q2",
      points: 10,
      allowScoredAnswers: true,
      text: "Which nation has won the most SnowCup titles across all editions?",
      why: "**Why it matters:** a quick aggregate over the tournaments table.",
      exercises: "Exercises · Explore",
    },

    {
      kind: "tier",
      tier: 2,
      label: "Tier 2 · Multi-hop joins",
      note: "Answers live across tables — 15 points each",
    },
    {
      kind: "question",
      id: "Q3",
      points: 15,
      allowScoredAnswers: true,
      text: "Which defender set up the most goals in knockout matches without taking a single shot?",
      why:
        "**Why it's hard:** joins position, match stage, assists and shots across three tables. " +
        "Trivial for an agent over a good model; tedious by hand.",
      exercises: "Exercises · Model (relationships)",
    },
    {
      kind: "question",
      id: "Q4",
      points: 15,
      allowScoredAnswers: true,
      text: "Which goalkeeper kept the most clean sheets across all three editions?",
      why:
        "**Why it's hard:** a \u201cclean sheet\u201d isn't a column — it's derived from whether the " +
        "keeper's nation conceded zero in a match they played.",
      exercises: "Exercises · Model (derived logic)",
    },

    {
      kind: "tier",
      tier: 3,
      label: "Tier 3 · Business language",
      note: "Only solvable if your model defines the metric — 20 points each",
    },
    {
      kind: "question",
      id: "Q5",
      points: 20,
      allowScoredAnswers: true,
      text: "Who was the biggest \u201cclutch\u201d performer of the SnowCup?",
      why:
        "**Why it's hard:** there is no `clutch` column. It only resolves if your semantic view " +
        "defines clutch as *late goals in one-goal-margin knockout matches*. That's the teachable " +
        "moment.",
      exercises: "Exercises · Model (named metric + synonym)",
    },
    {
      kind: "question",
      id: "Q6",
      points: 20,
      allowScoredAnswers: true,
      text:
        "Which nation had the highest xG overperformance — scoring the most goals above its " +
        "expected goals (xG)?",
      why:
        "**Why it's hard:** needs a derived metric (`SUM(GOALS) − SUM(XG)`) aggregated by nation. " +
        "Bonus: have your agent **chart** the top 5.",
      exercises: "Exercises · Model (metric) + Chart tool",
    },

    {
      kind: "tier",
      tier: 4,
      label: "Tier 4 · Lore & search",
      note: "Find them by story, not by stat — 15 points each",
    },
    {
      kind: "question",
      id: "Q7",
      points: 15,
      allowScoredAnswers: true,
      text: "Find the player nicknamed \u201cThe Whiteout.\u201d",
      why:
        "**Why it's hard:** the lore lives in free-text player bios. Your **Cortex Search** " +
        "service is what lets the agent find a player by description, not by a numeric filter.",
      exercises: "Exercises · Ground (Cortex Search)",
    },
    {
      kind: "question",
      id: "Q8",
      points: 15,
      allowScoredAnswers: true,
      text:
        "Name the tournament villain nicknamed \u201cThe Iceman\u201d — the most-carded, most-foul-prone " +
        "player in SnowCup history.",
      why:
        "**Why it's hard:** combines a lore lookup (the nickname) with a discipline aggregate — a " +
        "great test of search + analyst working together.",
      exercises: "Exercises · Ground + Model",
    },

    { kind: "heading", text: "Submit an answer" },
    {
      kind: "prose",
      text:
        "Open the Referee — in CoWork at `https://ai.snowflake.com`, or from **AI & ML » Agents » " +
        "SnowCup Referee** in Snowsight — and submit by question ID:",
    },
    { kind: "prompt", label: "In the Referee agent, type", text: "Q1: Sam Frostley" },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Don't see the SnowCup Referee?** Ask your admin to grant you your {{role}} " +
        "role, then refresh.",
    },
    {
      kind: "prose",
      text:
        "It replies whether you're correct and your running score. Retries are unlimited and " +
        "there's no penalty — but no hints. Each question counts **once**: re-submitting one you " +
        "already got right won't add points (or take any away), so you can safely re-check your " +
        "work. Check your standing anytime:",
    },
    { kind: "prompt", label: "In the Referee agent, type", text: "What's my score so far?" },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Stuck on Tier 3 or 4?** That almost always means your model is missing a metric, " +
        "synonym, or the search connection. Go back to Module 3 or 4, teach your agent the " +
        "concept, and ask again. Refining your model until the hard questions fall — that's the " +
        "whole skill.",
    },
    {
      kind: "quiz",
      ref: "m9.q1",
      text:
        "What happens if you re-submit a challenge question you already answered correctly?",
      options: [
        "It awards the points a second time",
        "It resets that question so you can try again",
        "It counts once - no points added and none taken away",
      ],
    },
    {
      kind: "quiz",
      ref: "m9.q2",
      text:
        "You are stuck on a business-language question in Tier 3. What does that usually mean?",
      options: [
        "Your model is missing a metric, a synonym, or the search connection",
        "The Referee is grading your answer incorrectly",
        "You need a larger orchestration model",
      ],
    },
    {
      kind: "checkpoint",
      key: "m9.checkpoint",
      text:
        "**Checkpoint:** submit all 8 answers to the Referee. Aim for 120/120 — then check the " +
        "*leaderboard*. **Keep every question and the answer the Referee confirmed** — you'll turn " +
        "them into permanent eval cases in the next module.",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[Best practices for modeling semantic views](https://docs.snowflake.com/en/user-guide/views-semantic/best-practices-modeling) — the reference for the gaps a hard question exposes",
          "[Cortex Analyst Verified Query Repository](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst/verified-query-repository) — teaching a question you could not otherwise land",
        ],
      },
  ],
}
