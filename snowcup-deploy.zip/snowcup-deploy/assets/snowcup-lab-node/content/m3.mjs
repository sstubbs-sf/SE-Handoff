/**
 * Module 3 — Model a semantic view.
 *
 * The highest-leverage module, and the one with the trap: a semantic-view metric
 * cannot reference a related table's columns, so "clutch" fails with
 * `invalid identifier 'MATCHES.STAGE'` unless the cross-table flags are
 * pre-computed in a plain SQL view first. That failure is taught deliberately
 * rather than worked around, because it is the lesson.
 *
 * The "good starter set" callout previews challenge-shaped questions on purpose,
 * so it carries allowScoredAnswers.
 */

/** @type {import("./types").Module} */
export const m3 = {
  id: "m3",
  seq: 3,
  phase: "Phase · Model",
  title: "Model a semantic view",
  blocks: [
    {
      kind: "prose",
      text:
        "{{skill:/semantic-view}} This is the highest-leverage step. A semantic view teaches Cortex " +
        "Analyst your tables, joins, and — crucially — your **business metrics**.",
    },
    {
      kind: "callout",
      text:
        "**Behind the scenes:** when you ask CoCo to build a semantic view, it invokes the packaged " +
        "`/semantic-view` skill — an expert workflow that knows how to declare tables, " +
        "relationships, facts, and metrics correctly. You'll see it load in the panel. You don't " +
        "have to type the slash command (though you can) — CoCo recognizes the job from your " +
        "plain-language ask.",
    },
    { kind: "heading", text: "Start with your destination questions" },
    {
      kind: "prose",
      text:
        "This is the step people skip — and it's the one that decides whether your model is any " +
        "good. **Don't model the whole warehouse and hope the agent finds its way.** Take the " +
        "question list you wrote in Module 2 and hand it to CoCo, so the model is reverse-engineered " +
        "from the *destinations* people actually want to reach. Every question tells you which " +
        "tables to join, which dimension to expose, which metric to define. No questions = you're " +
        "paving highways to nowhere.",
    },
    {
      kind: "callout",
      variant: "green",
      allowScoredAnswers: true,
      text:
        "**Write your list first.** Aim for 6–8 concrete questions, mixing easy and hard. A good " +
        "starter set (steal these, then add your own):",
      items: [
        "Who scored the most goals in the 2026 edition?",
        "Which nation has won the most SnowCup titles?",
        "Which defender set up the most goals in knockout matches without taking a shot?",
        "Who was the biggest \u201cclutch\u201d performer?",
        "Which nation had the highest xG overperformance?",
      ],
      after:
        "Notice these are exactly the shapes the challenge will test — model for them now and the " +
        "hard tiers fall out later.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Create a Cortex Analyst semantic view called SNOWCUP_ANALYTICS in my build schema " +
        "SNOWCUP_BUILDS.{{fillin}}, over the shared tables in SNOWCUP_SHARED.TOURNAMENT (PLAYERS, " +
        "MATCHES, PLAYER_MATCH_STATS, DISCIPLINE and TOURNAMENTS). Here are the specific questions " +
        "I need this model to answer: [paste your list from Module 2]. Model **backward** from " +
        "those questions — before you build, show me how each question maps to the tables, joins, " +
        "dimensions, facts, and metrics it needs, so we only model what the questions require. Then " +
        "wait for my go-ahead. Build it with the join relationships declared, a clear plain-English " +
        "description on every table and column, and synonyms for the words people actually use (for " +
        "example \u201ckeeper\u201d for goalkeeper, \u201cnation\u201d for country). Do not include PLAYER_PROFILES — " +
        "the bios belong to Cortex Search, which I build in the next module.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Watch for double-counting.** `PLAYER_MATCH_STATS` and `DISCIPLINE` are both at " +
        "player×match grain, so a naive join can multiply rows and silently inflate totals (goals, " +
        "fouls, cards). Ask CoCo to *check the relationships don't fan out — and verify a known " +
        "total, like one player's career goals, matches the raw table.*",
    },
    { kind: "heading", text: "Add the metrics the challenge needs" },
    {
      kind: "prose",
      text:
        "Two challenge questions use business language that only works if you define it. Teach the " +
        "model:",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Read this before you write \u201cclutch\u201d — it will fail the obvious way.** A semantic-view " +
        "metric can only reference columns from *its own* logical table. \u201cClutch\u201d needs " +
        "`LATE_GOALS` from `PLAYER_MATCH_STATS` *and* `STAGE`/`DECIDED_BY` from `MATCHES` — so " +
        "declaring it straight onto the stats table fails with `invalid identifier 'MATCHES.STAGE'`. " +
        "Relationships are for joining and grouping, **not** for row-level comparisons across " +
        "tables. The fix: have CoCo pre-compute the cross-table flags in a plain SQL view in your " +
        "build schema, then use *that view* as the logical table in your semantic view. The same " +
        "applies to any knockout-only metric (Q3) and to clean sheets (Q4), which needs the " +
        "keeper's nation checked against the match score.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Before adding the metrics, create a view in my build schema that joins PLAYER_MATCH_STATS " +
        "to MATCHES and PLAYERS and pre-computes the cross-table flags I need, because " +
        "semantic-view metrics can't reference a related table's columns. Include: IS_KNOCKOUT " +
        "(STAGE <> 'Group'), IS_ONE_GOAL_GAME (DECIDED_BY = 1), CLUTCH_LATE_GOALS (LATE_GOALS only " +
        "when the match is both knockout and one-goal), and CLEAN_SHEET (1 when a goalkeeper played " +
        "and the opposing side scored zero). Confirm the view has exactly the same row count as " +
        "PLAYER_MATCH_STATS so nothing fanned out, then rebuild SNOWCUP_ANALYTICS using that view " +
        "as the per-match performance table instead of PLAYER_MATCH_STATS.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Add two business metrics to SNOWCUP_ANALYTICS. The first is xG overperformance — goals " +
        "scored minus expected goals (SUM(GOALS) − SUM(XG)) — with synonyms like " +
        "\u201coverperformance\u201d, \u201cgoals above expected\u201d, and \u201cclinical finishing\u201d. The second is clutch " +
        "contributions — late goals (LATE_GOALS) scored in knockout matches that were decided by a " +
        "single goal. Remember there is no \u201cknockout\u201d value in STAGE, so knockout means STAGE <> " +
        "'Group', and a one-goal game is DECIDED_BY = 1. Give it synonyms like \u201cclutch\u201d and " +
        "\u201cbig-game goals\u201d. Also expose knockout as a reusable dimension or filter on the model so " +
        "I never have to spell that condition out again. Show me the definitions before you run " +
        "them so I can check the logic.",
    },
    {
      kind: "callout",
      text:
        "**This is the teachable moment.** \u201cClutch\u201d and \u201coverperformance\u201d aren't columns — they're " +
        "meaning you encode once, so every future answer computes them the same way. Review the DDL " +
        "CoCo proposes, confirm the join logic, then run it.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**Why the extra view is the lesson, not a workaround.** Pushing \u201cknockout\u201d and \u201cone-goal " +
        "game\u201d into a view means those definitions exist in exactly one place, and every metric " +
        "built on top inherits them. That is the same instinct as the metric itself: **define it " +
        "once, where it can't drift.** Check the row count every time — a join that fans out " +
        "inflates every number downstream and nothing will warn you.",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**Which metric does your company argue about?** Everyone has one: \u201cactive user,\u201d " +
        "\u201cqualified lead,\u201d \u201con-time delivery,\u201d \u201creadmission,\u201d \u201cchurn.\u201d If three teams compute it " +
        "three different ways, that is your first semantic-view metric — define it once and the " +
        "argument ends.",
    },
    { kind: "heading", text: "Let CoCo enrich the model for you" },
    {
      kind: "prose",
      text:
        "You don't have to think of every definition yourself. CoCo can read your model and the " +
        "underlying data and *propose* what's missing — richer descriptions, synonyms real users " +
        "would type, and derived expressions. Ask it to suggest, review each idea in plain English, " +
        "then accept the good ones.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Review SNOWCUP_ANALYTICS and propose ways to make it more complete: clearer plain-English " +
        "descriptions where any are thin or ambiguous, and missing synonyms for the everyday words " +
        "fans and analysts use (look at the actual values — \u201ckeeper\u201d/\u201cgoalie\u201d, " +
        "\u201cnation\u201d/\u201ccountry\u201d/\u201cteam\u201d, \u201cset up\u201d for assists, \u201csending off\u201d for red card). Show me the " +
        "additions as a list I can approve or reject before you change anything.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Now suggest useful derived expressions I might be missing — things like goals per 90 " +
        "minutes, shot conversion rate, or a knockout-only version of a metric — and add the ones I " +
        "approve as facts or metrics. Reusable conditions like \u201cknockout matches\u201d or \u201cone-goal " +
        "games\u201d should come from the pre-computed flags on my performance view, the way clutch " +
        "already does — don't try to reach across a relationship from inside a metric. For each, " +
        "show me the formula and which columns it uses before you add it.",
    },
    {
      kind: "callout",
      variant: "green",
      text:
        "**Why ask CoCo to suggest?** It has already read your schema and can spot the words and " +
        "cuts of data you'll forget under pressure. You stay the reviewer — approve what's right, " +
        "reject what isn't — so the model gets richer without you starting from a blank page each " +
        "time. (In Module 10 you'll see Snowflake do this *automatically* from real usage.)",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**What does your business call the same thing?** \u201cKeeper\u201d for goalkeeper is trivial; yours " +
        "won't be — churn vs. attrition vs. logo loss, SKU vs. item vs. part number, patient vs. " +
        "member vs. beneficiary, revenue vs. bookings vs. billings. Every synonym you skip is a " +
        "question your agent quietly fails to understand.",
    },
    {
      kind: "quiz",
      ref: "m3.q1",
      text:
        "Your clutch metric will not create - Analyst reports `invalid identifier 'MATCHES.STAGE'`. Which rule have you hit?",
      options: [
        "Semantic views cannot express derived metrics",
        "A metric can only reference columns from its own logical table",
        "The relationship between the tables was declared backward",
      ],
    },
    {
      kind: "quiz",
      ref: "m3.q2",
      text:
        "Why push definitions like knockout and one-goal game into a view rather than into each metric?",
      options: [
        "Views execute faster than metrics do",
        "A semantic view requires a view as its source",
        "The definition then exists in exactly one place and everything built on top inherits it",
      ],
    },
    {
      kind: "checkpoint",
      key: "m3.checkpoint",
      text:
        "**Checkpoint:** `SNOWCUP_ANALYTICS` exists with relationships, descriptions, synonyms, the " +
        "two metrics, and at least one CoCo-suggested addition (a synonym, description, or derived " +
        "metric) you reviewed. Ask CoCo to *\u201cvalidate the semantic view\u201d*.",
    },
  ],
}
