/**
 * Module 1 — Connect to the data & your build space.
 *
 * Pilot port: this module was chosen first because at 1.9 KB it is small but
 * still exercises most of the block vocabulary (prose, list, both callout
 * variants, a prompt, a checkpoint) and the {{fillin}} placeholder.
 */

/** @type {import("./types").Module} */
export const m1 = {
  id: "m1",
  seq: 1,
  phase: "Phase · Connect",
  title: "Connect to the data & your build space",
  blocks: [
    {
      kind: "prose",
      text:
        "Good news: **the data is already here**, so you go straight to building. " +
        "You'll work across two locations:",
    },
    {
      kind: "list",
      items: [
        "`SNOWCUP_SHARED.TOURNAMENT` — the shared tables you'll *read* (you can't change them).",
        "`SNOWCUP_BUILDS.{{fillin}}` — your personal *build schema*, where everything you create in this lab will live.",
      ],
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Replace {{fillin}} everywhere it appears.** That orange token is a *placeholder* — " +
        "swap it for the **exact** build-schema name your facilitator gave you (for example " +
        "`WS_JSMITH`). Every prompt below that creates or references your objects uses it, " +
        "so if something lands in the wrong place or a step fails, this is the first thing to check.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "@SNOWCUP_SHARED.TOURNAMENT — show me the tables in this schema with a couple of " +
        "sample rows each, and confirm I can read them. Then confirm I can create objects in " +
        "my build schema SNOWCUP_BUILDS.{{fillin}} (use the schema name my facilitator gave me).",
    },
    {
      kind: "callout",
      text:
        "**Two locations, two jobs:** your build schema is yours to create in; the shared data " +
        "stays untouched, so you can experiment freely without affecting anyone else.",
    },
    {
      kind: "quiz",
      ref: "m1.q1",
      text:
        "Which statement correctly describes how the shared schema and your own build schema are used?",
      options: [
        "The shared schema is read-only; your build schema is where you create things",
        "Both are read-only, so you build in a worksheet instead",
        "You copy the shared tables into your build schema first",
      ],
    },
    {
      kind: "quiz",
      ref: "m1.q2",
      text:
        "Why does the lab insist you replace the build-schema placeholder everywhere it appears?",
      options: [
        "It is cosmetic and only affects headings",
        "Every prompt that creates or references your objects uses it, so a wrong value sends work to the wrong place",
        "It is resolved automatically when the prompt runs",
      ],
    },
    {
      kind: "checkpoint",
      key: "m1.checkpoint",
      text:
        "**Checkpoint:** you can list and query the six shared tables, and you know your own " +
        "build-schema name.",
    },
  ],
}
