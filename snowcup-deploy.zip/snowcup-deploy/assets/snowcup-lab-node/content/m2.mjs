/**
 * Module 2 — Explore, and feel the pain of raw SQL.
 *
 * The hard-SQL drill deliberately asks for "most tackles in knockouts while
 * never scoring". That is NOT a scored question: Q3 asks about a defender's
 * knockout assists. Teaching on a near-miss shape gives the lesson without
 * handing over an answer.
 */

/** @type {import("./types").Module} */
export const m2 = {
  id: "m2",
  seq: 2,
  phase: "Phase · Explore",
  title: "Explore — and feel the pain of raw SQL",
  blocks: [
    {
      kind: "prose",
      text:
        "Before modeling, get a feel for the shape of the data and *why* a semantic layer will help.",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "@SNOWCUP_SHARED.TOURNAMENT — take a look at these tables. For each one, tell me in " +
        "plain English what it holds, its row count, and its key columns. Then explain how " +
        "PLAYERS, MATCHES and PLAYER_MATCH_STATS connect to each other, and help me write down " +
        "the 6–8 questions I most want this data to answer — I'll use that list to design my " +
        "semantic view in the next module.",
    },
    {
      kind: "callout",
      text:
        "**Keep that question list.** It's not busywork — those questions are your *destinations*, " +
        "and in Module 3 you'll hand them to CoCo and build the model *backward* from them. " +
        "Include a couple of genuinely awkward ones — a cross-table hop, or a \u201cmost X while never " +
        "Y\u201d — not just easy counts.",
    },
    {
      kind: "think",
      label: "In your industry",
      text:
        "**What 6–8 questions do your stakeholders actually ask you every week?** Write them down " +
        "before you model anything real. The *shape* matters more than the subject — a ranking " +
        "(\u201ctop accounts by churn risk\u201d), a derived metric (\u201con-time delivery rate\u201d), a cross-table " +
        "hop (\u201cwhich reps closed deals without ever giving a demo\u201d).",
    },
    { kind: "heading", text: "Now try a hard one by hand" },
    {
      kind: "prose",
      text:
        "Ask CoCo to write raw SQL for a deliberately awkward cross-table question — *\u201cwhich " +
        "midfielder made the most tackles in knockout matches without ever scoring?\u201d*",
    },
    {
      kind: "prompt",
      label: "In Cortex Code, type",
      text:
        "Write the raw SQL to answer this by hand: which midfielder made the most tackles in " +
        "knockout-stage matches while never scoring a goal? Walk me through each join and filter, " +
        "so I can feel how much work this is without a semantic model.",
    },
    {
      kind: "callout",
      variant: "warn",
      text:
        "**Notice the friction.** That query needs three tables, a position filter, a " +
        "`SUM(TACKLES)` ranking, a `HAVING SUM(GOALS)=0` — and a stage filter you have to " +
        "*invent*, because there's no `knockout` value to match on: you need `STAGE <> 'Group'`. " +
        "It works, but you had to know the schema cold, including which values a column actually " +
        "holds. Business users can't do this. That's the problem the next phases solve — and " +
        "\u201cknockout\u201d is your first candidate for something worth encoding once, in the model.",
    },
    {
      kind: "quiz",
      ref: "m2.q1",
      text:
        "Why write down 6-8 questions *before* modelling anything?",
      options: [
        "To fill time while the shared data loads",
        "They become your challenge questions later",
        "They are the destinations - you build the model backward from them",
      ],
    },
    {
      kind: "quiz",
      ref: "m2.q2",
      text:
        "There is no knockout value in the data - the query needs `STAGE <> 'Group'` instead. What does that tell you?",
      options: [
        "The concept you need is not a column, so you re-derive it by hand every time",
        "The data is malformed and needs cleaning",
        "Knockout matches are missing from the dataset",
      ],
    },
    {
      kind: "checkpoint",
      key: "m2.checkpoint",
      text:
        "**Checkpoint:** you can describe the six shared tables and you've seen how fiddly a " +
        "cross-table question is in raw SQL.",
    },
      {
        kind: "heading",
        text: "Go deeper",
      },
      {
        kind: "prose",
        text:
          "Official Snowflake documentation for what this module covered. These open in a "
          + "new tab, so you will not lose your place.",
      },
      {
        kind: "list",
        items: [
          "[SELECT](https://docs.snowflake.com/en/sql-reference/sql/select) — the reference for the raw SQL you just wrote by hand",
          "[Overview of semantic views](https://docs.snowflake.com/en/user-guide/views-semantic/overview) — the abstraction that removes the friction you just felt",
        ],
      },
  ],
}
