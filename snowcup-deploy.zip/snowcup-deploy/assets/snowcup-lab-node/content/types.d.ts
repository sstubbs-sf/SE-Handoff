/**
 * Content model for the SnowCup lab.
 *
 * WHY .mjs AND NOT .ts
 * Node 20 cannot strip types, so plain ES modules are importable by BOTH the
 * Next.js app and `node` directly. That matters because verify/check_leaks.py
 * asks node for the content as JSON rather than parsing source. There is no
 * generated artifact that can go stale, and no build step in the trust path of
 * the workshop's only leak guarantee.
 *
 * WHY CONTENT IS DATA AND NOT JSX
 * The leak scanner has to recover the prose a learner will read. Regex-stripping
 * JSX is unreliable (expressions, props, imports), and after the standalone HTML
 * is retired this scanner is the ONLY thing preventing a scored answer from
 * shipping to learners. Structured blocks make extraction exact, and let
 * `allowScoredAnswers` be an explicit field instead of the brittle string
 * markers the HTML version matched on.
 */

/**
 * Inline markup is a tiny deliberate subset, chosen so text extraction is a
 * handful of string replacements rather than a parser:
 *
 *   **bold**          -> strong
 *   *italic*          -> em
 *   `code`            -> inline code
 *   {{fillin}}        -> the orange WS_<yourname> placeholder
 *   [text](url)       -> link
 *   {{skill:/name}}   -> a skill chip, e.g. {{skill:/semantic-view}}
 *
 * Extend this only when a module genuinely needs it, and update
 * `extractText()` in validate.mjs at the same time, or the scanner will start
 * reading markers as prose.
 */
export type Inline = string

export type Block =
  | { kind: "prose"; text: Inline }
  | { kind: "list"; ordered?: boolean; items: Inline[] }
  | {
      kind: "callout"
      /** Maps to the existing lab styling: neutral, orange, green, red. */
      variant?: "info" | "warn" | "green" | "red"
      text: Inline
      /** Optional bullet list inside the callout. */
      items?: Inline[]
      /** Optional closing line after the list. */
      after?: Inline
      /**
       * Set only where scored question wording legitimately appears, e.g. the
       * m3 "good starter set" that previews the challenge shapes.
       */
      allowScoredAnswers?: true
    }
  | {
      kind: "prompt"
      /** The four labels the lab uses, e.g. "In Cortex Code, type". */
      label?: string
      text: Inline
    }
  | { kind: "heading"; text: Inline }
  | {
      kind: "figure"
      /** Component key, e.g. "car-road". Rendered by components/figures. */
      name: "car-road"
    }
  | {
      kind: "think"
      /** Small caps lead-in, e.g. "In your industry". */
      label?: string
      /** Reflection prompt that transfers the lesson to the learner's own work. */
      text: Inline
    }
  | { kind: "code"; lang?: string; text: string }
  | { kind: "table"; head: Inline[]; rows: Inline[][] }
  | {
      kind: "checkpoint"
      /**
       * Stable, content-defined key such as "m1.checkpoint". This is the
       * contract with LAB_STEPS and LAB_PROGRESS.
       *
       * It must NEVER be derived from position. The retired HTML generated ids
       * as `chk-<section>-<globalIndex>`, so inserting a checkpoint anywhere
       * shifted every later id and silently reassigned learners' saved progress
       * to the wrong step.
       */
      key: string
      text: Inline
    }
  | {
      kind: "tier"
      /** e.g. "Tier 1 · Warm-up" */
      label: Inline
      /** e.g. "Single-table lookups — 10 points each" */
      note?: Inline
      tier?: 1 | 2 | 3 | 4
    }
  | {
      kind: "question"
      /** "Q1".."Q8" — matches CHALLENGE_KEY.QUESTION_ID. */
      id: string
      points: number
      text: Inline
      why?: Inline
      exercises?: Inline
      /**
       * Required on question blocks. The scored question wording is meant to be
       * visible here, so the leak scanner treats these as permitted zones.
       */
      allowScoredAnswers: true
    }
  | {
      kind: "challenge"
      /**
       * Set true only where a scored answer is legitimately part of the learner
       * experience (the challenge table in m9, the tier previews). The leak
       * scanner permits answers inside these blocks and nowhere else.
       */
      allowScoredAnswers?: true
      head: Inline[]
      rows: Inline[][]
    }

  | {
      kind: "quiz"
      /**
       * Stable, content-defined reference such as "m3.q1". This is the contract
       * with QUIZ_KEY and QUIZ_PROGRESS, so like a checkpoint key it must NEVER
       * be derived from position -- inserting a question would otherwise
       * reassign a learner's saved answer to a different question.
       */
      ref: string
      text: Inline
      /**
       * Exactly three options, rendered in this order. The index of the correct
       * one lives in QUIZ_KEY.CORRECT_OPTION and is deliberately NOT here: the
       * content model is shipped to the browser, so an answer stored here would
       * be readable by the learner being asked. validateBlock rejects a quiz
       * block that carries a `correct` field for exactly that reason.
       */
      options: Inline[]
    }

export interface Module {
  /** "m0" .. "m10" — also the anchor and the LAB_STEPS module id. */
  id: string
  seq: number
  /** e.g. "Phase · Connect", or "Fundamentals" for m0. */
  phase: string
  title: Inline
  blocks: Block[]
}
