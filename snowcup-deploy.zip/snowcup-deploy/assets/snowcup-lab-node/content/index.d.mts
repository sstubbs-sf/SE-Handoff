import type { Module } from "./types"

/** The training this app delivers. Keys every progress row. */
export const TRAINING: { readonly id: string; readonly title: string }

/** Ordered by seq. Validated at import time by validateAll(). */
export const MODULES: Module[]

export interface Step {
  step_key: string
  /** Lab section within the training (m0..m10), not the training itself. */
  section_id: string
  section_seq: number
  section_title: string
  phase: string
  text: string
}

/** Flat checkpoint registry derived from the modules. */
export const STEPS: Step[]

export function validateAll(modules: Module[]): Module[]
export function stepsOf(modules: Module[]): Step[]
