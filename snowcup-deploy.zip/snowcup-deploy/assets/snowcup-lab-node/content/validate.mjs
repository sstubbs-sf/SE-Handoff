/**
 * Shape validation and text extraction for lab content.
 *
 * Both consumers depend on this: the Next.js renderer trusts the shape, and
 * verify/check_leaks.py trusts extractText() to recover exactly the prose a
 * learner will read. A silent failure here would weaken the workshop's only
 * remaining leak guarantee, so this validates loudly instead of coercing.
 */

const BLOCK_KINDS = new Set([
  "prose",
  "list",
  "callout",
  "prompt",
  "heading",
  "code",
  "table",
  "checkpoint",
  "challenge",
  "think",
  "tier",
  "question",
  "figure",
  "quiz",
])

/** Reinforcement quizzes are fixed at three options: see QUIZ_KEY.CORRECT_OPTION. */
const QUIZ_OPTIONS = 3
const QUIZ_REF = /^m\d+\.q\d+$/

const CALLOUT_VARIANTS = new Set(["info", "warn", "green", "red"])

/** The placeholder learners must replace. Kept in one place on purpose. */
export const FILLIN = "WS_<yourname>"

/**
 * Reduce inline markup to plain prose.
 *
 * Order matters: links collapse to their text before the emphasis markers are
 * stripped, so a bolded link does not leave stray asterisks behind. {{fillin}}
 * expands rather than disappearing, because the scanner should see the same
 * words a learner sees.
 */
export function extractText(inline) {
  if (inline == null) return ""
  let s = String(inline)
  s = s.replace(/\{\{skill:([^}]+)\}\}/g, "$1")
  s = s.replace(/\{\{fillin\}\}/g, FILLIN)
  s = s.replace(/\[([^\]]*)\]\([^)]*\)/g, "$1")
  s = s.replace(/`([^`]*)`/g, "$1")
  s = s.replace(/\*\*([^*]*)\*\*/g, "$1")
  s = s.replace(/\*([^*]*)\*/g, "$1")
  return s
}

/** Every string a learner can read in a block, already de-marked. */
export function blockText(block) {
  const out = []
  const push = (v) => {
    const t = extractText(v)
    if (t.trim()) out.push(t)
  }
  switch (block.kind) {
    case "callout":
      push(block.text)
      // A callout can wrap a list plus a closing line, e.g. the "good starter
      // set" in m3. Those strings are learner-visible and must be scanned.
      for (const item of block.items ?? []) push(item)
      push(block.after)
      break
    case "prose":
    case "prompt":
    case "heading":
    case "checkpoint":
    case "think":
      push(block.text)
      if (block.kind === "prompt" && block.label) push(block.label)
      if (block.kind === "think" && block.label) push(block.label)
      break
    case "code":
      // Code is read verbatim; no inline markup applies inside it.
      if (String(block.text ?? "").trim()) out.push(String(block.text))
      break
    case "list":
      for (const item of block.items) push(item)
      break
    case "tier":
      push(block.label)
      push(block.note)
      break
    case "question":
      // The scored question wording itself. Legitimately learner-visible, which
      // is why these blocks carry allowScoredAnswers.
      push(block.id)
      push(block.text)
      push(block.why)
      push(block.exercises)
      break
    case "quiz":
      // The ref is the contract with QUIZ_KEY and QUIZ_PROGRESS, so it is held to
      // the same discipline as a checkpoint key: content-defined, never
      // positional, and prefixed with its own module.
      if (typeof block.ref !== "string" || !QUIZ_REF.test(block.ref)) {
        fail(where, "quiz ref must look like m3.q1")
      }
      if (typeof block.text !== "string" || !block.text.trim()) {
        fail(where, "quiz text must be a non-empty string")
      }
      if (!Array.isArray(block.options) || block.options.length !== QUIZ_OPTIONS) {
        fail(where, `quiz needs exactly ${QUIZ_OPTIONS} options`)
      }
      for (const [i, opt] of block.options.entries()) {
        if (typeof opt !== "string" || !opt.trim()) {
          fail(`${where} option ${i}`, "option must be a non-empty string")
        }
      }
      // The answer belongs in QUIZ_KEY. Catching it here stops a well-meaning
      // edit from shipping the answer to the browser.
      if ("correct" in block || "answer" in block || "correctOption" in block) {
        fail(
          where,
          "a quiz block must NOT carry the correct answer -- it belongs in " +
            "QUIZ_KEY so it is never sent to a learner",
        )
      }
      break
    case "table":
    case "challenge":
      for (const h of block.head) push(h)
      for (const row of block.rows) for (const cell of row) push(cell)
      break
    case "quiz":
      // CRITICAL: the question and ALL THREE options are learner-visible, so they
      // must reach the leak scanner. Omitting this case would not error anywhere
      // -- the switch would simply fall through and contribute nothing, leaving
      // every quiz string unscanned and the "no scored answer reaches a learner"
      // guarantee quietly weaker than it claims.
      //
      // The correct answer is deliberately absent from content (it lives in
      // QUIZ_KEY), so there is nothing here that must be hidden -- only prose
      // that must be checked.
      push(block.text)
      for (const opt of block.options ?? []) push(opt)
      break
  }
  return out
}

function fail(where, msg) {
  throw new Error(`Invalid lab content at ${where}: ${msg}`)
}

function validateBlock(block, where) {
  if (!block || typeof block !== "object") fail(where, "block is not an object")
  if (!BLOCK_KINDS.has(block.kind)) {
    fail(where, `unknown block kind ${JSON.stringify(block.kind)}`)
  }
  switch (block.kind) {
    case "prose":
    case "heading":
      if (typeof block.text !== "string") fail(where, "text must be a string")
      break
    case "callout":
      if (typeof block.text !== "string") fail(where, "text must be a string")
      if (block.variant && !CALLOUT_VARIANTS.has(block.variant)) {
        fail(where, `unknown callout variant ${JSON.stringify(block.variant)}`)
      }
      break
    case "prompt":
    case "think":
      if (typeof block.text !== "string") fail(where, "text must be a string")
      break
    case "code":
      if (typeof block.text !== "string") fail(where, "text must be a string")
      break
    case "list":
      if (!Array.isArray(block.items) || block.items.length === 0) {
        fail(where, "list needs a non-empty items array")
      }
      break
    case "checkpoint":
      if (typeof block.text !== "string") fail(where, "text must be a string")
      if (typeof block.key !== "string" || !/^m\d+\.[a-z0-9-]+$/.test(block.key)) {
        fail(
          where,
          `checkpoint key ${JSON.stringify(block.key)} must look like "m3.checkpoint" ` +
            `-- it is the durable database key, so it cannot be positional or ad hoc`,
        )
      }
      break
    case "tier":
      if (typeof block.label !== "string") fail(where, "tier needs a label")
      break
    case "figure":
      // Diagrams are components, so a figure carries only a name. Its labels
      // live in the component and are covered by the app-source leak scan.
      if (typeof block.name !== "string") fail(where, "figure needs a name")
      break
    case "question":
      if (typeof block.id !== "string" || !/^Q\d+$/.test(block.id)) {
        fail(where, "question id must look like Q1")
      }
      if (typeof block.text !== "string") fail(where, "text must be a string")
      if (typeof block.points !== "number") fail(where, "points must be a number")
      if (block.allowScoredAnswers !== true) {
        // Fail loudly rather than quietly: a scored question block without this
        // flag would make the leak scanner report a false Class B failure, and
        // someone would "fix" it by weakening the scanner.
        fail(where, "a question block must set allowScoredAnswers: true")
      }
      break
    case "table":
    case "challenge":
      if (!Array.isArray(block.head) || !Array.isArray(block.rows)) {
        fail(where, "needs head and rows arrays")
      }
      for (const [i, row] of block.rows.entries()) {
        if (!Array.isArray(row)) fail(`${where} row ${i}`, "row must be an array")
        if (row.length !== block.head.length) {
          fail(
            `${where} row ${i}`,
            `has ${row.length} cells but head has ${block.head.length}`,
          )
        }
      }
      break
  }
}

/** Validate one module, returning it unchanged so callers can chain. */
export function validateModule(mod) {
  const where = `module ${mod?.id ?? "<unknown>"}`
  if (!mod || typeof mod !== "object") fail(where, "module is not an object")
  if (!/^m\d+$/.test(mod.id ?? "")) fail(where, "id must look like m3")
  if (typeof mod.seq !== "number") fail(where, "seq must be a number")
  if (typeof mod.title !== "string") fail(where, "title must be a string")
  if (typeof mod.phase !== "string") fail(where, "phase must be a string")
  if (!Array.isArray(mod.blocks) || mod.blocks.length === 0) {
    fail(where, "blocks must be a non-empty array")
  }
  mod.blocks.forEach((b, i) => validateBlock(b, `${where} block ${i} (${b?.kind})`))
  return mod
}

/**
 * Validate the whole set and enforce cross-module invariants: unique ids and
 * sequences, and globally unique checkpoint keys scoped to their own module.
 * A duplicate key would make two checkpoints share one progress row.
 */
export function validateAll(modules) {
  const ids = new Set()
  const seqs = new Set()
  const keys = new Set()
  const quizRefs = new Set()
  for (const mod of modules) {
    validateModule(mod)
    if (ids.has(mod.id)) fail(`module ${mod.id}`, "duplicate module id")
    if (seqs.has(mod.seq)) fail(`module ${mod.id}`, `duplicate seq ${mod.seq}`)
    ids.add(mod.id)
    seqs.add(mod.seq)
    for (const b of mod.blocks) {
      if (b.kind === "quiz") {
        if (!b.ref.startsWith(`${mod.id}.`)) {
          fail(`module ${mod.id}`, `quiz ref ${b.ref} must be prefixed ${mod.id}.`)
        }
        // A duplicate ref would make two questions share one QUIZ_PROGRESS row,
        // so answering one would silently credit the other.
        if (quizRefs.has(b.ref)) fail(`module ${mod.id}`, `duplicate quiz ref ${b.ref}`)
        quizRefs.add(b.ref)
        continue
      }
      if (b.kind !== "checkpoint") continue
      if (!b.key.startsWith(`${mod.id}.`)) {
        fail(`module ${mod.id}`, `checkpoint key ${b.key} must be prefixed ${mod.id}.`)
      }
      if (keys.has(b.key)) fail(`module ${mod.id}`, `duplicate checkpoint key ${b.key}`)
      keys.add(b.key)
    }
  }
  return modules
}

/** Flat step registry used to seed LAB_STEPS and to render progress. */
export function stepsOf(modules) {
  const steps = []
  for (const mod of modules) {
    for (const b of mod.blocks) {
      if (b.kind !== "checkpoint") continue
      steps.push({
        step_key: b.key,
        // section_*, not module_*: in the database MODULE_ID means the TRAINING
        // (SNOWCUP), and the lab section lives in SECTION_ID. Emitting the
        // database's vocabulary here keeps verify/check_lab_steps.py a direct
        // field-for-field comparison instead of a translation layer.
        section_id: mod.id,
        section_seq: mod.seq,
        section_title: extractText(mod.title),
        phase: mod.phase,
        text: extractText(b.text),
      })
    }
  }
  return steps
}
