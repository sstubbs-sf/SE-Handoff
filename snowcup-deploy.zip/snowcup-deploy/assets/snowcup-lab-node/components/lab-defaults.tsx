"use client"

import { useState } from "react"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import { Check, ChevronDown, Loader2, RotateCcw, ShieldQuestion, TriangleAlert, Wand2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

/**
 * The five session defaults this lab needs, expected vs actual.
 *
 * WHY THIS EXISTS
 * Cortex Code in Snowsight opens every session on the user's DEFAULT_ROLE and
 * ignores the Snowsight role picker. Asking CoCo to switch roles does nothing --
 * session context is fixed when the session is created. So if any of these five
 * is wrong, the only fix is to sign out and back in, and the learner needs to
 * know that BEFORE they start building rather than twenty minutes in.
 *
 * Showing expected AND actual side by side is the point. "Your role should be X"
 * is not actionable on its own; "should be X, is Y" tells them immediately
 * whether to keep going or re-authenticate.
 */

export interface SessionDefault {
  label: string
  expected: string | null
  actual: string | null
  ok: boolean
}

/** Mirrors BuildSpaceStatus in lib/lab-session.ts. */
export type BuildSpaceStatus = "ok" | "not-workshop-role" | "schema-unconfirmed"

export function LabDefaults({
  defaults,
  allOk,
  buildSpaceStatus,
  activeRole,
}: {
  defaults: SessionDefault[] | undefined
  allOk: boolean | undefined
  buildSpaceStatus?: BuildSpaceStatus
  activeRole?: string
}) {
  const [open, setOpen] = useState(false)
  const [result, setResult] = useState<{ changed: boolean; message: string } | null>(null)
  const qc = useQueryClient()

  // Both actions change the USER, not the current session, so re-reading the
  // session is what proves whether anything landed -- and it will still show the
  // old values until the learner signs out and back in. That is the whole reason
  // the success copy below leads with re-authenticating.
  const act = useMutation({
    mutationFn: async (action: "apply" | "revert") => {
      const res = await fetch("/api/defaults", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      })
      const body = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(String(body?.error ?? `Request failed (${res.status})`))
      return body as { changed: boolean; message: string }
    },
    onSuccess: (body) => {
      setResult({ changed: Boolean(body.changed), message: String(body.message ?? "") })
      // Open the panel on the way out. The outcome copy is the important half of
      // this feature -- "defaults set" means nothing until the learner also reads
      // that they must sign out and back in -- and when the buttons are pressed
      // from the strip the panel is closed, so the message would land unseen.
      setOpen(true)
      void qc.invalidateQueries({ queryKey: ["session"] })
    },
    onError: (e: unknown) => {
      setResult({ changed: false, message: e instanceof Error ? e.message : String(e) })
      setOpen(true)
    },
  })

  if (!defaults || defaults.length === 0) return null

  const bad = defaults.filter((d) => !d.ok).length

  // An admin or facilitator is not a broken learner, and conflating the two cost
  // real debugging time: three rows read "should be: unknown", which looks like
  // the lab failed to resolve them, when in fact the session simply is not a
  // learner session and there is nothing to resolve. Worse, the advice attached
  // to that alert -- press the button, then sign out and back in -- cannot work,
  // because APPLY_LAB_DEFAULTS skips ACCOUNTADMIN and SNOWCUP_FACILITATOR
  // holders by design. So this case gets its own neutral state and its own copy.
  const notLearner = buildSpaceStatus === "not-workshop-role"
  const showAlarm = !allOk && !notLearner

  // Hoisted so the same pair can sit in the identity strip (when something is
  // wrong, where they must be reachable without a click) and inside the panel
  // (when everything already matches, where they are a rarely-wanted escape
  // hatch and do not belong in the strip).
  const actions = (
    <>
      <Button
        size="sm"
        disabled={act.isPending}
        onClick={() => act.mutate("apply")}
        className="gap-1.5"
      >
        {act.isPending && act.variables === "apply" ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
        ) : (
          <Wand2 className="h-3.5 w-3.5" aria-hidden />
        )}
        Set my defaults for this lab
      </Button>
      <Button
        size="sm"
        variant="outline"
        disabled={act.isPending}
        onClick={() => act.mutate("revert")}
        className="gap-1.5"
      >
        {act.isPending && act.variables === "revert" ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
        ) : (
          <RotateCcw className="h-3.5 w-3.5" aria-hidden />
        )}
        Revert to my originals
      </Button>
    </>
  )

  return (
    <span className="relative inline-block">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-sm transition-colors",
          allOk
            ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/15 dark:text-emerald-300"
            : notLearner
              ? "border-border bg-muted/60 text-muted-foreground hover:bg-muted"
              : "border-orange-500/45 bg-orange-500/10 text-orange-700 hover:bg-orange-500/15 dark:text-orange-300",
        )}
      >
        {allOk ? (
          <Check className="h-3.5 w-3.5" aria-hidden />
        ) : notLearner ? (
          <ShieldQuestion className="h-3.5 w-3.5" aria-hidden />
        ) : (
          <TriangleAlert className="h-3.5 w-3.5" aria-hidden />
        )}
        <span className="font-medium">
          {allOk
            ? "Session ready"
            : notLearner
              ? "Not a learner session"
              : `${bad} setting${bad === 1 ? "" : "s"} to fix`}
        </span>
        <ChevronDown
          className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")}
          aria-hidden
        />
      </button>

      {/* The fix has to be reachable without a click. A learner whose defaults are
          wrong cannot build anything until this is sorted, so burying the buttons
          behind a disclosure put the one action they need behind a step they had no
          reason to take. The pill still opens the expected-vs-actual detail. */}
      {showAlarm && (
        <span className="ml-2 inline-flex flex-wrap items-center gap-2 align-middle">
          {actions}
        </span>
      )}

      {open && (
        <div className="absolute left-0 top-full z-30 mt-2 w-[26rem] max-w-[calc(100vw-2rem)] rounded-xl border border-border bg-background p-3 shadow-lg">
          <p className="mb-2 text-xs text-muted-foreground">
            Cortex Code uses these for every prompt in this lab. It reads them once, when
            your session starts — so if one is wrong,{" "}
            <strong className="text-foreground">sign out of Snowsight and back in</strong>.
            Asking CoCo to change them does nothing.
          </p>
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wide text-muted-foreground">
                <th className="py-1 pr-2 font-medium">Setting</th>
                <th className="py-1 pr-2 font-medium">Should be</th>
                <th className="py-1 font-medium">Yours</th>
              </tr>
            </thead>
            <tbody>
              {defaults.map((d) => (
                <tr key={d.label} className="border-t border-border/60 align-top">
                  <td className="py-1.5 pr-2 text-muted-foreground">{d.label}</td>
                  <td className="py-1.5 pr-2 font-mono text-[0.8rem] text-foreground">
                    {d.expected ?? (
                      <span className="text-muted-foreground">
                        {notLearner ? "n/a" : "unknown"}
                      </span>
                    )}
                  </td>
                  <td
                    className={cn(
                      "py-1.5 font-mono text-[0.8rem]",
                      d.ok
                        ? "text-emerald-700 dark:text-emerald-300"
                        : notLearner
                          ? "text-muted-foreground"
                          : "text-orange-700 dark:text-orange-300",
                    )}
                  >
                    <span className="inline-flex items-center gap-1">
                      {d.ok ? (
                        <Check className="h-3 w-3 shrink-0" aria-hidden />
                      ) : notLearner ? null : (
                        <TriangleAlert className="h-3 w-3 shrink-0" aria-hidden />
                      )}
                      {d.actual ?? "not set"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border/60 pt-3">
            {allOk || notLearner ? (
              actions
            ) : (
              <span className="text-xs text-muted-foreground">
                Use the buttons next to the alert above.
              </span>
            )}
          </div>
          <p className="mt-1.5 text-[0.7rem] leading-snug text-muted-foreground">
            Your original settings are saved before anything changes, so Revert always has
            somewhere to go back to. Both buttons only affect your own user.
          </p>

          {result && (
            <p
              className={cn(
                "mt-2 rounded-md border p-2 text-xs",
                result.changed
                  ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-800 dark:text-emerald-300"
                  : "border-orange-500/40 bg-orange-500/10 text-orange-800 dark:text-orange-300",
              )}
            >
              {result.changed ? (
                <>
                  <strong>Done — now close every other Snowflake window, then sign out and
                  back in.</strong> Your current session still has the old values; Snowflake only
                  reads these when a session starts, and one surviving Snowsight tab keeps the old
                  session alive. {result.message}
                </>
              ) : (
                result.message
              )}
            </p>
          )}

          {notLearner && (
            <p className="mt-2 rounded-md border border-border bg-muted/60 p-2 text-xs text-muted-foreground">
              This session is running as{" "}
              <strong className="font-mono text-foreground">{activeRole ?? "a non-workshop role"}</strong>
              , not a <span className="font-mono">SNOWCUP_WS_</span> role, so there is no build
              space to look up — that is why three rows read <span className="font-mono">n/a</span>{" "}
              rather than being wrong.{" "}
              <strong className="text-foreground">If you are a facilitator, this is expected.</strong>{" "}
              If you are here to build, note that{" "}
              <em>Set my defaults for this lab</em> will not help: it deliberately skips anyone
              holding <span className="font-mono">ACCOUNTADMIN</span> or{" "}
              <span className="font-mono">SNOWCUP_FACILITATOR</span> so it never overwrites an
              admin&apos;s defaults. Ask a facilitator to set your{" "}
              <span className="font-mono">DEFAULT_ROLE</span> to your{" "}
              <span className="font-mono">SNOWCUP_WS_</span> role, then sign out and back in.
            </p>
          )}

          {showAlarm && (
            <p className="mt-2 rounded-md border border-orange-500/35 bg-orange-500/10 p-2 text-xs text-orange-700 dark:text-orange-300">
              Anything that isn&apos;t a match means the lab can&apos;t fill in your build
              space, and CoCo may create objects in the wrong place. Sign out and back in,
              then reload this page. If it still doesn&apos;t match, tell your facilitator —
              you may not be provisioned yet.
            </p>
          )}
        </div>
      )}
    </span>
  )
}
