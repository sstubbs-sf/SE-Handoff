"use client"

import { ChevronRight, Check } from "lucide-react"

import { OUTLINE } from "@/lib/outline"
import { cn } from "@/lib/utils"

/**
 * The lab outline: every module, and the headings inside the ones a learner is
 * working through.
 *
 * Presentational only. Expansion state, checkpoint state and the active section
 * all live in <Lab>, because the same expansion state drives the body sections --
 * two sources would let the nav and the page disagree about what is open.
 *
 * Ticks come from the server-backed checkpoints, so this shows exactly what the
 * facilitator sees. There is deliberately no per-step tick: the retired HTML had
 * those in localStorage, which would now be a second notion of progress that
 * nobody but the learner's browser knows about.
 */
export interface LabNavProps {
  doneKeys: ReadonlySet<string>
  expanded: ReadonlySet<string>
  activeModuleId: string | null
  activeStepId: string | null
  /** Expand the owning module, then scroll to the anchor. */
  onNavigate: (anchor: string) => void
  onToggleModule: (id: string) => void
}

export function LabNav({
  doneKeys,
  expanded,
  activeModuleId,
  activeStepId,
  onNavigate,
  onToggleModule,
}: LabNavProps) {
  return (
    <nav aria-label="Lab contents" className="text-sm">
      <ol className="space-y-0.5">
        {OUTLINE.map((mod) => {
          const done = mod.checkpointKey ? doneKeys.has(mod.checkpointKey) : false
          const isActive = activeModuleId === mod.id
          // Steps are listed for the module being read and for any the learner
          // opened, mirroring the original lab's behaviour.
          const showSteps = mod.steps.length > 0 && (expanded.has(mod.id) || isActive)
          return (
            <li key={mod.id}>
              <div className="flex items-stretch gap-0.5">
                {mod.steps.length > 0 ? (
                  <button
                    type="button"
                    onClick={() => onToggleModule(mod.id)}
                    aria-expanded={expanded.has(mod.id)}
                    aria-label={`${showSteps ? "Hide" : "Show"} steps in ${mod.plainTitle}`}
                    className="flex w-5 shrink-0 items-center justify-center rounded text-muted-foreground hover:text-foreground"
                  >
                    <ChevronRight
                      aria-hidden
                      className={cn(
                        "h-3.5 w-3.5 transition-transform motion-reduce:transition-none",
                        showSteps && "rotate-90",
                      )}
                    />
                  </button>
                ) : (
                  <span aria-hidden className="w-5 shrink-0" />
                )}

                <button
                  type="button"
                  onClick={() => onNavigate(mod.id)}
                  aria-current={isActive ? "true" : undefined}
                  className={cn(
                    "flex min-w-0 flex-1 items-center gap-2 rounded px-2 py-1.5 text-left transition-colors",
                    isActive
                      ? "bg-sky-500/10 text-foreground"
                      : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                  )}
                >
                  <span
                    aria-hidden
                    className={cn(
                      "flex h-4 w-4 shrink-0 items-center justify-center rounded-[4px] border text-[10px]",
                      done
                        ? "border-emerald-500 bg-emerald-500 text-white"
                        : "border-muted-foreground/40",
                    )}
                  >
                    {done && <Check className="h-3 w-3" strokeWidth={3} />}
                  </span>
                  <span className="w-4 shrink-0 text-right text-xs tabular-nums opacity-70">
                    {mod.seq}
                  </span>
                  {/* Struck through when complete, so what is left stands out. */}
                  <span
                    className={cn(
                      "truncate",
                      done && "line-through decoration-muted-foreground/50",
                    )}
                    title={mod.plainTitle}
                  >
                    {mod.plainTitle}
                  </span>
                </button>
              </div>

              {showSteps && (
                <ol className="mb-1 ml-[3.1rem] space-y-0.5 border-l border-border pl-2">
                  {mod.steps.map((step) => (
                    <li key={step.id}>
                      <button
                        type="button"
                        onClick={() => onNavigate(step.id)}
                        aria-current={activeStepId === step.id ? "true" : undefined}
                        className={cn(
                          "block w-full truncate rounded px-2 py-1 text-left text-xs transition-colors",
                          activeStepId === step.id
                            ? "text-sky-600 dark:text-sky-400"
                            : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                        )}
                        title={step.title}
                      >
                        {step.title}
                      </button>
                    </li>
                  ))}
                </ol>
              )}
            </li>
          )
        })}
      </ol>
    </nav>
  )
}
