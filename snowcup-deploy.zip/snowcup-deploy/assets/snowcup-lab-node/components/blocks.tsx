"use client"

import { Fragment, createContext, useContext, useState, type ReactNode } from "react"
import { Check } from "lucide-react"

import { cn } from "@/lib/utils"

/**
 * Renderers for the lab content model.
 *
 * Inline markup is turned into React elements rather than injected as HTML.
 * That is deliberate: content is trusted today, but rendering it as markup would
 * make any future content source an XSS vector, and there is no need for the
 * risk when the vocabulary is this small.
 */

const FILLIN = "WS_<yourname>"
const ROLE_FILLIN = "SNOWCUP_WS_<yourname>"

/**
 * The signed-in learner's real build space, so `{{fillin}}` and `{{role}}` can
 * render their actual schema and role instead of a placeholder.
 *
 * Context rather than props: Inline is called from ten different renderers, and
 * threading identity through every one of them would be churn for no gain.
 *
 * Null means "not confirmed" -- the placeholder still renders, loudly. See
 * resolveBuildSpace in lib/lab-session.ts for why null is a deliberate outcome
 * rather than a failure to paper over.
 */
export const LabIdentityContext = createContext<{
  buildSchema: string | null
  buildRole: string | null
}>({ buildSchema: null, buildRole: null })

/**
 * Split on the inline markers the content model defines. Order matters: code
 * spans are taken first so emphasis markers inside them stay literal, which is
 * what you want for things like SELECT * FROM.
 */
const TOKEN = /(`[^`]*`|\*\*[^*]+\*\*|\*[^*]+\*|\{\{fillin\}\}|\{\{role\}\}|\{\{skill:[^}]+\}\}|\[[^\]]*\]\([^)]*\))/g

export function Inline({ text }: { text: string }): ReactNode {
  const { buildSchema, buildRole } = useContext(LabIdentityContext)
  // Code spans and bold are split BEFORE the name tokens, so a token written as
  // `{{fillin}}` or **{{fillin}}** would reach the DOM literally. Substituting
  // inside those two branches means content authors can nest the tokens freely
  // instead of having to remember the ordering rule.
  const fill = (v: string) =>
    v
      .replace(/\{\{fillin\}\}/g, buildSchema ?? FILLIN)
      .replace(/\{\{role\}\}/g, buildRole ?? ROLE_FILLIN)
  const parts = String(text ?? "").split(TOKEN).filter((p) => p !== "")
  return (
    <>
      {parts.map((part, i) => {
        const key = `${i}-${part.slice(0, 8)}`

        if (part.startsWith("`") && part.endsWith("`") && part.length > 1) {
          return (
            <code
              key={key}
              className="rounded border border-sky-500/25 bg-sky-500/10 px-1.5 py-0.5 font-mono text-[0.88em] text-sky-700 dark:text-sky-300"
            >
              {fill(part.slice(1, -1))}
            </code>
          )
        }
        if (part.startsWith("**") && part.endsWith("**")) {
          return (
            <strong key={key} className="font-semibold text-foreground">
              {fill(part.slice(2, -2))}
            </strong>
          )
        }
        if (part.startsWith("*") && part.endsWith("*") && part.length > 2) {
          return <em key={key}>{part.slice(1, -1)}</em>
        }
        if (part === "{{fillin}}" || part === "{{role}}") {
          const isRole = part === "{{role}}"
          const resolved = isRole ? buildRole : buildSchema
          // Resolved: quiet and confident, so it reads as a real name they can
          // copy. Unresolved: loud orange, because leaving a placeholder
          // unreplaced is the single most common reason a learner's prompt lands
          // in the wrong place.
          return (
            <span
              key={key}
              title={
                resolved
                  ? "Your own build space, filled in automatically"
                  : "We could not confirm your build space — check with your facilitator"
              }
              className={cn(
                "rounded border px-1.5 py-0.5 font-mono text-[0.88em] font-semibold",
                resolved
                  ? "border-sky-500/40 bg-sky-500/10 text-sky-700 dark:text-sky-300"
                  : "border-orange-500/40 bg-orange-500/15 text-orange-700 dark:text-orange-300",
              )}
            >
              {resolved ?? (isRole ? ROLE_FILLIN : FILLIN)}
            </span>
          )
        }
        if (part.startsWith("{{skill:")) {
          return (
            <span
              key={key}
              className="rounded border border-violet-500/35 bg-violet-500/10 px-1.5 py-0.5 font-mono text-[0.85em] text-violet-700 dark:text-violet-300"
            >
              {part.slice(8, -2)}
            </span>
          )
        }
        const link = /^\[([^\]]*)\]\(([^)]*)\)$/.exec(part)
        if (link) {
          return (
            <a
              key={key}
              href={link[2]}
              target="_blank"
              rel="noreferrer noopener"
              className="text-sky-600 underline decoration-sky-500/40 underline-offset-2 hover:decoration-sky-500 dark:text-sky-400"
            >
              {link[1]}
            </a>
          )
        }
        return <Fragment key={key}>{part}</Fragment>
      })}
    </>
  )
}

const CALLOUT_STYLES: Record<string, string> = {
  info: "border-l-sky-500 bg-sky-500/[0.07]",
  warn: "border-l-orange-500 bg-orange-500/[0.08]",
  green: "border-l-emerald-500 bg-emerald-500/[0.08]",
  red: "border-l-rose-500 bg-rose-500/[0.09]",
}

export function Callout({
  variant = "info",
  text,
  items,
  after,
}: {
  variant?: string
  text: string
  items?: string[]
  after?: string
}) {
  return (
    <div
      className={cn(
        "my-4 rounded-r-xl border-l-[3px] px-5 py-4 text-[0.95rem] leading-relaxed text-muted-foreground",
        CALLOUT_STYLES[variant] ?? CALLOUT_STYLES.info,
      )}
    >
      <Inline text={text} />
      {items && items.length > 0 && (
        <ul className="mt-2 ml-5 list-disc space-y-1">
          {items.map((item, i) => (
            <li key={i}>
              <Inline text={item} />
            </li>
          ))}
        </ul>
      )}
      {after && (
        <p className="mt-2">
          <Inline text={after} />
        </p>
      )}
    </div>
  )
}

export function Prompt({ label, text }: { label?: string; text: string }) {
  return (
    <div className="my-4 overflow-hidden rounded-xl border border-sky-500/25 bg-sky-500/[0.06]">
      <div className="border-b border-sky-500/20 px-4 py-2 text-[0.7rem] font-bold uppercase tracking-[0.14em] text-sky-700 dark:text-sky-300">
        {label ? `\u25b8 ${label}` : "\u25b8 Prompt"}
      </div>
      <p className="px-4 py-3 font-mono text-[0.85rem] leading-relaxed text-foreground">
        <Inline text={text} />
      </p>
    </div>
  )
}

export function DataTable({ head, rows }: { head: string[]; rows: string[][] }) {
  return (
    <div className="my-4 overflow-x-auto">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr>
            {head.map((h, i) => (
              <th
                key={i}
                className="border-b border-border px-3 py-2 text-left text-[0.7rem] font-bold uppercase tracking-[0.1em] text-muted-foreground"
              >
                <Inline text={h} />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, r) => (
            <tr key={r}>
              {row.map((cell, c) => (
                <td
                  key={c}
                  className="border-b border-border px-3 py-2 align-top text-muted-foreground"
                >
                  <Inline text={cell} />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function CodeBlock({ text }: { text: string }) {
  return (
    <pre className="my-4 overflow-x-auto rounded-xl border border-border bg-slate-900 px-5 py-4">
      <code className="font-mono text-[0.8rem] leading-relaxed text-slate-200">{text}</code>
    </pre>
  )
}

/**
 * Reflection prompt. Visually distinct from a callout because it asks the learner
 * to do something in their head rather than telling them something.
 */
export function Think({ label, text }: { label?: string; text: string }) {
  return (
    <div className="my-5 rounded-xl border border-dashed border-violet-500/40 bg-violet-500/[0.05] px-5 py-4">
      {label && (
        <div className="mb-1.5 text-[0.7rem] font-bold uppercase tracking-[0.14em] text-violet-600 dark:text-violet-400">
          {label}
        </div>
      )}
      <p className="text-[0.95rem] leading-relaxed text-muted-foreground">
        <Inline text={text} />
      </p>
    </div>
  )
}

const TIER_STYLES: Record<number, string> = {
  1: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
  2: "bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30",
  3: "bg-violet-500/15 text-violet-700 dark:text-violet-300 border-violet-500/30",
  4: "bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/30",
}

export function TierHead({
  label,
  note,
  tier = 1,
}: {
  label: string
  note?: string
  tier?: number
}) {
  return (
    <div className="mt-8 mb-3 flex flex-wrap items-center gap-3 border-b border-border pb-2">
      <span
        className={cn(
          "rounded-full border px-3 py-1 text-[0.72rem] font-bold",
          TIER_STYLES[tier] ?? TIER_STYLES[1],
        )}
      >
        <Inline text={label} />
      </span>
      {note && (
        <span className="text-[0.8rem] text-muted-foreground">
          <Inline text={note} />
        </span>
      )}
    </div>
  )
}

/** A scored challenge question. */
export function Question({
  id,
  points,
  text,
  why,
  exercises,
}: {
  id: string
  points: number
  text: string
  why?: string
  exercises?: string
}) {
  return (
    <div className="my-3 rounded-xl border border-border px-5 py-4">
      <div className="mb-2 flex items-center gap-3">
        <span className="rounded bg-foreground px-2 py-0.5 font-mono text-[0.72rem] font-bold text-background">
          {id}
        </span>
        <span className="text-[0.72rem] font-semibold uppercase tracking-wider text-muted-foreground">
          {points} pts
        </span>
      </div>
      <p className="text-[1rem] font-medium leading-relaxed text-foreground">
        <Inline text={text} />
      </p>
      {why && (
        <p className="mt-2 text-[0.88rem] leading-relaxed text-muted-foreground">
          <Inline text={why} />
        </p>
      )}
      {exercises && (
        <p className="mt-2 text-[0.72rem] font-semibold uppercase tracking-wider text-sky-600 dark:text-sky-400">
          <Inline text={exercises} />
        </p>
      )}
    </div>
  )
}

/**
 * A reinforcement quiz question.
 *
 * WHY THE ANSWER IS NOT A PROP
 * The correct option is never sent to the browser -- it lives in QUIZ_KEY and the
 * server grades the submission. This component therefore knows only what the
 * learner chose and what the server said about it, which is what allows quiz
 * results to gate training completion without the gate being self-asserted.
 *
 * The explanation arrives with the graded response for the same reason: shipping
 * it up front would hand over the reasoning, and usually the answer with it.
 */
export function Quiz({
  ref_,
  text,
  options,
  correct,
  attempts,
  pending,
  feedback,
  onSubmit,
}: {
  ref_: string
  text: string
  options: string[]
  /** Sticky: once right, it stays right, so the control locks. */
  correct: boolean
  attempts: number
  pending: boolean
  feedback: { correct: boolean; explanation: string | null } | null
  onSubmit: (choice: number) => void
}) {
  const [choice, setChoice] = useState<number | null>(null)
  const name = `quiz-${ref_}`

  // `correct` comes from the server query; `feedback` comes from the grading
  // response that just arrived. Both say the same thing, but the query lags by a
  // refetch -- so between the response landing and the refetch completing there is
  // a window where feedback says right and `correct` still says wrong. Reading only
  // `correct` there re-rendered the submit button and labelled it "Try again" for a
  // frame or two on a CORRECT answer, which reads as "you got it wrong" and is the
  // opposite of the truth.
  //
  // The grading response is authoritative the moment it arrives, so trust it and
  // stop waiting for the network to agree.
  const isCorrect = correct || feedback?.correct === true
  const answered = isCorrect || feedback !== null
  const wrong = feedback !== null && !feedback.correct && !isCorrect

  return (
    <div
      className={cn(
        "my-4 rounded-xl border px-5 py-4 transition-colors",
        isCorrect ? "border-emerald-500/40 bg-emerald-500/[0.06]" : "border-border",
      )}
    >
      <div className="mb-3 flex items-center gap-2">
        <span className="text-[0.7rem] font-bold uppercase tracking-[0.14em] text-muted-foreground">
          Quick check
        </span>
        {isCorrect && (
          <span className="inline-flex items-center gap-1 text-[0.7rem] font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
            <Check className="h-3 w-3" strokeWidth={3} /> Correct
          </span>
        )}
        {attempts > 0 && !isCorrect && (
          <span className="text-[0.7rem] text-muted-foreground">
            {attempts} {attempts === 1 ? "attempt" : "attempts"}
          </span>
        )}
      </div>

      <p className="text-[0.95rem] font-medium leading-relaxed text-foreground">
        <Inline text={text} />
      </p>

      <fieldset className="mt-3 space-y-1.5" disabled={isCorrect || pending}>
        <legend className="sr-only">{text}</legend>
        {options.map((opt, i) => (
          <label
            key={i}
            className={cn(
              "flex cursor-pointer items-start gap-2.5 rounded-lg border px-3 py-2 text-[0.9rem] transition-colors",
              choice === i ? "border-sky-500/50 bg-sky-500/[0.07]" : "border-transparent",
              !isCorrect && "hover:bg-muted/50",
              isCorrect && "cursor-default",
            )}
          >
            <input
              type="radio"
              name={name}
              value={i}
              checked={choice === i}
              onChange={() => setChoice(i)}
              className="mt-1 accent-sky-500"
            />
            <span className="text-muted-foreground">
              <Inline text={opt} />
            </span>
          </label>
        ))}
      </fieldset>

      {!isCorrect && (
        <div className="mt-3 flex items-center gap-3">
          <button
            type="button"
            disabled={choice === null || pending}
            onClick={() => choice !== null && onSubmit(choice)}
            className={cn(
              "rounded-lg border border-border px-3 py-1.5 text-sm font-medium transition-colors",
              choice === null || pending
                ? "cursor-not-allowed opacity-50"
                : "hover:bg-muted/60",
            )}
          >
            {pending ? "Checking…" : answered ? "Try again" : "Check answer"}
          </button>
          {wrong && (
            <span className="text-sm text-muted-foreground">
              Not quite — retries are free.
            </span>
          )}
        </div>
      )}

      {/* Shown only after grading. Also shown on a correct answer, because the
          reason is the reinforcement -- getting it right by luck teaches nothing. */}
      {feedback?.explanation && (
        <p
          className={cn(
            "mt-3 rounded-lg px-3 py-2 text-[0.88rem] leading-relaxed",
            feedback.correct
              ? "bg-emerald-500/[0.08] text-foreground"
              : "bg-muted/60 text-muted-foreground",
          )}
        >
          <Inline text={feedback.explanation} />
        </p>
      )}
    </div>
  )
}
