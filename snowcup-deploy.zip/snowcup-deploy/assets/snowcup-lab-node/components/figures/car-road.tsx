"use client"

/**
 * The car, the road, and the speed limit.
 *
 * Ported from the inline SVG in the retired HTML lab. It lives as a component
 * rather than a raw SVG string in the content model for two reasons: content
 * blocks render as React elements (never injected HTML), and a diagram is
 * presentation, not prose. Its labels are still covered by the leak scanner,
 * which scans all app source for answer values.
 */
export function CarRoadFigure() {
  return (
    <figure className="my-6">
      <svg
        viewBox="0 0 760 300"
        role="img"
        aria-labelledby="carfig-t carfig-d"
        className="w-full"
      >
        <title id="carfig-t">The car, the road, and the speed limit</title>
        <desc id="carfig-d">
          A car labelled &quot;the model&quot; drives along a road labelled &quot;your semantic
          view — the road you pave&quot;, passing road signs (synonyms), guardrails
          (verified queries) and a speed-limit sign (the fuel and time budget you set),
          heading toward a destination flag labelled &quot;your question, answered&quot;.
        </desc>

        {/* road */}
        <rect x="24" y="200" width="712" height="62" rx="7" className="fill-slate-800" />
        <line x1="24" y1="200" x2="736" y2="200" className="stroke-border" strokeWidth="1" />
        <line
          x1="44"
          y1="231"
          x2="716"
          y2="231"
          stroke="rgba(255,255,255,.40)"
          strokeWidth="3"
          strokeDasharray="18 14"
          strokeLinecap="round"
        />
        <text x="380" y="285" textAnchor="middle" className="fill-muted-foreground text-[13px]">
          your semantic view — the road you pave
        </text>

        {/* the car = the model */}
        <text x="134" y="150" textAnchor="middle" className="fill-sky-500 text-[13px] font-bold">
          the model
        </text>
        <line x1="134" y1="156" x2="134" y2="164" className="stroke-sky-500" strokeWidth="1.5" />
        <path d="M108,176 L120,166 L152,166 L164,176 Z" className="fill-sky-500" />
        <rect x="92" y="176" width="86" height="24" rx="7" className="fill-sky-500" />
        <rect x="124" y="168" width="26" height="9" rx="2" fill="rgba(255,255,255,.5)" />
        <circle cx="112" cy="202" r="8" fill="#6b7c8f" />
        <circle cx="158" cy="202" r="8" fill="#6b7c8f" />

        {/* road signs = synonyms */}
        <text x="268" y="96" textAnchor="middle" className="fill-foreground text-[13px] font-bold">
          Road signs
        </text>
        <text x="268" y="112" textAnchor="middle" className="fill-muted-foreground text-[11px]">
          synonyms
        </text>
        <line x1="268" y1="122" x2="268" y2="130" className="stroke-border" />
        <rect
          x="230"
          y="130"
          width="76"
          height="26"
          rx="5"
          className="fill-background stroke-sky-500"
          strokeWidth="1.5"
        />

        {/* guardrails = verified queries */}
        <text x="450" y="96" textAnchor="middle" className="fill-foreground text-[13px] font-bold">
          Guardrails
        </text>
        <text x="450" y="112" textAnchor="middle" className="fill-muted-foreground text-[11px]">
          verified queries
        </text>
        <line x1="450" y1="122" x2="450" y2="192" className="stroke-border" />
        <line
          x1="410"
          y1="192"
          x2="490"
          y2="192"
          className="stroke-emerald-500"
          strokeWidth="3"
          strokeLinecap="round"
        />

        {/* speed limit = budget */}
        <text x="620" y="96" textAnchor="middle" className="fill-foreground text-[13px] font-bold">
          Speed limit
        </text>
        <text x="620" y="112" textAnchor="middle" className="fill-muted-foreground text-[11px]">
          fuel &amp; time budget
        </text>
        <line x1="620" y1="122" x2="620" y2="160" className="stroke-border" />
        <circle
          cx="620"
          cy="176"
          r="19"
          className="fill-background stroke-rose-500"
          strokeWidth="2.5"
        />

        {/* destination */}
        <line x1="712" y1="150" x2="712" y2="200" className="stroke-border" strokeWidth="1.5" />
        <path d="M712,150 L740,158 L712,166 Z" className="fill-violet-500" />
        <text x="700" y="140" textAnchor="end" className="fill-muted-foreground text-[11px]">
          your question, answered
        </text>
      </svg>
    </figure>
  )
}
