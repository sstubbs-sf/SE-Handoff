"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { AlertTriangle, CheckCircle2, ChevronRight, Trophy } from "lucide-react"

import { MODULES } from "@/content/index.mjs"
import {
  ANCHOR_IDS,
  OUTLINE,
  OUTLINE_BY_ID,
  firstIncompleteModuleId,
  moduleIdForAnchor,
} from "@/lib/outline"
import { LabNav } from "@/components/lab-nav"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Callout,
  CodeBlock,
  DataTable,
  Inline,
  Prompt,
  Question,
  Quiz,
  Think,
  TierHead,
  LabIdentityContext,
} from "@/components/blocks"
import { LabDefaults } from "@/components/lab-defaults"
import { CarRoadFigure } from "@/components/figures/car-road"
import { cn } from "@/lib/utils"

/** Offline cache key. The server remains authoritative; see reconcile below. */
const CACHE = "snowcup-lab-progress"

interface StepState {
  stepKey: string
  /** Lab section (m0..m10) within the training, not the training itself. */
  sectionId: string
  sectionSeq: number
  done: boolean
}

async function getJson(url: string) {
  const res = await fetch(url)
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(body?.error || `${url} failed (${res.status})`)
  return body
}

export function Lab() {
  const qc = useQueryClient()

  const session = useQuery({ queryKey: ["session"], queryFn: () => getJson("/api/session") })
  const progress = useQuery({ queryKey: ["progress"], queryFn: () => getJson("/api/progress") })
  const score = useQuery({ queryKey: ["score"], queryFn: () => getJson("/api/score") })
  const quiz = useQuery({ queryKey: ["quiz"], queryFn: () => getJson("/api/quiz") })

  /** ref -> { correct, attempts } from the server. */
  const quizState = useMemo(() => {
    const m = new Map<string, { correct: boolean; attempts: number }>()
    for (const a of quiz.data?.answers ?? []) {
      m.set(String(a.ref), { correct: a.correct === true, attempts: Number(a.attempts ?? 0) })
    }
    return m
  }, [quiz.data])

  /**
   * Last graded response per question. Held in component state rather than in the
   * query cache because it is a reply to one submission, not server state -- and
   * the explanation must not persist into a fresh page load, where it would
   * appear before the learner has answered.
   */
  const [quizFeedback, setQuizFeedback] = useState<
    Record<string, { correct: boolean; explanation: string | null }>
  >({})

  const submitQuiz = useMutation({
    mutationFn: async (vars: { ref: string; choice: number }) => {
      const res = await fetch("/api/quiz", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(vars),
      })
      const body = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(body?.error || "Could not check your answer")
      return body as { ref: string; correct: boolean; explanation: string | null }
    },
    onSuccess: (body) => {
      setQuizFeedback((prev) => ({
        ...prev,
        [body.ref]: { correct: body.correct, explanation: body.explanation },
      }))
      // Correctness is sticky server-side, so refetch rather than guess locally.
      qc.invalidateQueries({ queryKey: ["quiz"] })
      // A correct answer can be the thing that completes the training.
      qc.invalidateQueries({ queryKey: ["progress"] })
    },
  })

  const steps: StepState[] = progress.data?.steps ?? []
  const doneKeys = useMemo(
    () => new Set(steps.filter((s) => s.done).map((s) => s.stepKey)),
    [steps],
  )

  /**
   * Mirror server state into localStorage so a learner who loses connectivity
   * still sees their ticks. The server is authoritative on load -- we never push
   * the cache back up, because doing so could resurrect a checkpoint the learner
   * deliberately cleared on another device.
   */
  useEffect(() => {
    if (!steps.length) return
    try {
      localStorage.setItem(CACHE, JSON.stringify([...doneKeys]))
    } catch {
      // Private browsing or a full quota. The lab still works; only the offline
      // convenience is lost, so there is nothing worth telling the learner.
    }
  }, [steps, doneKeys])

  const cached: string[] = useMemo(() => {
    if (typeof window === "undefined") return []
    try {
      const raw = localStorage.getItem(CACHE)
      return raw ? (JSON.parse(raw) as string[]) : []
    } catch {
      return []
    }
  }, [])

  const setStep = useMutation({
    mutationFn: async (vars: { stepKey: string; done: boolean }) => {
      const res = await fetch("/api/progress", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(vars),
      })
      const body = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(body?.error || "Could not save your progress")
      return body
    },
    // Optimistic: ticking a box should feel instant. Snapshot first so a failed
    // write rolls back rather than leaving the UI lying about what was saved.
    onMutate: async (vars) => {
      await qc.cancelQueries({ queryKey: ["progress"] })
      const prev = qc.getQueryData<{ steps: StepState[] }>(["progress"])
      qc.setQueryData<{ steps: StepState[] }>(["progress"], (old) =>
        old
          ? {
              ...old,
              steps: old.steps.map((s) =>
                s.stepKey === vars.stepKey ? { ...s, done: vars.done } : s,
              ),
            }
          : old,
      )
      return { prev }
    },
    onError: (_e, _vars, ctx) => {
      if (ctx?.prev) qc.setQueryData(["progress"], ctx.prev)
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["progress"] }),
  })

  const total = steps.length || MODULES.length
  const completed = doneKeys.size
  const pct = total ? Math.round((completed / total) * 100) : 0
  const offline = progress.isError && cached.length > 0

  /**
   * Quiz tally for the pinned bar. The denominator comes from the CONTENT model
   * rather than from the learner's answers, so it reads 3/22 and not 3/3 before
   * they have worked through the rest. QUIZ_KEY is the server-side allowlist and
   * check_quizzes.py asserts the two agree, so counting blocks here is safe.
   */
  const quizTotal = useMemo(
    () =>
      MODULES.reduce(
        (n, m) => n + m.blocks.filter((b) => b.kind === "quiz").length,
        0,
      ),
    [],
  )
  /** Correctness is sticky server-side, so this only ever goes up. */
  const quizCorrect = useMemo(
    () => [...quizState.values()].filter((s) => s.correct).length,
    [quizState],
  )

  /**
   * Keep --lab-anchor-offset in step with the real height of the sticky stack.
   *
   * WHY THIS IS MEASURED AND NOT A CONSTANT. Two sticky elements sit above the
   * content: the app header and the identity bar. The bar WRAPS -- three lines
   * on a phone, two on a laptop, one on a wide screen -- and its contents vary
   * per learner, because the challenge score only appears after their first
   * submission. Any hardcoded scroll-margin is therefore wrong for somebody, and
   * when it is too small the heading they just clicked is hidden behind the bar,
   * which reads as broken navigation rather than as a CSS offset being off.
   */
  const barRef = useRef<HTMLDivElement | null>(null)
  useEffect(() => {
    const bar = barRef.current
    if (!bar) return
    const apply = () => {
      const header = document.querySelector("header")
      const headerH = header?.getBoundingClientRect().height ?? 56
      // A little breathing room so the heading is not flush against the bar.
      const offset = Math.round(headerH + bar.getBoundingClientRect().height + 16)
      document.documentElement.style.setProperty(
        "--lab-anchor-offset",
        `${offset}px`,
      )
    }
    apply()
    const ro = new ResizeObserver(apply)
    ro.observe(bar)
    const header = document.querySelector("header")
    if (header) ro.observe(header)
    return () => ro.disconnect()
    // Re-measure when the bar's contents change, since that changes its height.
  }, [quiz.data, score.data, session.data, completed])

  /**
   * Which module sections are open. Seeded ONCE, from the first successful
   * progress load, to the first module whose checkpoint is not ticked -- so a
   * returning learner lands where they left off.
   *
   * The `seeded` ref matters: without it a background refetch would recompute
   * the default and slam shut whatever the learner had opened since.
   */
  const [expanded, setExpanded] = useState<Set<string>>(new Set())
  const seeded = useRef(false)

  useEffect(() => {
    if (seeded.current || !progress.isSuccess) return
    seeded.current = true
    setExpanded(new Set([firstIncompleteModuleId(doneKeys)]))
  }, [progress.isSuccess, doneKeys])

  const toggleModule = useCallback((id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }, [])

  /** Used by deep links and nav clicks: never collapses, only ensures open. */
  const ensureExpanded = useCallback((id: string) => {
    setExpanded((prev) => (prev.has(id) ? prev : new Set(prev).add(id)))
  }, [])

  const allOpen = expanded.size >= MODULES.length

  /* ----------------------------------------------------------------------- *
   * Navigation
   *
   * A collapsed section is UNMOUNTED, so its inner heading anchors do not exist
   * in the DOM. Scrolling therefore cannot happen in the same tick as the click:
   * expand first, record where we were headed, and let an effect scroll once the
   * target has actually rendered. Without this, every link into a closed module
   * silently did nothing.
   * ----------------------------------------------------------------------- */
  const [activeModuleId, setActiveModuleId] = useState<string | null>(null)
  const [activeStepId, setActiveStepId] = useState<string | null>(null)
  const [pendingAnchor, setPendingAnchor] = useState<string | null>(null)
  const [navOpen, setNavOpen] = useState(false)

  const navigateTo = useCallback(
    (anchor: string) => {
      const owner = moduleIdForAnchor(anchor)
      if (owner) ensureExpanded(owner)
      setPendingAnchor(anchor)
      setNavOpen(false)
    },
    [ensureExpanded],
  )

  useEffect(() => {
    if (!pendingAnchor) return
    const el = document.getElementById(pendingAnchor)
    if (!el) return // still mounting; the next render will bring us back here
    el.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "auto"
        : "smooth",
      block: "start",
    })
    setPendingAnchor(null)
  }, [pendingAnchor, expanded])

  /** Honour a deep link on first load and on every subsequent hash change. */
  useEffect(() => {
    const applyHash = () => {
      const raw = window.location.hash.replace(/^#/, "")
      if (raw && ANCHOR_IDS.has(raw)) navigateTo(raw)
    }
    applyHash()
    window.addEventListener("hashchange", applyHash)
    return () => window.removeEventListener("hashchange", applyHash)
  }, [navigateTo])

  /*
   * Scroll-spy: highlight where the learner is.
   *
   * A scroll handler rather than IntersectionObserver, because sections mount and
   * unmount as they collapse -- observers would have to be torn down and rebuilt
   * on every toggle, whereas querying on demand is always current. Same 160px
   * activation line the original lab used, and rAF-throttled so a fast scroll
   * costs one measurement per frame.
   *
   * Deliberately does NOT collapse anything. In the original it was the nav that
   * auto-collapsed; doing that to body content would pull text out from under
   * someone mid-read.
   */
  useEffect(() => {
    const LINE = 160
    let raf = 0
    const measure = () => {
      raf = 0
      let mod: string | null = null
      for (const m of OUTLINE) {
        const el = document.getElementById(m.id)
        if (el && el.getBoundingClientRect().top <= LINE) mod = m.id
      }
      let step: string | null = null
      if (mod) {
        for (const s of OUTLINE_BY_ID.get(mod)?.steps ?? []) {
          const el = document.getElementById(s.id)
          if (el && el.getBoundingClientRect().top <= LINE) step = s.id
        }
      }
      setActiveModuleId(mod)
      setActiveStepId(step)
    }
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(measure)
    }
    measure()
    window.addEventListener("scroll", onScroll, { passive: true })
    window.addEventListener("resize", onScroll)
    return () => {
      window.removeEventListener("scroll", onScroll)
      window.removeEventListener("resize", onScroll)
      if (raf) cancelAnimationFrame(raf)
    }
    // Re-measure when sections open or close, since every position below shifts.
  }, [expanded])

  const nav = (
    <LabNav
      doneKeys={doneKeys}
      expanded={expanded}
      activeModuleId={activeModuleId}
      activeStepId={activeStepId}
      onNavigate={navigateTo}
      onToggleModule={toggleModule}
    />
  )

  return (
    <LabIdentityContext.Provider
      value={{
        buildSchema: session.data?.buildSchema ?? null,
        buildRole: session.data?.buildRole ?? null,
      }}
    >
    <div className="lg:grid lg:grid-cols-[15rem_minmax(0,1fr)] lg:gap-10">
      {/* Desktop: sticky outline. Its own scroll, because 11 modules plus m6's
          nine steps comfortably exceed the viewport. */}
      <aside className="hidden lg:block">
        <div className="sticky top-14 max-h-[calc(100vh-3.5rem)] overflow-y-auto py-2 pr-2">
          {nav}
        </div>
      </aside>

      <div className="space-y-8">
        {/* Mobile: the same outline behind a disclosure, so no drawer library. */}
        <div className="lg:hidden">
          <Button
            variant="outline"
            size="sm"
            aria-expanded={navOpen}
            onClick={() => setNavOpen((v) => !v)}
          >
            {navOpen ? "Hide contents" : "Contents"}
          </Button>
          {navOpen && (
            <div className="mt-3 rounded-xl border border-border p-2">{nav}</div>
          )}
        </div>

        {/* Identity + progress summary.

            STICKY, and deliberately so: a learner deep in Module 6 needs to see
            which role and schema they are building into without scrolling back
            up. It pins under the 3.5rem app header, so the two stack rather
            than overlap.

            The negative inline margin lets the background bleed into the page's
            px-4 gutter, so module content scrolling underneath is covered rather
            than showing through at the edges.

            IF YOU CHANGE THE HEIGHT OF THIS BAR, change the scroll-mt on the
            <section> and step <h3> below to match, or anchor navigation will
            land with the heading hidden behind it. */}
      <div
        ref={barRef}
        className="sticky top-14 z-40 -mx-4 flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-border bg-background px-4 py-2.5 text-sm text-muted-foreground"
      >
        <span>
          Signed in as{" "}
          <strong className="text-foreground">{session.data?.user ?? "…"}</strong>
        </span>
        <LabDefaults
          defaults={session.data?.defaults}
          allOk={session.data?.defaultsOk}
          buildSpaceStatus={session.data?.buildSpaceStatus}
          activeRole={session.data?.activeRole}
        />
        <span>
          Checkpoints{" "}
          <strong className="text-foreground">
            {completed}/{total}
          </strong>{" "}
          ({pct}%)
        </span>
        {/* Guarded on quiz.data so the bar does not flash 0/22 before the answers
            land, which would read as lost progress on every page load. */}
        {quiz.data && (
          <span>
            Quizzes{" "}
            <strong className="text-foreground">
              {quizCorrect}/{quizTotal}
            </strong>
          </span>
        )}
        {score.data && (
          <span className="inline-flex items-center gap-1.5">
            <Trophy className="h-3.5 w-3.5" />
            Challenge{" "}
            <strong className="text-foreground">
              {score.data.points}/{score.data.maxPoints}
            </strong>
            {score.data.correct > 0 && (
              <Badge variant="outline">
                {score.data.correct} of {score.data.questions} solved
              </Badge>
            )}
          </span>
        )}
      </div>

      <div className="flex items-center gap-3">
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sky-500 to-violet-500 transition-all"
            style={{ width: `${pct}%` }}
          />
        </div>
        {/* Reviewing before the challenge means wanting everything open at once. */}
        <Button
          variant="outline"
          size="sm"
          className="shrink-0"
          onClick={() =>
            setExpanded(allOpen ? new Set() : new Set(OUTLINE.map((m) => m.id)))
          }
        >
          {allOpen ? "Collapse all" : "Expand all"}
        </Button>
      </div>

      {setStep.isError && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Your last checkpoint was not saved</AlertTitle>
          <AlertDescription>
            {(setStep.error as Error).message} Your other progress is unaffected — try
            ticking it again.
          </AlertDescription>
        </Alert>
      )}

      {offline && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Showing your last known progress</AlertTitle>
          <AlertDescription>
            We could not reach Snowflake, so these ticks come from this browser and new
            ones will not be saved until the connection returns.
          </AlertDescription>
        </Alert>
      )}

      {MODULES.map((mod) => {
        const outline = OUTLINE_BY_ID.get(mod.id)
        const isOpen = expanded.has(mod.id)
        const bodyId = `${mod.id}-body`
        const moduleDone = outline?.checkpointKey
          ? doneKeys.has(outline.checkpointKey)
          : false
        return (
          <section key={mod.id} id={mod.id} className="scroll-mt-[var(--lab-anchor-offset)]">
            {/*
              The header is the disclosure control. The tick here is decorative --
              the real checkbox lives in the body, so there is exactly one place
              that writes progress and no chance of a header click recording a
              checkpoint the learner did not mean to claim.
            */}
            <button
              type="button"
              aria-expanded={isOpen}
              aria-controls={bodyId}
              onClick={() => toggleModule(mod.id)}
              className={cn(
                "group mb-4 flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors",
                isOpen ? "border-border bg-muted/30" : "border-border hover:bg-muted/40",
              )}
            >
              <ChevronRight
                aria-hidden
                className={cn(
                  "h-4 w-4 shrink-0 text-muted-foreground transition-transform motion-reduce:transition-none",
                  isOpen && "rotate-90",
                )}
              />
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-sky-500 to-violet-500 text-sm font-bold text-white">
                {mod.seq}
              </div>
              <div className="min-w-0">
                <div className="text-[0.7rem] font-bold uppercase tracking-[0.14em] text-sky-600 dark:text-sky-400">
                  {mod.phase}
                </div>
                <h2 className="text-xl font-semibold tracking-tight">
                  <Inline text={mod.title} />
                </h2>
              </div>
              <div className="ml-auto flex shrink-0 items-center gap-2">
                {/* Only useful when collapsed: tells the learner how much is hidden. */}
                {!isOpen && outline && outline.steps.length > 0 && (
                  <span className="text-xs text-muted-foreground">
                    {outline.steps.length} steps
                  </span>
                )}
                {moduleDone && (
                  <CheckCircle2 aria-hidden className="h-5 w-5 text-emerald-500" />
                )}
                <span className="sr-only">
                  {moduleDone ? "Checkpoint complete." : "Checkpoint not complete."}
                </span>
              </div>
            </button>

            {isOpen && (
              <div id={bodyId}>
                {mod.blocks.map((block, i) => {
                  const key = `${mod.id}-${i}`
                  switch (block.kind) {
                    case "prose":
                      return (
                        <p key={key} className="my-3 leading-relaxed text-muted-foreground">
                          <Inline text={block.text} />
                        </p>
                      )
                    case "heading":
                      return (
                        <h3
                          key={key}
                          id={outline?.stepIdByBlock.get(i)}
                          className="mt-6 mb-2 scroll-mt-[var(--lab-anchor-offset)] text-base font-semibold"
                        >
                          <Inline text={block.text} />
                        </h3>
                      )
                    case "list":
                      return block.ordered ? (
                        <ol key={key} className="my-3 ml-6 list-decimal space-y-1.5 text-muted-foreground">
                          {block.items.map((item, j) => (
                            <li key={j}>
                              <Inline text={item} />
                            </li>
                          ))}
                        </ol>
                      ) : (
                        <ul key={key} className="my-3 ml-6 list-disc space-y-1.5 text-muted-foreground">
                          {block.items.map((item, j) => (
                            <li key={j}>
                              <Inline text={item} />
                            </li>
                          ))}
                        </ul>
                      )
                    case "callout":
                      return (
                        <Callout
                          key={key}
                          variant={block.variant}
                          text={block.text}
                          items={block.items}
                          after={block.after}
                        />
                      )
                    case "prompt":
                      return <Prompt key={key} label={block.label} text={block.text} />
                    case "think":
                      return <Think key={key} label={block.label} text={block.text} />
                    case "tier":
                      return (
                        <TierHead key={key} label={block.label} note={block.note} tier={block.tier} />
                      )
                    case "question":
                      return (
                        <Question
                          key={key}
                          id={block.id}
                          points={block.points}
                          text={block.text}
                          why={block.why}
                          exercises={block.exercises}
                        />
                      )
                    case "figure":
                      return <CarRoadFigure key={key} />
                    case "quiz": {
                      const st = quizState.get(block.ref)
                      return (
                        <Quiz
                          key={key}
                          ref_={block.ref}
                          text={block.text}
                          options={block.options}
                          correct={st?.correct ?? false}
                          attempts={st?.attempts ?? 0}
                          pending={
                            submitQuiz.isPending && submitQuiz.variables?.ref === block.ref
                          }
                          feedback={quizFeedback[block.ref] ?? null}
                          onSubmit={(choice) =>
                            submitQuiz.mutate({ ref: block.ref, choice })
                          }
                        />
                      )
                    }
                    case "code":
                      return <CodeBlock key={key} text={block.text} />
                    case "table":
                    case "challenge":
                      return <DataTable key={key} head={block.head} rows={block.rows} />
                    case "checkpoint": {
                      const done = doneKeys.has(block.key)
                      const pending =
                        setStep.isPending && setStep.variables?.stepKey === block.key
                      return (
                        <label
                          key={key}
                          className={cn(
                            "my-5 flex cursor-pointer items-start gap-3 rounded-xl border px-4 py-3 transition-colors",
                            done
                              ? "border-emerald-500/40 bg-emerald-500/[0.08]"
                              : "border-border hover:bg-muted/40",
                            pending && "opacity-60",
                          )}
                        >
                          <Checkbox
                            checked={done}
                            disabled={progress.isLoading}
                            onCheckedChange={(next) =>
                              setStep.mutate({ stepKey: block.key, done: next === true })
                            }
                            className="mt-0.5"
                          />
                          <span className="text-[0.95rem] leading-relaxed text-muted-foreground">
                            <Inline text={block.text} />
                          </span>
                          {done && (
                            <CheckCircle2 className="ml-auto mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                          )}
                        </label>
                      )
                    }
                    default:
                      return null
                  }
                })}
              </div>
            )}
          </section>
        )
      })}

      </div>
    </div>
    </LabIdentityContext.Provider>
  )
}
