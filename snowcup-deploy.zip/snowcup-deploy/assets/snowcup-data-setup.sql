/*=============================================================================
  SNOWCUP — SHARED DATA SETUP   (FACILITATOR / ADMIN — run ONCE)
  ============================================================================
  *** This is an ADMIN script. Learners do NOT run it. ***

  Run this once to stand up the shared, read-only SNOWCUP dataset that every
  learner builds their semantic view and agent on top of. Because all learners
  read the SAME rows, every challenge answer is identical for everyone — no one
  spends the session generating data; they focus on modeling and agent building.

  The data is 100% synthetic: invented nations, players and results. No PII/PHI.

  WHAT THIS SCRIPT DOES  (self-contained — just run it as ACCOUNTADMIN)
    1. Creates a dedicated warehouse (SNOWCUP_WH) — nothing to pre-create.
    2. Creates SNOWCUP_SHARED.TOURNAMENT and loads the 6 tables.
    3. Grants SELECT on them (read-only) to the SNOWCUP_PARTICIPANT role.
    4. Creates a per-learner build database (SNOWCUP_BUILDS) and a
       PROVISION_LEARNER helper. To add learners, add one CALL line per learner
       (see the ROSTER block near the end). As shipped it provisions just you.
  Learners build the Cortex Search service themselves (lab Module 4), so this
  script deliberately does NOT create one.

  TABLES (schema SNOWCUP_SHARED.TOURNAMENT)
    - PLAYERS             1 row / player     (name, nation, position; no nickname)
    - PLAYER_PROFILES     1 row / player     (nickname + bio; search owns the lore)
    - TOURNAMENTS         1 row / edition    (host, champion, golden boot/glove)
    - MATCHES             1 row / match      (stage, teams, score, margin)
    - PLAYER_MATCH_STATS  player x match     (minutes, goals, xg, assists, ...)
    - DISCIPLINE          player x match     (yellow/red cards, fouls)

  Data note: a handful of "star" players are hand-seeded so each challenge
  question has exactly one correct answer; the rest is generated with HASH()
  (never RANDOM()) so the dataset is identical on every run.

  SAFETY: no DROP DATABASE / DROP SCHEMA / DELETE / TRUNCATE, and no
  CREATE OR REPLACE on any database or schema -- so re-running this NEVER destroys
  work a learner has already built. Objects are created with CREATE OR REPLACE
  inside the shared database only; every database and schema uses IF NOT EXISTS.

  The one change this makes OUTSIDE the workshop's own objects is an account-level
  Cortex setting (CORTEX_ENABLED_CROSS_REGION), and it is only touched when it is
  DISABLED. When that happens the previous value and the exact statement to restore
  it are printed. Nothing else reaches beyond SNOWCUP_* objects except the learner
  DEFAULT_ROLE / DEFAULT_WAREHOUSE handling in PROVISION_LEARNER, which refuses to
  overwrite a default a user already has.
=============================================================================*/

-- ============================================================================
-- STEP 0: Admin context + a dedicated warehouse (created for you)
-- ============================================================================
USE ROLE ACCOUNTADMIN;                 -- or a role with CREATE DATABASE + CREATE WAREHOUSE
-- Cortex (Analyst / Search / agents / AI_COMPLETE) must be reachable, which needs
-- cross-region inference so the orchestration models work in any region.
--
-- This is an ACCOUNT-LEVEL setting whose default is DISABLED, and it is adjacent to
-- data residency -- an organisation may have chosen that deliberately. So it is
-- only changed when it is actually DISABLED, the previous value is reported, and
-- the statement to put it back is printed. "Idempotent" is not the same as
-- non-destructive, and silently loosening an account-wide control is not something
-- a workshop should do on the way past.
--
-- If it is set to an explicit region list rather than DISABLED, that list is left
-- exactly as it is. The workshop may still work (if the model's region is in the
-- list) or the Referee agent may fail to respond -- either way the deliberate
-- setting wins, and the message says so.
EXECUTE IMMEDIATE $$
DECLARE
  cur VARCHAR DEFAULT NULL;
BEGIN
  SHOW PARAMETERS LIKE 'CORTEX_ENABLED_CROSS_REGION' IN ACCOUNT;
  SELECT MAX("value") INTO :cur FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

  IF (UPPER(TRIM(COALESCE(:cur, ''))) = 'ANY_REGION') THEN
    RETURN 'cross-region inference already enabled (ANY_REGION) - account setting untouched';
  END IF;

  -- An explicit region list is a deliberate choice. Leave it exactly as it is.
  IF (:cur IS NOT NULL AND TRIM(:cur) <> '' AND UPPER(TRIM(:cur)) <> 'DISABLED') THEN
    RETURN 'cross-region inference is restricted to: ' || :cur
        || ' - LEFT UNCHANGED on purpose. If the Referee agent cannot respond, an '
        || 'ACCOUNTADMIN must decide whether to widen it.';
  END IF;

  -- Only reached when it is genuinely DISABLED (or unset). Handled rather than
  -- assumed: on some accounts this statement is refused (for example AI_SETTINGS
  -- guardrails), and an unhandled failure here would abort the whole data load.
  BEGIN
    ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';
  EXCEPTION WHEN OTHER THEN
    -- Markers are assembled by concatenation ('ACCT' || 'FAIL>') so the literal
    -- never appears in this file. snow echoes the query source it runs, so a
    -- plain marker would be matched in the echo and deploy.sh would report an
    -- account change on every run, including runs that changed nothing.
    RETURN 'ACCT' || 'FAIL> could not enable cross-region inference: ' || SQLERRM
        || ' -- nothing was changed. The rest of the workshop still loads, but the '
        || 'Referee agent may not respond until an ACCOUNTADMIN runs: '
        || 'ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = ''ANY_REGION'';';
  END;

  RETURN 'ACCT' || 'CHANGE> CORTEX_ENABLED_CROSS_REGION: '
      || COALESCE(NULLIF(TRIM(:cur), ''), 'DISABLED') || ' -> ANY_REGION, because '
      || 'Cortex orchestration models must be reachable. To restore afterwards: '
      || 'ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = '''
      || COALESCE(NULLIF(TRIM(:cur), ''), 'DISABLED')
      || '''; (accounts with AI_SETTINGS guardrails may refuse to narrow it again.)';
END;
$$;
-- Gen2 (GENERATION = '2') is a hard requirement for this workshop: it is faster
-- on the DML and table-scan work the agents generate, and being explicit keeps
-- the environment identical on every account. Newer orgs default to Gen2, but an
-- older org would silently give you Gen1 if this clause were omitted.
-- NOTE: Gen2 is unavailable in a small number of regions (currently AWS EU
-- Zurich, AWS Africa Cape Town, GCP Dammam, and the Azure US Gov Virginia
-- regions). Deploying there will fail on this statement by design -- drop the
-- GENERATION clause if you must run the workshop in one of them.
CREATE WAREHOUSE IF NOT EXISTS SNOWCUP_WH
  WITH GENERATION = '2'
       WAREHOUSE_SIZE = 'XSMALL'
       AUTO_SUSPEND = 60
       AUTO_RESUME = TRUE
       INITIALLY_SUSPENDED = TRUE
  COMMENT = 'SnowCup workshop warehouse (shared by the data, the grader/Referee, and learners).';

-- CREATE ... IF NOT EXISTS silently skips an existing warehouse, so re-running
-- this script would NOT apply these settings to an environment deployed earlier.
-- Set them explicitly. STATEMENT_TIMEOUT caps a runaway learner query so it
-- cannot hold a concurrency slot for hours in a shared room.
ALTER WAREHOUSE SNOWCUP_WH SET
  GENERATION = '2'
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  STATEMENT_TIMEOUT_IN_SECONDS = 300;

-- Concurrency, not query speed, is the limit in this workshop. Every query here
-- is small (measured: Analyst SQL ~0.6s, grader write ~0.3s, AI_COMPLETE ~4s),
-- but ONE cluster runs only MAX_CONCURRENCY_LEVEL (8) queries at a time. In a
-- guided session everyone reaches the same module together, so work queues --
-- and because a Cortex Agent has a *seconds* budget, a queued query can exhaust
-- it. The learner sees an agent that stalls, not a busy warehouse, and concludes
-- they built it wrong.
--
-- Hence 1-10 clusters on the STANDARD scaling policy: STANDARD starts a cluster
-- as soon as queries queue (ECONOMY makes them wait for sustained load), which
-- is the right trade for a live cohort. Idle clusters cost nothing; a Gen2
-- X-Small is ~1.35 credits/hour per running cluster on AWS.
--
-- Multi-cluster requires Enterprise Edition or higher, so report rather than
-- abort if it is unavailable -- the workshop still runs, just with less headroom.
EXECUTE IMMEDIATE $$
BEGIN
  ALTER WAREHOUSE SNOWCUP_WH SET
    MIN_CLUSTER_COUNT = 1
    MAX_CLUSTER_COUNT = 10
    SCALING_POLICY = 'STANDARD';
  RETURN 'Multi-cluster enabled: 1-10 clusters, STANDARD scaling. Sized for a few hundred concurrent learners.';
EXCEPTION
  WHEN OTHER THEN
    RETURN 'Multi-cluster NOT available on this edition - single X-Small Gen2 retained. '
        || 'Fine for a small group. For a large cohort raise WAREHOUSE_SIZE, give each '
        || 'cohort its own warehouse, or run in waves. See the facilitator guide, "Running at scale".';
END;
$$;

USE WAREHOUSE SNOWCUP_WH;           -- dedicated workshop warehouse — no COMPUTE_WH needed
SET SHARED_DB = 'SNOWCUP_SHARED';   -- shared, read-only data lives here

-- ============================================================================
-- STEP 1: Create the shared database + schema
-- ============================================================================
CREATE DATABASE IF NOT EXISTS IDENTIFIER($SHARED_DB);
USE DATABASE IDENTIFIER($SHARED_DB);
CREATE SCHEMA IF NOT EXISTS TOURNAMENT;
USE SCHEMA TOURNAMENT;

-- ============================================================================
-- STEP 2: Create tables
-- ============================================================================
CREATE OR REPLACE TABLE PLAYERS (
    PLAYER_ID       VARCHAR,
    PLAYER_NAME     VARCHAR,
    NATION          VARCHAR,
    POSITION        VARCHAR,     -- 'Goalkeeper' | 'Defender' | 'Midfielder' | 'Forward'
    CLUB            VARCHAR,
    HEIGHT_CM       NUMBER(38,0),
    PREFERRED_FOOT  VARCHAR      -- 'Left' | 'Right'
    -- NOTE: NICKNAME deliberately lives ONLY on PLAYER_PROFILES, never here.
    -- PLAYERS is the table learners model into their semantic view, so a
    -- nickname column here would let Cortex Analyst answer lore questions by
    -- string match and quietly defeat both the Module 6 "wrong tool" lesson
    -- and challenge Tier 4. Keeping it on the search-indexed profile table
    -- makes Cortex Search genuinely required. Verified empirically: with a
    -- nickname dimension exposed, an Analyst-only agent answered 3 of 4
    -- description-only lore questions correctly.
);

CREATE OR REPLACE TABLE TOURNAMENTS (
    EDITION_YEAR        NUMBER(38,0),
    HOST_NATION         VARCHAR,
    CHAMPION            VARCHAR,
    RUNNER_UP           VARCHAR,
    GOLDEN_BOOT_PLAYER  VARCHAR,   -- label only; the true top scorer is computable from stats
    GOLDEN_GLOVE_PLAYER VARCHAR
);

CREATE OR REPLACE TABLE MATCHES (
    MATCH_ID        VARCHAR,
    EDITION_YEAR    NUMBER(38,0),
    STAGE           VARCHAR,     -- 'Group' | 'Quarter-final' | 'Semi-final' | 'Final'
    HOME_TEAM       VARCHAR,
    AWAY_TEAM       VARCHAR,
    HOME_SCORE      NUMBER(38,0),
    AWAY_SCORE      NUMBER(38,0),
    VENUE           VARCHAR,
    ATTENDANCE      NUMBER(38,0),
    DECIDED_BY      NUMBER(38,0) -- goal margin = ABS(home_score - away_score); set in STEP 5
);

CREATE OR REPLACE TABLE PLAYER_MATCH_STATS (
    PLAYER_ID       VARCHAR,
    MATCH_ID        VARCHAR,
    MINUTES         NUMBER(38,0),
    GOALS           NUMBER(38,0),
    LATE_GOALS      NUMBER(38,0), -- goals scored in the 75th minute or later
    ASSISTS         NUMBER(38,0),
    SHOTS           NUMBER(38,0),
    XG              FLOAT,        -- expected goals
    XA              FLOAT,        -- expected assists
    PASSES          NUMBER(38,0),
    TACKLES         NUMBER(38,0),
    SPRINTS         NUMBER(38,0),
    DISTANCE_KM     FLOAT
);

CREATE OR REPLACE TABLE DISCIPLINE (
    PLAYER_ID       VARCHAR,
    MATCH_ID        VARCHAR,
    YELLOW_CARDS    NUMBER(38,0),
    RED_CARDS       NUMBER(38,0),
    FOULS           NUMBER(38,0)
);

CREATE OR REPLACE TABLE PLAYER_PROFILES (
    PLAYER_ID       VARCHAR,
    PLAYER_NAME     VARCHAR,
    NATION          VARCHAR,
    POSITION        VARCHAR,
    NICKNAME        VARCHAR,
    BIO             VARCHAR
);

-- ============================================================================
-- STEP 3: PLAYERS via the _ROSTER_LOAD staging table
--         (48 players — 8 competing nations x 5, + 8 depth players)
-- ============================================================================
-- Competing nations (appear in MATCHES): Powdermark, Flurria, Glacia, Cornice,
-- Rimeland, Cirrus, Snowholt, Driftland.
-- The roster is loaded into a short-lived staging table so that NICKNAME can be
-- routed to PLAYER_PROFILES (search's territory) and kept OUT of PLAYERS (the
-- table learners model). _ROSTER_LOAD is dropped at the end of STEP 9.
CREATE OR REPLACE TABLE _ROSTER_LOAD (
    PLAYER_ID       VARCHAR,
    PLAYER_NAME     VARCHAR,
    NATION          VARCHAR,
    POSITION        VARCHAR,
    CLUB            VARCHAR,
    HEIGHT_CM       NUMBER(38,0),
    PREFERRED_FOOT  VARCHAR,
    NICKNAME        VARCHAR
);

INSERT INTO _ROSTER_LOAD
  (PLAYER_ID, PLAYER_NAME, NATION, POSITION, CLUB, HEIGHT_CM, PREFERRED_FOOT, NICKNAME) VALUES
-- Driftland
('P01','Aldo Drifden',    'Driftland','Goalkeeper','Driftland City FC',191,'Right',NULL),
('P02','Marco Whitlock',  'Driftland','Defender',  'Driftland City FC',185,'Right',NULL),
('P03','Enzo Snowdon',    'Driftland','Defender',  'Port Glace',  183,'Left', NULL),
('P04','Luca Frostwick',   'Driftland','Midfielder','Driftland City FC',178,'Right',NULL),
('P05','Rico Glaze',   'Driftland','Forward',   'Driftland City FC',180,'Left', 'The Blizzard'),
-- Cirrus
('P06','Sten Cirrane',   'Cirrus','Goalkeeper','Cirrus United', 193,'Right',NULL),
('P07','Ivar Nimbus',      'Cirrus','Defender',  'Cirrus United', 187,'Right',NULL),
('P08','Bjorn Icefell',      'Cirrus','Defender',  'Nordfrost BK',   186,'Left', NULL),
('P09','Kai Winterholm',  'Cirrus','Midfielder','Cirrus United', 181,'Right',NULL),
('P10','Nils Vane',     'Cirrus','Forward',   'Cirrus United', 184,'Right','The Snowplow'),
-- Flurria
('P11','Gormar Hailstone',   'Flurria','Goalkeeper','Flurria FC',   194,'Right',NULL),
('P12','Roderik Rime',  'Flurria','Defender',  'Flurria FC',   188,'Right',NULL),
('P13','Halvor Grimsleet',   'Flurria','Defender',  'Rime Valley',    185,'Left', NULL),
('P14','Sorin Squall','Flurria','Midfielder','Flurria FC',   179,'Right',NULL),
('P15','Dain Thaw',    'Flurria','Forward',   'Flurria FC',   182,'Right','The Avalanche'),
-- Powdermark
('P16','Nevin Coldiron',    'Powdermark','Goalkeeper','Powdermark SK',   192,'Right',NULL),
('P17','Tomas Icewright',    'Powdermark','Defender',  'Powdermark SK',   186,'Right','The Snowsmith'),
('P18','Anders Snowfell',   'Powdermark','Defender',  'Frostgard IF',  184,'Left', NULL),
('P19','Petar Vossberg',     'Powdermark','Midfielder','Powdermark SK',   180,'Right',NULL),
('P20','Emil Sleet',     'Powdermark','Forward',   'Powdermark SK',   183,'Left', NULL),
-- Glacia
('P21','Paolo Glacio',    'Glacia','Goalkeeper','Glacia FC',     190,'Right',NULL),
('P22','Gino Icebourne',     'Glacia','Defender',  'Glacia FC',     184,'Right',NULL),
('P23','Marco Fennmoor',     'Glacia','Defender',  'Monteneve',     186,'Right',NULL),
('P24','Milo Chill',   'Glacia','Midfielder','Glacia FC',     176,'Left', 'The Late Frost'),
('P25','Dario Snowbelle',    'Glacia','Forward',   'Glacia FC',     181,'Right',NULL),
-- Cornice
('P26','Kova Icevault',   'Cornice','Goalkeeper','Cornice FC',   195,'Right','The Deep Freeze'),
('P27','Rurik Cornstone',     'Cornice','Defender',  'Cornice FC',   188,'Right',NULL),
('P28','Torvald Snowkane',   'Cornice','Defender',  'Icicle Town',    189,'Left', NULL),
('P29','Sigurd Snowvale',     'Cornice','Midfielder','Cornice FC',   182,'Right',NULL),
('P30','Alrik Snowstone',    'Cornice','Forward',   'Cornice FC',   183,'Right',NULL),
-- Snowholt
('P31','Lucian Marrfell',    'Snowholt','Goalkeeper','Snowholt CF',     191,'Right',NULL),
('P32','Viktor Icesen',    'Snowholt','Defender',  'Snowholt CF',     185,'Right',NULL),
('P33','Adrian Coldwell',    'Snowholt','Defender',  'Snowport',        184,'Left', NULL),
('P34','Felix Aranvale',     'Snowholt','Midfielder','Snowholt CF',     179,'Right',NULL),
('P35','Silas Flake',     'Snowholt','Forward',   'Snowholt CF',     178,'Right','The Whiteout'),
-- Rimeland
('P36','Dmitri Solrime',     'Rimeland','Goalkeeper','Rimeland FK',   192,'Right',NULL),
('P37','Bruno Kaltov',   'Rimeland','Defender',  'Rimeland FK',   187,'Right','The Iceman'),
('P38','Yuri Permafrost',    'Rimeland','Defender',  'Frostport',      185,'Left', NULL),
('P39','Andrei Lekvind',     'Rimeland','Midfielder','Rimeland FK',   180,'Right',NULL),
('P40','Stefan Icezar',    'Rimeland','Forward',   'Rimeland FK',   182,'Left', NULL),
-- Depth nations (in the player pool, did not qualify — no match stats)
('P41','Owen Hail',      'Sleetmoor', 'Forward',   'Sleetmoor FC',    181,'Right','The Hailstorm'),
('P42','Mateo Verglas',     'Frostmere','Midfielder','Frostmere CD',   178,'Left', NULL),
('P43','Kenji Yuki',     'Hailden', 'Forward',   'Hailden SC',    176,'Right','The Snow Fox'),
('P44','Hans Firnbach',  'Icemark','Defender',  'Icemark 04',   188,'Right',NULL),
('P45','Theo Icemarsh',     'Whitecap', 'Goalkeeper','Whitecap Bay',   190,'Right',NULL),
('P46','Wei Xue',       'Crystalia','Midfielder','Crystalia FC',   177,'Right',NULL),
('P47','Sami Lumi',      'Shimmerfell', 'Forward',   'Shimmerfell IF',    179,'Left', NULL),
('P48','Pieter Vestergaard','Tundrel', 'Defender',  'Tundrel United',186,'Right','The Snowbank');

-- Project the roster into PLAYERS without NICKNAME.
INSERT INTO PLAYERS
  (PLAYER_ID, PLAYER_NAME, NATION, POSITION, CLUB, HEIGHT_CM, PREFERRED_FOOT)
SELECT PLAYER_ID, PLAYER_NAME, NATION, POSITION, CLUB, HEIGHT_CM, PREFERRED_FOOT
  FROM _ROSTER_LOAD;

-- ============================================================================
-- STEP 4: TOURNAMENTS  (3 editions)
-- ============================================================================
-- Titles: Driftland 2018 + 2022, Cirrus 2026  => Driftland has the most (2).  [Q2]
INSERT INTO TOURNAMENTS
  (EDITION_YEAR, HOST_NATION, CHAMPION, RUNNER_UP, GOLDEN_BOOT_PLAYER, GOLDEN_GLOVE_PLAYER) VALUES
(2018,'Cirrus', 'Driftland','Cirrus', 'Dain Thaw', 'Nevin Coldiron'),
(2022,'Flurria','Driftland','Powdermark','Dain Thaw', 'Kova Icevault'),
(2026,'Snowholt', 'Cirrus','Driftland', 'Rico Glaze','Kova Icevault');

-- ============================================================================
-- STEP 5: MATCHES  (33 = 11 per edition)  Stages: Group, QF, SF, Final
-- ============================================================================
INSERT INTO MATCHES
  (MATCH_ID, EDITION_YEAR, STAGE, HOME_TEAM, AWAY_TEAM, HOME_SCORE, AWAY_SCORE, VENUE, ATTENDANCE) VALUES
-- 2018 (host Cirrus) — champion Driftland, runner-up Cirrus
('M2018-01',2018,'Group',        'Driftland','Snowholt', 2,1,'Cirrus Arena',    58000),
('M2018-02',2018,'Group',        'Cornice','Rimeland',3,0,'Nordfrost Stadium',52000),
('M2018-03',2018,'Group',        'Cirrus','Glacia',  1,0,'Cirrus Arena',    61000),
('M2018-04',2018,'Group',        'Flurria','Powdermark',4,3,'Rimefield Park',    47000),
('M2018-05',2018,'Quarter-final','Driftland','Rimeland', 2,1,'Cirrus Arena',    60000),
('M2018-06',2018,'Quarter-final','Cornice','Powdermark',2,0,'Nordfrost Stadium',53000),
('M2018-07',2018,'Quarter-final','Cirrus','Flurria', 3,2,'Cirrus Arena',    62000),
('M2018-08',2018,'Quarter-final','Glacia','Snowholt',  2,1,'Frostharbour Ground',    45000),
('M2018-09',2018,'Semi-final',   'Driftland','Cornice', 1,0,'Cirrus Arena',    63000),
('M2018-10',2018,'Semi-final',   'Cirrus','Glacia',  2,1,'Cirrus Arena',    64000),
('M2018-11',2018,'Final',        'Driftland','Cirrus',  2,1,'Cirrus Arena',    68000),
-- 2022 (host Flurria) — champion Driftland, runner-up Powdermark
('M2022-01',2022,'Group',        'Cornice','Snowholt', 2,0,'Rimefield Park',    49000),
('M2022-02',2022,'Group',        'Driftland','Glacia',  3,1,'Rimefield Park',    50000),
('M2022-03',2022,'Group',        'Powdermark','Rimeland',1,0,'Frostgard Dome',   44000),
('M2022-04',2022,'Group',        'Flurria','Cirrus', 3,2,'Glacier Stadium',  55000),
('M2022-05',2022,'Quarter-final','Cornice','Cirrus', 1,0,'Rimefield Park',    51000),
('M2022-06',2022,'Quarter-final','Driftland','Flurria', 3,2,'Rimefield Park',    52000),
('M2022-07',2022,'Quarter-final','Powdermark','Snowholt', 2,1,'Frostgard Dome',   46000),
('M2022-08',2022,'Quarter-final','Glacia','Rimeland', 3,2,'Glacier Stadium',  47000),
('M2022-09',2022,'Semi-final',   'Driftland','Glacia',  2,1,'Glacier Stadium',  57000),
('M2022-10',2022,'Semi-final',   'Powdermark','Cornice',1,0,'Glacier Stadium',  56000),
('M2022-11',2022,'Final',        'Driftland','Powdermark', 2,1,'Glacier Stadium',  60000),
-- 2026 (host Snowholt) — champion Cirrus, runner-up Driftland
('M2026-01',2026,'Group',        'Driftland','Rimeland', 3,0,'Snowholt Grand',    59000),
('M2026-02',2026,'Group',        'Cirrus','Snowholt',  2,1,'Snowholt Grand',    60000),
('M2026-03',2026,'Group',        'Cornice','Flurria',2,0,'Snowport Field',    48000),
('M2026-04',2026,'Group',        'Glacia','Powdermark', 2,2,'Snowport Field',    45000),
('M2026-05',2026,'Quarter-final','Driftland','Powdermark', 3,2,'Snowholt Grand',    61000),
('M2026-06',2026,'Quarter-final','Cirrus','Flurria', 1,0,'Snowholt Grand',    62000),
('M2026-07',2026,'Quarter-final','Cornice','Glacia', 1,0,'Snowport Field',    49000),
('M2026-08',2026,'Quarter-final','Rimeland','Snowholt', 3,2,'Snowholt Grand',    58000),
('M2026-09',2026,'Semi-final',   'Driftland','Cornice', 2,1,'Snowholt Grand',    63000),
('M2026-10',2026,'Semi-final',   'Cirrus','Rimeland', 1,0,'Snowholt Grand',    64000),
('M2026-11',2026,'Final',        'Cirrus','Driftland',  2,1,'Snowholt Grand',    69000);

UPDATE MATCHES SET DECIDED_BY = ABS(HOME_SCORE - AWAY_SCORE);

-- ============================================================================
-- STEP 6: STAR PLAYER STATS  (hand-authored signature performances)
-- ============================================================================
-- These players are excluded from the generated filler in STEP 7 and given
-- explicit, hand-authored rows here. Columns: PLAYER_ID, MATCH_ID, MINUTES,
-- GOALS, LATE_GOALS, ASSISTS, SHOTS, XG, XA, PASSES, TACKLES, SPRINTS, DISTANCE_KM

-- Rico Glaze (P05, Driftland FWD) — Driftland's talismanic striker.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P05','M2018-01',90,1,0,0,4,0.7,0.1,28,1,24,10.4),
('P05','M2018-05',90,1,0,1,5,0.7,0.4,30,0,26,10.8),
('P05','M2018-09',90,1,0,0,3,0.7,0.1,27,1,25,10.1),
('P05','M2018-11',90,1,0,1,5,0.7,0.3,29,0,27,10.6),
('P05','M2022-02',90,1,0,0,4,0.7,0.1,31,1,24,10.2),
('P05','M2022-06',90,1,0,1,5,0.7,0.3,28,0,26,10.7),
('P05','M2022-09',90,1,0,0,4,0.7,0.1,30,1,25,10.3),
('P05','M2022-11',90,1,0,0,5,0.7,0.2,29,0,27,10.5),
('P05','M2026-01',90,3,0,0,7,1.8,0.2,26,0,28,11.0),
('P05','M2026-05',90,2,0,1,6,1.4,0.4,27,0,27,10.9),
('P05','M2026-09',90,2,0,0,5,1.3,0.1,25,1,26,10.6),
('P05','M2026-11',90,2,0,0,6,1.4,0.2,28,0,29,11.2);

-- Nils Vane (P10, Cirrus FWD) — Cirrus's forward.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P10','M2018-03',90,1,0,0,3,0.6,0.1,22,0,23,10.0),
('P10','M2018-11',90,1,0,0,4,0.6,0.1,24,0,24,10.2),
('P10','M2022-04',90,2,0,0,5,1.0,0.1,23,0,25,10.3),
('P10','M2026-02',90,1,0,0,3,0.7,0.1,22,0,24,10.1),
('P10','M2026-06',90,1,0,1,4,0.6,0.3,25,0,26,10.5),
('P10','M2026-10',90,1,0,0,3,0.5,0.1,24,0,25,10.3),
('P10','M2026-11',90,1,0,0,4,1.0,0.1,26,0,27,10.6);

-- Dain Thaw (P15, Flurria FWD) — Flurria's forward.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P15','M2018-04',90,3,0,0,6,0.3,0.1,20,0,29,11.4),
('P15','M2018-07',90,2,0,0,5,0.2,0.1,21,0,28,11.1),
('P15','M2022-04',90,2,0,0,5,0.2,0.1,22,0,29,11.3),
('P15','M2022-06',90,2,0,0,5,0.3,0.1,20,0,28,11.0),
('P15','M2026-03',90,0,0,0,3,0.0,0.1,19,0,27,10.8),
('P15','M2026-06',90,0,0,0,2,0.0,0.1,18,0,26,10.5);

-- Tomas Icewright (P17, Powdermark DEF) — a playmaking defender who never shoots.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P17','M2018-04',90,0,0,1,0,0.0,0.6,55,4,22,10.7),
('P17','M2018-06',90,0,0,0,0,0.0,0.1,52,5,21,10.5),
('P17','M2022-03',90,0,0,1,0,0.0,0.5,58,3,22,10.8),
('P17','M2022-07',90,0,0,2,0,0.0,1.1,60,4,23,11.0),
('P17','M2022-10',90,0,0,1,0,0.0,0.6,57,5,22,10.6),
('P17','M2022-11',90,0,0,0,0,0.0,0.2,59,4,23,10.9),
('P17','M2026-04',90,0,0,1,0,0.0,0.5,54,3,21,10.4),
('P17','M2026-05',90,0,0,2,0,0.0,1.0,56,4,22,10.7);

-- Emil Sleet (P20, Powdermark FWD) — Powdermark's forward.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P20','M2018-04',90,2,0,0,5,1.5,0.1,23,0,26,10.6),
('P20','M2022-07',90,2,0,0,5,1.5,0.1,24,0,27,10.8),
('P20','M2022-11',90,1,0,0,4,1.0,0.1,22,0,25,10.4),
('P20','M2026-05',90,1,0,0,4,1.0,0.1,23,0,26,10.5);

-- Milo Chill (P24, Glacia MID) — Glacia's midfielder.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P24','M2018-03',90,0,0,0,2,0.6,0.2,44,2,27,11.3),
('P24','M2018-08',90,1,1,0,3,0.7,0.1,46,2,28,11.5),
('P24','M2018-10',90,1,1,0,3,0.7,0.1,45,3,27,11.4),
('P24','M2022-02',90,1,0,0,3,0.7,0.1,47,2,28,11.6),
('P24','M2022-08',90,2,2,0,4,0.9,0.1,48,2,29,11.8),
('P24','M2022-09',90,1,1,0,3,0.7,0.1,46,3,28,11.5),
('P24','M2026-04',90,1,0,0,3,0.7,0.1,45,2,27,11.3),
('P24','M2026-07',90,0,0,0,2,0.0,0.1,44,3,27,11.2);

-- Kova Icevault (P26, Cornice GK) — Cornice's goalkeeper; plays every Cornice match.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P26','M2018-02',90,0,0,0,0,0.0,0.0,18,0,8,5.2),
('P26','M2018-06',90,0,0,0,0,0.0,0.0,17,0,8,5.1),
('P26','M2018-09',90,0,0,0,0,0.0,0.0,19,0,9,5.3),
('P26','M2022-01',90,0,0,0,0,0.0,0.0,18,0,8,5.2),
('P26','M2022-05',90,0,0,0,0,0.0,0.0,17,0,8,5.0),
('P26','M2022-10',90,0,0,0,0,0.0,0.0,19,0,9,5.4),
('P26','M2026-03',90,0,0,0,0,0.0,0.0,18,0,8,5.2),
('P26','M2026-07',90,0,0,0,0,0.0,0.0,17,0,8,5.1),
('P26','M2026-09',90,0,0,0,0,0.0,0.0,20,0,9,5.5);

-- Silas Flake (P35, Snowholt FWD) — a low-mileage poacher (very few sprints).
INSERT INTO PLAYER_MATCH_STATS VALUES
('P35','M2018-01',90,1,0,0,3,1.0,0.1,12,0,2,7.1),
('P35','M2018-08',90,1,0,0,3,1.0,0.1,11,0,1,6.9),
('P35','M2022-01',90,1,0,0,2,1.0,0.1,13,0,2,7.2),
('P35','M2022-07',90,1,0,0,3,1.0,0.1,12,0,1,7.0),
('P35','M2026-02',90,2,0,0,4,2.0,0.1,11,0,2,7.1),
('P35','M2026-08',90,1,0,0,3,1.0,0.1,12,0,1,6.8);

-- Bruno Kaltov (P37, Rimeland DEF) — a hard-tackling defender.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P37','M2018-02',90,0,0,0,1,0.1,0.1,40,6,20,10.9),
('P37','M2018-05',90,0,0,0,1,0.1,0.1,38,5,19,10.6),
('P37','M2022-03',90,0,0,0,1,0.1,0.1,41,6,20,11.0),
('P37','M2022-08',90,0,0,0,2,0.2,0.1,39,5,19,10.7),
('P37','M2026-01',90,0,0,0,1,0.1,0.1,40,6,20,10.8),
('P37','M2026-08',90,0,0,0,2,0.2,0.1,38,5,19,10.5),
('P37','M2026-10',90,0,0,0,1,0.1,0.1,41,6,20,11.0);

-- ============================================================================
-- STEP 7: GENERATED FILLER STATS  (deterministic — HASH(), never RANDOM())
-- ============================================================================
-- Every non-star player of the two competing nations in a match gets one row.
-- Values are a pure function of (player_id, match_id) via HASH(), so the dataset
-- is byte-identical for every learner who runs it. The bounds keep the generated
-- filler realistic and reproducible: goals in {0,1}; knockout shots >= 1;
-- late_goals = 0; xg = goals.
INSERT INTO PLAYER_MATCH_STATS
  (PLAYER_ID, MATCH_ID, MINUTES, GOALS, LATE_GOALS, ASSISTS, SHOTS, XG, XA, PASSES, TACKLES, SPRINTS, DISTANCE_KM)
WITH parts AS (
  SELECT
    p.PLAYER_ID, p.POSITION, m.MATCH_ID, m.STAGE,
    ABS(HASH(p.PLAYER_ID || '|' || m.MATCH_ID)) AS H
  FROM MATCHES m
  JOIN PLAYERS p
    ON (p.NATION = m.HOME_TEAM OR p.NATION = m.AWAY_TEAM)
  WHERE p.PLAYER_ID NOT IN ('P05','P10','P15','P17','P20','P24','P26','P35','P37')
),
calc AS (
  SELECT
    PLAYER_ID, MATCH_ID, POSITION, STAGE, H,
    IFF(POSITION IN ('Forward','Midfielder') AND MOD(H,4)=0, 1, 0) AS G,
    IFF(STAGE <> 'Group', 1 + MOD(H,4), MOD(H,3))                  AS S
  FROM parts
)
SELECT
  PLAYER_ID,
  MATCH_ID,
  IFF(POSITION='Goalkeeper', 90, 62 + MOD(H,29))          AS MINUTES,
  G                                                        AS GOALS,
  0                                                        AS LATE_GOALS,
  IFF(POSITION<>'Goalkeeper' AND MOD(H,5)=0, 1, 0)         AS ASSISTS,
  IFF(POSITION='Goalkeeper', 0, S)                         AS SHOTS,
  IFF(POSITION='Goalkeeper', 0.0, CAST(G AS FLOAT))        AS XG,
  ROUND(0.10 * IFF(POSITION<>'Goalkeeper' AND MOD(H,5)=0,1,0), 2) AS XA,
  IFF(POSITION='Goalkeeper', 15 + MOD(H,10), 25 + MOD(H,45)) AS PASSES,
  IFF(POSITION='Goalkeeper', 0, MOD(H,6))                  AS TACKLES,
  IFF(POSITION='Goalkeeper', 6 + MOD(H,5), 18 + MOD(H,22)) AS SPRINTS,
  ROUND(IFF(POSITION='Goalkeeper', 4.5 + MOD(H,10)/10.0, 9.5 + MOD(H,35)/10.0), 1) AS DISTANCE_KM
FROM calc;

-- ============================================================================
-- STEP 8: DISCIPLINE  (one hand-authored high-discipline player; the rest generated + bounded)
-- ============================================================================
-- Bruno Kaltov's hand-authored discipline record.
INSERT INTO DISCIPLINE VALUES
('P37','M2018-02',1,0,5),
('P37','M2018-05',1,0,4),
('P37','M2022-03',1,0,5),
('P37','M2022-08',1,1,6),
('P37','M2026-01',1,0,4),
('P37','M2026-08',0,0,5),
('P37','M2026-10',1,0,4);

-- Everyone else: bounded low discipline (generated).
INSERT INTO DISCIPLINE (PLAYER_ID, MATCH_ID, YELLOW_CARDS, RED_CARDS, FOULS)
WITH parts AS (
  SELECT p.PLAYER_ID, m.MATCH_ID,
    ABS(HASH('D' || p.PLAYER_ID || '|' || m.MATCH_ID)) AS H
  FROM MATCHES m
  JOIN PLAYERS p
    ON (p.NATION = m.HOME_TEAM OR p.NATION = m.AWAY_TEAM)
  WHERE p.PLAYER_ID <> 'P37'
)
SELECT
  PLAYER_ID, MATCH_ID,
  IFF(MOD(H,5)=0, 1, 0)  AS YELLOW_CARDS,   -- at most 1 per match, ~1 in 5 matches
  0                      AS RED_CARDS,       -- no filler reds
  MOD(H,3)               AS FOULS            -- 0..2 per match
FROM parts;

-- ============================================================================
-- STEP 9: PLAYER_PROFILES  (bios + seeded lore — indexed by Cortex Search)
-- ============================================================================
INSERT INTO PLAYER_PROFILES (PLAYER_ID, PLAYER_NAME, NATION, POSITION, NICKNAME, BIO)
SELECT
  p.PLAYER_ID, p.PLAYER_NAME, p.NATION, p.POSITION, p.NICKNAME,
  CASE p.PLAYER_ID
    WHEN 'P35' THEN 'Silas Flake, the Snowholt forward known across the SnowCup as "The Whiteout". '
      || 'He barely runs — one of the lowest sprint counts of any outfield player — yet materialises '
      || 'in the six-yard box at the decisive moment to finish. Defenders say they never see him coming; '
      || 'by the time they turn, the ball is in the net and Flake has disappeared into the white again. A silent, minimal-movement poacher.'
    WHEN 'P37' THEN 'Bruno Kaltov, the Rimeland defender they call "The Iceman". '
      || 'A bruising stopper who treats every attacker as a personal affront. Referees know his name. '
      || 'A villain to opposing fans, a wall to his own.'
    WHEN 'P05' THEN 'Rico Glaze, "The Blizzard", the talismanic Driftland forward. '
      || 'Left-footed, ice-cold in front of goal, and the engine behind Driftland''s golden era.'
    WHEN 'P15' THEN 'Dain Thaw, "The Avalanche" of Flurria. A forward who buries defences under more goals than his chances '
      || 'suggest. Flurria lives and dies by his avalanches.'
    WHEN 'P17' THEN 'Tomas Icewright, "The Snowsmith" of Powdermark''s back line. A defender who never shoots — he builds. '
      || 'His killer passes turn defence into goals in the knockout rounds, all without a single shot to his name.'
    WHEN 'P24' THEN 'Milo Chill, "The Late Frost" of Glacia. A midfielder with a habit of scoring late — the sort who is '
      || 'still dangerous in the closing minutes when a knockout tie is finely balanced.'
    WHEN 'P26' THEN 'Kova Icevault, "The Deep Freeze" — Cornice''s goalkeeper. '
      || 'Nations simply do not score on him; shut-outs follow him from group stage to final.'
    WHEN 'P10' THEN 'Nils Vane, "The Snowplow" of Cirrus. A powerful, clinical forward and a mainstay of Cirrus''s 2026 title run.'
    WHEN 'P20' THEN 'Emil Sleet, Powdermark''s reliable forward — a steady source of goals through three SnowCup editions.'
    -- The three nicknamed depth-nation players. Their nations never qualified, so
    -- they carry no match stats: search can find them, Analyst has nothing to
    -- compute. That contrast is a useful teaching moment, so say it out loud here.
    WHEN 'P41' THEN 'Owen Hail, "The Hailstorm" of Sleetmoor — a forward with a fearsome strike. '
      || 'Sleetmoor have never qualified for a SnowCup, so his reputation is built entirely on club football.'
    WHEN 'P43' THEN 'Kenji Yuki, "The Snow Fox" of Hailden — a quick, cunning forward who finds space nobody else sees. '
      || 'Hailden are still waiting for their first SnowCup appearance.'
    WHEN 'P48' THEN 'Pieter Vestergaard, "The Snowbank" of Tundrel — an immovable defender attackers simply bounce off. '
      || 'Tundrel have yet to reach a SnowCup finals.'
    ELSE p.PLAYER_NAME || ' is a ' || LOWER(p.POSITION) || ' for ' || p.NATION
      || COALESCE(', nicknamed "' || p.NICKNAME || '"', '')
      || '. A dependable squad member across the SnowCup.'
  END AS BIO
FROM _ROSTER_LOAD p;

-- Staging table has served its purpose; NICKNAME now lives only on
-- PLAYER_PROFILES, which is what Cortex Search indexes.
DROP TABLE IF EXISTS _ROSTER_LOAD;

-- ============================================================================
-- STEP 10: Make the data read-only to learners + provision build schemas
-- ============================================================================
-- The SNOWCUP_PARTICIPANT role is also created by snowcup-grader-setup.sql;
-- create it here too so the two scripts can run in either order.
CREATE ROLE IF NOT EXISTS SNOWCUP_PARTICIPANT;

-- ---------------------------------------------------------------------------
-- SNOWCUP_FACILITATOR: lets a co-facilitator run the SnowCup Admin app (the
-- learner roster) WITHOUT holding ACCOUNTADMIN.
--
-- The admin app does its privileged work (CREATE ROLE / GRANT, which
-- Snowflake's restricted caller's rights forbids) with the app OWNER's rights,
-- and authorises the operator in application code. So membership of this role
-- IS the permission -- grant it narrowly, and never grant the app to PUBLIC.
--
-- The app checks roles the person HOLDS (CURRENT_AVAILABLE_ROLES), not just
-- their active role. That is deliberate: a session opens with the user's
-- DEFAULT role, and restricted caller's rights forbids USE ROLE, so a
-- role-based check would lock out real facilitators who would then have no way
-- to fix it from inside the app. Consequence: facilitators do NOT need to
-- switch roles before opening the app.
--
-- This role is also granted oversight privileges further down (it inherits
-- SNOWCUP_PARTICIPANT and every SNOWCUP_WS_ role, so a facilitator can reach
-- every build schema). It still cannot reach the answer key in
-- SNOWCUP_WORKSHOP.GRADING.
--
-- After deploying the app (see snowcup-admin-node/), finish the wiring:
--   GRANT USAGE, MONITOR ON APPLICATION SERVICE
--     SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP TO ROLE SNOWCUP_FACILITATOR;
--   GRANT USAGE ON WAREHOUSE SNOWFLAKE_APPS_QUERY_WH TO ROLE SNOWCUP_FACILITATOR;
--   GRANT ROLE SNOWCUP_FACILITATOR TO USER <person>;
-- ---------------------------------------------------------------------------
CREATE ROLE IF NOT EXISTS SNOWCUP_FACILITATOR
  COMMENT = 'Opens the SnowCup Admin app to run the learner roster without ACCOUNTADMIN. Membership is the permission - the app checks for this role before provisioning.';

-- Cortex privileges: learners use Cortex Analyst, Cortex Search, agents, and
-- AI_COMPLETE (the scouting skill). All of these require the SNOWFLAKE.CORTEX_USER
-- database role. Without this grant, Cortex features fail for the participant role.
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE SNOWCUP_PARTICIPANT;

-- Granted explicitly even though all four are on PUBLIC by default. On a hardened
-- account -- one that has revoked Cortex or Copilot from PUBLIC -- the lab would
-- otherwise fail with opaque errors that look nothing like a missing grant:
--   COPILOT_USER          Cortex Code itself. No CoCo, no lab.
--   CORTEX_AGENT_USER     the Agents API behind Snowflake CoWork.
--   USE AI FUNCTIONS      AI_COMPLETE, and the LLM-as-judge in Module 8 evals.
--   EXECUTE AGENT TASK    agent execution.
GRANT DATABASE ROLE SNOWFLAKE.COPILOT_USER      TO ROLE SNOWCUP_PARTICIPANT;
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_AGENT_USER TO ROLE SNOWCUP_PARTICIPANT;
GRANT USE AI FUNCTIONS   ON ACCOUNT TO ROLE SNOWCUP_PARTICIPANT;
GRANT EXECUTE AGENT TASK ON ACCOUNT TO ROLE SNOWCUP_PARTICIPANT;

-- Module 8 and 10 run Cortex Analyst evaluations, which execute as Snowflake TASKS.
-- EXECUTE TASK is ACCOUNT-scoped; CREATE TASK is schema-scoped and is granted per
-- learner in PROVISION_LEARNER. Both are required -- they are different objects.
-- Tasks also ignore SECONDARY roles, which is why the learner's primary role must
-- hold this directly or by inheritance.
GRANT EXECUTE TASK ON ACCOUNT TO ROLE SNOWCUP_PARTICIPANT;

-- Read-only access to the shared data (learners SELECT it; they never write it).
GRANT USAGE  ON DATABASE IDENTIFIER($SHARED_DB)                 TO ROLE SNOWCUP_PARTICIPANT;
GRANT USAGE  ON SCHEMA   SNOWCUP_SHARED.TOURNAMENT             TO ROLE SNOWCUP_PARTICIPANT;
GRANT SELECT ON ALL TABLES    IN SCHEMA SNOWCUP_SHARED.TOURNAMENT TO ROLE SNOWCUP_PARTICIPANT;
GRANT SELECT ON FUTURE TABLES IN SCHEMA SNOWCUP_SHARED.TOURNAMENT TO ROLE SNOWCUP_PARTICIPANT;
-- Views as well as tables: the grants above cover TABLES only, so a view added to
-- the shared schema later would be silently unreadable to every learner.
GRANT SELECT ON ALL VIEWS     IN SCHEMA SNOWCUP_SHARED.TOURNAMENT TO ROLE SNOWCUP_PARTICIPANT;
GRANT SELECT ON FUTURE VIEWS  IN SCHEMA SNOWCUP_SHARED.TOURNAMENT TO ROLE SNOWCUP_PARTICIPANT;
-- (If you renamed SHARED_DB above, change SNOWCUP_SHARED here to match.)

-- Enable change tracking so learners can build a Cortex Search service over the
-- shared data. The service is backed by a dynamic table and needs change tracking
-- on its source; a learner's read-only role can't auto-enable it (that needs
-- MODIFY on the base table), so the owner enables it here once.
--
-- ALL SIX TABLES, not just PLAYER_PROFILES. Module 4 points at PLAYER_PROFILES,
-- but any learner who picks a different table -- or asks CoCo to choose one -- hits
-- a hard failure their role cannot fix, mid-module, with no way forward.
ALTER TABLE SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES    SET CHANGE_TRACKING = TRUE;
ALTER TABLE SNOWCUP_SHARED.TOURNAMENT.PLAYERS            SET CHANGE_TRACKING = TRUE;
ALTER TABLE SNOWCUP_SHARED.TOURNAMENT.MATCHES            SET CHANGE_TRACKING = TRUE;
ALTER TABLE SNOWCUP_SHARED.TOURNAMENT.PLAYER_MATCH_STATS SET CHANGE_TRACKING = TRUE;
ALTER TABLE SNOWCUP_SHARED.TOURNAMENT.TOURNAMENTS        SET CHANGE_TRACKING = TRUE;
ALTER TABLE SNOWCUP_SHARED.TOURNAMENT.DISCIPLINE         SET CHANGE_TRACKING = TRUE;

-- Per-learner build space: one schema each, where a learner creates their own
-- semantic view, Cortex Search service, and agent over the shared data.
CREATE DATABASE IF NOT EXISTS SNOWCUP_BUILDS;
GRANT USAGE ON DATABASE SNOWCUP_BUILDS TO ROLE SNOWCUP_PARTICIPANT;

-- Learners run their semantic view / search / agent / skill on this warehouse.
--
-- OPERATE as well as USAGE: Cortex Code issues
--   ALTER WAREHOUSE SNOWCUP_WH RESUME IF SUSPENDED
-- on its own initiative. With USAGE only that fails with "Your primary role
-- SNOWCUP_WS_<NAME> must have OPERATE granted", which surfaces to the learner as
-- an unexplained error on their first query of the day.
GRANT USAGE, OPERATE ON WAREHOUSE SNOWCUP_WH TO ROLE SNOWCUP_PARTICIPANT;

-- ----------------------------------------------------------------------------
-- Role model: shared access is ONE role, build space is a role PER LEARNER.
-- ----------------------------------------------------------------------------
--   SNOWCUP_PARTICIPANT      shared, read-only: the tournament tables, the
--                            Referee agent, the grading procedures, the score
--                            views, the warehouse and Cortex. Deliberately has
--                            NO privileges on any WS_ build schema.
--   SNOWCUP_WS_<NAME>        one per learner. Build rights on that learner's own
--                            schema only, and SNOWCUP_PARTICIPANT nested inside
--                            it so a single DEFAULT_ROLE covers everything.
--                            Objects a learner creates are owned by this role,
--                            which is what keeps one learner's work private.
--   SNOWCUP_FACILITATOR      oversight. Every SNOWCUP_WS_ role is granted to it,
--                            so a facilitator can reach every build schema.
--
-- A granted role confers exactly its own privileges, so nesting
-- SNOWCUP_PARTICIPANT cannot expose anything it does not already hold - the
-- answer key in SNOWCUP_WORKSHOP.GRADING stays unreachable either way.
-- ----------------------------------------------------------------------------
-- Created above with its COMMENT; these are its oversight grants.
GRANT ROLE  SNOWCUP_PARTICIPANT      TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON DATABASE SNOWCUP_BUILDS TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON WAREHOUSE SNOWCUP_WH    TO ROLE SNOWCUP_FACILITATOR;
GRANT ROLE  SNOWCUP_FACILITATOR      TO ROLE ACCOUNTADMIN;

-- Admin home for the provisioning procedures called by the SnowCup Admin app.
-- SNOWCUP_WORKSHOP is also created by snowcup-grader-setup.sql; IF NOT EXISTS
-- here keeps the two scripts runnable in either order (same defensive pattern
-- already used for SNOWCUP_WH). Learners never get USAGE on this schema.
CREATE DATABASE IF NOT EXISTS SNOWCUP_WORKSHOP;
CREATE SCHEMA   IF NOT EXISTS SNOWCUP_WORKSHOP.ADMIN;
CREATE STAGE    IF NOT EXISTS SNOWCUP_WORKSHOP.ADMIN.APP_STAGE
  DIRECTORY = (ENABLE = TRUE)
  COMMENT = 'Admin schema for the SnowCup provisioning procedures.';

-- >>> PROVISION_RUN / PROVISION_EVENT: live progress for a provisioning batch.
--
--     WHY THIS EXISTS. Provisioning a cohort takes minutes -- each learner costs
--     ~12 round trips, including a full SHOW USERS and FIX_BUILD_OWNERSHIP -- and
--     the Admin app used to show nothing at all between "click" and "done". A
--     facilitator could not tell a slow run from a hung one, which is the single
--     thing they need to know while a room full of people waits.
--
--     WHY A TABLE RATHER THAN STREAMING THE RESPONSE. The app provisions the whole
--     batch inside ONE long request, so nothing can reach the browser until it
--     ends. Writing progress here lets the UI read it over a SEPARATE polling
--     request, with no streaming and no background jobs. It also means that if the
--     long request dies -- ingress timeout, closed laptop -- the exact person and
--     phase it stopped on survives, which previously was lost entirely.
--
--     APPEND-ONLY, one row per phase transition. No MERGE, and the timings come
--     out for free: the gap between consecutive rows IS the cost of that phase.
--     The UI derives "where are we now" from the newest row per person.
--
--     THESE TABLES ARE DIAGNOSTIC, NEVER AUTHORITATIVE. Provisioning succeeds or
--     fails on its own terms; every write here is best-effort (see
--     LOG_PROVISION_STEP). Nothing reads these tables to make a decision.
CREATE TABLE IF NOT EXISTS SNOWCUP_WORKSHOP.ADMIN.PROVISION_RUN (
  RUN_ID      VARCHAR       NOT NULL,
  STARTED_AT  TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP(),
  STARTED_BY  VARCHAR,
  TOTAL       NUMBER,
  FINISHED_AT TIMESTAMP_LTZ,
  PRIMARY KEY (RUN_ID)
)
COMMENT = 'One row per provisioning batch. FINISHED_AT NULL means still running (or the request died).';

CREATE TABLE IF NOT EXISTS SNOWCUP_WORKSHOP.ADMIN.PROVISION_EVENT (
  RUN_ID VARCHAR NOT NULL,
  PERSON VARCHAR NOT NULL,
  -- RESOLVE | PRECHECK | CREATE | GRANT | OWNERSHIP | DEFAULTS | DONE
  PHASE  VARCHAR NOT NULL,
  -- NULL while a phase is in flight. On DONE: OK | PARTIAL | SKIPPED | ERROR.
  STATE  VARCHAR,
  DETAIL VARCHAR,
  AT     TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
)
COMMENT = 'Append-only provisioning phase log. Newest row per (RUN_ID, PERSON) is the current state.';

-- Housekeeping. Append-only, but the rows are tiny and a workshop cohort is ~30
-- people, so this is not a real concern. Prune by hand if it ever matters:
--   DELETE FROM SNOWCUP_WORKSHOP.ADMIN.PROVISION_EVENT
--    WHERE RUN_ID IN (SELECT RUN_ID FROM SNOWCUP_WORKSHOP.ADMIN.PROVISION_RUN
--                      WHERE STARTED_AT < DATEADD(day, -30, CURRENT_TIMESTAMP()));
--   DELETE FROM SNOWCUP_WORKSHOP.ADMIN.PROVISION_RUN
--    WHERE STARTED_AT < DATEADD(day, -30, CURRENT_TIMESTAMP());

-- >>> LOG_PROVISION_STEP: record one phase transition. NEVER fails the caller.
--
--     THE ENTIRE POINT IS THAT THIS CANNOT BREAK PROVISIONING. It is called from
--     inside PROVISION_LEARNER, so if an unwritable table or a missing grant threw
--     from here, observability would take down the thing it is meant to observe.
--     The exception handler swallows everything and returns quietly.
--
--     P_RUN_ID NULL is the "not tracking this run" signal and writes nothing. That
--     is what keeps the original single-argument PROVISION_LEARNER, the batch
--     PROVISION_LEARNERS, and any facilitator calling it by hand working unchanged.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(
  P_RUN_ID VARCHAR, P_PERSON VARCHAR, P_PHASE VARCHAR, P_STATE VARCHAR, P_DETAIL VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
BEGIN
  IF (P_RUN_ID IS NULL OR TRIM(P_RUN_ID) = '') THEN
    RETURN 'untracked';
  END IF;

  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.PROVISION_EVENT (RUN_ID, PERSON, PHASE, STATE, DETAIL)
  VALUES (:P_RUN_ID, UPPER(NVL(:P_PERSON, '?')), :P_PHASE, :P_STATE, :P_DETAIL);

  RETURN 'logged';
EXCEPTION
  WHEN OTHER THEN
    -- Deliberately silent. A progress row is never worth failing a provision over.
    RETURN 'log failed';
END;
$$;

-- >>> USER_DEFAULTS_BACKUP: what each learner's session defaults were BEFORE the lab.
--
--     The lab sets three properties on a learner's user (DEFAULT_ROLE,
--     DEFAULT_WAREHOUSE, DEFAULT_NAMESPACE) because Cortex Code in Snowsight
--     reads ONLY the default role -- it ignores the Snowsight role picker, and
--     asking it to switch roles mid-session does nothing. Session context is
--     fixed when the session is created, so the defaults are the only lever.
--     See MY_LAB_DEFAULTS_RESTORE for the way back.
--
--     DEFAULT_SECONDARY_ROLES is deliberately NOT managed. A learner's
--     DEFAULT_ROLE is SNOWCUP_WS_<NAME>, which inherits SNOWCUP_PARTICIPANT, so
--     the primary role alone covers shared data and their build schema. Nothing
--     in the lab depends on secondary roles being narrowed, so the lab does not
--     touch a property it does not need.
--
--     CAPTURE-ONCE, never update. Provisioning is idempotent and gets re-run; on
--     the second run the user's CURRENT values ARE the lab values, so an upsert
--     would overwrite the snapshot with lab settings and destroy the original
--     permanently. Every write below is MERGE ... WHEN NOT MATCHED THEN INSERT.
CREATE TABLE IF NOT EXISTS SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP (
  USERNAME                     VARCHAR       NOT NULL,
  ORIG_DEFAULT_ROLE            VARCHAR,
  ORIG_DEFAULT_WAREHOUSE       VARCHAR,
  ORIG_DEFAULT_NAMESPACE       VARCHAR,
  CAPTURED_AT                  TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP(),
  CAPTURED_BY                  VARCHAR,
  RESTORED_AT                  TIMESTAMP_LTZ
)
COMMENT = 'Pre-lab session defaults per learner. Capture-once; never updated on re-provision.';

-- The table above is CREATE ... IF NOT EXISTS, so an account provisioned by an
-- earlier version still carries the retired secondary-roles column. Drop it here
-- so source and account agree. Idempotent, and safe to re-run.
ALTER TABLE IF EXISTS SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP
  DROP COLUMN IF EXISTS ORIG_DEFAULT_SECONDARY_ROLES;

-- >>> APPLY_LAB_DEFAULTS: snapshot a learner's defaults, then set the lab's three.
--
--     EXECUTE AS OWNER on purpose. Users are ACCOUNTADMIN-owned, so a
--     SNOWCUP_FACILITATOR caller cannot ALTER USER or read SHOW USERS. Running
--     this step as the owner is what lets a facilitator provision at all. The
--     escalation is fenced by three refusals below, not by the caller's role.
--
--     REFUSES to touch:
--       - the caller's own user (a smoke test must not hijack the admin session)
--       - anyone holding ACCOUNTADMIN or SNOWCUP_FACILITATOR (they do real work
--         in this account; their defaults are not ours to rewrite, and skipping
--         them also closes the "provision an admin to rewrite their defaults"
--         path that owner's rights would otherwise open)
--
--     FAILS CLOSED. The old procedure protected users by never overwriting an
--     existing default. That guard is gone -- the lab needs all four set -- so
--     its replacement is: if the snapshot cannot be taken, do not change
--     anything. An unreadable user or an unwritable backup table both abort.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.APPLY_LAB_DEFAULTS(NAME VARCHAR, WSROLE VARCHAR, WSSCHEMA VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
  guser    VARCHAR DEFAULT TRIM(NAME);
  o_role   VARCHAR DEFAULT NULL;
  o_wh     VARCHAR DEFAULT NULL;
  o_ns     VARCHAR DEFAULT NULL;
  is_admin NUMBER  DEFAULT 0;
  snapped  NUMBER  DEFAULT 0;
BEGIN
  IF (guser IS NULL OR guser = '') THEN
    RETURN 'defaults NOT set (no username)';
  END IF;

  -- NOTE ON THE MISSING SELF-GUARD. This procedure used to refuse when the target
  -- was CURRENT_USER(). That guard has moved out, for two reasons:
  --   1. PROVISION_LEARNER already returns early for its own caller, so the guard
  --      was redundant on the path it was written for.
  --   2. Under EXECUTE AS OWNER, CURRENT_USER() is the INVOKING user -- so the
  --      guard made self-service impossible, and GRADING.MY_LAB_DEFAULTS_APPLY()
  --      exists precisely so a learner can set their own defaults from the lab app.
  -- The protections that actually matter are still here: the admin/facilitator
  -- skip below, and the capture-once snapshot with its fail-closed check.

  -- Read the CURRENT values. Exact match on "name" -- no LIKE for SELECTION, because
  -- '_' is a LIKE wildcard and B_JONES would also match BXJONES, i.e. someone else's
  -- row.
  --
  -- The SHOW is narrowed with LIKE purely to shrink the result set, and the exact
  -- match below still decides which row is used. That distinction is the whole point:
  -- an unnarrowed SHOW USERS lists every user in the account on every learner, which
  -- measured as the bulk of this phase, while a LIKE that is allowed to pick the row
  -- is the bug the paragraph above warns about. Narrow, then match exactly.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW USERS LIKE ''' || REPLACE(:guser, '''', '''''') || '''';
    SELECT MAX("default_role"), MAX("default_warehouse"),
           MAX("default_namespace")
      INTO :o_role, :o_wh, :o_ns
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE UPPER("name") = UPPER(:guser);
  EXCEPTION WHEN OTHER THEN
    RETURN 'defaults NOT set (could not read current values: ' || SQLERRM || ')';
  END;

  -- Facilitators and account admins are skipped by design.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW GRANTS TO USER "' || :guser || '"';
    SELECT COUNT(*) INTO :is_admin
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE UPPER("role") IN ('ACCOUNTADMIN', 'SNOWCUP_FACILITATOR');
  EXCEPTION WHEN OTHER THEN
    -- Cannot tell whether they are an admin, so assume they are and skip.
    is_admin := 1;
  END;
  IF (:is_admin > 0) THEN
    RETURN 'defaults left unchanged (holds ACCOUNTADMIN or SNOWCUP_FACILITATOR)';
  END IF;

  -- Snapshot, capture-once. A second provisioning run must not overwrite this.
  BEGIN
    MERGE INTO SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP t
    USING (SELECT UPPER(:guser) AS USERNAME) s
       ON UPPER(t.USERNAME) = s.USERNAME
     WHEN NOT MATCHED THEN INSERT
          (USERNAME, ORIG_DEFAULT_ROLE, ORIG_DEFAULT_WAREHOUSE,
           ORIG_DEFAULT_NAMESPACE, CAPTURED_BY)
          VALUES (s.USERNAME, :o_role, :o_wh, :o_ns, CURRENT_USER());
  EXCEPTION WHEN OTHER THEN
    RETURN 'defaults NOT set (could not save originals: ' || SQLERRM || ')';
  END;

  -- Prove the snapshot exists before changing anything. Without this the MERGE
  -- could silently no-op and we would overwrite an uncaptured original.
  SELECT COUNT(*) INTO :snapped
    FROM SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP
   WHERE UPPER(USERNAME) = UPPER(:guser);
  IF (:snapped = 0) THEN
    RETURN 'defaults NOT set (originals were not saved)';
  END IF;

  -- All three, unconditionally. DEFAULT_NAMESPACE is the one people forget: without
  -- it a session opens with no current database and CoCo fails with
  -- "Cannot perform SHOW GRANTS. This session does not have a current database."
  EXECUTE IMMEDIATE 'ALTER USER "' || :guser || '" SET '
    || 'DEFAULT_ROLE = '            || :WSROLE   || ', '
    || 'DEFAULT_WAREHOUSE = SNOWCUP_WH, '
    || 'DEFAULT_NAMESPACE = ''' || :WSSCHEMA || '''';

  RETURN 'defaults set (role, warehouse, database/schema); originals saved';
END;
$$;

-- >>> RESTORE_USER_DEFAULTS: put ONE user's pre-lab session defaults back.
--
--     EXECUTE AS OWNER for the same reason as APPLY_LAB_DEFAULTS: users are
--     ACCOUNTADMIN-owned, so a facilitator caller could not ALTER USER otherwise.
--
--     RESTORE RULE, one rule for all three properties:
--       originally empty -> UNSET        originally set -> SET to the old value
--
--     DEFAULT_SECONDARY_ROLES is not restored because the lab never changes it.
--     Historical note, kept because it is a genuine trap if this is ever revived:
--     ALTER USER ... UNSET DEFAULT_SECONDARY_ROLES reverts to ["ALL"], not [], so
--     restoring that property by UNSET would WIDEN standing privileges rather than
--     restore them. It had to be driven by the saved value.
--
--     SET and UNSET cannot be combined in one ALTER USER, hence separate
--     statements. Restoring takes effect at the user's NEXT SIGN-IN, exactly like
--     the original change did.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESTORE_USER_DEFAULTS(NAME VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
  guser  VARCHAR DEFAULT TRIM(NAME);
  o_role VARCHAR DEFAULT NULL;
  o_wh   VARCHAR DEFAULT NULL;
  o_ns   VARCHAR DEFAULT NULL;
  found  NUMBER  DEFAULT 0;
BEGIN
  IF (guser IS NULL OR guser = '') THEN
    RETURN 'NOTHING TO DO (no username)';
  END IF;

  SELECT COUNT(*), MAX(ORIG_DEFAULT_ROLE), MAX(ORIG_DEFAULT_WAREHOUSE),
         MAX(ORIG_DEFAULT_NAMESPACE)
    INTO :found, :o_role, :o_wh, :o_ns
    FROM SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP
   WHERE UPPER(USERNAME) = UPPER(:guser);

  IF (:found = 0) THEN
    RETURN 'NOTHING TO DO  ' || :guser
        || ' (no saved defaults -- this user was never changed by the lab)';
  END IF;

  -- Role
  IF (:o_role IS NULL OR TRIM(:o_role) = '') THEN
    EXECUTE IMMEDIATE 'ALTER USER "' || :guser || '" UNSET DEFAULT_ROLE';
  ELSE
    EXECUTE IMMEDIATE 'ALTER USER "' || :guser || '" SET DEFAULT_ROLE = "' || :o_role || '"';
  END IF;

  -- Warehouse
  IF (:o_wh IS NULL OR TRIM(:o_wh) = '') THEN
    EXECUTE IMMEDIATE 'ALTER USER "' || :guser || '" UNSET DEFAULT_WAREHOUSE';
  ELSE
    EXECUTE IMMEDIATE 'ALTER USER "' || :guser || '" SET DEFAULT_WAREHOUSE = "' || :o_wh || '"';
  END IF;

  -- Database/schema
  IF (:o_ns IS NULL OR TRIM(:o_ns) = '') THEN
    EXECUTE IMMEDIATE 'ALTER USER "' || :guser || '" UNSET DEFAULT_NAMESPACE';
  ELSE
    EXECUTE IMMEDIATE 'ALTER USER "' || :guser || '" SET DEFAULT_NAMESPACE = ''' || :o_ns || '''';
  END IF;

  -- Secondary roles: not restored, because the lab never changes them.

  UPDATE SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP
     SET RESTORED_AT = CURRENT_TIMESTAMP()
   WHERE UPPER(USERNAME) = UPPER(:guser);

  RETURN 'RESTORED  ' || :guser
      || '  (role, warehouse, database/schema put back --'
      || ' takes effect the next time they sign in)';
END;
$$;

-- >>> RESTORE_ALL_LEARNER_DEFAULTS: the end-of-workshop sweep.
--     Safe to re-run; a user already restored is simply restored again to the
--     same saved values.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESTORE_ALL_LEARNER_DEFAULTS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
  out_txt VARCHAR DEFAULT '';
  one     VARCHAR;
  c1 CURSOR FOR SELECT USERNAME FROM SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP ORDER BY USERNAME;
BEGIN
  FOR r IN c1 DO
    BEGIN
      CALL SNOWCUP_WORKSHOP.ADMIN.RESTORE_USER_DEFAULTS(r.USERNAME) INTO :one;
    EXCEPTION WHEN OTHER THEN
      one := 'ERROR    ' || r.USERNAME || ' (' || SQLERRM || ')';
    END;
    out_txt := :out_txt || :one || '\n';
  END FOR;
  IF (out_txt = '') THEN
    RETURN 'NOTHING TO DO (no saved defaults on record)';
  END IF;
  RETURN :out_txt;
END;
$$;

-- >>> RESOLVE_LEARNER: the ONE place that decides a learner's build space name.
--
--     PROVISION, DEPROVISION and AUDIT_BUILD_OWNERSHIP each used to carry their own
--     copy of this derivation. Three copies of a naming rule is how provisioning and
--     teardown end up disagreeing about who owns what, so there is now exactly one.
--
--     RESOLUTION ORDER, most to least authoritative:
--
--       1. THE ROLE THEY ALREADY HOLD.  SHOW GRANTS TO USER reports the SNOWCUP_WS_
--          role a learner actually has, which is ground truth for what was
--          provisioned REGARDLESS of what any naming rule would compute today. This
--          is what makes the naming rule safe to change: somebody provisioned under
--          an older rule keeps their existing schema instead of being handed a fresh
--          empty one while their work is orphaned. It also means a learner whose
--          schema was dropped is repaired rather than renamed.
--
--       2. THE RESOLVED USERNAME.  Usernames are unique per account; the string an
--          admin typed is not. Anchoring here is what stops one human entered two
--          ways -- SSTUBBS and samson.stubbs@snowflake.com -- from getting two
--          separate build schemas, which silently splits their work in half.
--
--       3. THE RAW INPUT.  Only when no single user resolves. Still needed: a role
--          and schema are deliberately created for someone whose Snowflake user does
--          not exist yet, so a facilitator can pre-stage a roster.
--
--     The local part before '@' is still what gets sanitised, even in cases 1 and 2.
--     Every learner in a Snowflake-internal account has an email address AS their
--     username, so using the whole thing would rename WS_KARLA_NESS to
--     WS_KARLA_NESS_SNOWFLAKE_COM and relocate live work. The cost is that
--     jdoe@a.com and jdoe@b.com both reduce to JDOE -- that is what the collision
--     guard in PROVISION_LEARNER is for, and it refuses rather than letting them
--     share.
--
--     TWO TRAPS, both learned the hard way and both load-bearing here:
--       * STARTSWITH, never LIKE 'SNOWCUP\_WS\_%'. The backslash escaping does not
--         survive a dollar-quoted procedure body, and unescaped '_' is a LIKE
--         wildcard, so the pattern silently matches the wrong thing or nothing.
--       * Never write a doubled dollar sign inside these comments; it closes the
--         procedure body early and the error points somewhere unrelated.
--
--     Returns an OBJECT so all of it travels together and callers cannot recompute
--     half of it. held_count is exposed on purpose: 2 or more means the duplicate
--     bug already bit this person and a human has to consolidate them.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESOLVE_LEARNER(NAME VARCHAR)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  uname  VARCHAR DEFAULT TRIM(NAME);
  guser  VARCHAR DEFAULT NULL;
  ambig  NUMBER  DEFAULT 0;
  held   VARCHAR DEFAULT NULL;
  nheld  NUMBER  DEFAULT 0;
  basis  VARCHAR;
  suffix VARCHAR;
  anchor VARCHAR DEFAULT 'input';
BEGIN
  IF (uname IS NULL OR uname = '') THEN
    RETURN OBJECT_CONSTRUCT_KEEP_NULL(
      'input', NAME, 'username', NULL, 'suffix', NULL, 'role', NULL,
      'schema', NULL, 'ambig', 0, 'held_count', 0, 'anchored', 'none');
  END IF;

  -- Match name, login_name AND email so any of the three forms an admin might paste
  -- resolves to the same person. COUNT(DISTINCT "name") because one user can match
  -- on several of those columns at once and must still count once.
  --
  -- The EXCEPTION is not decoration: a SNOWCUP_FACILITATOR caller may not be allowed
  -- to list users at all, and degrading to input-derived naming is far better than
  -- failing to provision.
  BEGIN
    SHOW USERS;
    SELECT COUNT(DISTINCT "name"), MAX("name")
      INTO :ambig, :guser
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE UPPER("name")       = UPPER(:uname)
        OR UPPER("login_name") = UPPER(:uname)
        OR LOWER("email")      = LOWER(:uname);
  EXCEPTION WHEN OTHER THEN
    guser := NULL; ambig := 0;
  END;

  -- Only ask about held roles once we know exactly WHICH user we mean. Asking on an
  -- ambiguous match could read a different person's role and hand over their schema.
  IF (:ambig = 1 AND :guser IS NOT NULL) THEN
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS TO USER "' || :guser || '"';
      SELECT COUNT(DISTINCT "role"), MAX("role")
        INTO :nheld, :held
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("role", 'SNOWCUP_WS_');
    EXCEPTION WHEN OTHER THEN
      nheld := 0; held := NULL;
    END;
  END IF;

  IF (:nheld = 1 AND :held IS NOT NULL) THEN
    -- Follow the existing name rather than recomputing one.
    suffix := SUBSTR(:held, LENGTH('SNOWCUP_WS_') + 1);
    anchor := 'held_role';
  ELSE
    IF (:ambig = 1 AND :guser IS NOT NULL) THEN
      basis  := :guser;
      anchor := 'username';
    ELSE
      basis  := :uname;
      anchor := 'input';
    END IF;
    suffix := TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(basis, '@', 1)), '[^A-Z0-9]+', '_'), '_');
  END IF;

  -- A name of nothing but punctuation sanitises to empty. Report it instead of
  -- building SNOWCUP_WS_ and WS_ and colliding every such learner into one space.
  IF (suffix IS NULL OR suffix = '') THEN
    RETURN OBJECT_CONSTRUCT_KEEP_NULL(
      'input', :uname, 'username', :guser, 'suffix', NULL, 'role', NULL,
      'schema', NULL, 'ambig', :ambig, 'held_count', :nheld, 'anchored', 'none');
  END IF;

  RETURN OBJECT_CONSTRUCT_KEEP_NULL(
    'input',      :uname,
    'username',   :guser,
    'suffix',     :suffix,
    'role',       'SNOWCUP_WS_' || :suffix,
    'schema',     'SNOWCUP_BUILDS.WS_' || :suffix,
    'ambig',      :ambig,
    'held_count', :nheld,
    'anchored',   :anchor);
END;
$$;

-- >>> PROVISION_LEARNER: sets up ONE learner completely.
--     Derives a valid build schema SNOWCUP_BUILDS.WS_<NAME> from the username
--     (email-style names like jdoe@acme.com become WS_JDOE), creates the matching
--     SNOWCUP_WS_<NAME> role, grants build rights on that schema ONLY, nests
--     SNOWCUP_PARTICIPANT inside it, attaches the role to SNOWCUP_FACILITATOR,
--     and grants it to the user.
--     Idempotent. Runs as the caller, so it does exactly what the person running
--     it is allowed to do.
--
--     NOT NON-DESTRUCTIVE ABOUT USER SETTINGS, deliberately. It sets three
--     session defaults (DEFAULT_ROLE, DEFAULT_WAREHOUSE, DEFAULT_NAMESPACE)
--     unconditionally, because Cortex Code in Snowsight
--     reads ONLY the default role -- it ignores the Snowsight role picker, and
--     asking it to change roles mid-session does nothing. The originals are saved
--     to ADMIN.USER_DEFAULTS_BACKUP first, and the learner can put them back with
--     GRADING.MY_LAB_DEFAULTS_RESTORE(). Anyone holding ACCOUNTADMIN or
--     SNOWCUP_FACILITATOR is skipped, and your own defaults are never touched, so
--     a smoke test cannot hijack the admin's session. See APPLY_LAB_DEFAULTS.
--
--     RUN_ID is progress reporting and nothing else. Pass NULL (or use the
--     single-argument version below) and no progress is recorded; behaviour is
--     otherwise identical. When supplied, each phase boundary is written to
--     ADMIN.PROVISION_EVENT so the Admin app can show a live per-person position
--     while the batch is still running. Logging is best-effort by construction --
--     see LOG_PROVISION_STEP -- so it can never turn a good provision bad.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(NAME VARCHAR, RUN_ID VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  uname  VARCHAR DEFAULT TRIM(NAME);
  res    VARIANT;
  suffix VARCHAR;
  schema VARCHAR;
  wsrole VARCHAR;
  anchor VARCHAR DEFAULT 'input';
  nheld  NUMBER  DEFAULT 0;
  repair VARCHAR DEFAULT '';
  extra  VARCHAR DEFAULT '';
  dstat  VARCHAR DEFAULT 'defaults NOT set';
  guser  VARCHAR DEFAULT NULL;
  ambig  NUMBER  DEFAULT 0;
  clash  NUMBER  DEFAULT 0;
  clash_who VARCHAR DEFAULT NULL;
  sch_existed NUMBER DEFAULT 1;   -- assume pre-existing: the SAFE default, see OWNERSHIP below
  warn   VARCHAR DEFAULT '';
  tag    VARCHAR DEFAULT 'OK       ';
  lg     VARCHAR DEFAULT NULL;   -- throwaway; LOG_PROVISION_STEP swallows its own errors
BEGIN
  IF (uname IS NULL OR uname = '') THEN
    CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :NAME, 'DONE', 'SKIPPED', 'empty name') INTO :lg;
    RETURN 'SKIPPED  (empty name)';
  END IF;

  CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'RESOLVE', NULL, NULL) INTO :lg;

  -- ONE resolver owns the naming rule, and it runs BEFORE anything is created so the
  -- schema and role are correct on the first attempt. It also hands back the resolved
  -- username, which this procedure needs for GRANT ... TO USER below, so there is no
  -- second lookup to drift out of step. See RESOLVE_LEARNER.
  CALL SNOWCUP_WORKSHOP.ADMIN.RESOLVE_LEARNER(:uname) INTO :res;
  guser  := res:username::VARCHAR;
  ambig  := res:ambig::NUMBER;
  nheld  := res:held_count::NUMBER;
  anchor := res:anchored::VARCHAR;
  suffix := res:suffix::VARCHAR;
  schema := res:schema::VARCHAR;
  wsrole := res:role::VARCHAR;

  IF (:suffix IS NULL OR :suffix = '') THEN
    CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'DONE', 'SKIPPED', 'could not derive a schema name') INTO :lg;
    RETURN 'SKIPPED  ' || :uname || ' (could not derive a schema name)';
  END IF;

  CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'PRECHECK', NULL, :schema) INTO :lg;

  -- Holding two workshop roles is only possible if this person was already
  -- provisioned twice under different spellings of their name. Picking one would
  -- strand the other half of their work, so a human decides which survives.
  IF (:nheld > 1) THEN
    CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'DONE', 'ERROR',
      'holds ' || :nheld || ' SNOWCUP_WS_ roles') INTO :lg;
    RETURN 'ERROR    ' || :uname || '  holds ' || :nheld || ' SNOWCUP_WS_ roles.'
        || ' They were provisioned more than once under different spellings of their'
        || ' name. Consolidate the work into one schema, revoke the spare role, then'
        || ' re-run.';
  END IF;

  -- COLLISION GUARD. The suffix collapses non-alphanumerics and drops the mail
  -- domain, so DIFFERENT people can still map to the SAME schema and role:
  --   jdoe@acme.com and jdoe@other.com   -> both JDOE
  --   j.doe@x.com, j-doe@x.com, J_DOE    -> all  J_DOE
  --   Jose.X and José.X                  -> both JOS_X (accents are stripped)
  -- Without this the second person is silently granted the first person's role and
  -- build schema. Nothing errors. They then overwrite each other's semantic view,
  -- search service and agent MID-LAB, and the first learner's work disappears.
  --
  -- Runs BEFORE the schema and role are created, so a refusal leaves nothing behind.
  -- Two cases land harmlessly on clash = 0: a name taken from a role this user
  -- already holds cannot collide by definition, and SHOW GRANTS OF ROLE against a
  -- role that does not exist yet throws, which the handler treats as no collision.
  IF (:guser IS NOT NULL AND :ambig = 1) THEN
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS OF ROLE ' || :wsrole;
      SELECT COUNT(*), MAX("grantee_name")
        INTO :clash, :clash_who
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE "granted_to" = 'USER'
         AND UPPER("grantee_name") <> UPPER(:guser);
    EXCEPTION WHEN OTHER THEN
      clash := 0;
    END;
    IF (:clash > 0) THEN
      CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'DONE', 'ERROR',
        :schema || ' already belongs to ' || :clash_who) INTO :lg;
      RETURN 'ERROR    ' || :uname || '  ->  ' || :schema
          || '  ALREADY BELONGS TO ' || :clash_who
          || '. Two different usernames collapse to the same build schema name, so'
          || ' provisioning was refused rather than letting them share it and'
          || ' overwrite each other. Give one of them a distinct username and re-run.';
    END IF;
  END IF;

  -- Surface HOW the name was decided. 'held_role' is the steady state and would be
  -- noise on every line; anything else means a NEW name was minted, which is exactly
  -- the case worth seeing when a learner reports an unexpected schema.
  IF (:anchor <> 'held_role') THEN
    extra := :extra || '\n         build space named from ' || :anchor;
  END IF;

  CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'CREATE', NULL, :schema) INTO :lg;

  -- Did this schema exist BEFORE we created it? Asked here because it is the last
  -- moment the answer is knowable, and the OWNERSHIP phase below uses it to skip a
  -- sweep that cannot find anything.
  --
  -- Fails CLOSED: any doubt leaves sch_existed = 1, which runs the full sweep. A
  -- wrong "it is new" would skip the repair for a learner whose objects are
  -- mis-owned, and mis-ownership produces no error anywhere -- the learner just
  -- sees an empty schema. Wasting 12s is the cheaper mistake by far.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW SCHEMAS LIKE ''WS_' || :suffix || ''' IN DATABASE SNOWCUP_BUILDS';
    SELECT COUNT(*) INTO :sch_existed FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  EXCEPTION WHEN OTHER THEN
    sch_existed := 1;
  END;

  EXECUTE IMMEDIATE 'CREATE SCHEMA IF NOT EXISTS ' || :schema;
  EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS ' || :wsrole;

  CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'GRANT', NULL, :wsrole) INTO :lg;

  -- Build rights on this learner's schema only.
  --
  -- STAGE / FILE FORMAT / TASK / DATASET are here for Modules 8 and 10: Cortex
  -- Analyst evaluations run as Snowflake TASKS and stage their config, so
  -- CREATE TASK + CREATE DATASET + CREATE STAGE + CREATE FILE FORMAT are all
  -- required. Note EXECUTE TASK is an ACCOUNT-level privilege and is granted to
  -- SNOWCUP_PARTICIPANT separately -- CREATE TASK alone is not enough.
  -- Evaluations also ignore SECONDARY roles, which is why the learner's own
  -- primary role has to hold every one of these directly or by inheritance.
  EXECUTE IMMEDIATE 'GRANT USAGE, CREATE TABLE, CREATE VIEW, CREATE SEMANTIC VIEW, '
    || 'CREATE CORTEX SEARCH SERVICE, CREATE AGENT, CREATE PROCEDURE, CREATE FUNCTION, '
    || 'CREATE STAGE, CREATE FILE FORMAT, CREATE TASK, CREATE DATASET '
    || 'ON SCHEMA ' || :schema || ' TO ROLE ' || :wsrole;

  -- Shared access, inherited: one DEFAULT_ROLE then covers the whole lab.
  EXECUTE IMMEDIATE 'GRANT ROLE SNOWCUP_PARTICIPANT TO ROLE ' || :wsrole;
  -- Cortex granted directly as well as inherited. Cortex underpins every module,
  -- so this removes any dependence on transitive database-role inheritance.
  EXECUTE IMMEDIATE 'GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE ' || :wsrole;

  -- Oversight, and the learner themselves.
  EXECUTE IMMEDIATE 'GRANT ROLE ' || :wsrole || ' TO ROLE SNOWCUP_FACILITATOR';

  -- Two names could match only if one person's username is another's email, so
  -- guessing between them could hand a learner's schema to the wrong user. Refuse.
  IF (:ambig > 1) THEN
    warn := 'WARNING: ''' || :uname || ''' matches more than one Snowflake user, so the'
         || ' role was NOT granted to anyone. Re-run with the exact username.';
  ELSE
    IF (:guser IS NULL) THEN
      guser := :uname;
    END IF;
    BEGIN
      EXECUTE IMMEDIATE 'GRANT ROLE ' || :wsrole || ' TO USER "' || :guser || '"';
    EXCEPTION WHEN OTHER THEN
      -- Report instead of aborting. Aborting here is what produced the confusing
      -- half-provisioned state: schema and role present, nobody holding the role.
      warn := 'WARNING: no Snowflake user matches ''' || :uname || ''', so the role was'
           || ' NOT granted to anyone. The schema and role exist and SNOWCUP_FACILITATOR'
           || ' can see them. Run SHOW USERS, then re-run with their exact username.';
    END;
  END IF;

  IF (:warn <> '') THEN
    tag := 'PARTIAL  ';
  END IF;

  -- Hand back anything in this learner's schema that their own role does not own.
  --
  -- Provisioning cannot PREVENT this -- the objects do not exist yet on a first
  -- run -- so re-running provisioning is the repair path. That matters because a
  -- wrong owner produces no error anywhere: the learner just sees an empty schema,
  -- or an agent that reports its search service does not exist.
  --
  -- SKIPPED FOR A BRAND-NEW SCHEMA, and this is a correctness argument rather than
  -- an optimisation: mis-ownership only happens when someone creates an object
  -- INSIDE a learner's schema, so a schema that did not exist a few statements ago
  -- contains nothing and the sweep can only ever report "nothing to repair".
  -- Measured, it was 12.6s of a 22.7s provision -- 58% of the time spent proving a
  -- schema created 0.9s earlier is empty. Re-provisioning an existing learner (the
  -- repair path above) still sweeps, which is the case that actually repairs.
  --
  -- The batch entry points also run ONE database-wide sweep after the whole cohort
  -- (see PROVISION_LEARNERS), so "is anything mis-owned anywhere" is still answered
  -- per run -- and over every build schema, not just this one.
  --
  -- Failure here must not fail provisioning. A SNOWCUP_FACILITATOR caller cannot
  -- transfer ACCOUNTADMIN-owned objects, and that is worth reporting rather than
  -- turning a successful provision into an error.
  --
  -- Logged as its own phase because it is by far the slowest step -- roughly nine
  -- SHOW statements plus temp tables -- so it is the one a facilitator is most
  -- likely to catch mid-flight and mistake for a hang.
  CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'OWNERSHIP', NULL, NULL) INTO :lg;
  IF (:sch_existed = 0) THEN
    repair := 'ownership OK (new schema, nothing could be mis-owned)';
  ELSE
    BEGIN
      CALL SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP(:uname) INTO :repair;
    EXCEPTION WHEN OTHER THEN
      repair := 'ownership check could not run (' || SQLERRM || ')';
    END;
  END IF;
  IF (NOT STARTSWITH(:repair, 'ownership OK')) THEN
    extra := '\n         ' || :repair;
  END IF;
  IF (:warn <> '') THEN
    extra := :extra || '\n         ' || :warn;
  END IF;

  IF (UPPER(:guser) = UPPER(CURRENT_USER())) THEN
    CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'DONE', TRIM(:tag),
      'your own defaults left unchanged') INTO :lg;
    RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
        || '  (your own defaults left unchanged)' || :extra;
  END IF;

  -- Nobody holds the role, so there is no user whose defaults could be set. Stop here:
  -- the defaults logic below would otherwise run ALTER USER against a name that does
  -- not exist and abort, which is the very failure this block exists to prevent.
  IF (:warn <> '') THEN
    CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'DONE', TRIM(:tag),
      'schema and role created, but NOT granted to any user') INTO :lg;
    RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
        || '  (schema and role created, but NOT granted to any user)' || :extra;
  END IF;

  -- Set the four session defaults the lab depends on, after saving the originals.
  --
  -- This USED to refuse to overwrite an existing default, on the grounds that the
  -- old value would be lost. That protection is why the lab broke in practice:
  -- Cortex Code in Snowsight reads ONLY the default role -- it ignores the
  -- Snowsight role picker, and asking it to switch roles mid-session does nothing
  -- (measured: zero USE ROLE statements across every CoCo session in a real
  -- account). So "left alone, tell them to run USE ROLE" was advice that could
  -- not work, and every learner who already had a default role -- which is
  -- everyone on a shared account -- landed in CoCo on the wrong role.
  --
  -- The replacement protection is a snapshot plus a way back, not a refusal.
  -- APPLY_LAB_DEFAULTS captures the originals first and aborts if it cannot, and
  -- it skips anyone holding ACCOUNTADMIN or SNOWCUP_FACILITATOR. Learners restore
  -- themselves with GRADING.MY_LAB_DEFAULTS_RESTORE().
  CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'DEFAULTS', NULL, NULL) INTO :lg;
  BEGIN
    CALL SNOWCUP_WORKSHOP.ADMIN.APPLY_LAB_DEFAULTS(:guser, :wsrole, 'SNOWCUP_BUILDS.WS_' || :suffix)
      INTO :dstat;
  EXCEPTION WHEN OTHER THEN
    dstat := 'defaults NOT set (' || SQLERRM || ')';
  END;

  -- Downgrade the status when the defaults did not apply. Without this the result
  -- still starts with 'OK', and the Admin app decides success on exactly that
  -- prefix -- so a learner whose defaults were never set would show a green row
  -- and then land in Cortex Code on the wrong role, which is the original bug.
  -- 'defaults left unchanged' is the deliberate facilitator/self skip, not a fault.
  IF (STARTSWITH(:dstat, 'defaults NOT set')) THEN
    tag := 'PARTIAL  ';
  END IF;

  CALL SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(:RUN_ID, :uname, 'DONE', TRIM(:tag), :dstat) INTO :lg;

  RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
      || '  (' || :dstat || ')' || :extra;
END;
$$;

-- >>> PROVISION_LEARNER(NAME): the original single-argument form, unchanged in
--     behaviour. Delegates to the two-argument version with no run id, so nothing
--     is logged. Kept so PROVISION_LEARNERS, every runbook, and any facilitator
--     calling this by hand keep working exactly as before -- only the Admin app
--     passes a run id.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(NAME VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  res VARCHAR;
BEGIN
  CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(:NAME, NULL) INTO :res;
  RETURN :res;
END;
$$;

-- >>> PROVISION_LEARNERS: the same thing for a whole list. Accepts commas,
--     semicolons or newlines, so you can paste a column out of a spreadsheet.
--
--     Ends with ONE database-wide ownership sweep. PROVISION_LEARNER skips its own
--     sweep for a schema it just created (nothing can be mis-owned in a schema that
--     did not exist), so this is where the guarantee is paid: once per batch, over
--     EVERY build schema -- including ones not in this list, which the old
--     per-learner sweep never looked at. One sweep instead of N.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS(NAMES VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  c1 CURSOR FOR
    SELECT DISTINCT TRIM(f.value)::VARCHAR AS uname
      FROM TABLE(FLATTEN(input => SPLIT(REGEXP_REPLACE(?, '[;\r\n]+', ','), ','))) f
     WHERE TRIM(f.value) <> ''
     ORDER BY 1;
  out VARCHAR DEFAULT '';
  one VARCHAR;
  nm  VARCHAR;
  sweep VARCHAR DEFAULT NULL;
BEGIN
  OPEN c1 USING (NAMES);
  FOR rec IN c1 DO
    -- assign to a local first: a cursor row field cannot be bound directly
    -- into a CALL argument.
    nm := rec.uname;
    CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(:nm) INTO :one;
    out := out || :one || '\n';
  END FOR;
  CLOSE c1;
  IF (out = '') THEN
    RETURN 'Nothing to do - the list was empty.';
  END IF;

  -- Never fatal. Every learner above already succeeded or reported its own state,
  -- and losing the sweep must not retract that.
  BEGIN
    CALL SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP('') INTO :sweep;
  EXCEPTION WHEN OTHER THEN
    sweep := 'ownership sweep could not run (' || SQLERRM || ')';
  END;
  RETURN :out || 'all build schemas: ' || :sweep;
END;
$$;

-- >>> DEPROVISION_LEARNER: offboard one person. Revokes their role and detaches
--     it from the facilitator role. DROP_SCHEMA = TRUE also deletes everything
--     they built and removes the role; FALSE keeps their work (and the role that
--     owns it) so it can be handed back later.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_LEARNER(NAME VARCHAR, DROP_SCHEMA BOOLEAN)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  uname  VARCHAR DEFAULT TRIM(NAME);
  res    VARIANT;
  suffix VARCHAR;
  schema VARCHAR;
  wsrole VARCHAR;
  guser  VARCHAR DEFAULT NULL;
  ambig  NUMBER  DEFAULT 0;
  rstat  VARCHAR DEFAULT 'defaults not restored';
BEGIN
  IF (uname IS NULL OR uname = '') THEN
    RETURN 'SKIPPED  (empty name)';
  END IF;

  -- The SAME resolver PROVISION_LEARNER uses, which is the entire point: teardown has
  -- to agree with provisioning about which schema and role belong to this person.
  --
  -- It anchors on the role they actually HOLD rather than recomputing a name, so a
  -- learner provisioned under an OLDER naming rule is still removable. Re-deriving
  -- here would quietly look for a schema that was never created and report success
  -- while leaving the real role and schema behind forever.
  --
  -- It also resolves the username needed to restore defaults and revoke below. If
  -- their Snowflake user has already been dropped nothing resolves, and it falls back
  -- to the input-derived name -- the best available guess, and the same behaviour as
  -- before.
  CALL SNOWCUP_WORKSHOP.ADMIN.RESOLVE_LEARNER(:uname) INTO :res;
  guser  := res:username::VARCHAR;
  ambig  := res:ambig::NUMBER;
  suffix := res:suffix::VARCHAR;
  schema := res:schema::VARCHAR;
  wsrole := res:role::VARCHAR;

  IF (:suffix IS NULL OR :suffix = '') THEN
    RETURN 'SKIPPED  ' || :uname || ' (could not derive a schema name)';
  END IF;

  -- Put their pre-lab session defaults back BEFORE revoking the role.
  --
  -- Provisioning set DEFAULT_ROLE to SNOWCUP_WS_<NAME>. Revoking that role
  -- without restoring leaves the user's default pointing at a role they no longer
  -- hold, and ALTER USER accepts a role that does not even exist without
  -- complaint -- so nothing would warn, and their next sign-in is broken. Restore
  -- first, then revoke.
  --
  -- Never fatal: offboarding must still remove the role and schema even if the
  -- restore cannot run.
  IF (:guser IS NOT NULL AND :ambig = 1) THEN
    BEGIN
      CALL SNOWCUP_WORKSHOP.ADMIN.RESTORE_USER_DEFAULTS(:guser) INTO :rstat;
    EXCEPTION WHEN OTHER THEN
      rstat := 'defaults could not be restored (' || SQLERRM || ')';
    END;
  ELSE
    rstat := 'defaults not restored (user could not be resolved)';
  END IF;

  -- A revoke is cleanup, so a missing or ambiguous user must not stop the offboarding:
  -- the schema and role still need removing. Skipping a revoke that cannot apply is
  -- safe, because DROP ROLE below removes every grant of it anyway.
  IF (:guser IS NOT NULL AND :ambig = 1) THEN
    BEGIN
      EXECUTE IMMEDIATE 'REVOKE ROLE ' || :wsrole || ' FROM USER "' || :guser || '"';
    EXCEPTION WHEN OTHER THEN
      NULL;
    END;
  END IF;

  IF (DROP_SCHEMA) THEN
    EXECUTE IMMEDIATE 'DROP SCHEMA IF EXISTS ' || :schema || ' CASCADE';
    -- REVOKE has no IF EXISTS, so this MUST be guarded. Removing a learner whose
    -- role is already gone -- removed twice, role dropped by hand, or two people
    -- who collapse to the same build space being removed one after the other --
    -- otherwise fails HERE, after the schema has already been dropped. The caller
    -- then sees an error for work that partly succeeded and reasonably retries.
    -- Observed for real: the second of two colliding test users returned
    -- "SQL compilation error" with the schema already deleted.
    --
    -- Safe to swallow: DROP ROLE below removes every grant of the role anyway.
    BEGIN
      EXECUTE IMMEDIATE 'REVOKE ROLE ' || :wsrole || ' FROM ROLE SNOWCUP_FACILITATOR';
    EXCEPTION WHEN OTHER THEN
      NULL;
    END;
    EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || :wsrole;
    RETURN 'REMOVED  ' || :uname || '  (role and ' || :schema || ' dropped)'
        || '\n         ' || :rstat;
  END IF;
  RETURN 'REVOKED  ' || :uname || '  (role kept so ' || :schema
      || ' and its objects survive)' || '\n         ' || :rstat;
END;
$$;

-- >>> DEPROVISION_ORPHAN: delete a build space that has NO learner attached.
--
--     WHY THIS IS NOT DEPROVISION_LEARNER. That procedure finds its target through
--     RESOLVE_LEARNER, which anchors on the role a USER holds. An orphan has no
--     user, so resolution falls back to deriving a name from the input -- and if a
--     Snowflake user happens to match that input while holding a DIFFERENT
--     SNOWCUP_WS_ role, the resolver anchors on their role and the call drops a
--     live learner's schema instead of the orphan. For a statement ending in
--     DROP SCHEMA ... CASCADE that is not an acceptable failure mode.
--
--     So this procedure does the opposite of name resolution: it acts on the exact
--     role and schema it was handed (the strings the roster displayed) and refuses
--     if anyone is attached. Nothing is inferred.
--
--     Either argument may be empty, because the two orphan shapes differ: a role
--     whose learner was never granted or was revoked elsewhere, and a schema whose
--     role has already been dropped.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_ORPHAN(ROLE_NAME VARCHAR, SCHEMA_NAME VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  wsrole   VARCHAR DEFAULT UPPER(TRIM(COALESCE(ROLE_NAME, '')));
  wsschema VARCHAR DEFAULT UPPER(TRIM(COALESCE(SCHEMA_NAME, '')));
  fqschema VARCHAR;
  holders  NUMBER  DEFAULT 0;
  rexists  NUMBER  DEFAULT 0;
  sexists  NUMBER  DEFAULT 0;
  did      VARCHAR DEFAULT '';
BEGIN
  IF (:wsrole = '' AND :wsschema = '') THEN
    RETURN 'SKIPPED  (no role and no schema given)';
  END IF;

  -- Shape gate. This procedure drops schemas, so it accepts ONLY names matching the
  -- workshop's own naming rule. Anything else -- a quoted identifier, a name with a
  -- dot, an injected clause -- is refused rather than sanitised, because a partial
  -- sanitise of a DROP target is worse than a refusal.
  IF (:wsrole <> '' AND NOT RLIKE(:wsrole, 'SNOWCUP_WS_[A-Z0-9_]+')) THEN
    RETURN 'SKIPPED  ' || :wsrole || ' (not a SNOWCUP_WS_ role)';
  END IF;
  IF (:wsschema <> '' AND NOT RLIKE(:wsschema, 'WS_[A-Z0-9_]+')) THEN
    RETURN 'SKIPPED  ' || :wsschema || ' (not a WS_ schema)';
  END IF;

  -- OCCUPANCY GATE, and the reason this procedure is safe to expose. "Orphan" is a
  -- claim about the present, not about what the roster showed when it was last
  -- refreshed: a learner can be granted the role between that read and this call.
  -- Re-check here, and refuse, so this path can never delete a live build space.
  IF (:wsrole <> '') THEN
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS OF ROLE ' || :wsrole;
      SELECT COUNT(*) INTO :holders
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE "granted_to" = 'USER';
      rexists := 1;
    EXCEPTION WHEN OTHER THEN
      -- The role does not exist (or cannot be inspected). Either way there is no
      -- role to drop and nobody to protect.
      holders := 0; rexists := 0;
    END;

    IF (:holders > 0) THEN
      RETURN 'SKIPPED  ' || :wsrole || ' (still held by ' || :holders
          || ' user(s) -- remove the learner instead)';
    END IF;
  END IF;

  -- Drop the schema first: if this fails, the role still exists and the pair stays
  -- visible on the roster as an orphan. Dropping the role first would leave an
  -- unreachable schema owned by a role that no longer exists.
  IF (:wsschema <> '') THEN
    fqschema := 'SNOWCUP_BUILDS.' || :wsschema;
    -- SHOW rather than INFORMATION_SCHEMA.SCHEMATA on purpose: the roster reads SHOW
    -- SCHEMAS, so using the same mechanism means what the facilitator was shown and
    -- what teardown believes exists can never disagree.
    BEGIN
      EXECUTE IMMEDIATE 'SHOW SCHEMAS LIKE ''' || :wsschema || ''' IN DATABASE SNOWCUP_BUILDS';
      SELECT COUNT(*) INTO :sexists FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
    EXCEPTION WHEN OTHER THEN
      sexists := 0;
    END;
    IF (:sexists > 0) THEN
      EXECUTE IMMEDIATE 'DROP SCHEMA IF EXISTS ' || :fqschema || ' CASCADE';
      did := did || 'dropped ' || :fqschema;
    ELSE
      did := did || :fqschema || ' was already gone';
    END IF;
  END IF;

  -- Guarded separately because REVOKE has no IF EXISTS: on a schema-only orphan the
  -- role is already gone, and an unguarded REVOKE would abort the procedure AFTER
  -- the schema was dropped -- reporting failure for work that partly succeeded.
  IF (:wsrole <> '' AND :rexists = 1) THEN
    BEGIN
      EXECUTE IMMEDIATE 'REVOKE ROLE ' || :wsrole || ' FROM ROLE SNOWCUP_FACILITATOR';
    EXCEPTION WHEN OTHER THEN
      NULL;
    END;
    EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || :wsrole;
    did := IFF(:did = '', '', :did || ', ') || 'dropped role ' || :wsrole;
  ELSEIF (:wsrole <> '') THEN
    did := IFF(:did = '', '', :did || ', ') || 'role ' || :wsrole || ' was already gone';
  END IF;

  RETURN 'REMOVED  ' || IFF(:wsrole = '', :wsschema, :wsrole) || '  (' || :did || ')';
END;
$$;

-- >>> RESET_LEARNER_PROGRESS: put one learner back to the start of one training.
--
--     WHAT IT CLEARS: their checkpoints, reinforcement quiz answers, challenge
--     answers and points, and the completion stamp -- for the ONE training named.
--
--     WHAT IT DELIBERATELY DOES NOT TOUCH:
--       * anything in their build schema. Their semantic view, agent, Cortex Search
--         service, views and procedures are their WORK, not their score. A reset is
--         for letting someone re-run the lab or clearing a demo, and silently
--         deleting hours of building would be unrecoverable.
--       * their role, schema, or user defaults. This is not offboarding --
--         DEPROVISION_LEARNER does that.
--       * their visit history in LAB_ACTIVITY. First-seen, last-seen and the visit
--         count survive, so a facilitator can still see they had engaged. Only
--         COMPLETED_AT is cleared, because keeping a completion stamp on a learner
--         with zero answers is exactly the dishonest state the gates check for.
--
--     Scoped to one training rather than the whole participant on purpose: with a
--     second training registered, resetting "everything" would wipe work the
--     facilitator may not have meant to touch.
--
--     Idempotent -- resetting an already-clean learner reports zero rows cleared
--     rather than failing.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESET_LEARNER_PROGRESS(
  P_PARTICIPANT VARCHAR, P_MODULE_ID VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  p        VARCHAR DEFAULT UPPER(TRIM(COALESCE(P_PARTICIPANT, '')));
  m        VARCHAR DEFAULT UPPER(TRIM(COALESCE(P_MODULE_ID, '')));
  n_steps  NUMBER  DEFAULT 0;
  n_quiz   NUMBER  DEFAULT 0;
  n_chal   NUMBER  DEFAULT 0;
  n_pts    NUMBER  DEFAULT 0;
  n_stamp  NUMBER  DEFAULT 0;
BEGIN
  IF (p = '' OR m = '') THEN
    RETURN 'SKIPPED  (participant and training are both required)';
  END IF;

  -- Counted before deleting so the caller learns what was actually cleared. A
  -- reset that reports nothing is indistinguishable from one that silently
  -- matched the wrong participant.
  SELECT COUNT(*) INTO :n_steps FROM SNOWCUP_WORKSHOP.GRADING.LAB_PROGRESS
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m;
  SELECT COUNT(*) INTO :n_quiz FROM SNOWCUP_WORKSHOP.GRADING.QUIZ_PROGRESS
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m;
  SELECT COUNT(*), COALESCE(SUM(POINTS_AWARDED), 0) INTO :n_chal, :n_pts
    FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_PROGRESS
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m;
  SELECT COUNT(*) INTO :n_stamp FROM SNOWCUP_WORKSHOP.GRADING.LAB_ACTIVITY
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m AND COMPLETED_AT IS NOT NULL;

  IF (:n_steps + :n_quiz + :n_chal + :n_stamp = 0) THEN
    RETURN 'NOTHING TO DO  ' || :p || ' / ' || :m || ' already has no progress';
  END IF;

  DELETE FROM SNOWCUP_WORKSHOP.GRADING.LAB_PROGRESS
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m;
  DELETE FROM SNOWCUP_WORKSHOP.GRADING.QUIZ_PROGRESS
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m;
  DELETE FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_PROGRESS
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m;
  UPDATE SNOWCUP_WORKSHOP.GRADING.LAB_ACTIVITY SET COMPLETED_AT = NULL
   WHERE UPPER(PARTICIPANT) = :p AND UPPER(MODULE_ID) = :m;

  RETURN 'RESET    ' || :p || ' / ' || :m || ': cleared '
      || :n_steps::VARCHAR || ' checkpoint(s), '
      || :n_quiz::VARCHAR  || ' quiz answer(s), '
      || :n_chal::VARCHAR  || ' challenge answer(s) worth ' || :n_pts::VARCHAR || ' point(s)'
      || IFF(:n_stamp > 0, ', and the completion stamp', '')
      || '. Their build schema was NOT touched.';
END;
$$;

-- >>> AUDIT_BUILD_OWNERSHIP: find objects in a build schema that the learner's
--     own role does NOT own.
--
--     WHY THIS EXISTS
--     A learner owns everything they create: ownership follows the role that ran
--     CREATE, and their DEFAULT_ROLE is SNOWCUP_WS_<NAME>. The problem is an
--     ADMIN creating something inside a learner's schema -- authoring a reference
--     solution on ACCOUNTADMIN, or a facilitator helping someone who is stuck.
--     The learner then holds no privilege on it, and NOTHING errors: SHOW and
--     Snowsight simply omit it, and an agent pointed at it fails with a message
--     about the object not existing. Worse, DEFAULT_SECONDARY_ROLES = ALL hides
--     it while the admin's own session is the one testing, because the object
--     resolves through ACCOUNTADMIN.
--
--     WHY IT ASKS THE QUESTION BACKWARDS
--     The obvious implementation -- read an "owner" column per object kind -- is
--     what made this bug survive three separate checks. SHOW CORTEX SEARCH
--     SERVICES has no "owner" column at all, and neither does SHOW PROCEDURES,
--     so those kinds were structurally invisible to every owner-column check.
--     Instead this asks: what EXISTS in the schema, minus what the learner's role
--     OWNS. One "SHOW GRANTS TO ROLE" returns OWNERSHIP rows for every kind,
--     fully qualified, so no owner column is needed anywhere and a newly
--     supported object kind cannot silently fall outside the audit.
--
--     P_PARTICIPANT scopes to one learner; NULL or '' audits every build schema.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(P_PARTICIPANT VARCHAR)
RETURNS TABLE (KIND VARCHAR, SCH VARCHAR, OBJ VARCHAR, OWNER VARCHAR,
               EXPECTED_ROLE VARCHAR, FIX_SQL VARCHAR)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  suffix  VARCHAR DEFAULT NULL;
  res     VARIANT;
  pn      VARCHAR;
  scope   VARCHAR DEFAULT 'IN DATABASE SNOWCUP_BUILDS';
  n       INT;
  i       INT DEFAULT 1;
  sch     VARCHAR;
  vn      INT;
  vi      INT DEFAULT 1;
  vkind   VARCHAR;
  vref    VARCHAR;
  vowner  VARCHAR;
  rs      RESULTSET;
BEGIN
  IF (P_PARTICIPANT IS NOT NULL AND TRIM(P_PARTICIPANT) <> '') THEN
    -- The SAME resolver PROVISION_LEARNER and DEPROVISION_LEARNER use. It anchors on
    -- the role the learner actually HOLDS, so the audit inspects the schema that
    -- really belongs to them -- including one named under an older rule. Re-deriving
    -- here would point the audit at a schema that does not exist and then report
    -- ownership OK for a learner whose objects are every one of them mis-owned.
    -- Assign to a local first: a procedure PARAMETER cannot be bound straight into a
    -- CALL argument (same restriction PROVISION_LEARNERS hits with a cursor field).
    pn := TRIM(P_PARTICIPANT);
    CALL SNOWCUP_WORKSHOP.ADMIN.RESOLVE_LEARNER(:pn) INTO :res;
    suffix := res:suffix::VARCHAR;
    IF (:suffix IS NULL OR :suffix = '') THEN
      -- A name of pure punctuation resolves to nothing. Point the audit at a schema
      -- that cannot exist, so every kind is recorded as UNREADABLE rather than clean.
      -- Silently auditing nothing and reporting OK is the dangerous outcome.
      suffix := 'UNRESOLVABLE_NAME';
    END IF;
    -- Narrow every SHOW to the one schema. PROVISION_LEARNERS calls this once per
    -- learner, so a database-wide scan per learner would make provisioning a
    -- 30-person cohort needlessly slow.
    scope := 'IN SCHEMA SNOWCUP_BUILDS.WS_' || :suffix;
  END IF;

  -- Temp tables are qualified on purpose: an unqualified CREATE TEMPORARY TABLE
  -- fails with "session does not have a current database" when the caller has
  -- only done USE ROLE. Being temporary, two facilitators auditing at the same
  -- time each get their own copy.
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS (
    KIND VARCHAR, KIND_SQL VARCHAR, SCH VARCHAR, OBJ VARCHAR,
    OBJ_REF VARCHAR,     -- what GRANT OWNERSHIP needs (carries the signature for procs)
    MATCH_KEY VARCHAR);  -- normalised to compare against SHOW GRANTS output
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_OWNED (MATCH_KEY VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND (KIND VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL (
    RN INT, KIND VARCHAR, KIND_SQL VARCHAR, SCH VARCHAR, OBJ VARCHAR,
    OBJ_REF VARCHAR, OWNER VARCHAR, EXPECTED_ROLE VARCHAR, FIX_SQL VARCHAR);

  -- ---- What exists, one SHOW per kind. --------------------------------------
  -- Every kind PROVISION_LEARNER grants CREATE on. Each SHOW is followed
  -- IMMEDIATELY by its INSERT so LAST_QUERY_ID() needs no offset -- the
  -- LAST_QUERY_ID(-N) form used elsewhere silently misreads if a SHOW is ever
  -- added, removed or skipped.
  --
  -- A kind that cannot be read (unsupported on the account) is RECORDED, never
  -- ignored: an unreadable kind must not be reported as clean.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW TABLES ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'TABLE', 'TABLE', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('TABLE');
  END;

  BEGIN
    EXECUTE IMMEDIATE 'SHOW VIEWS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'VIEW', 'VIEW', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('VIEW');
  END;

  -- SHOW VIEWS and SHOW SEMANTIC VIEWS are disjoint -- verified, no double
  -- counting. (SHOW OBJECTS does conflate them, which is why it is not used:
  -- it would emit GRANT ... ON VIEW for a semantic view and fail.)
  BEGIN
    EXECUTE IMMEDIATE 'SHOW SEMANTIC VIEWS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'SEMANTIC VIEW', 'SEMANTIC VIEW', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('SEMANTIC VIEW');
  END;

  BEGIN
    EXECUTE IMMEDIATE 'SHOW AGENTS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'AGENT', 'AGENT', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('AGENT');
  END;

  -- The kind this whole procedure exists for. No "owner" column anywhere in its
  -- SHOW output, which is exactly why the earlier checks could not see it.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW CORTEX SEARCH SERVICES ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'CORTEX SEARCH SERVICE', 'CORTEX SEARCH SERVICE', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('CORTEX SEARCH SERVICE');
  END;

  -- STAGE / FILE FORMAT / TASK / DATASET.
  --
  -- These four exist here because PROVISION_LEARNER grants CREATE on them, and the
  -- audit must cover every kind a learner can create or it reports a clean bill of
  -- health for objects it never looked at. They were added later than the rest and
  -- were missing for a while, which mattered most in Modules 8 and 10: a Cortex
  -- Analyst evaluation IS a task, it stages its config, and it writes a dataset, so
  -- these are the kinds most likely to be created under the wrong role.
  --
  -- All four were verified to support GRANT OWNERSHIP ... COPY CURRENT GRANTS, and all
  -- four report schema_name and name from their SHOW. SHOW GRANTS spells the kind
  -- FILE_FORMAT with an underscore, which does not matter: MATCH_KEY compares the
  -- fully-qualified NAME only, never the kind.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW STAGES ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'STAGE', 'STAGE', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('STAGE');
  END;

  BEGIN
    EXECUTE IMMEDIATE 'SHOW FILE FORMATS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'FILE FORMAT', 'FILE FORMAT', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('FILE FORMAT');
  END;

  BEGIN
    EXECUTE IMMEDIATE 'SHOW TASKS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'TASK', 'TASK', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('TASK');
  END;

  BEGIN
    EXECUTE IMMEDIATE 'SHOW DATASETS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'DATASET', 'DATASET', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('DATASET');
  END;

  -- Procedures and functions need their argument signature to be transferred:
  -- GRANT OWNERSHIP ON PROCEDURE f(VARCHAR). "arguments" arrives as
  -- 'F(VARCHAR) RETURN VARCHAR', so only the RETURN suffix is stripped -- a
  -- '\([^)]*\)' match would truncate a type like NUMBER(38,0).
  --
  -- MATCH_KEY deliberately drops the signature, because SHOW GRANTS renders
  -- argument types in its own way and an exact string compare would report a
  -- correctly-owned procedure as mis-owned. The cost is that two overloads of
  -- one name are treated as a single object, which would only matter if a
  -- learner had one overload owned correctly and another not.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW PROCEDURES ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'PROCEDURE', 'PROCEDURE', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.'
               || REGEXP_REPLACE("arguments", '\\s+RETURN\\s+.*$', ''),
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('PROCEDURE');
  END;

  -- USER FUNCTIONS, not FUNCTIONS: the latter includes every built-in.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW USER FUNCTIONS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'FUNCTION', 'FUNCTION', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.'
               || REGEXP_REPLACE("arguments", '\\s+RETURN\\s+.*$', ''),
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('FUNCTION');
  END;

  -- ---- What each learner's role owns, one SHOW GRANTS per role. -------------
  -- Driven off the schemas that actually hold objects, so a learner who has
  -- built nothing costs nothing. WHILE + SELECT INTO rather than a cursor:
  -- the inline FOR rec IN (SELECT ...) form fails here with
  -- "invalid identifier 'REC.COL'".
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_SCHEMAS AS
    SELECT ROW_NUMBER() OVER (ORDER BY SCH) AS RN, SCH
      FROM (SELECT DISTINCT SCH FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS);
  SELECT COUNT(*) INTO :n FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_SCHEMAS;

  WHILE (:i <= :n) DO
    SELECT SCH INTO :sch FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_SCHEMAS WHERE RN = :i;
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS TO ROLE SNOWCUP_' || :sch;
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_OWNED
        SELECT SPLIT_PART("name", '(', 1)
          FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
         WHERE "privilege" = 'OWNERSHIP';
    EXCEPTION WHEN OTHER THEN
      -- A missing role means nothing in that schema can be learner-owned, so
      -- every object in it is correctly reported as a violation.
      NULL;
    END;
    i := :i + 1;
  END WHILE;

  -- ---- Violations, then the true owner of each one. -------------------------
  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL
    SELECT ROW_NUMBER() OVER (ORDER BY e.SCH, e.KIND, e.OBJ), e.KIND, e.KIND_SQL,
           e.SCH, e.OBJ, e.OBJ_REF, '(unknown)', 'SNOWCUP_' || e.SCH,
           'GRANT OWNERSHIP ON ' || e.KIND_SQL || ' ' || e.OBJ_REF
             || ' TO ROLE SNOWCUP_' || e.SCH || ';'
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS e
     WHERE NOT EXISTS (SELECT 1 FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_OWNED o
                        WHERE o.MATCH_KEY = e.MATCH_KEY);

  -- Naming the actual owner turns "something is wrong" into "you created this on
  -- ACCOUNTADMIN". Done per violation rather than per object because violations
  -- are normally zero, so this loop usually does not run at all.
  SELECT COUNT(*) INTO :vn FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL;
  WHILE (:vi <= :vn) DO
    SELECT KIND_SQL, OBJ_REF INTO :vkind, :vref
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL WHERE RN = :vi;
    vowner := '(unknown)';
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS ON ' || :vkind || ' ' || :vref;
      SELECT MAX("grantee_name") INTO :vowner
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE "privilege" = 'OWNERSHIP';
    EXCEPTION WHEN OTHER THEN
      vowner := '(unreadable)';
    END;
    UPDATE SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL
       SET OWNER = COALESCE(:vowner, '(none)') WHERE RN = :vi;
    vi := :vi + 1;
  END WHILE;

  -- An unreadable kind is surfaced as a row, never omitted -- otherwise a kind
  -- this account cannot report on would look identical to a clean result.
  rs := (
    SELECT KIND, SCH, OBJ, OWNER, EXPECTED_ROLE, FIX_SQL
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL
    UNION ALL
    SELECT '(kind not readable)', '-', KIND, '(could not enumerate)', '-',
           '-- this object kind could not be listed on this account; audit is incomplete'
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND
     ORDER BY 2, 1, 3);
  RETURN TABLE(rs);
END;
$$;

-- >>> FIX_BUILD_OWNERSHIP: hand every mis-owned object back to its learner.
--
--     Each GRANT is wrapped in its own exception handler so one failure cannot
--     abandon the rest, and the procedure RE-AUDITS afterwards rather than
--     assuming the grants worked -- a partial repair must never report success.
--
--     Deliberately no COPY CURRENT GRANTS: it would carry the admin's grants
--     across and widen access beyond that one learner, defeating the isolation
--     gate in check_roles.sql check 1.
--
--     Runs as caller, like the rest of ADMIN. A SNOWCUP_FACILITATOR caller
--     cannot transfer ACCOUNTADMIN-owned objects, which is precisely the common
--     case -- those come back in the "still broken" list with their owner named,
--     rather than failing silently.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP(P_PARTICIPANT VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  blk     VARCHAR;
  fixed   VARCHAR;
  n_before INT DEFAULT 0;
  n_after  INT DEFAULT 0;
  left_over VARCHAR;
BEGIN
  CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(:P_PARTICIPANT);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX AS
    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

  SELECT COUNT(*) INTO :n_before FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX
   WHERE STARTSWITH(FIX_SQL, 'GRANT');
  IF (:n_before = 0) THEN
    RETURN 'ownership OK (nothing to repair)';
  END IF;

  SELECT LISTAGG(KIND || ' ' || SCH || '.' || OBJ || ' (was ' || OWNER || ')', ', ')
    INTO :fixed FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX
   WHERE STARTSWITH(FIX_SQL, 'GRANT');

  -- One dynamic block instead of iterating rows, which avoids the cursor-field
  -- resolution problem; the per-statement handler keeps it resilient.
  SELECT LISTAGG('BEGIN ' || FIX_SQL || ' EXCEPTION WHEN OTHER THEN NULL; END;', ' ')
    INTO :blk FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX
   WHERE STARTSWITH(FIX_SQL, 'GRANT');
  EXECUTE IMMEDIATE 'BEGIN ' || :blk || ' END;';

  -- Prove it, do not assume it.
  CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(:P_PARTICIPANT);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_RECHECK AS
    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  SELECT COUNT(*) INTO :n_after FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_RECHECK
   WHERE STARTSWITH(FIX_SQL, 'GRANT');

  IF (:n_after = 0) THEN
    RETURN 'repaired ' || :n_before::VARCHAR || ': ' || :fixed;
  END IF;

  SELECT LISTAGG(KIND || ' ' || SCH || '.' || OBJ || ' (owned by ' || OWNER || ')', ', ')
    INTO :left_over FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_RECHECK
   WHERE STARTSWITH(FIX_SQL, 'GRANT');
  RETURN 'PARTIAL: repaired ' || (:n_before - :n_after)::VARCHAR || ' of '
      || :n_before::VARCHAR || '. STILL BROKEN: ' || :left_over
      || '  -- you probably need ACCOUNTADMIN to transfer these.';
END;
$$;

-- >>> AUDIT_BUILD_OWNERSHIP_JSON: the same audit, as a single VARIANT value.
--
--     WHY THIS EXISTS AND WHY IT HOLDS NO LOGIC OF ITS OWN
--     A caller outside Snowflake cannot use the table form. Reading it needs
--     CALL followed by SELECT ... FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())), and
--     those are two round trips -- so with a connection POOL (which the admin app
--     uses) the second statement can land on a different session, where
--     LAST_QUERY_ID() refers to some unrelated query. The symptom is an
--     "invalid identifier" on the first selected column, not a permission error.
--
--     Inside a procedure the CALL and the RESULT_SCAN are guaranteed to share a
--     session, so this wrapper is safe. It delegates entirely -- there is exactly
--     one definition of "who should own this", in AUDIT_BUILD_OWNERSHIP, because
--     the whole reason this feature exists is that three copies of that logic
--     drifted apart.
--
--     Returns [] when everything is correctly owned.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP_JSON(P_PARTICIPANT VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  out VARIANT DEFAULT NULL;
BEGIN
  CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(:P_PARTICIPANT);
  SELECT COALESCE(ARRAY_AGG(OBJECT_CONSTRUCT(
           'kind', KIND, 'sch', SCH, 'obj', OBJ, 'owner', OWNER,
           'expected_role', EXPECTED_ROLE, 'fix_sql', FIX_SQL)), ARRAY_CONSTRUCT())
    INTO :out
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  RETURN :out;
END;
$$;

-- >>> AUDIT_LEARNER_ROLES: does every learner role still hold what the lab needs?
--
--     WHY THIS EXISTS AND WHY check_roles.sql IS NOT ENOUGH
--     check_roles.sql samples ONE probe role for scope and nesting. That is fine
--     for a freshly deployed account, where every role was minted by the same
--     code path, and useless for a DRIFTED one: an account provisioned by an
--     older version can have five broken roles and one good one, and a
--     single-role sample reports PASS. This checks every role, every time.
--
--     WHAT NOTHING ELSE CHECKS AT ALL
--       * the twelve schema privileges PROVISION_LEARNER grants. Missing
--         CREATE TASK / CREATE DATASET / CREATE STAGE / CREATE FILE FORMAT
--         blocks the Module 8 and 10 evaluations and nothing else notices.
--       * one user holding TWO SNOWCUP_WS_ roles. RESOLVE_LEARNER refuses to
--         provision into that state but cannot see roles already in it -- which
--         is exactly what an older provisioner produced when it derived names
--         from email addresses and a later run derived them from logins.
--       * whether a role's name derives from its holder's LOGIN or their EMAIL.
--         Cosmetic on its own; the reason it matters is that it is the signal
--         that this role predates the current naming rule, so the other gaps
--         above are likely too.
--
--     NAME_BASIS is a report, never an instruction. An email-derived name is
--     functionally fine, and RENAME_LEARNER_SPACE below is the only thing that
--     acts on it -- deliberately, because renaming touches a learner's work and
--     restoring a grant does not.
--
--     Every gate that CANNOT be evaluated reports UNVERIFIED, never PASS. An
--     unreadable role is not a clean one, and reporting it as clean is the exact
--     failure mode that let mis-owned objects hide for a whole workshop.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_LEARNER_ROLES(P_PARTICIPANT VARCHAR)
RETURNS TABLE (SCOPE VARCHAR, ROLE_NAME VARCHAR, HOLDER VARCHAR, NAME_BASIS VARCHAR,
               VERDICT VARCHAR, GAPS VARCHAR, SUGGESTED_ROLE VARCHAR, OBJ_COUNT INT)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  only_sfx VARCHAR DEFAULT NULL;
  pn       VARCHAR;
  res      VARIANT;
  n        INT DEFAULT 0;
  i        INT DEFAULT 1;
  rname    VARCHAR;
  rsfx     VARCHAR;
  rsch     VARCHAR;
  readable INT DEFAULT 1;
  gaps     VARCHAR;
  holder   VARCHAR;
  nusers   INT DEFAULT 0;
  hasfac   INT DEFAULT 0;
  nested   INT DEFAULT 0;
  cortex   INT DEFAULT 0;
  owns     INT DEFAULT 0;
  note     VARCHAR DEFAULT '';
  basis    VARCHAR;
  suggest  VARCHAR;
  nobj     INT DEFAULT 0;
  dupes    INT DEFAULT 0;
  nheld    INT DEFAULT 0;
  exectask INT DEFAULT 0;
  leaked   INT DEFAULT 0;
  partok   INT DEFAULT 1;
  rs       RESULTSET;
BEGIN
  -- Scope to one learner when asked, using the SAME resolver provisioning uses so
  -- the audit inspects the role they actually HOLD -- including one named under an
  -- older rule. Re-deriving the name here would point the audit at a role that does
  -- not exist and then report nothing wrong with a learner who is entirely broken.
  IF (P_PARTICIPANT IS NOT NULL AND TRIM(P_PARTICIPANT) <> '') THEN
    pn := TRIM(P_PARTICIPANT);
    CALL SNOWCUP_WORKSHOP.ADMIN.RESOLVE_LEARNER(:pn) INTO :res;
    only_sfx := res:suffix::VARCHAR;
    -- Captured here because it is the ONLY way the scoped path can see a duplicate.
    -- T_RA_HOLD below is filled from in-scope roles only, so when the audit is
    -- narrowed to one person its GROUP BY can never find a second role and the
    -- duplicate check silently reports nothing -- which reads as "no duplicate"
    -- rather than "not checked". RESOLVE_LEARNER already counted the SNOWCUP_WS_
    -- roles this person holds, so this costs nothing.
    nheld := COALESCE(res:held_count::NUMBER, 0);
    IF (:only_sfx IS NULL OR :only_sfx = '') THEN
      only_sfx := 'UNRESOLVABLE_NAME';
    END IF;
  END IF;

  -- Qualified temp tables: an unqualified CREATE TEMPORARY TABLE fails with
  -- "session does not have a current database" for a caller who has only done
  -- USE ROLE. Temporary, so two facilitators auditing at once do not collide.
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_ROLES (
    RN INT, ROLE_NAME VARCHAR, SFX VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_SCHEMAS (SFX VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_USERS (
    UNAME VARCHAR, SFX_LOGIN VARCHAR, SFX_EMAIL VARCHAR, SFX_NAME VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_HOLD (
    ROLE_NAME VARCHAR, UNAME VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_OBJ (
    SFX VARCHAR, N INT);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_WANT (PRIV VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_GRANT (PRIV VARCHAR);
  -- Created ONCE and emptied per role inside the loop. See the DELETE there for why
  -- this is not CREATE OR REPLACE per role.
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_TO (
    PRIV VARCHAR, GO VARCHAR, NM VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_OF (
    GT VARCHAR, GN VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_OUT (
    RN INT, SCOPE VARCHAR, ROLE_NAME VARCHAR, HOLDER VARCHAR, NAME_BASIS VARCHAR,
    VERDICT VARCHAR, GAPS VARCHAR, SUGGESTED_ROLE VARCHAR, OBJ_COUNT INT);

  -- The contract, as data rather than as twelve hand-written IF statements. Kept in
  -- the same order PROVISION_LEARNER grants them so a diff between the two is a
  -- one-line read.
  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_WANT (PRIV) VALUES
    ('USAGE'), ('CREATE TABLE'), ('CREATE VIEW'), ('CREATE SEMANTIC VIEW'),
    ('CREATE CORTEX SEARCH SERVICE'), ('CREATE AGENT'), ('CREATE PROCEDURE'),
    ('CREATE FUNCTION'), ('CREATE STAGE'), ('CREATE FILE FORMAT'),
    ('CREATE TASK'), ('CREATE DATASET');

  -- ---- What exists -----------------------------------------------------------
  -- STARTSWITH, never LIKE, for the WS_ prefix test. '_' is a LIKE wildcard and
  -- backslash is not an escape character without an ESCAPE clause, so 'WS\_%'
  -- matches nothing and every gate below would pass vacuously.
  SHOW ROLES LIKE 'SNOWCUP_WS_%';
  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_ROLES (RN, ROLE_NAME, SFX)
    SELECT ROW_NUMBER() OVER (ORDER BY "name"), "name",
           SUBSTR("name", LENGTH('SNOWCUP_WS_') + 1)
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE STARTSWITH("name", 'SNOWCUP_WS_');

  IF (:only_sfx IS NOT NULL) THEN
    DELETE FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_ROLES WHERE SFX <> :only_sfx;
    -- Renumber, or the loop below skips every row whose original position is
    -- past the filtered count and the audit silently reports nothing.
    CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_ROLES AS
      SELECT ROW_NUMBER() OVER (ORDER BY ROLE_NAME) AS RN, ROLE_NAME, SFX
        FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_ROLES;
  END IF;

  SHOW SCHEMAS LIKE 'WS_%' IN DATABASE SNOWCUP_BUILDS;
  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_SCHEMAS (SFX)
    SELECT SUBSTR("name", LENGTH('WS_') + 1)
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE STARTSWITH("name", 'WS_');

  -- Users, for NAME_BASIS. All three sanitised forms use the SAME expression
  -- RESOLVE_LEARNER uses, so a verdict of "email-derived" means precisely "what the
  -- old provisioner would have produced" rather than an approximation of it.
  -- SFX_NAME is the canonical one -- see NAME_BASIS in the loop below.
  BEGIN
    SHOW USERS;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_USERS (UNAME, SFX_LOGIN, SFX_EMAIL, SFX_NAME)
      SELECT UPPER("name"),
             TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(COALESCE("login_name", ''), '@', 1)), '[^A-Z0-9]+', '_'), '_'),
             TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(COALESCE("email", ''),      '@', 1)), '[^A-Z0-9]+', '_'), '_'),
             TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(COALESCE("name", ''),       '@', 1)), '[^A-Z0-9]+', '_'), '_')
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  EXCEPTION WHEN OTHER THEN
    -- A facilitator caller may not be allowed to list users. Leave the table empty
    -- so NAME_BASIS reports 'unknown' rather than guessing.
    NULL;
  END;

  -- ---- How much work is in each build schema ---------------------------------
  -- Surfaced so the console can refuse a rename on a schema that still has work in
  -- it. Four SHOWs for the whole database rather than four per learner. Each SHOW is
  -- followed IMMEDIATELY by its INSERT, so LAST_QUERY_ID() needs no offset -- the
  -- LAST_QUERY_ID(-N) form misreads the moment a SHOW is added or skipped.
  --
  -- SHOW, NOT INFORMATION_SCHEMA, AND THIS WAS MEASURED. The first version counted
  -- from SNOWCUP_BUILDS.INFORMATION_SCHEMA.TABLES and reported OBJ_COUNT = 0 for a
  -- schema that demonstrably held a table. INFORMATION_SCHEMA is filtered more
  -- strictly than SHOW: an object owned by a role OUTSIDE the caller's hierarchy is
  -- absent from it entirely, while SHOW still lists it. The roles that fall outside
  -- the hierarchy are exactly the orphaned and mis-granted ones this audit exists to
  -- find -- so the old version under-reported precisely where it mattered, and the
  -- console would have called such a schema empty and offered a rename as safe.
  BEGIN
    SHOW TABLES IN DATABASE SNOWCUP_BUILDS;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OBJ (SFX, N)
      SELECT SUBSTR("schema_name", LENGTH('WS_') + 1), COUNT(*)
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_') GROUP BY 1;
  EXCEPTION WHEN OTHER THEN NULL; END;
  BEGIN
    SHOW VIEWS IN DATABASE SNOWCUP_BUILDS;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OBJ (SFX, N)
      SELECT SUBSTR("schema_name", LENGTH('WS_') + 1), COUNT(*)
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_') GROUP BY 1;
  EXCEPTION WHEN OTHER THEN NULL; END;
  BEGIN
    SHOW SEMANTIC VIEWS IN DATABASE SNOWCUP_BUILDS;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OBJ (SFX, N)
      SELECT SUBSTR("schema_name", LENGTH('WS_') + 1), COUNT(*)
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_') GROUP BY 1;
  EXCEPTION WHEN OTHER THEN NULL; END;
  BEGIN
    SHOW CORTEX SEARCH SERVICES IN DATABASE SNOWCUP_BUILDS;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OBJ (SFX, N)
      SELECT SUBSTR("schema_name", LENGTH('WS_') + 1), COUNT(*)
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_') GROUP BY 1;
  EXCEPTION WHEN OTHER THEN NULL; END;
  BEGIN
    SHOW AGENTS IN DATABASE SNOWCUP_BUILDS;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OBJ (SFX, N)
      SELECT SUBSTR("schema_name", LENGTH('WS_') + 1), COUNT(*)
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_') GROUP BY 1;
  EXCEPTION WHEN OTHER THEN NULL; END;

  -- ---- Per-role gates --------------------------------------------------------
  SELECT COUNT(*) INTO :n FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_ROLES;
  WHILE (:i <= :n) DO
    SELECT ROLE_NAME, SFX INTO :rname, :rsfx
      FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_ROLES WHERE RN = :i;
    rsch     := 'SNOWCUP_BUILDS.WS_' || :rsfx;
    gaps     := '';
    note     := '';
    readable := 1;
    suggest  := NULL;

    -- ONE SHOW GRANTS TO ROLE, read three ways. It used to be three identical
    -- SHOWs, which is three times the round trips inside the loop and, worse, left
    -- the later two outside the exception handler -- so a role that became
    -- unreadable mid-loop threw out of the whole procedure instead of being
    -- recorded as UNVERIFIED.
    --
    -- INSERT into a table created ONCE, not CREATE OR REPLACE TEMPORARY TABLE per
    -- role. Kept because table DDL inside a loop is worse practice, NOT because it
    -- was faster -- it was measured both ways and made no material difference
    -- (~50s before, ~44-50s after, for seven roles). Do not cite this as an
    -- optimisation.
    --
    -- THE REAL COST IS THE SHOW STATEMENTS, and it is not avoidable here. This runs
    -- roughly 40 of them for seven roles at about one second each, two per role.
    -- SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES would answer for every role in a
    -- single query, and it is the obvious optimisation, but it lags by up to two
    -- hours -- so a re-scan straight after a repair would still report the failure
    -- that was just fixed, and the operator would repair again. A slow truthful
    -- answer beats a fast stale one, so the audit stays on SHOW. Budget roughly
    -- five seconds per learner, and expect a 30-person cohort to take minutes.
    -- That is why the console runs this from a button and never on page load.
    DELETE FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_GRANT;
    DELETE FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_TO;
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS TO ROLE ' || :rname;
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_TO (PRIV, GO, NM)
        SELECT UPPER("privilege"), "granted_on", "name"
          FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
      -- Privileges on ITS OWN schema. Scoped to granted_on = 'SCHEMA' with an EXACT
      -- name match: objects the learner creates live inside that schema and their
      -- qualified names would otherwise be counted as schema privileges.
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_GRANT (PRIV)
        SELECT PRIV FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_TO
         WHERE GO = 'SCHEMA' AND UPPER(NM) = UPPER(:rsch);
      SELECT COUNT(*) INTO :leaked FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_TO
       WHERE GO = 'SCHEMA' AND POSITION('.WS_' IN UPPER(NM)) > 0
         AND UPPER(NM) <> UPPER(:rsch);
      SELECT SUM(IFF(NM = 'SNOWCUP_PARTICIPANT', 1, 0)),
             SUM(IFF(UPPER(NM) LIKE '%CORTEX_USER%', 1, 0))
        INTO :nested, :cortex
        FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_TO;
    EXCEPTION WHEN OTHER THEN
      readable := 0;
    END;

    IF (:readable = 0) THEN
      gaps := 'could not read SHOW GRANTS TO ROLE';
    ELSE
      -- OWNERSHIP SATISFIES ALL TWELVE, and skipping this check produces a
      -- spectacular false failure: the owner of a schema holds every privilege on
      -- it implicitly, so a role that OWNS its build space shows none of the twelve
      -- as explicit grants and would be reported as missing all of them.
      --
      -- Provisioning does not produce this shape -- it creates the schema as the
      -- caller (usually ACCOUNTADMIN) and grants the twelve explicitly -- so a role
      -- that owns its schema was configured some other way. That is worth SAYING,
      -- because ownership also means the learner can drop their own build space,
      -- but it is not a missing privilege and must not be coloured as one.
      SELECT COUNT(*) INTO :owns FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_GRANT
       WHERE PRIV = 'OWNERSHIP';

      IF (:owns > 0) THEN
        gaps := '';
        note := 'owns its build schema, so the twelve privileges are implicit'
             || ' (provisioning grants them explicitly instead)';
      ELSE
        -- Missing schema privileges, named individually so the fix is obvious.
        SELECT COALESCE(LISTAGG(w.PRIV, ', ') WITHIN GROUP (ORDER BY w.PRIV), '')
          INTO :gaps
          FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_WANT w
         WHERE NOT EXISTS (SELECT 1 FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_GRANT g
                            WHERE g.PRIV = w.PRIV);
        -- LISTAGG returns '' and not NULL over an empty set, so test the empty string.
        IF (:gaps <> '') THEN
          gaps := 'missing on own schema: ' || :gaps;
        END IF;
      END IF;

      IF (:leaked > 0) THEN
        gaps := TRIM(:gaps || '; reaches ' || :leaked::VARCHAR
             || ' OTHER build schema(s) - isolation break', '; ');
      END IF;
      IF (COALESCE(:nested, 0) = 0) THEN
        gaps := TRIM(:gaps || '; SNOWCUP_PARTICIPANT not nested', '; ');
      END IF;
      IF (COALESCE(:cortex, 0) = 0) THEN
        gaps := TRIM(:gaps || '; SNOWFLAKE.CORTEX_USER not granted', '; ');
      END IF;
    END IF;

    -- Who holds it, and does the facilitator? SHOW GRANTS OF ROLE answers both, so
    -- this is one statement rather than a per-role read of the facilitator's grants.
    holder := NULL; nusers := 0; hasfac := 0;
    DELETE FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_OF;
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS OF ROLE ' || :rname;
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OF (GT, GN)
        SELECT "granted_to", "grantee_name"
          FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
      SELECT COUNT(*), COALESCE(LISTAGG(GN, ', ') WITHIN GROUP (ORDER BY GN), '')
        INTO :nusers, :holder
        FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_OF WHERE GT = 'USER';
      SELECT COUNT(*) INTO :hasfac FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_OF
       WHERE GT = 'ROLE' AND UPPER(GN) = 'SNOWCUP_FACILITATOR';
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_HOLD (ROLE_NAME, UNAME)
        SELECT :rname, UPPER(GN) FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_OF WHERE GT = 'USER';
    EXCEPTION WHEN OTHER THEN
      readable := 0;
      gaps := TRIM(:gaps || '; could not read SHOW GRANTS OF ROLE', '; ');
    END;

    IF (COALESCE(:nusers, 0) = 0) THEN
      gaps := TRIM(:gaps || '; granted to nobody (orphan role)', '; ');
    ELSEIF (:nusers > 1) THEN
      gaps := TRIM(:gaps || '; held by ' || :nusers::VARCHAR || ' users - they share a build schema', '; ');
    END IF;
    IF (COALESCE(:hasfac, 0) = 0) THEN
      gaps := TRIM(:gaps || '; not granted to SNOWCUP_FACILITATOR', '; ');
    END IF;

    IF (NOT EXISTS (SELECT 1 FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_SCHEMAS WHERE SFX = :rsfx)) THEN
      gaps := TRIM(:gaps || '; build schema ' || :rsch || ' does not exist', '; ');
    END IF;

    -- NAME_BASIS: which spelling of this person does the role name come from?
    --
    -- THE CANONICAL BASIS IS THE SNOWFLAKE USERNAME, not login_name and not email.
    -- RESOLVE_LEARNER derives the suffix from MAX("name") out of SHOW USERS, so
    -- SFX_NAME is what re-running provisioning WOULD produce for a person who holds
    -- no role yet. Suggesting a login_name-derived name instead -- which an earlier
    -- version of this procedure did -- proposes a rename that provisioning would
    -- then disagree with, leaving the two fighting over the name forever.
    --
    -- 'both' is the ordinary case on accounts where the username IS the email
    -- address: the old and new rules agree and there is nothing to report.
    IF (COALESCE(:nusers, 0) <> 1) THEN
      basis := 'orphan';
    ELSE
      SELECT CASE
               WHEN u.SFX_NAME  = :rsfx AND u.SFX_EMAIL = :rsfx THEN 'both'
               WHEN u.SFX_NAME  = :rsfx                         THEN 'username'
               WHEN u.SFX_LOGIN = :rsfx                         THEN 'login'
               WHEN u.SFX_EMAIL = :rsfx                         THEN 'email'
               ELSE 'unknown'
             END,
             NULLIF(u.SFX_NAME, '')
        INTO :basis, :suggest
        FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_USERS u
       WHERE u.UNAME = UPPER(:holder)
       LIMIT 1;
      IF (:basis IS NULL) THEN
        -- No matching user row, which means SHOW USERS was unreadable. Say so
        -- rather than implying the name was checked and found fine.
        basis := 'unknown';
      END IF;
      -- Only propose a new name for a role that does NOT already match the
      -- canonical rule, and only when the canonical name is actually usable.
      IF (:basis IN ('both', 'username') OR :suggest IS NULL OR :suggest = :rsfx) THEN
        suggest := NULL;
      ELSE
        suggest := 'SNOWCUP_WS_' || :suggest;
      END IF;
    END IF;

    SELECT COALESCE(SUM(N), 0) INTO :nobj
      FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_OBJ WHERE SFX = :rsfx;

    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OUT
      (RN, SCOPE, ROLE_NAME, HOLDER, NAME_BASIS, VERDICT, GAPS, SUGGESTED_ROLE, OBJ_COUNT)
    SELECT :i, 'ROLE', :rname, NULLIF(:holder, ''), :basis,
           CASE WHEN :readable = 0 THEN 'UNVERIFIED'
                WHEN :gaps = ''    THEN 'PASS'
                ELSE 'FAIL' END,
           -- NOTE is appended in both directions on purpose. A non-standard but
           -- valid shape -- owning your own build schema -- must be visible on a
           -- PASS row too, or the only way to learn about it is to hit a
           -- consequence of it later.
           TRIM(IFF(:gaps = '', 'holds the full lab contract', :gaps)
                || IFF(:note = '', '', '; ' || :note), '; '),
           :suggest, :nobj;

    i := :i + 1;
  END WHILE;

  -- ---- Duplicate holders -----------------------------------------------------
  -- One person holding two SNOWCUP_WS_ roles is the email-versus-login double
  -- provision. Reported as its own row because the subject is the PERSON, not
  -- either role, and picking one of their roles to flag would imply the other is
  -- the wrong one -- which only they can decide.
  --
  -- TWO PATHS, because the account-wide check cannot work when scoped. T_RA_HOLD
  -- only contains roles that were in scope, so with a named participant the
  -- GROUP BY below sees exactly one role and finds nothing -- indistinguishable
  -- from a clean result. The scoped path uses the count RESOLVE_LEARNER already
  -- returned instead.
  IF (:only_sfx IS NOT NULL) THEN
    IF (:nheld > 1) THEN
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OUT
        (RN, SCOPE, ROLE_NAME, HOLDER, NAME_BASIS, VERDICT, GAPS, SUGGESTED_ROLE, OBJ_COUNT)
      SELECT -2, 'DUPLICATE', '(' || :nheld::VARCHAR || ' roles - re-run the audit for'
             || ' the whole account to see which)',
             MAX(UNAME), 'conflict', 'FAIL',
             'holds ' || :nheld::VARCHAR || ' build spaces - provisioned more than once'
               || ' under different spellings. Consolidate the work into one, then revoke'
               || ' the spare.',
             NULL, 0
        FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_HOLD;
    END IF;
  ELSE
    SELECT COUNT(*) INTO :dupes FROM (
      SELECT UNAME FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_HOLD
       GROUP BY UNAME HAVING COUNT(DISTINCT ROLE_NAME) > 1);
    IF (:dupes > 0) THEN
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OUT
        (RN, SCOPE, ROLE_NAME, HOLDER, NAME_BASIS, VERDICT, GAPS, SUGGESTED_ROLE, OBJ_COUNT)
      SELECT -2, 'DUPLICATE', LISTAGG(ROLE_NAME, ' + ') WITHIN GROUP (ORDER BY ROLE_NAME),
             UNAME, 'conflict', 'FAIL',
             'holds ' || COUNT(DISTINCT ROLE_NAME)::VARCHAR || ' build spaces - provisioned twice'
               || ' under different spellings. Consolidate the work into one, then revoke the spare.',
             NULL, 0
        FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_HOLD
       GROUP BY UNAME HAVING COUNT(DISTINCT ROLE_NAME) > 1;
    END IF;
  END IF;

  -- ---- Account scope ---------------------------------------------------------
  -- EXECUTE TASK is an ACCOUNT-level privilege on the shared role. CREATE TASK on
  -- the learner's own schema is NOT sufficient, and the Module 8 and 10 evaluations
  -- run as tasks -- so a cohort can pass every per-role gate above and still be
  -- unable to complete the lab.
  BEGIN
    SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT;
    CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RA_PART AS
      SELECT UPPER("privilege") AS PRIV, "granted_on" AS GO, UPPER("name") AS NM
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
    SELECT COUNT(*) INTO :exectask FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_PART
     WHERE PRIV = 'EXECUTE TASK';
    -- Narrow on purpose. A learner who grants their own agent to SNOWCUP_PARTICIPANT
    -- produces a qualified object name that also contains 'WS_', so a looser match
    -- reports a false isolation break every time someone finishes Module 7.
    SELECT COUNT(*) INTO :leaked FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_PART
     WHERE GO = 'SCHEMA' AND POSITION('.WS_' IN NM) > 0;
  EXCEPTION WHEN OTHER THEN
    partok := 0;
  END;

  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OUT
    (RN, SCOPE, ROLE_NAME, HOLDER, NAME_BASIS, VERDICT, GAPS, SUGGESTED_ROLE, OBJ_COUNT)
  SELECT -1, 'ACCOUNT', 'SNOWCUP_PARTICIPANT', NULL, 'n/a',
         CASE WHEN :partok = 0 THEN 'UNVERIFIED'
              WHEN :exectask > 0 AND :leaked = 0 THEN 'PASS'
              ELSE 'FAIL' END,
         CASE WHEN :partok = 0 THEN 'could not read SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT'
              WHEN :exectask = 0 AND :leaked > 0
                THEN 'EXECUTE TASK missing (blocks evaluations); ' || :leaked::VARCHAR
                     || ' build-schema privilege(s) leaked to the shared role'
              WHEN :exectask = 0 THEN 'EXECUTE TASK missing - blocks the Module 8 and 10 evaluations'
              WHEN :leaked > 0 THEN :leaked::VARCHAR
                     || ' build-schema privilege(s) leaked to the shared role - learners can read each other'
              ELSE 'EXECUTE TASK held, no build-schema privileges leaked' END,
         NULL, 0;

  -- An account with no learner roles must not read as clean. [].every() is TRUE in
  -- the console and 0 = 0 is TRUE here, so say it explicitly.
  IF (:n = 0) THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RA_OUT
      (RN, SCOPE, ROLE_NAME, HOLDER, NAME_BASIS, VERDICT, GAPS, SUGGESTED_ROLE, OBJ_COUNT)
    VALUES (-3, 'ACCOUNT', '(no learner roles)', NULL, 'n/a', 'FAIL',
            IFF(:only_sfx IS NULL,
                'no SNOWCUP_WS_ roles exist - nobody is provisioned',
                'no SNOWCUP_WS_ role matches that person'), NULL, 0);
  END IF;

  rs := (SELECT SCOPE, ROLE_NAME, HOLDER, NAME_BASIS, VERDICT, GAPS, SUGGESTED_ROLE, OBJ_COUNT
           FROM SNOWCUP_WORKSHOP.ADMIN.T_RA_OUT ORDER BY RN);
  RETURN TABLE(rs);
END;
$$;

-- >>> AUDIT_LEARNER_ROLES_JSON: the same audit as a single VARIANT value.
--
--     Holds no logic. Exists because a caller outside Snowflake cannot read the
--     table form: that needs CALL then SELECT ... RESULT_SCAN(LAST_QUERY_ID()),
--     two round trips, and with a connection POOL (which the admin app uses) the
--     second can land on a different session where LAST_QUERY_ID() means some
--     unrelated query. The symptom is an "invalid identifier" on the first
--     column, which looks nothing like a session problem. Inside a procedure the
--     two statements are guaranteed to share a session.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_LEARNER_ROLES_JSON(P_PARTICIPANT VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  out VARIANT DEFAULT NULL;
BEGIN
  CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_LEARNER_ROLES(:P_PARTICIPANT);
  SELECT COALESCE(ARRAY_AGG(OBJECT_CONSTRUCT_KEEP_NULL(
           'scope', SCOPE, 'role', ROLE_NAME, 'holder', HOLDER,
           'name_basis', NAME_BASIS, 'verdict', VERDICT, 'gaps', GAPS,
           'suggested_role', SUGGESTED_ROLE, 'obj_count', OBJ_COUNT)), ARRAY_CONSTRUCT())
    INTO :out
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  RETURN :out;
END;
$$;

-- >>> REPAIR_LEARNER_ROLE: put back the grants a learner role is missing.
--
--     WHY THIS EXISTS RATHER THAN "JUST RE-RUN PROVISIONING"
--     Re-running PROVISION_LEARNER is the documented repair, and on an account
--     running the CURRENT setup script it is the right answer -- it is idempotent
--     and anchors on the role the learner already holds.
--
--     It does nothing useful on the accounts that need repairing most. Measured on
--     a real deployed account: it was provisioned by an OLDER version of this
--     script, whose PROVISION_LEARNER never granted CREATE STAGE, CREATE FILE
--     FORMAT, CREATE TASK or CREATE DATASET -- so those four were missing on every
--     learner, and re-running that account's own provisioning could not fix them,
--     because the missing grants are missing from the procedure too. That account
--     also lacked RESOLVE_LEARNER and APPLY_LAB_DEFAULTS entirely, so the newer
--     provisioning path was not even callable there.
--
--     So this procedure carries the contract itself and depends on NOTHING else in
--     this schema. That is the whole point: it has to run on a drifted account,
--     which by definition is one where the other procedures are the wrong version.
--
--     P_ROLE NULL means every SNOWCUP_WS_ role, AND the account-level grant on
--     SNOWCUP_PARTICIPANT. EXECUTE TASK is only repaired in that all-roles form
--     because it is not a property of any one learner: it is one account-wide
--     grant that the Module 8 and 10 evaluations need, and a per-learner repair
--     silently re-granting an account-wide privilege would hide which action
--     actually changed the account.
--
--     Idempotent, and every grant is individually guarded, so one privilege this
--     account's edition does not support cannot abort the rest of the repair.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.REPAIR_LEARNER_ROLE(P_ROLE VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  one   VARCHAR DEFAULT NULLIF(TRIM(UPPER(COALESCE(P_ROLE, ''))), '');
  n     INT DEFAULT 0;
  i     INT DEFAULT 1;
  rname VARCHAR;
  rsfx  VARCHAR;
  rsch  VARCHAR;
  blk   VARCHAR;
  done  VARCHAR DEFAULT '';
  acct  VARCHAR DEFAULT '';
BEGIN
  -- VALIDATE, do not escape: a role name cannot be bound, it is interpolated into
  -- GRANT statements. Anything outside the shape the sanitiser can emit is refused.
  IF (:one IS NOT NULL AND NOT REGEXP_LIKE(:one, '^SNOWCUP_WS_[A-Z0-9_]{1,200}$')) THEN
    RETURN 'REFUSED  ' || :one || ' is not a learner role name (expected'
        || ' SNOWCUP_WS_<NAME> using A-Z, 0-9 and underscore only).';
  END IF;

  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RR_ROLES (
    RN INT, ROLE_NAME VARCHAR, SFX VARCHAR);
  SHOW ROLES LIKE 'SNOWCUP_WS_%';
  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_RR_ROLES (RN, ROLE_NAME, SFX)
    SELECT ROW_NUMBER() OVER (ORDER BY "name"), "name",
           SUBSTR("name", LENGTH('SNOWCUP_WS_') + 1)
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE STARTSWITH("name", 'SNOWCUP_WS_')
       AND (:one IS NULL OR UPPER("name") = :one);

  SELECT COUNT(*) INTO :n FROM SNOWCUP_WORKSHOP.ADMIN.T_RR_ROLES;
  IF (:n = 0) THEN
    RETURN 'REFUSED  no matching SNOWCUP_WS_ role exists'
        || IFF(:one IS NULL, ' - nobody is provisioned.', ': ' || :one);
  END IF;
  -- Renumber after filtering, or the loop below indexes past the end and repairs
  -- nothing while reporting success.
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_RR_ROLES AS
    SELECT ROW_NUMBER() OVER (ORDER BY ROLE_NAME) AS RN, ROLE_NAME, SFX
      FROM SNOWCUP_WORKSHOP.ADMIN.T_RR_ROLES;

  WHILE (:i <= :n) DO
    SELECT ROLE_NAME, SFX INTO :rname, :rsfx
      FROM SNOWCUP_WORKSHOP.ADMIN.T_RR_ROLES WHERE RN = :i;
    rsch := 'SNOWCUP_BUILDS.WS_' || :rsfx;

    -- The same twelve privileges PROVISION_LEARNER grants, in one statement, plus
    -- the nesting and Cortex grants. Each wrapped individually: a privilege this
    -- account cannot grant must not abort the repair of the other eleven.
    blk := 'BEGIN '
        || 'BEGIN GRANT USAGE, CREATE TABLE, CREATE VIEW, CREATE SEMANTIC VIEW, '
        || 'CREATE CORTEX SEARCH SERVICE, CREATE AGENT, CREATE PROCEDURE, '
        || 'CREATE FUNCTION, CREATE STAGE, CREATE FILE FORMAT, CREATE TASK, '
        || 'CREATE DATASET ON SCHEMA ' || :rsch || ' TO ROLE ' || :rname
        || '; EXCEPTION WHEN OTHER THEN NULL; END; '
        || 'BEGIN GRANT ROLE SNOWCUP_PARTICIPANT TO ROLE ' || :rname
        || '; EXCEPTION WHEN OTHER THEN NULL; END; '
        || 'BEGIN GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE ' || :rname
        || '; EXCEPTION WHEN OTHER THEN NULL; END; '
        || 'BEGIN GRANT ROLE ' || :rname || ' TO ROLE SNOWCUP_FACILITATOR'
        || '; EXCEPTION WHEN OTHER THEN NULL; END; '
        || 'END;';
    EXECUTE IMMEDIATE :blk;

    done := :done || IFF(:done = '', '', ', ') || :rname;
    i := :i + 1;
  END WHILE;

  -- Account scope, only on the all-roles form. See the header for why.
  IF (:one IS NULL) THEN
    BEGIN
      GRANT EXECUTE TASK ON ACCOUNT TO ROLE SNOWCUP_PARTICIPANT;
      acct := '  Also granted EXECUTE TASK on the account to SNOWCUP_PARTICIPANT'
           || ' (the Module 8 and 10 evaluations run as tasks, and CREATE TASK on a'
           || ' learner''s own schema is not sufficient).';
    EXCEPTION WHEN OTHER THEN
      acct := '  EXECUTE TASK on the account could NOT be granted to'
           || ' SNOWCUP_PARTICIPANT (' || SQLERRM || ') - evaluations will still'
           || ' fail. This needs ACCOUNTADMIN.';
    END;
  END IF;

  RETURN 'REPAIRED ' || :n::VARCHAR || ' role(s): ' || :done || '.' || :acct
      || '  Re-run the audit to confirm - this reports what it ATTEMPTED, and the'
      || ' audit is what confirms the account.';
END;
$$;

-- >>> RENAME_LEARNER_SPACE: move a learner's role AND schema to a new name,
--     in place, keeping everything they have built.
--
--     WHY BOTH OBJECTS, ALWAYS, TOGETHER
--     The ownership model pairs them BY NAME: schema WS_X belongs to role
--     SNOWCUP_WS_X, and AUDIT_BUILD_OWNERSHIP compares owner against
--     'SNOWCUP_' || schema_name. Rename only the role and every object in that
--     schema reads as mis-owned; rename only the schema and the same. So this
--     renames both or neither, and rolls the role back if the schema rename fails.
--
--     WHY NOT CREATE-NEW-AND-COPY
--     Because the point is to keep the learner whole. A new role and schema
--     strands their semantic view, search service and agent in the old space.
--     ALTER ... RENAME TO acts on the same object rather than making another one.
--
--     WHAT IT DOES NOT CLAIM
--     It does NOT assert that grants survive the rename. It re-runs
--     AUDIT_LEARNER_ROLES afterwards and returns what that observed. If the audit
--     is not clean the result is PARTIAL and names the gaps, because a rename that
--     quietly dropped the schema privileges would leave a learner who can log in,
--     see their schema, and create nothing in it.
--
--     REFERENCES ARE THE CALLER'S PROBLEM, AND MUST BE SURFACED AS SUCH. Per the
--     ALTER SCHEMA reference: "When an object is renamed, other objects that
--     reference it must be updated with the new name." A learner's agent names its
--     semantic view and Cortex Search Service in full, so anything in a renamed
--     schema needs re-pointing. The return value says so whenever the schema is
--     not empty; AUDIT_LEARNER_ROLES.OBJ_COUNT is how the console warns first.
--
--     ALTER ROLE ... RENAME TO also needs the global CREATE ROLE privilege, which
--     a SNOWCUP_FACILITATOR does not normally hold. Through the admin app this
--     runs with the app owner's rights and works; called directly in SQL by a
--     facilitator it will not, and that is a privilege boundary rather than a bug.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RENAME_LEARNER_SPACE(
  P_OLD_SUFFIX VARCHAR, P_NEW_SUFFIX VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  o     VARCHAR DEFAULT TRIM(UPPER(P_OLD_SUFFIX));
  w     VARCHAR DEFAULT TRIM(UPPER(P_NEW_SUFFIX));
  orole VARCHAR;
  nrole VARCHAR;
  osch  VARCHAR;
  nsch  VARCHAR;
  cnt   INT DEFAULT 0;
  holder VARCHAR DEFAULT NULL;
  sowner VARCHAR DEFAULT NULL;
  nobj  INT DEFAULT 0;
  verd  VARCHAR DEFAULT NULL;
  gaps  VARCHAR DEFAULT NULL;
  dstat VARCHAR DEFAULT 'defaults not re-applied';
  rolled INT DEFAULT 0;
BEGIN
  -- VALIDATE, do not escape. Both values are interpolated into DDL -- an identifier
  -- cannot be bound -- so anything outside the character set a suffix can legally
  -- contain is refused outright rather than quoted and hoped for. The sanitiser in
  -- RESOLVE_LEARNER only ever emits A-Z, 0-9 and underscore.
  IF (:o IS NULL OR NOT REGEXP_LIKE(:o, '^[A-Z0-9_]{1,200}$')) THEN
    RETURN 'REFUSED  old suffix ' || COALESCE(:o, '(null)')
        || ' is not a valid build-space name (A-Z, 0-9, underscore only).';
  END IF;
  IF (:w IS NULL OR NOT REGEXP_LIKE(:w, '^[A-Z0-9_]{1,200}$')) THEN
    RETURN 'REFUSED  new suffix ' || COALESCE(:w, '(null)')
        || ' is not a valid build-space name (A-Z, 0-9, underscore only).';
  END IF;
  IF (:o = :w) THEN
    RETURN 'REFUSED  old and new names are the same (' || :o || ') - nothing to do.';
  END IF;

  orole := 'SNOWCUP_WS_' || :o;  nrole := 'SNOWCUP_WS_' || :w;
  osch  := 'SNOWCUP_BUILDS.WS_' || :o;
  nsch  := 'SNOWCUP_BUILDS.WS_' || :w;

  -- ---- Refuse BEFORE altering anything ---------------------------------------
  EXECUTE IMMEDIATE 'SHOW ROLES LIKE ''SNOWCUP_WS_' || :o || '''';
  SELECT COUNT(*) INTO :cnt FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
   WHERE "name" = :orole;
  IF (:cnt = 0) THEN
    RETURN 'REFUSED  role ' || :orole || ' does not exist.';
  END IF;

  EXECUTE IMMEDIATE 'SHOW ROLES LIKE ''SNOWCUP_WS_' || :w || '''';
  SELECT COUNT(*) INTO :cnt FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
   WHERE "name" = :nrole;
  IF (:cnt > 0) THEN
    RETURN 'REFUSED  role ' || :nrole || ' already exists. If that is this person''s'
        || ' other build space they were provisioned twice - consolidate the work'
        || ' into one and revoke the spare rather than renaming onto it.';
  END IF;

  EXECUTE IMMEDIATE 'SHOW SCHEMAS LIKE ''WS_' || :w || ''' IN DATABASE SNOWCUP_BUILDS';
  SELECT COUNT(*) INTO :cnt FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  IF (:cnt > 0) THEN
    RETURN 'REFUSED  schema ' || :nsch || ' already exists.';
  END IF;

  EXECUTE IMMEDIATE 'SHOW SCHEMAS LIKE ''WS_' || :o || ''' IN DATABASE SNOWCUP_BUILDS';
  SELECT COUNT(*) INTO :cnt FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  IF (:cnt = 0) THEN
    RETURN 'REFUSED  schema ' || :osch || ' does not exist, so renaming the role'
        || ' alone would break the role-to-schema pairing the ownership audit'
        || ' depends on. Re-run provisioning for this person first.';
  END IF;

  -- Exactly one holder. Zero means there is nobody whose defaults could be moved
  -- and the rename is cosmetic; more than one means two people share this space and
  -- a human has to separate them first.
  EXECUTE IMMEDIATE 'SHOW GRANTS OF ROLE ' || :orole;
  SELECT COUNT(*), MAX("grantee_name") INTO :cnt, :holder
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())) WHERE "granted_to" = 'USER';
  IF (:cnt <> 1) THEN
    RETURN 'REFUSED  ' || :orole || ' is held by ' || :cnt::VARCHAR || ' users.'
        || ' A rename is only safe for exactly one holder: with none there is'
        || ' nothing to move, and with several they share this build space and'
        || ' must be separated first.';
  END IF;

  -- How much is in there, for the reference warning below. SHOW rather than
  -- INFORMATION_SCHEMA: the latter omits objects owned by a role outside the
  -- caller's hierarchy, which would report an empty schema for exactly the
  -- mis-granted roles most likely to be renamed. Best-effort -- an unreadable
  -- count must not stop a rename that is otherwise safe, so it fails to -1 and
  -- the warning says the count is unknown rather than saying zero.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW TABLES IN SCHEMA ' || :osch;
    SELECT COUNT(*) INTO :nobj FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  EXCEPTION WHEN OTHER THEN
    nobj := -1;
  END;

  -- CAN WE ACTUALLY RENAME THE SCHEMA? Asked BEFORE the role is touched.
  --
  -- MEASURED, not theoretical: renaming a schema needs OWNERSHIP on it, and a
  -- schema owned by the learner's own role is NOT renameable by ACCOUNTADMIN --
  -- "Your primary role ACCOUNTADMIN must have OWNERSHIP granted on SCHEMA ...".
  -- Provisioning creates the schema as the caller, so the normal shape is an
  -- ACCOUNTADMIN-owned schema and this passes; a learner-owned one is the shape a
  -- drifted account can be in, and it is precisely the shape being repaired here.
  --
  -- The rollback below already handles the failure, and it was verified to work.
  -- This check exists anyway because refusing before changing anything is a
  -- strictly better outcome than changing something and undoing it -- the rollback
  -- itself can fail, and that leaves the role and schema names unpaired, which is
  -- worse than either starting state.
  --
  -- CURRENT_AVAILABLE_ROLES() rather than SHOW GRANTS TO USER: it reports what this
  -- session can actually use, including inherited roles, and it works under
  -- restricted caller's rights where USE ROLE and SHOW GRANTS do not.
  EXECUTE IMMEDIATE 'SHOW SCHEMAS LIKE ''WS_' || :o || ''' IN DATABASE SNOWCUP_BUILDS';
  SELECT MAX("owner") INTO :sowner FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  SELECT COUNT(*) INTO :cnt
    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(CURRENT_AVAILABLE_ROLES())))
   WHERE UPPER(VALUE::VARCHAR) = UPPER(COALESCE(:sowner, ''));
  IF (:cnt = 0) THEN
    RETURN 'REFUSED  schema ' || :osch || ' is owned by ' || COALESCE(:sowner, '(unknown)')
        || ', which this session does not hold, so the schema cannot be renamed.'
        || ' Renaming the role alone would break the role-to-schema pairing the'
        || ' ownership audit depends on, so nothing was changed. Either run this as'
        || ' a role that holds ' || COALESCE(:sowner, 'that role') || ', or hand the'
        || ' schema back first with: GRANT OWNERSHIP ON SCHEMA ' || :osch
        || ' TO ROLE ACCOUNTADMIN REVOKE CURRENT GRANTS; then re-run provisioning'
        || ' for this person to restore their privileges.';
  END IF;

  -- ---- Act -------------------------------------------------------------------
  EXECUTE IMMEDIATE 'ALTER ROLE ' || :orole || ' RENAME TO ' || :nrole;

  BEGIN
    EXECUTE IMMEDIATE 'ALTER SCHEMA ' || :osch || ' RENAME TO WS_' || :w;
  EXCEPTION WHEN OTHER THEN
    -- Put the role back. A renamed role beside an un-renamed schema is WORSE than
    -- either original state: every object in the schema then reads as mis-owned and
    -- the learner loses their build space until someone notices why.
    BEGIN
      EXECUTE IMMEDIATE 'ALTER ROLE ' || :nrole || ' RENAME TO ' || :orole;
      rolled := 1;
    EXCEPTION WHEN OTHER THEN
      rolled := 0;
    END;
    IF (:rolled = 1) THEN
      RETURN 'FAILED   could not rename ' || :osch || ' (' || SQLERRM || ').'
          || ' The role rename was rolled back, so nothing changed.';
    END IF;
    RETURN 'BROKEN   renamed role to ' || :nrole || ' but could not rename '
        || :osch || ' (' || SQLERRM || '), AND could not roll the role back.'
        || ' The role and schema names no longer pair, so every object in that'
        || ' schema now reads as mis-owned. Fix by hand: ALTER ROLE ' || :nrole
        || ' RENAME TO ' || :orole || ';';
  END;

  -- The holder's DEFAULT_ROLE and DEFAULT_NAMESPACE both name the OLD objects, so
  -- without this they sign in to a role that no longer exists.
  BEGIN
    CALL SNOWCUP_WORKSHOP.ADMIN.APPLY_LAB_DEFAULTS(:holder, :nrole, 'SNOWCUP_BUILDS.WS_' || :w)
      INTO :dstat;
  EXCEPTION WHEN OTHER THEN
    dstat := 'defaults NOT re-applied (' || SQLERRM || ')';
  END;

  -- ---- Prove it, do not assume it --------------------------------------------
  BEGIN
    CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_LEARNER_ROLES(:holder);
    SELECT MAX(VERDICT), MAX(GAPS) INTO :verd, :gaps
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())) WHERE SCOPE = 'ROLE';
  EXCEPTION WHEN OTHER THEN
    verd := 'UNVERIFIED'; gaps := SQLERRM;
  END;

  IF (COALESCE(:verd, 'UNVERIFIED') <> 'PASS') THEN
    RETURN 'PARTIAL  ' || :orole || ' -> ' || :nrole || ' and ' || :osch || ' -> '
        || :nsch || ', but the role no longer holds the full lab contract: '
        || COALESCE(:gaps, 'audit could not run')
        || '. Re-run provisioning for ' || :holder || ' to restore the grants.'
        || '  (' || :dstat || ')';
  END IF;

  RETURN 'OK       ' || :orole || ' -> ' || :nrole || '  and  ' || :osch || ' -> '
      || :nsch || '  (' || :dstat || ')'
      || IFF(:nobj <> 0,
             '  WARNING: ' || IFF(:nobj < 0, 'an unknown number of', :nobj::VARCHAR)
             || ' table(s) moved with the schema. Any semantic view, Cortex Search'
             || ' Service or agent that names the OLD schema in full must be'
             || ' re-pointed at ' || :nsch || ' - a rename does not update'
             || ' references.',
             '');
END;
$$;

-- ----------------------------------------------------------------------------
-- Facilitator access to the admin procedures.
-- ----------------------------------------------------------------------------
-- Granted last, because GRANT USAGE ON ALL PROCEDURES only covers procedures that
-- already exist.
--
-- Not strictly required to use the SnowCup Admin app: that app runs with OWNER's
-- rights (as its ACCOUNTADMIN installer) and uses the caller's identity only to
-- decide who is allowed in. These grants are for the facilitator who works in SQL
-- instead -- without them, SNOWCUP_FACILITATOR has no USAGE on this schema and
-- cannot CALL anything here, which contradicts every runbook that tells them to.
--
-- Note what this still does NOT give them: users are ACCOUNTADMIN-owned, so a
-- facilitator cannot ALTER USER directly. That is why APPLY_LAB_DEFAULTS and
-- RESTORE_USER_DEFAULTS run as OWNER -- it is what makes facilitator-run
-- provisioning work at all.
GRANT USAGE ON SCHEMA SNOWCUP_WORKSHOP.ADMIN                   TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON ALL PROCEDURES IN SCHEMA SNOWCUP_WORKSHOP.ADMIN TO ROLE SNOWCUP_FACILITATOR;

-- >>> AND THE SAME GRANTS AGAIN, EXPLICITLY, PER PROCEDURE.
--
--     NOT REDUNDANT. "ON ALL PROCEDURES" is a POINT-IN-TIME grant: it grants what
--     exists when it runs and nothing afterwards. `CREATE OR REPLACE PROCEDURE`
--     drops the object's grants, so the moment anyone edits a procedure without
--     re-running this whole file, the facilitator silently loses USAGE on it.
--
--     This is not hypothetical. An audit found FIVE procedures orphaned exactly
--     this way -- PROVISION_LEARNER (both signatures), LOG_PROVISION_STEP,
--     APPLY_LAB_DEFAULTS and RESTORE_USER_DEFAULTS -- after two separate editing
--     sessions replaced them individually.
--
--     WHY IT BROKE PROVISIONING RATHER THAN JUST LOOKING UNTIDY. PROVISION_LEARNERS
--     is EXECUTE AS CALLER and calls PROVISION_LEARNER, also EXECUTE AS CALLER, so
--     the facilitator needs USAGE on the inner procedure too. They could reach the
--     entry point and failed on the first inner call with "Unknown user-defined
--     function". ACCOUNTADMIN and the admin app run with owner's rights and were
--     unaffected, which is why the break stayed invisible: the only path that
--     failed was the delegated one the workshop exists to support.
--
--     ADDING A PROCEDURE? Add its grant here too. A missing line here is a
--     facilitator who cannot provision.
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESOLVE_LEARNER(VARCHAR)                              TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(VARCHAR)                            TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(VARCHAR, VARCHAR)                   TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS(VARCHAR)                           TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_LEARNER(VARCHAR, BOOLEAN)                 TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_ORPHAN(VARCHAR, VARCHAR)                  TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.LOG_PROVISION_STEP(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR) TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.APPLY_LAB_DEFAULTS(VARCHAR, VARCHAR, VARCHAR)         TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESTORE_USER_DEFAULTS(VARCHAR)                        TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESTORE_ALL_LEARNER_DEFAULTS()                        TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RESET_LEARNER_PROGRESS(VARCHAR, VARCHAR)              TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP(VARCHAR)                          TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(VARCHAR)                        TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP_JSON(VARCHAR)                   TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_LEARNER_ROLES(VARCHAR)                          TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_LEARNER_ROLES_JSON(VARCHAR)                     TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.REPAIR_LEARNER_ROLE(VARCHAR)                          TO ROLE SNOWCUP_FACILITATOR;
-- RENAME_LEARNER_SPACE is granted so the runbook path exists, but note it will
-- still fail for a facilitator working directly in SQL: ALTER ROLE ... RENAME TO
-- additionally requires the global CREATE ROLE privilege, which SNOWCUP_FACILITATOR
-- does not hold. Through the admin app it runs with the app owner's rights and
-- works. That is a privilege boundary, not a missing grant -- do not "fix" it by
-- granting CREATE ROLE, which would let a facilitator mint roles account-wide.
GRANT USAGE ON PROCEDURE SNOWCUP_WORKSHOP.ADMIN.RENAME_LEARNER_SPACE(VARCHAR, VARCHAR)                TO ROLE SNOWCUP_FACILITATOR;

GRANT SELECT ON TABLE SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP TO ROLE SNOWCUP_FACILITATOR;

-- Provisioning progress. SELECT so a facilitator can inspect a run in SQL. No
-- INSERT needed: LOG_PROVISION_STEP is EXECUTE AS OWNER, so the write happens as
-- the owner no matter who calls it -- and logging is best-effort regardless, so
-- the worst case of getting this wrong is a run with no progress rows, never a
-- failed provision.
GRANT SELECT ON TABLE SNOWCUP_WORKSHOP.ADMIN.PROVISION_RUN   TO ROLE SNOWCUP_FACILITATOR;
GRANT SELECT ON TABLE SNOWCUP_WORKSHOP.ADMIN.PROVISION_EVENT TO ROLE SNOWCUP_FACILITATOR;

-- ROSTER: as shipped this provisions whoever runs the script (CURRENT_USER), so
-- the smoke test works immediately on any account with no edits, and your own
-- defaults are left untouched. Add everyone else in one call, or use the
-- SnowCup Admin app (see snowcup-admin-node/).
CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(CURRENT_USER());
-- CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS('jdoe@acme.com, asmith@acme.com, BJONES');
-- CALL SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_LEARNER('jdoe@acme.com', FALSE);

-- ============================================================================
-- STEP 11: Verify the load
-- ============================================================================
-- Fully qualified: STEP 10 created SNOWCUP_BUILDS, which changes the session's
-- current database, so unqualified table names here would not resolve.
SELECT 'PLAYERS'            AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM SNOWCUP_SHARED.TOURNAMENT.PLAYERS
UNION ALL SELECT 'TOURNAMENTS',        COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.TOURNAMENTS
UNION ALL SELECT 'MATCHES',            COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.MATCHES
UNION ALL SELECT 'PLAYER_MATCH_STATS', COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_MATCH_STATS
UNION ALL SELECT 'DISCIPLINE',         COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.DISCIPLINE
UNION ALL SELECT 'PLAYER_PROFILES',    COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES
ORDER BY TABLE_NAME;
