/*=============================================================================
  SNOWCUP — SHARED DATA SETUP   (FACILITATOR / ADMIN — run ONCE)
  ============================================================================
  *** This is an ADMIN script. Learners do NOT run it. ***

  Run this once to stand up the shared, read-only SNOWCUP dataset that every
  learner builds their semantic view and agent on top of. Because all learners
  read the SAME rows, every challenge answer is identical for everyone — no one
  spends the session generating data; they focus on modeling and agent building.

  The data is 100% synthetic: invented nations, players and results. No PII/PHI.

  WHAT THIS SCRIPT DOES  (self-contained — just run it as ACCOUNTADMIN)
    1. Creates a dedicated warehouse (SNOWCUP_WH) — nothing to pre-create.
    2. Creates SNOWCUP_SHARED.TOURNAMENT and loads the 6 tables.
    3. Grants SELECT on them (read-only) to the SNOWCUP_PARTICIPANT role.
    4. Creates a per-learner build database (SNOWCUP_BUILDS) and a
       PROVISION_LEARNER helper. To add learners, add one CALL line per learner
       (see the ROSTER block near the end). As shipped it provisions just you.
  Learners build the Cortex Search service themselves (lab Module 4), so this
  script deliberately does NOT create one.

  TABLES (schema SNOWCUP_SHARED.TOURNAMENT)
    - PLAYERS             1 row / player     (name, nation, position; no nickname)
    - PLAYER_PROFILES     1 row / player     (nickname + bio; search owns the lore)
    - TOURNAMENTS         1 row / edition    (host, champion, golden boot/glove)
    - MATCHES             1 row / match      (stage, teams, score, margin)
    - PLAYER_MATCH_STATS  player x match     (minutes, goals, xg, assists, ...)
    - DISCIPLINE          player x match     (yellow/red cards, fouls)

  Data note: a handful of "star" players are hand-seeded so each challenge
  question has exactly one correct answer; the rest is generated with HASH()
  (never RANDOM()) so the dataset is identical on every run.

  SAFETY: no DROP DATABASE / DROP SCHEMA / DELETE / TRUNCATE, and no
  CREATE OR REPLACE on any database or schema -- so re-running this NEVER destroys
  work a learner has already built. Objects are created with CREATE OR REPLACE
  inside the shared database only; every database and schema uses IF NOT EXISTS.

  The one change this makes OUTSIDE the workshop's own objects is an account-level
  Cortex setting (CORTEX_ENABLED_CROSS_REGION), and it is only touched when it is
  DISABLED. When that happens the previous value and the exact statement to restore
  it are printed. Nothing else reaches beyond SNOWCUP_* objects except the learner
  DEFAULT_ROLE / DEFAULT_WAREHOUSE handling in PROVISION_LEARNER, which refuses to
  overwrite a default a user already has.
=============================================================================*/

-- ============================================================================
-- STEP 0: Admin context + a dedicated warehouse (created for you)
-- ============================================================================
USE ROLE ACCOUNTADMIN;                 -- or a role with CREATE DATABASE + CREATE WAREHOUSE
-- Cortex (Analyst / Search / agents / AI_COMPLETE) must be reachable, which needs
-- cross-region inference so the orchestration models work in any region.
--
-- This is an ACCOUNT-LEVEL setting whose default is DISABLED, and it is adjacent to
-- data residency -- an organisation may have chosen that deliberately. So it is
-- only changed when it is actually DISABLED, the previous value is reported, and
-- the statement to put it back is printed. "Idempotent" is not the same as
-- non-destructive, and silently loosening an account-wide control is not something
-- a workshop should do on the way past.
--
-- If it is set to an explicit region list rather than DISABLED, that list is left
-- exactly as it is. The workshop may still work (if the model's region is in the
-- list) or the Referee agent may fail to respond -- either way the deliberate
-- setting wins, and the message says so.
EXECUTE IMMEDIATE $$
DECLARE
  cur VARCHAR DEFAULT NULL;
BEGIN
  SHOW PARAMETERS LIKE 'CORTEX_ENABLED_CROSS_REGION' IN ACCOUNT;
  SELECT MAX("value") INTO :cur FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

  IF (UPPER(TRIM(COALESCE(:cur, ''))) = 'ANY_REGION') THEN
    RETURN 'cross-region inference already enabled (ANY_REGION) - account setting untouched';
  END IF;

  -- An explicit region list is a deliberate choice. Leave it exactly as it is.
  IF (:cur IS NOT NULL AND TRIM(:cur) <> '' AND UPPER(TRIM(:cur)) <> 'DISABLED') THEN
    RETURN 'cross-region inference is restricted to: ' || :cur
        || ' - LEFT UNCHANGED on purpose. If the Referee agent cannot respond, an '
        || 'ACCOUNTADMIN must decide whether to widen it.';
  END IF;

  -- Only reached when it is genuinely DISABLED (or unset). Handled rather than
  -- assumed: on some accounts this statement is refused (for example AI_SETTINGS
  -- guardrails), and an unhandled failure here would abort the whole data load.
  BEGIN
    ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';
  EXCEPTION WHEN OTHER THEN
    -- Markers are assembled by concatenation ('ACCT' || 'FAIL>') so the literal
    -- never appears in this file. snow echoes the query source it runs, so a
    -- plain marker would be matched in the echo and deploy.sh would report an
    -- account change on every run, including runs that changed nothing.
    RETURN 'ACCT' || 'FAIL> could not enable cross-region inference: ' || SQLERRM
        || ' -- nothing was changed. The rest of the workshop still loads, but the '
        || 'Referee agent may not respond until an ACCOUNTADMIN runs: '
        || 'ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = ''ANY_REGION'';';
  END;

  RETURN 'ACCT' || 'CHANGE> CORTEX_ENABLED_CROSS_REGION: '
      || COALESCE(NULLIF(TRIM(:cur), ''), 'DISABLED') || ' -> ANY_REGION, because '
      || 'Cortex orchestration models must be reachable. To restore afterwards: '
      || 'ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = '''
      || COALESCE(NULLIF(TRIM(:cur), ''), 'DISABLED')
      || '''; (accounts with AI_SETTINGS guardrails may refuse to narrow it again.)';
END;
$$;
-- Gen2 (GENERATION = '2') is a hard requirement for this workshop: it is faster
-- on the DML and table-scan work the agents generate, and being explicit keeps
-- the environment identical on every account. Newer orgs default to Gen2, but an
-- older org would silently give you Gen1 if this clause were omitted.
-- NOTE: Gen2 is unavailable in a small number of regions (currently AWS EU
-- Zurich, AWS Africa Cape Town, GCP Dammam, and the Azure US Gov Virginia
-- regions). Deploying there will fail on this statement by design -- drop the
-- GENERATION clause if you must run the workshop in one of them.
CREATE WAREHOUSE IF NOT EXISTS SNOWCUP_WH
  WITH GENERATION = '2'
       WAREHOUSE_SIZE = 'XSMALL'
       AUTO_SUSPEND = 60
       AUTO_RESUME = TRUE
       INITIALLY_SUSPENDED = TRUE
  COMMENT = 'SnowCup workshop warehouse (shared by the data, the grader/Referee, and learners).';

-- CREATE ... IF NOT EXISTS silently skips an existing warehouse, so re-running
-- this script would NOT apply these settings to an environment deployed earlier.
-- Set them explicitly. STATEMENT_TIMEOUT caps a runaway learner query so it
-- cannot hold a concurrency slot for hours in a shared room.
ALTER WAREHOUSE SNOWCUP_WH SET
  GENERATION = '2'
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  STATEMENT_TIMEOUT_IN_SECONDS = 300;

-- Concurrency, not query speed, is the limit in this workshop. Every query here
-- is small (measured: Analyst SQL ~0.6s, grader write ~0.3s, AI_COMPLETE ~4s),
-- but ONE cluster runs only MAX_CONCURRENCY_LEVEL (8) queries at a time. In a
-- guided session everyone reaches the same module together, so work queues --
-- and because a Cortex Agent has a *seconds* budget, a queued query can exhaust
-- it. The learner sees an agent that stalls, not a busy warehouse, and concludes
-- they built it wrong.
--
-- Hence 1-10 clusters on the STANDARD scaling policy: STANDARD starts a cluster
-- as soon as queries queue (ECONOMY makes them wait for sustained load), which
-- is the right trade for a live cohort. Idle clusters cost nothing; a Gen2
-- X-Small is ~1.35 credits/hour per running cluster on AWS.
--
-- Multi-cluster requires Enterprise Edition or higher, so report rather than
-- abort if it is unavailable -- the workshop still runs, just with less headroom.
EXECUTE IMMEDIATE $$
BEGIN
  ALTER WAREHOUSE SNOWCUP_WH SET
    MIN_CLUSTER_COUNT = 1
    MAX_CLUSTER_COUNT = 10
    SCALING_POLICY = 'STANDARD';
  RETURN 'Multi-cluster enabled: 1-10 clusters, STANDARD scaling. Sized for a few hundred concurrent learners.';
EXCEPTION
  WHEN OTHER THEN
    RETURN 'Multi-cluster NOT available on this edition - single X-Small Gen2 retained. '
        || 'Fine for a small group. For a large cohort raise WAREHOUSE_SIZE, give each '
        || 'cohort its own warehouse, or run in waves. See the facilitator guide, "Running at scale".';
END;
$$;

USE WAREHOUSE SNOWCUP_WH;           -- dedicated workshop warehouse — no COMPUTE_WH needed
SET SHARED_DB = 'SNOWCUP_SHARED';   -- shared, read-only data lives here

-- ============================================================================
-- STEP 1: Create the shared database + schema
-- ============================================================================
CREATE DATABASE IF NOT EXISTS IDENTIFIER($SHARED_DB);
USE DATABASE IDENTIFIER($SHARED_DB);
CREATE SCHEMA IF NOT EXISTS TOURNAMENT;
USE SCHEMA TOURNAMENT;

-- ============================================================================
-- STEP 2: Create tables
-- ============================================================================
CREATE OR REPLACE TABLE PLAYERS (
    PLAYER_ID       VARCHAR,
    PLAYER_NAME     VARCHAR,
    NATION          VARCHAR,
    POSITION        VARCHAR,     -- 'Goalkeeper' | 'Defender' | 'Midfielder' | 'Forward'
    CLUB            VARCHAR,
    HEIGHT_CM       NUMBER(38,0),
    PREFERRED_FOOT  VARCHAR      -- 'Left' | 'Right'
    -- NOTE: NICKNAME deliberately lives ONLY on PLAYER_PROFILES, never here.
    -- PLAYERS is the table learners model into their semantic view, so a
    -- nickname column here would let Cortex Analyst answer lore questions by
    -- string match and quietly defeat both the Module 6 "wrong tool" lesson
    -- and challenge Tier 4. Keeping it on the search-indexed profile table
    -- makes Cortex Search genuinely required. Verified empirically: with a
    -- nickname dimension exposed, an Analyst-only agent answered 3 of 4
    -- description-only lore questions correctly.
);

CREATE OR REPLACE TABLE TOURNAMENTS (
    EDITION_YEAR        NUMBER(38,0),
    HOST_NATION         VARCHAR,
    CHAMPION            VARCHAR,
    RUNNER_UP           VARCHAR,
    GOLDEN_BOOT_PLAYER  VARCHAR,   -- label only; the true top scorer is computable from stats
    GOLDEN_GLOVE_PLAYER VARCHAR
);

CREATE OR REPLACE TABLE MATCHES (
    MATCH_ID        VARCHAR,
    EDITION_YEAR    NUMBER(38,0),
    STAGE           VARCHAR,     -- 'Group' | 'Quarter-final' | 'Semi-final' | 'Final'
    HOME_TEAM       VARCHAR,
    AWAY_TEAM       VARCHAR,
    HOME_SCORE      NUMBER(38,0),
    AWAY_SCORE      NUMBER(38,0),
    VENUE           VARCHAR,
    ATTENDANCE      NUMBER(38,0),
    DECIDED_BY      NUMBER(38,0) -- goal margin = ABS(home_score - away_score); set in STEP 5
);

CREATE OR REPLACE TABLE PLAYER_MATCH_STATS (
    PLAYER_ID       VARCHAR,
    MATCH_ID        VARCHAR,
    MINUTES         NUMBER(38,0),
    GOALS           NUMBER(38,0),
    LATE_GOALS      NUMBER(38,0), -- goals scored in the 75th minute or later
    ASSISTS         NUMBER(38,0),
    SHOTS           NUMBER(38,0),
    XG              FLOAT,        -- expected goals
    XA              FLOAT,        -- expected assists
    PASSES          NUMBER(38,0),
    TACKLES         NUMBER(38,0),
    SPRINTS         NUMBER(38,0),
    DISTANCE_KM     FLOAT
);

CREATE OR REPLACE TABLE DISCIPLINE (
    PLAYER_ID       VARCHAR,
    MATCH_ID        VARCHAR,
    YELLOW_CARDS    NUMBER(38,0),
    RED_CARDS       NUMBER(38,0),
    FOULS           NUMBER(38,0)
);

CREATE OR REPLACE TABLE PLAYER_PROFILES (
    PLAYER_ID       VARCHAR,
    PLAYER_NAME     VARCHAR,
    NATION          VARCHAR,
    POSITION        VARCHAR,
    NICKNAME        VARCHAR,
    BIO             VARCHAR
);

-- ============================================================================
-- STEP 3: PLAYERS via the _ROSTER_LOAD staging table
--         (48 players — 8 competing nations x 5, + 8 depth players)
-- ============================================================================
-- Competing nations (appear in MATCHES): Powdermark, Flurria, Glacia, Cornice,
-- Rimeland, Cirrus, Snowholt, Driftland.
-- The roster is loaded into a short-lived staging table so that NICKNAME can be
-- routed to PLAYER_PROFILES (search's territory) and kept OUT of PLAYERS (the
-- table learners model). _ROSTER_LOAD is dropped at the end of STEP 9.
CREATE OR REPLACE TABLE _ROSTER_LOAD (
    PLAYER_ID       VARCHAR,
    PLAYER_NAME     VARCHAR,
    NATION          VARCHAR,
    POSITION        VARCHAR,
    CLUB            VARCHAR,
    HEIGHT_CM       NUMBER(38,0),
    PREFERRED_FOOT  VARCHAR,
    NICKNAME        VARCHAR
);

INSERT INTO _ROSTER_LOAD
  (PLAYER_ID, PLAYER_NAME, NATION, POSITION, CLUB, HEIGHT_CM, PREFERRED_FOOT, NICKNAME) VALUES
-- Driftland
('P01','Aldo Drifden',    'Driftland','Goalkeeper','Driftland City FC',191,'Right',NULL),
('P02','Marco Whitlock',  'Driftland','Defender',  'Driftland City FC',185,'Right',NULL),
('P03','Enzo Snowdon',    'Driftland','Defender',  'Port Glace',  183,'Left', NULL),
('P04','Luca Frostwick',   'Driftland','Midfielder','Driftland City FC',178,'Right',NULL),
('P05','Rico Glaze',   'Driftland','Forward',   'Driftland City FC',180,'Left', 'The Blizzard'),
-- Cirrus
('P06','Sten Cirrane',   'Cirrus','Goalkeeper','Cirrus United', 193,'Right',NULL),
('P07','Ivar Nimbus',      'Cirrus','Defender',  'Cirrus United', 187,'Right',NULL),
('P08','Bjorn Icefell',      'Cirrus','Defender',  'Nordfrost BK',   186,'Left', NULL),
('P09','Kai Winterholm',  'Cirrus','Midfielder','Cirrus United', 181,'Right',NULL),
('P10','Nils Vane',     'Cirrus','Forward',   'Cirrus United', 184,'Right','The Snowplow'),
-- Flurria
('P11','Gormar Hailstone',   'Flurria','Goalkeeper','Flurria FC',   194,'Right',NULL),
('P12','Roderik Rime',  'Flurria','Defender',  'Flurria FC',   188,'Right',NULL),
('P13','Halvor Grimsleet',   'Flurria','Defender',  'Rime Valley',    185,'Left', NULL),
('P14','Sorin Squall','Flurria','Midfielder','Flurria FC',   179,'Right',NULL),
('P15','Dain Thaw',    'Flurria','Forward',   'Flurria FC',   182,'Right','The Avalanche'),
-- Powdermark
('P16','Nevin Coldiron',    'Powdermark','Goalkeeper','Powdermark SK',   192,'Right',NULL),
('P17','Tomas Icewright',    'Powdermark','Defender',  'Powdermark SK',   186,'Right','The Snowsmith'),
('P18','Anders Snowfell',   'Powdermark','Defender',  'Frostgard IF',  184,'Left', NULL),
('P19','Petar Vossberg',     'Powdermark','Midfielder','Powdermark SK',   180,'Right',NULL),
('P20','Emil Sleet',     'Powdermark','Forward',   'Powdermark SK',   183,'Left', NULL),
-- Glacia
('P21','Paolo Glacio',    'Glacia','Goalkeeper','Glacia FC',     190,'Right',NULL),
('P22','Gino Icebourne',     'Glacia','Defender',  'Glacia FC',     184,'Right',NULL),
('P23','Marco Fennmoor',     'Glacia','Defender',  'Monteneve',     186,'Right',NULL),
('P24','Milo Chill',   'Glacia','Midfielder','Glacia FC',     176,'Left', 'The Late Frost'),
('P25','Dario Snowbelle',    'Glacia','Forward',   'Glacia FC',     181,'Right',NULL),
-- Cornice
('P26','Kova Icevault',   'Cornice','Goalkeeper','Cornice FC',   195,'Right','The Deep Freeze'),
('P27','Rurik Cornstone',     'Cornice','Defender',  'Cornice FC',   188,'Right',NULL),
('P28','Torvald Snowkane',   'Cornice','Defender',  'Icicle Town',    189,'Left', NULL),
('P29','Sigurd Snowvale',     'Cornice','Midfielder','Cornice FC',   182,'Right',NULL),
('P30','Alrik Snowstone',    'Cornice','Forward',   'Cornice FC',   183,'Right',NULL),
-- Snowholt
('P31','Lucian Marrfell',    'Snowholt','Goalkeeper','Snowholt CF',     191,'Right',NULL),
('P32','Viktor Icesen',    'Snowholt','Defender',  'Snowholt CF',     185,'Right',NULL),
('P33','Adrian Coldwell',    'Snowholt','Defender',  'Snowport',        184,'Left', NULL),
('P34','Felix Aranvale',     'Snowholt','Midfielder','Snowholt CF',     179,'Right',NULL),
('P35','Silas Flake',     'Snowholt','Forward',   'Snowholt CF',     178,'Right','The Whiteout'),
-- Rimeland
('P36','Dmitri Solrime',     'Rimeland','Goalkeeper','Rimeland FK',   192,'Right',NULL),
('P37','Bruno Kaltov',   'Rimeland','Defender',  'Rimeland FK',   187,'Right','The Iceman'),
('P38','Yuri Permafrost',    'Rimeland','Defender',  'Frostport',      185,'Left', NULL),
('P39','Andrei Lekvind',     'Rimeland','Midfielder','Rimeland FK',   180,'Right',NULL),
('P40','Stefan Icezar',    'Rimeland','Forward',   'Rimeland FK',   182,'Left', NULL),
-- Depth nations (in the player pool, did not qualify — no match stats)
('P41','Owen Hail',      'Sleetmoor', 'Forward',   'Sleetmoor FC',    181,'Right','The Hailstorm'),
('P42','Mateo Verglas',     'Frostmere','Midfielder','Frostmere CD',   178,'Left', NULL),
('P43','Kenji Yuki',     'Hailden', 'Forward',   'Hailden SC',    176,'Right','The Snow Fox'),
('P44','Hans Firnbach',  'Icemark','Defender',  'Icemark 04',   188,'Right',NULL),
('P45','Theo Icemarsh',     'Whitecap', 'Goalkeeper','Whitecap Bay',   190,'Right',NULL),
('P46','Wei Xue',       'Crystalia','Midfielder','Crystalia FC',   177,'Right',NULL),
('P47','Sami Lumi',      'Shimmerfell', 'Forward',   'Shimmerfell IF',    179,'Left', NULL),
('P48','Pieter Vestergaard','Tundrel', 'Defender',  'Tundrel United',186,'Right','The Snowbank');

-- Project the roster into PLAYERS without NICKNAME.
INSERT INTO PLAYERS
  (PLAYER_ID, PLAYER_NAME, NATION, POSITION, CLUB, HEIGHT_CM, PREFERRED_FOOT)
SELECT PLAYER_ID, PLAYER_NAME, NATION, POSITION, CLUB, HEIGHT_CM, PREFERRED_FOOT
  FROM _ROSTER_LOAD;

-- ============================================================================
-- STEP 4: TOURNAMENTS  (3 editions)
-- ============================================================================
-- Titles: Driftland 2018 + 2022, Cirrus 2026  => Driftland has the most (2).  [Q2]
INSERT INTO TOURNAMENTS
  (EDITION_YEAR, HOST_NATION, CHAMPION, RUNNER_UP, GOLDEN_BOOT_PLAYER, GOLDEN_GLOVE_PLAYER) VALUES
(2018,'Cirrus', 'Driftland','Cirrus', 'Dain Thaw', 'Nevin Coldiron'),
(2022,'Flurria','Driftland','Powdermark','Dain Thaw', 'Kova Icevault'),
(2026,'Snowholt', 'Cirrus','Driftland', 'Rico Glaze','Kova Icevault');

-- ============================================================================
-- STEP 5: MATCHES  (33 = 11 per edition)  Stages: Group, QF, SF, Final
-- ============================================================================
INSERT INTO MATCHES
  (MATCH_ID, EDITION_YEAR, STAGE, HOME_TEAM, AWAY_TEAM, HOME_SCORE, AWAY_SCORE, VENUE, ATTENDANCE) VALUES
-- 2018 (host Cirrus) — champion Driftland, runner-up Cirrus
('M2018-01',2018,'Group',        'Driftland','Snowholt', 2,1,'Cirrus Arena',    58000),
('M2018-02',2018,'Group',        'Cornice','Rimeland',3,0,'Nordfrost Stadium',52000),
('M2018-03',2018,'Group',        'Cirrus','Glacia',  1,0,'Cirrus Arena',    61000),
('M2018-04',2018,'Group',        'Flurria','Powdermark',4,3,'Rimefield Park',    47000),
('M2018-05',2018,'Quarter-final','Driftland','Rimeland', 2,1,'Cirrus Arena',    60000),
('M2018-06',2018,'Quarter-final','Cornice','Powdermark',2,0,'Nordfrost Stadium',53000),
('M2018-07',2018,'Quarter-final','Cirrus','Flurria', 3,2,'Cirrus Arena',    62000),
('M2018-08',2018,'Quarter-final','Glacia','Snowholt',  2,1,'Frostharbour Ground',    45000),
('M2018-09',2018,'Semi-final',   'Driftland','Cornice', 1,0,'Cirrus Arena',    63000),
('M2018-10',2018,'Semi-final',   'Cirrus','Glacia',  2,1,'Cirrus Arena',    64000),
('M2018-11',2018,'Final',        'Driftland','Cirrus',  2,1,'Cirrus Arena',    68000),
-- 2022 (host Flurria) — champion Driftland, runner-up Powdermark
('M2022-01',2022,'Group',        'Cornice','Snowholt', 2,0,'Rimefield Park',    49000),
('M2022-02',2022,'Group',        'Driftland','Glacia',  3,1,'Rimefield Park',    50000),
('M2022-03',2022,'Group',        'Powdermark','Rimeland',1,0,'Frostgard Dome',   44000),
('M2022-04',2022,'Group',        'Flurria','Cirrus', 3,2,'Glacier Stadium',  55000),
('M2022-05',2022,'Quarter-final','Cornice','Cirrus', 1,0,'Rimefield Park',    51000),
('M2022-06',2022,'Quarter-final','Driftland','Flurria', 3,2,'Rimefield Park',    52000),
('M2022-07',2022,'Quarter-final','Powdermark','Snowholt', 2,1,'Frostgard Dome',   46000),
('M2022-08',2022,'Quarter-final','Glacia','Rimeland', 3,2,'Glacier Stadium',  47000),
('M2022-09',2022,'Semi-final',   'Driftland','Glacia',  2,1,'Glacier Stadium',  57000),
('M2022-10',2022,'Semi-final',   'Powdermark','Cornice',1,0,'Glacier Stadium',  56000),
('M2022-11',2022,'Final',        'Driftland','Powdermark', 2,1,'Glacier Stadium',  60000),
-- 2026 (host Snowholt) — champion Cirrus, runner-up Driftland
('M2026-01',2026,'Group',        'Driftland','Rimeland', 3,0,'Snowholt Grand',    59000),
('M2026-02',2026,'Group',        'Cirrus','Snowholt',  2,1,'Snowholt Grand',    60000),
('M2026-03',2026,'Group',        'Cornice','Flurria',2,0,'Snowport Field',    48000),
('M2026-04',2026,'Group',        'Glacia','Powdermark', 2,2,'Snowport Field',    45000),
('M2026-05',2026,'Quarter-final','Driftland','Powdermark', 3,2,'Snowholt Grand',    61000),
('M2026-06',2026,'Quarter-final','Cirrus','Flurria', 1,0,'Snowholt Grand',    62000),
('M2026-07',2026,'Quarter-final','Cornice','Glacia', 1,0,'Snowport Field',    49000),
('M2026-08',2026,'Quarter-final','Rimeland','Snowholt', 3,2,'Snowholt Grand',    58000),
('M2026-09',2026,'Semi-final',   'Driftland','Cornice', 2,1,'Snowholt Grand',    63000),
('M2026-10',2026,'Semi-final',   'Cirrus','Rimeland', 1,0,'Snowholt Grand',    64000),
('M2026-11',2026,'Final',        'Cirrus','Driftland',  2,1,'Snowholt Grand',    69000);

UPDATE MATCHES SET DECIDED_BY = ABS(HOME_SCORE - AWAY_SCORE);

-- ============================================================================
-- STEP 6: STAR PLAYER STATS  (hand-authored signature performances)
-- ============================================================================
-- These players are excluded from the generated filler in STEP 7 and given
-- explicit, hand-authored rows here. Columns: PLAYER_ID, MATCH_ID, MINUTES,
-- GOALS, LATE_GOALS, ASSISTS, SHOTS, XG, XA, PASSES, TACKLES, SPRINTS, DISTANCE_KM

-- Rico Glaze (P05, Driftland FWD) — Driftland's talismanic striker.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P05','M2018-01',90,1,0,0,4,0.7,0.1,28,1,24,10.4),
('P05','M2018-05',90,1,0,1,5,0.7,0.4,30,0,26,10.8),
('P05','M2018-09',90,1,0,0,3,0.7,0.1,27,1,25,10.1),
('P05','M2018-11',90,1,0,1,5,0.7,0.3,29,0,27,10.6),
('P05','M2022-02',90,1,0,0,4,0.7,0.1,31,1,24,10.2),
('P05','M2022-06',90,1,0,1,5,0.7,0.3,28,0,26,10.7),
('P05','M2022-09',90,1,0,0,4,0.7,0.1,30,1,25,10.3),
('P05','M2022-11',90,1,0,0,5,0.7,0.2,29,0,27,10.5),
('P05','M2026-01',90,3,0,0,7,1.8,0.2,26,0,28,11.0),
('P05','M2026-05',90,2,0,1,6,1.4,0.4,27,0,27,10.9),
('P05','M2026-09',90,2,0,0,5,1.3,0.1,25,1,26,10.6),
('P05','M2026-11',90,2,0,0,6,1.4,0.2,28,0,29,11.2);

-- Nils Vane (P10, Cirrus FWD) — Cirrus's forward.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P10','M2018-03',90,1,0,0,3,0.6,0.1,22,0,23,10.0),
('P10','M2018-11',90,1,0,0,4,0.6,0.1,24,0,24,10.2),
('P10','M2022-04',90,2,0,0,5,1.0,0.1,23,0,25,10.3),
('P10','M2026-02',90,1,0,0,3,0.7,0.1,22,0,24,10.1),
('P10','M2026-06',90,1,0,1,4,0.6,0.3,25,0,26,10.5),
('P10','M2026-10',90,1,0,0,3,0.5,0.1,24,0,25,10.3),
('P10','M2026-11',90,1,0,0,4,1.0,0.1,26,0,27,10.6);

-- Dain Thaw (P15, Flurria FWD) — Flurria's forward.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P15','M2018-04',90,3,0,0,6,0.3,0.1,20,0,29,11.4),
('P15','M2018-07',90,2,0,0,5,0.2,0.1,21,0,28,11.1),
('P15','M2022-04',90,2,0,0,5,0.2,0.1,22,0,29,11.3),
('P15','M2022-06',90,2,0,0,5,0.3,0.1,20,0,28,11.0),
('P15','M2026-03',90,0,0,0,3,0.0,0.1,19,0,27,10.8),
('P15','M2026-06',90,0,0,0,2,0.0,0.1,18,0,26,10.5);

-- Tomas Icewright (P17, Powdermark DEF) — a playmaking defender who never shoots.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P17','M2018-04',90,0,0,1,0,0.0,0.6,55,4,22,10.7),
('P17','M2018-06',90,0,0,0,0,0.0,0.1,52,5,21,10.5),
('P17','M2022-03',90,0,0,1,0,0.0,0.5,58,3,22,10.8),
('P17','M2022-07',90,0,0,2,0,0.0,1.1,60,4,23,11.0),
('P17','M2022-10',90,0,0,1,0,0.0,0.6,57,5,22,10.6),
('P17','M2022-11',90,0,0,0,0,0.0,0.2,59,4,23,10.9),
('P17','M2026-04',90,0,0,1,0,0.0,0.5,54,3,21,10.4),
('P17','M2026-05',90,0,0,2,0,0.0,1.0,56,4,22,10.7);

-- Emil Sleet (P20, Powdermark FWD) — Powdermark's forward.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P20','M2018-04',90,2,0,0,5,1.5,0.1,23,0,26,10.6),
('P20','M2022-07',90,2,0,0,5,1.5,0.1,24,0,27,10.8),
('P20','M2022-11',90,1,0,0,4,1.0,0.1,22,0,25,10.4),
('P20','M2026-05',90,1,0,0,4,1.0,0.1,23,0,26,10.5);

-- Milo Chill (P24, Glacia MID) — Glacia's midfielder.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P24','M2018-03',90,0,0,0,2,0.6,0.2,44,2,27,11.3),
('P24','M2018-08',90,1,1,0,3,0.7,0.1,46,2,28,11.5),
('P24','M2018-10',90,1,1,0,3,0.7,0.1,45,3,27,11.4),
('P24','M2022-02',90,1,0,0,3,0.7,0.1,47,2,28,11.6),
('P24','M2022-08',90,2,2,0,4,0.9,0.1,48,2,29,11.8),
('P24','M2022-09',90,1,1,0,3,0.7,0.1,46,3,28,11.5),
('P24','M2026-04',90,1,0,0,3,0.7,0.1,45,2,27,11.3),
('P24','M2026-07',90,0,0,0,2,0.0,0.1,44,3,27,11.2);

-- Kova Icevault (P26, Cornice GK) — Cornice's goalkeeper; plays every Cornice match.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P26','M2018-02',90,0,0,0,0,0.0,0.0,18,0,8,5.2),
('P26','M2018-06',90,0,0,0,0,0.0,0.0,17,0,8,5.1),
('P26','M2018-09',90,0,0,0,0,0.0,0.0,19,0,9,5.3),
('P26','M2022-01',90,0,0,0,0,0.0,0.0,18,0,8,5.2),
('P26','M2022-05',90,0,0,0,0,0.0,0.0,17,0,8,5.0),
('P26','M2022-10',90,0,0,0,0,0.0,0.0,19,0,9,5.4),
('P26','M2026-03',90,0,0,0,0,0.0,0.0,18,0,8,5.2),
('P26','M2026-07',90,0,0,0,0,0.0,0.0,17,0,8,5.1),
('P26','M2026-09',90,0,0,0,0,0.0,0.0,20,0,9,5.5);

-- Silas Flake (P35, Snowholt FWD) — a low-mileage poacher (very few sprints).
INSERT INTO PLAYER_MATCH_STATS VALUES
('P35','M2018-01',90,1,0,0,3,1.0,0.1,12,0,2,7.1),
('P35','M2018-08',90,1,0,0,3,1.0,0.1,11,0,1,6.9),
('P35','M2022-01',90,1,0,0,2,1.0,0.1,13,0,2,7.2),
('P35','M2022-07',90,1,0,0,3,1.0,0.1,12,0,1,7.0),
('P35','M2026-02',90,2,0,0,4,2.0,0.1,11,0,2,7.1),
('P35','M2026-08',90,1,0,0,3,1.0,0.1,12,0,1,6.8);

-- Bruno Kaltov (P37, Rimeland DEF) — a hard-tackling defender.
INSERT INTO PLAYER_MATCH_STATS VALUES
('P37','M2018-02',90,0,0,0,1,0.1,0.1,40,6,20,10.9),
('P37','M2018-05',90,0,0,0,1,0.1,0.1,38,5,19,10.6),
('P37','M2022-03',90,0,0,0,1,0.1,0.1,41,6,20,11.0),
('P37','M2022-08',90,0,0,0,2,0.2,0.1,39,5,19,10.7),
('P37','M2026-01',90,0,0,0,1,0.1,0.1,40,6,20,10.8),
('P37','M2026-08',90,0,0,0,2,0.2,0.1,38,5,19,10.5),
('P37','M2026-10',90,0,0,0,1,0.1,0.1,41,6,20,11.0);

-- ============================================================================
-- STEP 7: GENERATED FILLER STATS  (deterministic — HASH(), never RANDOM())
-- ============================================================================
-- Every non-star player of the two competing nations in a match gets one row.
-- Values are a pure function of (player_id, match_id) via HASH(), so the dataset
-- is byte-identical for every learner who runs it. The bounds keep the generated
-- filler realistic and reproducible: goals in {0,1}; knockout shots >= 1;
-- late_goals = 0; xg = goals.
INSERT INTO PLAYER_MATCH_STATS
  (PLAYER_ID, MATCH_ID, MINUTES, GOALS, LATE_GOALS, ASSISTS, SHOTS, XG, XA, PASSES, TACKLES, SPRINTS, DISTANCE_KM)
WITH parts AS (
  SELECT
    p.PLAYER_ID, p.POSITION, m.MATCH_ID, m.STAGE,
    ABS(HASH(p.PLAYER_ID || '|' || m.MATCH_ID)) AS H
  FROM MATCHES m
  JOIN PLAYERS p
    ON (p.NATION = m.HOME_TEAM OR p.NATION = m.AWAY_TEAM)
  WHERE p.PLAYER_ID NOT IN ('P05','P10','P15','P17','P20','P24','P26','P35','P37')
),
calc AS (
  SELECT
    PLAYER_ID, MATCH_ID, POSITION, STAGE, H,
    IFF(POSITION IN ('Forward','Midfielder') AND MOD(H,4)=0, 1, 0) AS G,
    IFF(STAGE <> 'Group', 1 + MOD(H,4), MOD(H,3))                  AS S
  FROM parts
)
SELECT
  PLAYER_ID,
  MATCH_ID,
  IFF(POSITION='Goalkeeper', 90, 62 + MOD(H,29))          AS MINUTES,
  G                                                        AS GOALS,
  0                                                        AS LATE_GOALS,
  IFF(POSITION<>'Goalkeeper' AND MOD(H,5)=0, 1, 0)         AS ASSISTS,
  IFF(POSITION='Goalkeeper', 0, S)                         AS SHOTS,
  IFF(POSITION='Goalkeeper', 0.0, CAST(G AS FLOAT))        AS XG,
  ROUND(0.10 * IFF(POSITION<>'Goalkeeper' AND MOD(H,5)=0,1,0), 2) AS XA,
  IFF(POSITION='Goalkeeper', 15 + MOD(H,10), 25 + MOD(H,45)) AS PASSES,
  IFF(POSITION='Goalkeeper', 0, MOD(H,6))                  AS TACKLES,
  IFF(POSITION='Goalkeeper', 6 + MOD(H,5), 18 + MOD(H,22)) AS SPRINTS,
  ROUND(IFF(POSITION='Goalkeeper', 4.5 + MOD(H,10)/10.0, 9.5 + MOD(H,35)/10.0), 1) AS DISTANCE_KM
FROM calc;

-- ============================================================================
-- STEP 8: DISCIPLINE  (one hand-authored high-discipline player; the rest generated + bounded)
-- ============================================================================
-- Bruno Kaltov's hand-authored discipline record.
INSERT INTO DISCIPLINE VALUES
('P37','M2018-02',1,0,5),
('P37','M2018-05',1,0,4),
('P37','M2022-03',1,0,5),
('P37','M2022-08',1,1,6),
('P37','M2026-01',1,0,4),
('P37','M2026-08',0,0,5),
('P37','M2026-10',1,0,4);

-- Everyone else: bounded low discipline (generated).
INSERT INTO DISCIPLINE (PLAYER_ID, MATCH_ID, YELLOW_CARDS, RED_CARDS, FOULS)
WITH parts AS (
  SELECT p.PLAYER_ID, m.MATCH_ID,
    ABS(HASH('D' || p.PLAYER_ID || '|' || m.MATCH_ID)) AS H
  FROM MATCHES m
  JOIN PLAYERS p
    ON (p.NATION = m.HOME_TEAM OR p.NATION = m.AWAY_TEAM)
  WHERE p.PLAYER_ID <> 'P37'
)
SELECT
  PLAYER_ID, MATCH_ID,
  IFF(MOD(H,5)=0, 1, 0)  AS YELLOW_CARDS,   -- at most 1 per match, ~1 in 5 matches
  0                      AS RED_CARDS,       -- no filler reds
  MOD(H,3)               AS FOULS            -- 0..2 per match
FROM parts;

-- ============================================================================
-- STEP 9: PLAYER_PROFILES  (bios + seeded lore — indexed by Cortex Search)
-- ============================================================================
INSERT INTO PLAYER_PROFILES (PLAYER_ID, PLAYER_NAME, NATION, POSITION, NICKNAME, BIO)
SELECT
  p.PLAYER_ID, p.PLAYER_NAME, p.NATION, p.POSITION, p.NICKNAME,
  CASE p.PLAYER_ID
    WHEN 'P35' THEN 'Silas Flake, the Snowholt forward known across the SnowCup as "The Whiteout". '
      || 'He barely runs — one of the lowest sprint counts of any outfield player — yet materialises '
      || 'in the six-yard box at the decisive moment to finish. Defenders say they never see him coming; '
      || 'by the time they turn, the ball is in the net and Flake has disappeared into the white again. A silent, minimal-movement poacher.'
    WHEN 'P37' THEN 'Bruno Kaltov, the Rimeland defender they call "The Iceman". '
      || 'A bruising stopper who treats every attacker as a personal affront. Referees know his name. '
      || 'A villain to opposing fans, a wall to his own.'
    WHEN 'P05' THEN 'Rico Glaze, "The Blizzard", the talismanic Driftland forward. '
      || 'Left-footed, ice-cold in front of goal, and the engine behind Driftland''s golden era.'
    WHEN 'P15' THEN 'Dain Thaw, "The Avalanche" of Flurria. A forward who buries defences under more goals than his chances '
      || 'suggest. Flurria lives and dies by his avalanches.'
    WHEN 'P17' THEN 'Tomas Icewright, "The Snowsmith" of Powdermark''s back line. A defender who never shoots — he builds. '
      || 'His killer passes turn defence into goals in the knockout rounds, all without a single shot to his name.'
    WHEN 'P24' THEN 'Milo Chill, "The Late Frost" of Glacia. A midfielder with a habit of scoring late — the sort who is '
      || 'still dangerous in the closing minutes when a knockout tie is finely balanced.'
    WHEN 'P26' THEN 'Kova Icevault, "The Deep Freeze" — Cornice''s goalkeeper. '
      || 'Nations simply do not score on him; shut-outs follow him from group stage to final.'
    WHEN 'P10' THEN 'Nils Vane, "The Snowplow" of Cirrus. A powerful, clinical forward and a mainstay of Cirrus''s 2026 title run.'
    WHEN 'P20' THEN 'Emil Sleet, Powdermark''s reliable forward — a steady source of goals through three SnowCup editions.'
    -- The three nicknamed depth-nation players. Their nations never qualified, so
    -- they carry no match stats: search can find them, Analyst has nothing to
    -- compute. That contrast is a useful teaching moment, so say it out loud here.
    WHEN 'P41' THEN 'Owen Hail, "The Hailstorm" of Sleetmoor — a forward with a fearsome strike. '
      || 'Sleetmoor have never qualified for a SnowCup, so his reputation is built entirely on club football.'
    WHEN 'P43' THEN 'Kenji Yuki, "The Snow Fox" of Hailden — a quick, cunning forward who finds space nobody else sees. '
      || 'Hailden are still waiting for their first SnowCup appearance.'
    WHEN 'P48' THEN 'Pieter Vestergaard, "The Snowbank" of Tundrel — an immovable defender attackers simply bounce off. '
      || 'Tundrel have yet to reach a SnowCup finals.'
    ELSE p.PLAYER_NAME || ' is a ' || LOWER(p.POSITION) || ' for ' || p.NATION
      || COALESCE(', nicknamed "' || p.NICKNAME || '"', '')
      || '. A dependable squad member across the SnowCup.'
  END AS BIO
FROM _ROSTER_LOAD p;

-- Staging table has served its purpose; NICKNAME now lives only on
-- PLAYER_PROFILES, which is what Cortex Search indexes.
DROP TABLE IF EXISTS _ROSTER_LOAD;

-- ============================================================================
-- STEP 10: Make the data read-only to learners + provision build schemas
-- ============================================================================
-- The SNOWCUP_PARTICIPANT role is also created by snowcup-grader-setup.sql;
-- create it here too so the two scripts can run in either order.
CREATE ROLE IF NOT EXISTS SNOWCUP_PARTICIPANT;

-- ---------------------------------------------------------------------------
-- SNOWCUP_FACILITATOR: lets a co-facilitator run the SnowCup Admin app (the
-- learner roster) WITHOUT holding ACCOUNTADMIN.
--
-- The admin app does its privileged work (CREATE ROLE / GRANT, which
-- Snowflake's restricted caller's rights forbids) with the app OWNER's rights,
-- and authorises the operator in application code. So membership of this role
-- IS the permission -- grant it narrowly, and never grant the app to PUBLIC.
--
-- The app checks roles the person HOLDS (CURRENT_AVAILABLE_ROLES), not just
-- their active role. That is deliberate: a session opens with the user's
-- DEFAULT role, and restricted caller's rights forbids USE ROLE, so a
-- role-based check would lock out real facilitators who would then have no way
-- to fix it from inside the app. Consequence: facilitators do NOT need to
-- switch roles before opening the app.
--
-- This role is also granted oversight privileges further down (it inherits
-- SNOWCUP_PARTICIPANT and every SNOWCUP_WS_ role, so a facilitator can reach
-- every build schema). It still cannot reach the answer key in
-- SNOWCUP_WORKSHOP.GRADING.
--
-- After deploying the app (see snowcup-admin-node/), finish the wiring:
--   GRANT USAGE, MONITOR ON APPLICATION SERVICE
--     SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP TO ROLE SNOWCUP_FACILITATOR;
--   GRANT USAGE ON WAREHOUSE SNOWFLAKE_APPS_QUERY_WH TO ROLE SNOWCUP_FACILITATOR;
--   GRANT ROLE SNOWCUP_FACILITATOR TO USER <person>;
-- ---------------------------------------------------------------------------
CREATE ROLE IF NOT EXISTS SNOWCUP_FACILITATOR
  COMMENT = 'Opens the SnowCup Admin app to run the learner roster without ACCOUNTADMIN. Membership is the permission - the app checks for this role before provisioning.';

-- Cortex privileges: learners use Cortex Analyst, Cortex Search, agents, and
-- AI_COMPLETE (the scouting skill). All of these require the SNOWFLAKE.CORTEX_USER
-- database role. Without this grant, Cortex features fail for the participant role.
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE SNOWCUP_PARTICIPANT;

-- Read-only access to the shared data (learners SELECT it; they never write it).
GRANT USAGE  ON DATABASE IDENTIFIER($SHARED_DB)                 TO ROLE SNOWCUP_PARTICIPANT;
GRANT USAGE  ON SCHEMA   SNOWCUP_SHARED.TOURNAMENT             TO ROLE SNOWCUP_PARTICIPANT;
GRANT SELECT ON ALL TABLES    IN SCHEMA SNOWCUP_SHARED.TOURNAMENT TO ROLE SNOWCUP_PARTICIPANT;
GRANT SELECT ON FUTURE TABLES IN SCHEMA SNOWCUP_SHARED.TOURNAMENT TO ROLE SNOWCUP_PARTICIPANT;
-- (If you renamed SHARED_DB above, change SNOWCUP_SHARED here to match.)

-- Enable change tracking on PLAYER_PROFILES so learners can build a Cortex Search
-- service over the bios. The service is backed by a dynamic table and needs change
-- tracking on its source; a learner's read-only role can't auto-enable it (that needs
-- MODIFY on the base table), so the owner enables it here once.
ALTER TABLE SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES SET CHANGE_TRACKING = TRUE;

-- Per-learner build space: one schema each, where a learner creates their own
-- semantic view, Cortex Search service, and agent over the shared data.
CREATE DATABASE IF NOT EXISTS SNOWCUP_BUILDS;
GRANT USAGE ON DATABASE SNOWCUP_BUILDS TO ROLE SNOWCUP_PARTICIPANT;

-- Learners run their semantic view / search / agent / skill on this warehouse.
GRANT USAGE ON WAREHOUSE SNOWCUP_WH TO ROLE SNOWCUP_PARTICIPANT;

-- ----------------------------------------------------------------------------
-- Role model: shared access is ONE role, build space is a role PER LEARNER.
-- ----------------------------------------------------------------------------
--   SNOWCUP_PARTICIPANT      shared, read-only: the tournament tables, the
--                            Referee agent, the grading procedures, the score
--                            views, the warehouse and Cortex. Deliberately has
--                            NO privileges on any WS_ build schema.
--   SNOWCUP_WS_<NAME>        one per learner. Build rights on that learner's own
--                            schema only, and SNOWCUP_PARTICIPANT nested inside
--                            it so a single DEFAULT_ROLE covers everything.
--                            Objects a learner creates are owned by this role,
--                            which is what keeps one learner's work private.
--   SNOWCUP_FACILITATOR      oversight. Every SNOWCUP_WS_ role is granted to it,
--                            so a facilitator can reach every build schema.
--
-- A granted role confers exactly its own privileges, so nesting
-- SNOWCUP_PARTICIPANT cannot expose anything it does not already hold - the
-- answer key in SNOWCUP_WORKSHOP.GRADING stays unreachable either way.
-- ----------------------------------------------------------------------------
-- Created above with its COMMENT; these are its oversight grants.
GRANT ROLE  SNOWCUP_PARTICIPANT      TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON DATABASE SNOWCUP_BUILDS TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON WAREHOUSE SNOWCUP_WH    TO ROLE SNOWCUP_FACILITATOR;
GRANT ROLE  SNOWCUP_FACILITATOR      TO ROLE ACCOUNTADMIN;

-- Admin home for the provisioning procedures called by the SnowCup Admin app.
-- SNOWCUP_WORKSHOP is also created by snowcup-grader-setup.sql; IF NOT EXISTS
-- here keeps the two scripts runnable in either order (same defensive pattern
-- already used for SNOWCUP_WH). Learners never get USAGE on this schema.
CREATE DATABASE IF NOT EXISTS SNOWCUP_WORKSHOP;
CREATE SCHEMA   IF NOT EXISTS SNOWCUP_WORKSHOP.ADMIN;
CREATE STAGE    IF NOT EXISTS SNOWCUP_WORKSHOP.ADMIN.APP_STAGE
  DIRECTORY = (ENABLE = TRUE)
  COMMENT = 'Admin schema for the SnowCup provisioning procedures.';

-- >>> PROVISION_LEARNER: sets up ONE learner completely.
--     Derives a valid build schema SNOWCUP_BUILDS.WS_<NAME> from the username
--     (email-style names like jdoe@acme.com become WS_JDOE), creates the matching
--     SNOWCUP_WS_<NAME> role, grants build rights on that schema ONLY, nests
--     SNOWCUP_PARTICIPANT inside it, attaches the role to SNOWCUP_FACILITATOR,
--     and grants it to the user.
--     Idempotent. Runs as the caller, so it does exactly what the person running
--     it is allowed to do.
--
--     NON-DESTRUCTIVE about user settings: it sets DEFAULT_ROLE and
--     DEFAULT_WAREHOUSE only when the user has none (NULL, empty or PUBLIC). An
--     existing default is REPORTED and left alone -- the same user may do real work
--     in this account, and replacing their default would discard a value we have no
--     record of. When it is left alone the output tells you to have them run
--     USE ROLE SNOWCUP_WS_<NAME>. Your own defaults are never touched, so a smoke
--     test cannot hijack the admin's session.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(NAME VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  uname  VARCHAR DEFAULT TRIM(NAME);
  suffix VARCHAR;
  schema VARCHAR;
  wsrole VARCHAR;
  repair VARCHAR DEFAULT '';
  extra  VARCHAR DEFAULT '';
  cur_role VARCHAR DEFAULT NULL;
  known  BOOLEAN DEFAULT FALSE;
  guser  VARCHAR DEFAULT NULL;
  ambig  NUMBER  DEFAULT 0;
  warn   VARCHAR DEFAULT '';
  tag    VARCHAR DEFAULT 'OK       ';
BEGIN
  IF (uname IS NULL OR uname = '') THEN
    RETURN 'SKIPPED  (empty name)';
  END IF;
  -- Take the local part of an email-style username and collapse any run of
  -- non-alphanumerics to a single underscore (jdoe@acme.com -> JDOE).
  suffix := TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(uname, '@', 1)), '[^A-Z0-9]+', '_'), '_');
  IF (suffix = '') THEN
    RETURN 'SKIPPED  ' || :uname || ' (could not derive a schema name)';
  END IF;

  schema := 'SNOWCUP_BUILDS.WS_' || suffix;
  wsrole := 'SNOWCUP_WS_' || suffix;   -- prefix is hard-coded on purpose

  EXECUTE IMMEDIATE 'CREATE SCHEMA IF NOT EXISTS ' || :schema;
  EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS ' || :wsrole;

  -- Build rights on this learner's schema only.
  EXECUTE IMMEDIATE 'GRANT USAGE, CREATE TABLE, CREATE VIEW, CREATE SEMANTIC VIEW, '
    || 'CREATE CORTEX SEARCH SERVICE, CREATE AGENT, CREATE PROCEDURE, CREATE FUNCTION '
    || 'ON SCHEMA ' || :schema || ' TO ROLE ' || :wsrole;

  -- Shared access, inherited: one DEFAULT_ROLE then covers the whole lab.
  EXECUTE IMMEDIATE 'GRANT ROLE SNOWCUP_PARTICIPANT TO ROLE ' || :wsrole;
  -- Cortex granted directly as well as inherited. Cortex underpins every module,
  -- so this removes any dependence on transitive database-role inheritance.
  EXECUTE IMMEDIATE 'GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE ' || :wsrole;

  -- Resolve the input to this account's ACTUAL username before granting.
  --
  -- The schema name is derived from the email local part above, but GRANT ... TO USER
  -- needs the real username, and the two are frequently different: the user
  -- GEOFF.SOMERVILLE has the email geoff.somerville@snowflake.com. Granting the raw
  -- input meant an email address failed with "User '"..."' does not exist" AFTER the
  -- schema and role had already been created, leaving a half-provisioned learner.
  -- Matching name, login_name and email means either form works.
  --
  -- Deliberately no LIKE pattern: '_' is a LIKE wildcard, so B_JONES would also match
  -- BXJONES. Filtering exactly in SQL cannot pick up a neighbouring user.
  BEGIN
    SHOW USERS;
    SELECT COUNT(DISTINCT "name"), MAX("name")
      INTO :ambig, :guser
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE UPPER("name")       = UPPER(:uname)
        OR UPPER("login_name") = UPPER(:uname)
        OR LOWER("email")      = LOWER(:uname);
  EXCEPTION WHEN OTHER THEN
    -- No privilege to list users (a facilitator rather than ACCOUNTADMIN). Fall back
    -- to the literal input, which is correct whenever the username was supplied.
    guser := NULL; ambig := 0;
  END;

  -- Oversight, and the learner themselves.
  EXECUTE IMMEDIATE 'GRANT ROLE ' || :wsrole || ' TO ROLE SNOWCUP_FACILITATOR';

  -- Two names could match only if one person's username is another's email, so
  -- guessing between them could hand a learner's schema to the wrong user. Refuse.
  IF (:ambig > 1) THEN
    warn := 'WARNING: ''' || :uname || ''' matches more than one Snowflake user, so the'
         || ' role was NOT granted to anyone. Re-run with the exact username.';
  ELSE
    IF (:guser IS NULL) THEN
      guser := :uname;
    END IF;
    BEGIN
      EXECUTE IMMEDIATE 'GRANT ROLE ' || :wsrole || ' TO USER "' || :guser || '"';
    EXCEPTION WHEN OTHER THEN
      -- Report instead of aborting. Aborting here is what produced the confusing
      -- half-provisioned state: schema and role present, nobody holding the role.
      warn := 'WARNING: no Snowflake user matches ''' || :uname || ''', so the role was'
           || ' NOT granted to anyone. The schema and role exist and SNOWCUP_FACILITATOR'
           || ' can see them. Run SHOW USERS, then re-run with their exact username.';
    END;
  END IF;

  IF (:warn <> '') THEN
    tag := 'PARTIAL  ';
  END IF;

  -- Hand back anything in this learner's schema that their own role does not own.
  --
  -- Provisioning cannot PREVENT this -- the objects do not exist yet on a first
  -- run -- so re-running provisioning is the repair path. That matters because a
  -- wrong owner produces no error anywhere: the learner just sees an empty schema,
  -- or an agent that reports its search service does not exist.
  --
  -- Failure here must not fail provisioning. A SNOWCUP_FACILITATOR caller cannot
  -- transfer ACCOUNTADMIN-owned objects, and that is worth reporting rather than
  -- turning a successful provision into an error.
  BEGIN
    CALL SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP(:uname) INTO :repair;
  EXCEPTION WHEN OTHER THEN
    repair := 'ownership check could not run (' || SQLERRM || ')';
  END;
  IF (NOT STARTSWITH(:repair, 'ownership OK')) THEN
    extra := '\n         ' || :repair;
  END IF;
  IF (:warn <> '') THEN
    extra := :extra || '\n         ' || :warn;
  END IF;

  IF (UPPER(:guser) = UPPER(CURRENT_USER())) THEN
    RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
        || '  (your own defaults left unchanged)' || :extra;
  END IF;

  -- Nobody holds the role, so there is no user whose defaults could be set. Stop here:
  -- the defaults logic below would otherwise run ALTER USER against a name that does
  -- not exist and abort, which is the very failure this block exists to prevent.
  IF (:warn <> '') THEN
    RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
        || '  (schema and role created, but NOT granted to any user)' || :extra;
  END IF;

  -- Never overwrite a default the user already has. A workshop account is often a
  -- throwaway, but not always: the same user may do real work here, and their
  -- DEFAULT_ROLE is not ours to replace -- especially as the old value would be
  -- gone with no record of it. Only fill in a default that is genuinely absent
  -- (NULL, empty, or PUBLIC, which is Snowflake's "nothing chosen").
  --
  -- Read through SHOW USERS. Matching on "name" rather than trusting the LIKE
  -- pattern matters: '_' is a LIKE wildcard, so a name such as B_JONES would also
  -- match BXJONES and we could read somebody else's default role.
  cur_role := NULL;
  BEGIN
    EXECUTE IMMEDIATE 'SHOW USERS LIKE ''' || :guser || '''';
    SELECT MAX(CASE WHEN UPPER("name") = UPPER(:guser) THEN "default_role" END)
      INTO :cur_role FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
    known := TRUE;
  EXCEPTION WHEN OTHER THEN
    -- No privilege to inspect users (a facilitator rather than ACCOUNTADMIN).
    -- Failing closed means leaving their settings alone.
    known := FALSE;
  END;

  IF (NOT :known) THEN
    RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
        || '  (could not read their current defaults, so none were changed --'
        || ' tell them to run: USE ROLE ' || :wsrole || ';)' || :extra;
  END IF;

  IF (:cur_role IS NULL OR TRIM(:cur_role) = '' OR UPPER(TRIM(:cur_role)) = 'PUBLIC') THEN
    EXECUTE IMMEDIATE 'ALTER USER "' || :guser
      || '" SET DEFAULT_ROLE = ' || :wsrole || ', DEFAULT_WAREHOUSE = SNOWCUP_WH';
    RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
        || '  (default role + warehouse set; they had none)' || :extra;
  END IF;

  RETURN :tag || :uname || '  ->  ' || :schema || '  role ' || :wsrole
      || '  (LEFT ALONE: their default role is already ' || TRIM(:cur_role)
      || ', so it was not replaced -- tell them to run: USE ROLE ' || :wsrole || ';)'
      || :extra;
END;
$$;

-- >>> PROVISION_LEARNERS: the same thing for a whole list. Accepts commas,
--     semicolons or newlines, so you can paste a column out of a spreadsheet.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS(NAMES VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  c1 CURSOR FOR
    SELECT DISTINCT TRIM(f.value)::VARCHAR AS uname
      FROM TABLE(FLATTEN(input => SPLIT(REGEXP_REPLACE(?, '[;\r\n]+', ','), ','))) f
     WHERE TRIM(f.value) <> ''
     ORDER BY 1;
  out VARCHAR DEFAULT '';
  one VARCHAR;
  nm  VARCHAR;
BEGIN
  OPEN c1 USING (NAMES);
  FOR rec IN c1 DO
    -- assign to a local first: a cursor row field cannot be bound directly
    -- into a CALL argument.
    nm := rec.uname;
    CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(:nm) INTO :one;
    out := out || :one || '\n';
  END FOR;
  CLOSE c1;
  IF (out = '') THEN
    RETURN 'Nothing to do - the list was empty.';
  END IF;
  RETURN :out;
END;
$$;

-- >>> DEPROVISION_LEARNER: offboard one person. Revokes their role and detaches
--     it from the facilitator role. DROP_SCHEMA = TRUE also deletes everything
--     they built and removes the role; FALSE keeps their work (and the role that
--     owns it) so it can be handed back later.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_LEARNER(NAME VARCHAR, DROP_SCHEMA BOOLEAN)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  uname  VARCHAR DEFAULT TRIM(NAME);
  suffix VARCHAR;
  schema VARCHAR;
  wsrole VARCHAR;
  guser  VARCHAR DEFAULT NULL;
  ambig  NUMBER  DEFAULT 0;
BEGIN
  IF (uname IS NULL OR uname = '') THEN
    RETURN 'SKIPPED  (empty name)';
  END IF;
  suffix := TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(uname, '@', 1)), '[^A-Z0-9]+', '_'), '_');
  IF (suffix = '') THEN
    RETURN 'SKIPPED  ' || :uname || ' (could not derive a schema name)';
  END IF;
  schema := 'SNOWCUP_BUILDS.WS_' || suffix;
  wsrole := 'SNOWCUP_WS_' || suffix;

  -- Resolve to the account's real username, same reasoning as PROVISION_LEARNER: the
  -- user GEOFF.SOMERVILLE has the email geoff.somerville@snowflake.com, so revoking
  -- from the raw input aborted and left the learner half-offboarded. Anyone
  -- provisioned BY email could therefore never be offboarded at all.
  BEGIN
    SHOW USERS;
    SELECT COUNT(DISTINCT "name"), MAX("name")
      INTO :ambig, :guser
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
     WHERE UPPER("name")       = UPPER(:uname)
        OR UPPER("login_name") = UPPER(:uname)
        OR LOWER("email")      = LOWER(:uname);
  EXCEPTION WHEN OTHER THEN
    guser := NULL; ambig := 0;
  END;

  -- A revoke is cleanup, so a missing or ambiguous user must not stop the offboarding:
  -- the schema and role still need removing. Skipping a revoke that cannot apply is
  -- safe, because DROP ROLE below removes every grant of it anyway.
  IF (:guser IS NOT NULL AND :ambig = 1) THEN
    BEGIN
      EXECUTE IMMEDIATE 'REVOKE ROLE ' || :wsrole || ' FROM USER "' || :guser || '"';
    EXCEPTION WHEN OTHER THEN
      NULL;
    END;
  END IF;

  IF (DROP_SCHEMA) THEN
    EXECUTE IMMEDIATE 'DROP SCHEMA IF EXISTS ' || :schema || ' CASCADE';
    EXECUTE IMMEDIATE 'REVOKE ROLE ' || :wsrole || ' FROM ROLE SNOWCUP_FACILITATOR';
    EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || :wsrole;
    RETURN 'REMOVED  ' || :uname || '  (role and ' || :schema || ' dropped)';
  END IF;
  RETURN 'REVOKED  ' || :uname || '  (role kept so ' || :schema
      || ' and its objects survive)';
END;
$$;

-- >>> AUDIT_BUILD_OWNERSHIP: find objects in a build schema that the learner's
--     own role does NOT own.
--
--     WHY THIS EXISTS
--     A learner owns everything they create: ownership follows the role that ran
--     CREATE, and their DEFAULT_ROLE is SNOWCUP_WS_<NAME>. The problem is an
--     ADMIN creating something inside a learner's schema -- authoring a reference
--     solution on ACCOUNTADMIN, or a facilitator helping someone who is stuck.
--     The learner then holds no privilege on it, and NOTHING errors: SHOW and
--     Snowsight simply omit it, and an agent pointed at it fails with a message
--     about the object not existing. Worse, DEFAULT_SECONDARY_ROLES = ALL hides
--     it while the admin's own session is the one testing, because the object
--     resolves through ACCOUNTADMIN.
--
--     WHY IT ASKS THE QUESTION BACKWARDS
--     The obvious implementation -- read an "owner" column per object kind -- is
--     what made this bug survive three separate checks. SHOW CORTEX SEARCH
--     SERVICES has no "owner" column at all, and neither does SHOW PROCEDURES,
--     so those kinds were structurally invisible to every owner-column check.
--     Instead this asks: what EXISTS in the schema, minus what the learner's role
--     OWNS. One "SHOW GRANTS TO ROLE" returns OWNERSHIP rows for every kind,
--     fully qualified, so no owner column is needed anywhere and a newly
--     supported object kind cannot silently fall outside the audit.
--
--     P_PARTICIPANT scopes to one learner; NULL or '' audits every build schema.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(P_PARTICIPANT VARCHAR)
RETURNS TABLE (KIND VARCHAR, SCH VARCHAR, OBJ VARCHAR, OWNER VARCHAR,
               EXPECTED_ROLE VARCHAR, FIX_SQL VARCHAR)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  suffix  VARCHAR DEFAULT NULL;
  scope   VARCHAR DEFAULT 'IN DATABASE SNOWCUP_BUILDS';
  n       INT;
  i       INT DEFAULT 1;
  sch     VARCHAR;
  vn      INT;
  vi      INT DEFAULT 1;
  vkind   VARCHAR;
  vref    VARCHAR;
  vowner  VARCHAR;
  rs      RESULTSET;
BEGIN
  IF (P_PARTICIPANT IS NOT NULL AND TRIM(P_PARTICIPANT) <> '') THEN
    -- Same derivation as PROVISION_LEARNER, so jdoe@acme.com -> WS_JDOE.
    suffix := TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(TRIM(P_PARTICIPANT), '@', 1)),
                                  '[^A-Z0-9]+', '_'), '_');
    -- Narrow every SHOW to the one schema. PROVISION_LEARNERS calls this once per
    -- learner, so a database-wide scan per learner would make provisioning a
    -- 30-person cohort needlessly slow.
    scope := 'IN SCHEMA SNOWCUP_BUILDS.WS_' || :suffix;
  END IF;

  -- Temp tables are qualified on purpose: an unqualified CREATE TEMPORARY TABLE
  -- fails with "session does not have a current database" when the caller has
  -- only done USE ROLE. Being temporary, two facilitators auditing at the same
  -- time each get their own copy.
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS (
    KIND VARCHAR, KIND_SQL VARCHAR, SCH VARCHAR, OBJ VARCHAR,
    OBJ_REF VARCHAR,     -- what GRANT OWNERSHIP needs (carries the signature for procs)
    MATCH_KEY VARCHAR);  -- normalised to compare against SHOW GRANTS output
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_OWNED (MATCH_KEY VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND (KIND VARCHAR);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL (
    RN INT, KIND VARCHAR, KIND_SQL VARCHAR, SCH VARCHAR, OBJ VARCHAR,
    OBJ_REF VARCHAR, OWNER VARCHAR, EXPECTED_ROLE VARCHAR, FIX_SQL VARCHAR);

  -- ---- What exists, one SHOW per kind. --------------------------------------
  -- Every kind PROVISION_LEARNER grants CREATE on. Each SHOW is followed
  -- IMMEDIATELY by its INSERT so LAST_QUERY_ID() needs no offset -- the
  -- LAST_QUERY_ID(-N) form used elsewhere silently misreads if a SHOW is ever
  -- added, removed or skipped.
  --
  -- A kind that cannot be read (unsupported on the account) is RECORDED, never
  -- ignored: an unreadable kind must not be reported as clean.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW TABLES ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'TABLE', 'TABLE', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('TABLE');
  END;

  BEGIN
    EXECUTE IMMEDIATE 'SHOW VIEWS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'VIEW', 'VIEW', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('VIEW');
  END;

  -- SHOW VIEWS and SHOW SEMANTIC VIEWS are disjoint -- verified, no double
  -- counting. (SHOW OBJECTS does conflate them, which is why it is not used:
  -- it would emit GRANT ... ON VIEW for a semantic view and fail.)
  BEGIN
    EXECUTE IMMEDIATE 'SHOW SEMANTIC VIEWS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'SEMANTIC VIEW', 'SEMANTIC VIEW', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('SEMANTIC VIEW');
  END;

  BEGIN
    EXECUTE IMMEDIATE 'SHOW AGENTS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'AGENT', 'AGENT', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('AGENT');
  END;

  -- The kind this whole procedure exists for. No "owner" column anywhere in its
  -- SHOW output, which is exactly why the earlier checks could not see it.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW CORTEX SEARCH SERVICES ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'CORTEX SEARCH SERVICE', 'CORTEX SEARCH SERVICE', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('CORTEX SEARCH SERVICE');
  END;

  -- Procedures and functions need their argument signature to be transferred:
  -- GRANT OWNERSHIP ON PROCEDURE f(VARCHAR). "arguments" arrives as
  -- 'F(VARCHAR) RETURN VARCHAR', so only the RETURN suffix is stripped -- a
  -- '\([^)]*\)' match would truncate a type like NUMBER(38,0).
  --
  -- MATCH_KEY deliberately drops the signature, because SHOW GRANTS renders
  -- argument types in its own way and an exact string compare would report a
  -- correctly-owned procedure as mis-owned. The cost is that two overloads of
  -- one name are treated as a single object, which would only matter if a
  -- learner had one overload owned correctly and another not.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW PROCEDURES ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'PROCEDURE', 'PROCEDURE', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.'
               || REGEXP_REPLACE("arguments", '\\s+RETURN\\s+.*$', ''),
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('PROCEDURE');
  END;

  -- USER FUNCTIONS, not FUNCTIONS: the latter includes every built-in.
  BEGIN
    EXECUTE IMMEDIATE 'SHOW USER FUNCTIONS ' || :scope;
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS
      SELECT 'FUNCTION', 'FUNCTION', "schema_name", "name",
             'SNOWCUP_BUILDS.' || "schema_name" || '.'
               || REGEXP_REPLACE("arguments", '\\s+RETURN\\s+.*$', ''),
             'SNOWCUP_BUILDS.' || "schema_name" || '.' || "name"
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE STARTSWITH("schema_name", 'WS_')
         AND (:suffix IS NULL OR "schema_name" = 'WS_' || :suffix);
  EXCEPTION WHEN OTHER THEN
    INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND VALUES ('FUNCTION');
  END;

  -- ---- What each learner's role owns, one SHOW GRANTS per role. -------------
  -- Driven off the schemas that actually hold objects, so a learner who has
  -- built nothing costs nothing. WHILE + SELECT INTO rather than a cursor:
  -- the inline FOR rec IN (SELECT ...) form fails here with
  -- "invalid identifier 'REC.COL'".
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_SCHEMAS AS
    SELECT ROW_NUMBER() OVER (ORDER BY SCH) AS RN, SCH
      FROM (SELECT DISTINCT SCH FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS);
  SELECT COUNT(*) INTO :n FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_SCHEMAS;

  WHILE (:i <= :n) DO
    SELECT SCH INTO :sch FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_SCHEMAS WHERE RN = :i;
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS TO ROLE SNOWCUP_' || :sch;
      INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_OWNED
        SELECT SPLIT_PART("name", '(', 1)
          FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
         WHERE "privilege" = 'OWNERSHIP';
    EXCEPTION WHEN OTHER THEN
      -- A missing role means nothing in that schema can be learner-owned, so
      -- every object in it is correctly reported as a violation.
      NULL;
    END;
    i := :i + 1;
  END WHILE;

  -- ---- Violations, then the true owner of each one. -------------------------
  INSERT INTO SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL
    SELECT ROW_NUMBER() OVER (ORDER BY e.SCH, e.KIND, e.OBJ), e.KIND, e.KIND_SQL,
           e.SCH, e.OBJ, e.OBJ_REF, '(unknown)', 'SNOWCUP_' || e.SCH,
           'GRANT OWNERSHIP ON ' || e.KIND_SQL || ' ' || e.OBJ_REF
             || ' TO ROLE SNOWCUP_' || e.SCH || ';'
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_EXISTS e
     WHERE NOT EXISTS (SELECT 1 FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_OWNED o
                        WHERE o.MATCH_KEY = e.MATCH_KEY);

  -- Naming the actual owner turns "something is wrong" into "you created this on
  -- ACCOUNTADMIN". Done per violation rather than per object because violations
  -- are normally zero, so this loop usually does not run at all.
  SELECT COUNT(*) INTO :vn FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL;
  WHILE (:vi <= :vn) DO
    SELECT KIND_SQL, OBJ_REF INTO :vkind, :vref
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL WHERE RN = :vi;
    vowner := '(unknown)';
    BEGIN
      EXECUTE IMMEDIATE 'SHOW GRANTS ON ' || :vkind || ' ' || :vref;
      SELECT MAX("grantee_name") INTO :vowner
        FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
       WHERE "privilege" = 'OWNERSHIP';
    EXCEPTION WHEN OTHER THEN
      vowner := '(unreadable)';
    END;
    UPDATE SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL
       SET OWNER = COALESCE(:vowner, '(none)') WHERE RN = :vi;
    vi := :vi + 1;
  END WHILE;

  -- An unreadable kind is surfaced as a row, never omitted -- otherwise a kind
  -- this account cannot report on would look identical to a clean result.
  rs := (
    SELECT KIND, SCH, OBJ, OWNER, EXPECTED_ROLE, FIX_SQL
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_VIOL
    UNION ALL
    SELECT '(kind not readable)', '-', KIND, '(could not enumerate)', '-',
           '-- this object kind could not be listed on this account; audit is incomplete'
      FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_BLIND
     ORDER BY 2, 1, 3);
  RETURN TABLE(rs);
END;
$$;

-- >>> FIX_BUILD_OWNERSHIP: hand every mis-owned object back to its learner.
--
--     Each GRANT is wrapped in its own exception handler so one failure cannot
--     abandon the rest, and the procedure RE-AUDITS afterwards rather than
--     assuming the grants worked -- a partial repair must never report success.
--
--     Deliberately no COPY CURRENT GRANTS: it would carry the admin's grants
--     across and widen access beyond that one learner, defeating the isolation
--     gate in check_roles.sql check 1.
--
--     Runs as caller, like the rest of ADMIN. A SNOWCUP_FACILITATOR caller
--     cannot transfer ACCOUNTADMIN-owned objects, which is precisely the common
--     case -- those come back in the "still broken" list with their owner named,
--     rather than failing silently.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP(P_PARTICIPANT VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  blk     VARCHAR;
  fixed   VARCHAR;
  n_before INT DEFAULT 0;
  n_after  INT DEFAULT 0;
  left_over VARCHAR;
BEGIN
  CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(:P_PARTICIPANT);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX AS
    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

  SELECT COUNT(*) INTO :n_before FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX
   WHERE STARTSWITH(FIX_SQL, 'GRANT');
  IF (:n_before = 0) THEN
    RETURN 'ownership OK (nothing to repair)';
  END IF;

  SELECT LISTAGG(KIND || ' ' || SCH || '.' || OBJ || ' (was ' || OWNER || ')', ', ')
    INTO :fixed FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX
   WHERE STARTSWITH(FIX_SQL, 'GRANT');

  -- One dynamic block instead of iterating rows, which avoids the cursor-field
  -- resolution problem; the per-statement handler keeps it resilient.
  SELECT LISTAGG('BEGIN ' || FIX_SQL || ' EXCEPTION WHEN OTHER THEN NULL; END;', ' ')
    INTO :blk FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_FIX
   WHERE STARTSWITH(FIX_SQL, 'GRANT');
  EXECUTE IMMEDIATE 'BEGIN ' || :blk || ' END;';

  -- Prove it, do not assume it.
  CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(:P_PARTICIPANT);
  CREATE OR REPLACE TEMPORARY TABLE SNOWCUP_WORKSHOP.ADMIN.T_OWN_RECHECK AS
    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  SELECT COUNT(*) INTO :n_after FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_RECHECK
   WHERE STARTSWITH(FIX_SQL, 'GRANT');

  IF (:n_after = 0) THEN
    RETURN 'repaired ' || :n_before::VARCHAR || ': ' || :fixed;
  END IF;

  SELECT LISTAGG(KIND || ' ' || SCH || '.' || OBJ || ' (owned by ' || OWNER || ')', ', ')
    INTO :left_over FROM SNOWCUP_WORKSHOP.ADMIN.T_OWN_RECHECK
   WHERE STARTSWITH(FIX_SQL, 'GRANT');
  RETURN 'PARTIAL: repaired ' || (:n_before - :n_after)::VARCHAR || ' of '
      || :n_before::VARCHAR || '. STILL BROKEN: ' || :left_over
      || '  -- you probably need ACCOUNTADMIN to transfer these.';
END;
$$;

-- >>> AUDIT_BUILD_OWNERSHIP_JSON: the same audit, as a single VARIANT value.
--
--     WHY THIS EXISTS AND WHY IT HOLDS NO LOGIC OF ITS OWN
--     A caller outside Snowflake cannot use the table form. Reading it needs
--     CALL followed by SELECT ... FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())), and
--     those are two round trips -- so with a connection POOL (which the admin app
--     uses) the second statement can land on a different session, where
--     LAST_QUERY_ID() refers to some unrelated query. The symptom is an
--     "invalid identifier" on the first selected column, not a permission error.
--
--     Inside a procedure the CALL and the RESULT_SCAN are guaranteed to share a
--     session, so this wrapper is safe. It delegates entirely -- there is exactly
--     one definition of "who should own this", in AUDIT_BUILD_OWNERSHIP, because
--     the whole reason this feature exists is that three copies of that logic
--     drifted apart.
--
--     Returns [] when everything is correctly owned.
CREATE OR REPLACE PROCEDURE SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP_JSON(P_PARTICIPANT VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  out VARIANT DEFAULT NULL;
BEGIN
  CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(:P_PARTICIPANT);
  SELECT COALESCE(ARRAY_AGG(OBJECT_CONSTRUCT(
           'kind', KIND, 'sch', SCH, 'obj', OBJ, 'owner', OWNER,
           'expected_role', EXPECTED_ROLE, 'fix_sql', FIX_SQL)), ARRAY_CONSTRUCT())
    INTO :out
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
  RETURN :out;
END;
$$;

-- ROSTER: as shipped this provisions whoever runs the script (CURRENT_USER), so
-- the smoke test works immediately on any account with no edits, and your own
-- defaults are left untouched. Add everyone else in one call, or use the
-- SnowCup Admin app (see snowcup-admin-node/).
CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(CURRENT_USER());
-- CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS('jdoe@acme.com, asmith@acme.com, BJONES');
-- CALL SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_LEARNER('jdoe@acme.com', FALSE);

-- ============================================================================
-- STEP 11: Verify the load
-- ============================================================================
-- Fully qualified: STEP 10 created SNOWCUP_BUILDS, which changes the session's
-- current database, so unqualified table names here would not resolve.
SELECT 'PLAYERS'            AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM SNOWCUP_SHARED.TOURNAMENT.PLAYERS
UNION ALL SELECT 'TOURNAMENTS',        COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.TOURNAMENTS
UNION ALL SELECT 'MATCHES',            COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.MATCHES
UNION ALL SELECT 'PLAYER_MATCH_STATS', COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_MATCH_STATS
UNION ALL SELECT 'DISCIPLINE',         COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.DISCIPLINE
UNION ALL SELECT 'PLAYER_PROFILES',    COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES
ORDER BY TABLE_NAME;
