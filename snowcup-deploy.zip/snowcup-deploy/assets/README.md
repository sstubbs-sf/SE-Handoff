# SnowCup — Build-an-Agent Lab

A self-paced Snowflake workshop that teaches Cortex Code (CoCo) fundamentals end to end on a
fictional football tournament: model a semantic view, ground it with Cortex Search, assemble a
Cortex Agent with a custom tool, publish it in Snowflake CoWork, evaluate it, and beat a scored,
auto-graded 8-question challenge.

Everything is **self-provisioning**: the scripts create their own warehouse, databases, role, and
grants. An admin runs two SQL files as `ACCOUNTADMIN` and the whole environment is ready.

---

## BUILD ALL ASSETS (admin / agent runbook)

> If you were told **"build all assets for this training"** or **"prep everything needed for the users
> to start,"** do exactly this, in order, as `ACCOUNTADMIN`. Both scripts are idempotent and safe to
> re-run. **Agent note:** run Step 1 and Step 2 as-is, then **ask the admin for the list of learner
> Snowflake usernames** and pass them all to one `PROVISION_LEARNERS` call (Step 3). The scripts already
> provision the admin who runs them, so a solo run needs no learner list.

**Prerequisites**
- Role: `ACCOUNTADMIN` (or a role with `CREATE DATABASE`, `CREATE WAREHOUSE`, `CREATE AGENT`, and the ability to grant `SNOWFLAKE.CORTEX_USER`).
- A Snowflake CLI connection (this repo was built with connection **`default`** — substitute your own), or a Snowsight worksheet.
- Nothing else — no pre-existing warehouse, database, or role is required. The scripts enable Cortex cross-region inference for you.

**Step 1 — Load data + provision the environment**
```bash
snow sql -f snowcup-data-setup.sql -c default
```
Creates: warehouse `SNOWCUP_WH`; enables `CORTEX_ENABLED_CROSS_REGION`; `SNOWCUP_SHARED.TOURNAMENT`
(6 tables loaded); the `SNOWCUP_PARTICIPANT` role with `SNOWFLAKE.CORTEX_USER` + read grants;
`SNOWCUP_FACILITATOR` (oversight); `SNOWCUP_BUILDS` (per-learner build DB); `SNOWCUP_WORKSHOP.ADMIN`
with the `PROVISION_LEARNER` / `PROVISION_LEARNERS` / `DEPROVISION_LEARNER` procedures and a stage for
the admin app; and a build schema **plus a private role** for **whoever runs the script**
(via `CURRENT_USER()`), so the smoke test works immediately.

**Step 2 — Deploy the grader + Referee agent**
```bash
snow sql -f snowcup-grader-setup.sql -c default
```
Creates `SNOWCUP_WORKSHOP.GRADING` (module registry, answer key, owner's-rights grading procedures,
participant-readable views) and the **SnowCup Referee** agent, and grants the participant role everything it needs to submit answers.

> **Safe to re-run.** This script is idempotent: it never drops `CHALLENGE_PROGRESS` and never resets a score,
> so you can re-deploy it over a live workshop to pick up fixes. Progress is tracked per
> *(participant, module, question)* with points **assigned** rather than added, so re-answering a question that
> is already correct never double counts.

**One-liner (both, in order)**
```bash
snow sql -f snowcup-data-setup.sql -c default && snow sql -f snowcup-grader-setup.sql -c default
```

**Step 3 — Add learners (optional)**
Each learner gets a private build schema **and their own role**. Pass the whole list in one call —
commas, semicolons or newlines all work, so you can paste a column from a spreadsheet:
```sql
CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS('jdoe@acme.com, asmith@acme.com, BJONES');
```
Per learner this derives `SNOWCUP_BUILDS.WS_JDOE` and role `SNOWCUP_WS_JDOE` from the username, grants
build rights **on that schema only**, nests `SNOWCUP_PARTICIPANT` + `CORTEX_USER` inside the role, attaches
the role to `SNOWCUP_FACILITATOR`, grants it to the user, and sets their **default role + warehouse**.
It is idempotent, so re-running for someone is harmless. As shipped, `snowcup-data-setup.sql` provisions the
admin who runs it (via `CURRENT_USER()`, leaving the admin's own defaults untouched).

## Two Cortex Code skills

| Skill | Use it when | Self-contained |
|-------|-------------|----------------|
| `snowcup-deploy` | You have a **fresh account** and need to stand the whole training up, then hand it off | **Yes** — bundles every artifact including the admin console source |
| `snowcup-admin` | The workshop **already exists** and you are operating it (add learners, delegate, health, verify) | No — expects this folder to hand |

Build the hand-off package before shipping it. Its copies of the setup scripts are
generated from this folder rather than committed, so they cannot silently drift from
the grader's answer key:

```bash
tools/build-deploy-package.sh            # -> dist/snowcup-deploy/
tools/build-deploy-package.sh --install  # also install for local use
cd dist && zip -qr snowcup-deploy.zip snowcup-deploy
```

The recipient unzips into `~/.snowflake/cortex/skills/` and starts a new session. The
build fails loudly if an artifact the skill references is missing, and refuses to ship
`node_modules`.

> **The package contains the answer key** (`snowcup-grader-setup.sql` seeds it). Hand it
> to admins only. Learners get only the `SNOWCUP_LAB_APP` URL.

**Step 3b — Deploy the admin app (recommended)**
A four-tab console for the roster: add learners, see who is set up, offboard, and check environment
health (including the isolation gate and the search-owns-the-lore gate). It is a **Snowflake App**
(Next.js on App Runtime) in `snowcup-admin-node/`, and it replaced the earlier Streamlit version.

> **Prerequisite — check this or facilitator delegation silently breaks.** Until account-level
> **App Development Setup** is done, `snow app deploy` *succeeds* but deploys into your personal
> database `USER$<login>`, and an Application Service there **cannot be granted to any role** — so
> nobody but you can ever open it and `SNOWCUP_FACILITATOR` is useless. Verify first with
> `SHOW PARAMETERS LIKE 'DEFAULT_SNOWFLAKE_APPS%' IN ACCOUNT;` — the destination database, schema
> and query warehouse must be set. If empty, use Snowsight » Settings » Account » Apps » Begin
> Setup, or as ACCOUNTADMIN:
>
> ```sql
> CREATE DATABASE IF NOT EXISTS SNOWFLAKE_APPS;
> CREATE WAREHOUSE IF NOT EXISTS SNOWFLAKE_APPS_QUERY_WH
>   WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE;
> ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_DATABASE = 'SNOWFLAKE_APPS';
> ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_SCHEMA   = 'PUBLIC';
> ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_QUERY_WAREHOUSE      = 'SNOWFLAKE_APPS_QUERY_WH';
> ```

```bash
cd snowcup-admin-node
npm install
snow app deploy --role ACCOUNTADMIN   # default role fails on the access integration
snow app open                          # or: snow app open --print-only
```

Then grant access. Access is limited to **ACCOUNTADMIN** and **SNOWCUP_FACILITATOR**; `lib/authz.ts`
refuses everyone else with a 403:

```sql
-- All THREE object grants are required; the database and schema ones are easy to
-- miss and their absence looks like a broken app rather than a missing grant.
GRANT USAGE ON DATABASE SNOWFLAKE_APPS        TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON SCHEMA   SNOWFLAKE_APPS.PUBLIC TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE, MONITOR ON APPLICATION SERVICE SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP
  TO ROLE SNOWCUP_FACILITATOR;
GRANT USAGE ON WAREHOUSE SNOWFLAKE_APPS_QUERY_WH TO ROLE SNOWCUP_FACILITATOR;
GRANT ROLE SNOWCUP_FACILITATOR TO USER <person>;
```

Facilitators do **not** need to switch roles: the app authorises on roles a person *holds*
(`CURRENT_AVAILABLE_ROLES()`), not just their active one, and always shows which role authorised
them.

> **Security note.** Provisioning must `CREATE ROLE` and `GRANT`, which Snowflake's restricted
> caller's rights forbids, so the privileged work runs with the app owner's rights and
> authorisation is enforced in application code (`lib/authz.ts`). That is what lets a facilitator
> act without ACCOUNTADMIN. Consequence: **grant `USAGE` on the application service only to those
> two roles — never to `PUBLIC`.** See `snowcup-admin-node/README.md`.

**Adding people after the workshop has started** — the procedures persist in `SNOWCUP_WORKSHOP.ADMIN`, so
onboarding a latecomer is one call as `ACCOUNTADMIN` (or a few clicks in the admin app), with no re-deploy.
The reply gives you the exact schema name to send them. Useful companions:
```sql
SHOW SCHEMAS LIKE 'WS%' IN DATABASE SNOWCUP_BUILDS;   -- who's set up
SHOW ROLES LIKE 'SNOWCUP_WS_%';                       -- every per-learner role
SHOW GRANTS OF ROLE SNOWCUP_WS_JANE_DOE;              -- who holds one role

-- offboard: FALSE keeps their work, TRUE deletes their schema and role
CALL SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_LEARNER('jane.doe@acme.com', FALSE);
```
The facilitator guide's **Add people later** section has a copy-paste learner invite, how to find your Snowsight URL,
and the full offboarding steps.

**Step 4 — Smoke-test, then hand out the lab**
- Open the **SnowCup Referee** (CoWork at https://ai.snowflake.com, or Snowsight » AI & ML » Agents), submit `Q2: Driftland` → expect "correct".
- Check CoWork visibility: run `SHOW SNOWFLAKE INTELLIGENCES;`. If a row comes back, add the Referee
  (`ALTER SNOWFLAKE INTELLIGENCE SNOWFLAKE_INTELLIGENCE_OBJECT_DEFAULT ADD AGENT SNOWCUP_WORKSHOP.GRADING.SNOWCUP_REFEREE;`),
  grant `USAGE` on the object to `SNOWCUP_PARTICIPANT`, and grant `MODIFY` so learners can add their own
  agent in Module 7. If it returns nothing, **do not create one** — that would hide every learner-built agent.
- Confirm the key is hidden: as the participant role with `USE SECONDARY ROLES NONE`,
  `SELECT * FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY` must be **denied**.
- Give learners **only** the `SNOWCUP_LAB_APP` URL.

**Step 5 — Track how far builders get**
```sql
SELECT PARTICIPANT, MODULE_TITLE, QUESTIONS_CORRECT, QUESTIONS_TOTAL,
       PERCENT_COMPLETE, STATUS, POINTS, LAST_ACTIVITY
  FROM SNOWCUP_WORKSHOP.GRADING.BUILDER_PROGRESS
 ORDER BY MODULE_SEQUENCE, PERCENT_COMPLETE DESC, PARTICIPANT;
```
One row per builder per module, with `STATUS` of `not started` / `in progress` / `complete` — builders who
haven't begun a module still appear, so you can spot who hasn't started rather than only who's behind.

**Adding a training module later** — a new module is *data, not code*: insert a row into `MODULES`, insert its
questions into `CHALLENGE_KEY` with that `MODULE_ID`, and grade with
`SUBMIT_MODULE_ANSWER(module_id, question_id, answer)`. Question ids are scoped per module, so a second module
can reuse `Q1` without colliding. All progress views pick it up automatically. See the facilitator guide's
**Add a training module** section.

---

## Files

| File | Audience | Contents |
|------|----------|----------|
| `snowcup-lab-node/` → `SNOWCUP_LAB_APP` | **Learners** (they get the URL) | Overview + guided modules 0–10 + the scored challenge |
| `snowcup-data-setup.sql` | Admin only | Warehouse, shared data, roles + grants, build DB, provisioning procedures |
| `snowcup-admin-node/` | Admin only | Snowflake App (Next.js) console: add / list / remove learners, environment health. ACCOUNTADMIN or SNOWCUP_FACILITATOR only |
| `snowcup-grader-setup.sql` | Admin only | Grading backend + Referee agent (**contains the answer key**) |
| `snowcup-facilitator-guide.html` | Admin only | Full runbook, answer key, golden metric definitions, teardown |
| `README.md` | Admin only | This build manifest |
| `verify/` | Admin only | Static checks that gate the deliverables (see below). **Contains the answer key** in `verify/mapping.py`, so it is admin-only like the grader script. |

---

## Verifying after an edit

Run every static check from the workshop folder:

```bash
./verify/run_all.sh
```

| Check | Gates |
|---|---|
| `check_names.py --all` | No legacy token survives; surnames, nicknames and nations unique; no accepted variant is a substring of another entity |
| `check_key.py` | The 8 key rows match `verify/mapping.py` — catches stale surname variants a find/replace would miss |
| `check_roster.py` | 48 players on the right `PLAYER_ID`s, 16 nations, depth nations absent from `MATCHES`, and `HASH()` still keyed on `PLAYER_ID`/`MATCH_ID` |
| `check_leaks.py` | No answer value or accepted variant appears in the learner file, and nothing tells a learner to *run* a scored question outside the challenge itself |
| `check_html.py` | Tag balance, anchor resolution, and JavaScript syntax |

Then the live-data checks, against a deployed environment:

```bash
snow sql -f verify/verify_answers.sql -c default
```

That re-derives all 8 answers from the data independently of the key and counts
ties — expect `MATCH` and `tied = 1` on every row, plus `safe` for every lab demo.

> **Why this exists.** `verify/mapping.py` is the single source of truth for every
> name. The leak scanner builds its signatures from the answer key rather than
> hardcoding question wording, because an earlier hardcoded version reported a
> false CLEAN after the questions changed. `check_roster.py` guards the invariant
> the whole dataset rests on: the generated stats hash on `PLAYER_ID || MATCH_ID`,
> so if an ID moves, every answer shifts silently while the SQL still runs clean.

> **Secrecy:** `snowcup-grader-setup.sql`, `snowcup-facilitator-guide.html`, and
> `snowcup-data-setup.sql` (its data encodes the star-player answers) are **admin-only**.
> Learners receive the `SNOWCUP_LAB_APP` URL and nothing else.

---

## Role model

Three kinds of role, so that learners are isolated from each other without extra work:

| Role | Purpose |
|------|---------|
| `SNOWCUP_PARTICIPANT` | Shared, read-only. Nested inside every learner role. **No privilege on any build schema.** |
| `SNOWCUP_WS_<name>` | One per learner. Build rights on their own schema only; owns everything they create. |
| `SNOWCUP_FACILITATOR` | Oversight. Holds every `SNOWCUP_WS_` role, so an admin can reach any learner's schema. |

A granted role confers *exactly* its own privileges and cannot add any, so nesting
`SNOWCUP_PARTICIPANT` inside a learner role exposes nothing it does not already hold — the answer key
stays unreachable. Gate it with `snow sql -f verify/check_roles.sql -c default` (5 checks, all must PASS).

### What the shared participant role can do (grant summary)

`SNOWCUP_PARTICIPANT` is granted, across the two scripts:
- `SNOWFLAKE.CORTEX_USER` database role — Cortex Analyst / Search / agents / `AI_COMPLETE`.
- `USAGE` on databases `SNOWCUP_SHARED`, `SNOWCUP_BUILDS`, `SNOWCUP_WORKSHOP`.
- `USAGE` on schemas `SNOWCUP_SHARED.TOURNAMENT` and `SNOWCUP_WORKSHOP.GRADING` — **not** on any `WS_<name>` build schema.
- `SELECT` on all shared `TOURNAMENT` tables (read-only).
- Build privileges on a `WS_<name>` schema (`CREATE TABLE / VIEW / SEMANTIC VIEW / CORTEX SEARCH SERVICE / AGENT / PROCEDURE / FUNCTION`) belong to that learner's own `SNOWCUP_WS_<name>` role, not to this shared role.
- `USAGE` on warehouse `SNOWCUP_WH`.
- `USAGE` on `SUBMIT_ANSWER`, `SUBMIT_MODULE_ANSWER`, `GET_PROGRESS`; `SELECT` on `MY_SCORE`, `LEADERBOARD`, `LEADERBOARD_BY_MODULE`; `USAGE` on the `SNOWCUP_REFEREE` agent.

The role is **never** granted `SELECT` on `CHALLENGE_KEY` / `CHALLENGE_PROGRESS` / `MODULES` / `BUILDER_PROGRESS`; the answer key stays hidden
behind owner's-rights procedures.

---

## Teardown

```sql
DROP AGENT IF EXISTS SNOWCUP_WORKSHOP.GRADING.SNOWCUP_REFEREE;
DROP DATABASE IF EXISTS SNOWCUP_WORKSHOP;
DROP DATABASE IF EXISTS SNOWCUP_BUILDS;   -- removes every WS_<name> and everything learners built
DROP DATABASE IF EXISTS SNOWCUP_SHARED;
DROP ROLE IF EXISTS SNOWCUP_PARTICIPANT;
DROP ROLE IF EXISTS SNOWCUP_FACILITATOR;
-- then each per-learner role:  SHOW ROLES LIKE 'SNOWCUP_WS_%';
-- DROP ROLE IF EXISTS SNOWCUP_WS_JANE_DOE;
DROP WAREHOUSE IF EXISTS SNOWCUP_WH;
```
