import { describe, it, expect } from "vitest"

import { orphanKey, removalTarget, type RosterRow } from "../../lib/snowcup"

/**
 * removalTarget decides which schema a tick in the roster will DROP, so the cases
 * that matter are the ones where mis-classifying a row destroys the wrong thing:
 * a live learner treated as an orphan, or an orphan silently treated as removable
 * by name (which resolves through held roles and can hit someone else's space).
 */
const row = (over: Partial<RosterRow> = {}): RosterRow => ({
  learner: "JDOE",
  role: "SNOWCUP_WS_JDOE",
  schema: "WS_JDOE",
  schemaExists: true,
  hasUser: true,
  ...over,
})

describe("removalTarget", () => {
  it("removes a learner by name, never as an orphan", () => {
    expect(removalTarget(row())).toEqual({ users: ["JDOE"], orphan: null })
  })

  it("ticks every user granted the same role", () => {
    const t = removalTarget(row({ learner: "JDOE, ASMITH" }))
    expect(t.users).toEqual(["JDOE", "ASMITH"])
    expect(t.orphan).toBeNull()
  })

  it("treats a role with nobody attached as an orphan, addressed literally", () => {
    const t = removalTarget(row({ learner: "(nobody)", hasUser: false }))
    expect(t.users).toEqual([])
    expect(t.orphan).toEqual({ role: "SNOWCUP_WS_JDOE", schema: "WS_JDOE" })
  })

  it("sends no role for a schema whose role is gone, because MISSING is a display marker", () => {
    const t = removalTarget(
      row({ learner: "(none)", role: "MISSING", schema: "WS_GHOST", hasUser: false }),
    )
    expect(t.orphan).toEqual({ role: null, schema: "WS_GHOST" })
  })

  it("still targets the role when its schema is already gone", () => {
    const t = removalTarget(
      row({ learner: "(nobody)", hasUser: false, schemaExists: false }),
    )
    expect(t.orphan).toEqual({ role: "SNOWCUP_WS_JDOE", schema: "WS_JDOE" })
  })

  it("selects nothing when there is neither a role nor a schema to act on", () => {
    const t = removalTarget(row({ learner: "(none)", role: "MISSING", schema: "", hasUser: false }))
    expect(t).toEqual({ users: [], orphan: null })
  })
})

describe("orphanKey", () => {
  it("distinguishes a role-only orphan from a schema-only one", () => {
    expect(orphanKey({ role: "SNOWCUP_WS_A", schema: null })).not.toBe(
      orphanKey({ role: null, schema: "WS_A" }),
    )
  })

  it("is stable for the same target so selection survives a refresh", () => {
    expect(orphanKey({ role: "SNOWCUP_WS_A", schema: "WS_A" })).toBe(
      orphanKey({ role: "SNOWCUP_WS_A", schema: "WS_A" }),
    )
  })
})
