import { describe, it, expect } from "vitest"

import { groupForConcurrency } from "../../lib/snowcup"
import { classifyError, systemicSummary, explainOneLine } from "../../lib/errors"

/**
 * groupForConcurrency is what stops parallel provisioning from handing two people the
 * same build schema, so these cases are about the race, not about tidy grouping.
 */
describe("groupForConcurrency", () => {
  it("serialises people who resolve to the SAME role", () => {
    const groups = groupForConcurrency([
      { person: "jdoe@acme.com", role: "SNOWCUP_WS_JDOE" },
      { person: "jdoe@other.com", role: "SNOWCUP_WS_JDOE" },
    ])
    expect(groups).toHaveLength(1)
    expect(groups[0]).toEqual(["jdoe@acme.com", "jdoe@other.com"])
  })

  it("parallelises people with distinct roles", () => {
    const groups = groupForConcurrency([
      { person: "a@x.com", role: "SNOWCUP_WS_A" },
      { person: "b@x.com", role: "SNOWCUP_WS_B" },
    ])
    expect(groups).toHaveLength(2)
  })

  it("ignores role-name case when deciding a collision", () => {
    const groups = groupForConcurrency([
      { person: "a", role: "snowcup_ws_a" },
      { person: "b", role: "SNOWCUP_WS_A" },
    ])
    expect(groups).toHaveLength(1)
  })

  it("fails closed: unresolved names share one group rather than racing", () => {
    const groups = groupForConcurrency([
      { person: "x", role: null },
      { person: "y", role: null },
    ])
    expect(groups).toHaveLength(1)
    expect(groups[0]).toEqual(["x", "y"])
  })

  it("keeps every person exactly once", () => {
    const people = [
      { person: "a", role: "SNOWCUP_WS_A" },
      { person: "b", role: "SNOWCUP_WS_A" },
      { person: "c", role: "SNOWCUP_WS_C" },
      { person: "d", role: null },
    ]
    const flat = groupForConcurrency(people).flat().sort()
    expect(flat).toEqual(["a", "b", "c", "d"])
  })
})

/**
 * Signatures below are real Snowflake / driver messages, not invented ones -- a
 * classifier tested against strings we made up would pass while never matching
 * anything in production.
 */
describe("classifyError", () => {
  it("classifies a missing workshop procedure as setup, not as a name problem", () => {
    const c = classifyError(
      new Error(
        "Query failed: SQL compilation error: Unknown function SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER",
      ),
    )
    expect(c.klass).toBe("setup_missing")
    expect(c.systemic).toBe(true)
  })

  it("treats lock conflicts as retryable contention, not as a timeout", () => {
    const c = classifyError(
      new Error("Query failed: 000041 (42601): Transaction 'x' is locked by transaction 'y'"),
    )
    expect(c.klass).toBe("contention")
    expect(c.retryable).toBe(true)
  })

  it("points a suspended warehouse at the status page before config changes", () => {
    const c = classifyError(new Error("Query failed: Warehouse 'SNOWCUP_WH' cannot be resumed"))
    expect(c.klass).toBe("warehouse_unavailable")
    expect(c.action).toMatch(/status\.snowflake\.com/)
  })

  it("classifies a statement timeout as systemic and retryable", () => {
    const c = classifyError(
      new Error("Query failed: 000625 (57014): Statement reached its statement or warehouse timeout"),
    )
    expect(c.klass).toBe("timeout")
  })

  it("keeps an unrecognised error verbatim instead of guessing a cause", () => {
    const raw = "Query failed: something nobody has seen before"
    const c = classifyError(new Error(raw))
    expect(c.klass).toBe("unknown")
    expect(c.raw).toBe(raw)
    expect(c.action).toBe("")
  })

  it("carries the query id through so support can find the statement", () => {
    const c = classifyError(new Error("Query failed: boom (queryId=01b2c3d4-0000-abcd-0000-000000000001)"))
    expect(c.queryId).toBe("01b2c3d4-0000-abcd-0000-000000000001")
    expect(explainOneLine(c)).toMatch(/queryId=/)
  })

  it("always preserves the raw text in the one-line rendering", () => {
    const c = classifyError(new Error("Query failed: Insufficient privileges to operate on schema"))
    expect(explainOneLine(c)).toContain("Insufficient privileges to operate on schema")
  })
})

describe("systemicSummary", () => {
  it("headlines a shared environmental cause once", () => {
    const errs = [
      classifyError(new Error("Warehouse 'W' cannot be resumed")),
      classifyError(new Error("Warehouse 'W' cannot be resumed")),
      classifyError(new Error("Warehouse 'W' cannot be resumed")),
    ]
    expect(systemicSummary(errs)?.klass).toBe("warehouse_unavailable")
  })

  it("stays silent for a single failure, which its own row already explains", () => {
    expect(systemicSummary([classifyError(new Error("Warehouse 'W' cannot be resumed"))])).toBeNull()
  })

  it("stays silent when failures are per-person rather than environmental", () => {
    const errs = [
      classifyError(new Error("Rejected name \"!!\": expected only letters")),
      classifyError(new Error("Rejected name \"??\": expected only letters")),
    ]
    expect(systemicSummary(errs)).toBeNull()
  })
})
