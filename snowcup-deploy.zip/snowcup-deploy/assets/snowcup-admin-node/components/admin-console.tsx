"use client"

import { Fragment, useEffect, useMemo, useState } from "react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  XCircle,
} from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { parsePeople, suffixFor, orphanKey, removalTarget, type OrphanTarget, type ResolvedName, type RoleAuditRow, type RosterRow } from "@/lib/snowcup"

const BUILDS_DB = "SNOWCUP_BUILDS"
const ROLE_PREFIX = "SNOWCUP_WS_"
const SCHEMA_PREFIX = "WS_"
/** Only used if the session route somehow omits the list. */
const ADMIN_ROLES_FALLBACK = ["ACCOUNTADMIN", "SNOWCUP_FACILITATOR"]


/**
 * Say plainly where a previewed name came from, because "unverified guess" and
 * "this person already has this exact build space" look identical otherwise, and
 * only one of them is safe to act on.
 */
function resolveNote(
  r: ResolvedName | undefined,
  fetching: boolean,
) {
  if (!r) {
    return (
      <span className="text-muted-foreground">
        {fetching ? "checking\u2026" : "unverified guess"}
      </span>
    )
  }
  if (r.error) return <span className="text-destructive">{r.error}</span>
  if (r.heldCount > 1) {
    return (
      <span className="text-destructive">
        holds {r.heldCount} build roles \u2014 needs consolidating
      </span>
    )
  }
  if (r.anchored === "held_role") {
    return <span className="text-emerald-600 dark:text-emerald-400">existing build space</span>
  }
  if (r.anchored === "username") {
    return <span className="text-muted-foreground">new, user {r.username}</span>
  }
  if (r.anchored === "input") {
    return <span className="text-amber-600 dark:text-amber-400">no such user yet</span>
  }
  return <span className="text-destructive">unusable name</span>
}

async function getJson(url: string) {
  const res = await fetch(url)
  const body = await res.json()
  if (!res.ok) throw new Error(body?.error ?? `${url} failed`)
  return body
}

async function postJson(url: string, payload: unknown) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
  const body = await res.json()
  if (!res.ok) throw new Error(body?.error ?? `${url} failed`)
  return body
}

type ActionResult = { person: string; result: string; ok: boolean; state?: string }

/** Human wording for the phases ADMIN.PROVISION_EVENT records. */
const PHASE_LABEL: Record<string, string> = {
  RESOLVE: "resolving name",
  PRECHECK: "checking for collisions",
  CREATE: "creating schema and role",
  GRANT: "granting privileges",
  OWNERSHIP: "repairing ownership",
  DEFAULTS: "applying session defaults",
  DONE: "done",
}

// Calibrated against ADMIN.PROVISION_EVENT rather than guessed. Measured slowest
// phases: OWNERSHIP 12-14s when it actually sweeps (re-provisioning an existing
// learner), 0.7s when skipped for a new schema; RESOLVE ~2.2s. The old value of 60s
// paired with a claim of "~40s each" meant this warning could never fire at all.
// 30s sits clear of the real worst case while still being reachable.
const SLOW_PHASE_SEC = 30

const STATE_STYLE: Record<string, string> = {
  OK: "text-emerald-700 dark:text-emerald-300",
  PARTIAL: "text-orange-700 dark:text-orange-300",
  SKIPPED: "text-muted-foreground",
  ERROR: "text-red-700 dark:text-red-300",
}

function mmss(total: number) {
  const s = Math.max(0, Math.floor(total))
  const m = Math.floor(s / 60)
  return m > 0 ? `${m}m${String(s % 60).padStart(2, "0")}s` : `${s}s`
}

interface ProgressPerson {
  person: string
  phase: string
  state: string | null
  detail: string | null
  inPhaseSec: number
  totalSec: number
}

interface ProgressData {
  found: boolean
  total: number
  done: number
  running: number
  elapsedSec: number
  finishedAt: string | null
  stalled: boolean
  people: ProgressPerson[]
}

/**
 * Live per-person provisioning progress, read from ADMIN.PROVISION_EVENT.
 *
 * WHY THIS IS NOT DERIVED FROM THE MUTATION. The whole batch runs inside one long
 * request, so its response arrives only when everything is finished -- by which
 * point progress is worthless. This reads the durable phase log over a separate
 * polling request instead, which is also why it survives a page reload and why a
 * dead request still shows exactly where it stopped.
 */
function ProvisionProgress({ data, pending }: { data: ProgressData | undefined; pending: boolean }) {
  if (!data?.found) {
    // The POST fires and polling starts in the same tick, so the run row may not
    // exist for a moment. Say something immediately -- silence here is the exact
    // complaint this feature addresses.
    return pending ? (
      <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
        Starting…
      </p>
    ) : null
  }

  const pct = data.total > 0 ? Math.round((data.done / data.total) * 100) : 0

  return (
    <div className="mt-3 rounded-md border p-3">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
        <span className="font-medium">
          {data.finishedAt ? "Finished" : "Provisioning"} {data.done} of {data.total}
        </span>
        <span className="text-muted-foreground">({pct}%)</span>
        <span className="text-muted-foreground">elapsed {mmss(data.elapsedSec)}</span>
        {!data.finishedAt && (
          <span className="inline-flex items-center gap-1.5 text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
            working
          </span>
        )}
      </div>

      <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all"
          style={{ width: `${pct}%` }}
        />
      </div>

      {data.stalled && (
        <Alert variant="destructive" className="mt-3">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>This run may have stopped</AlertTitle>
          <AlertDescription>
            No progress for over two minutes and the run never recorded a finish. The
            request was probably cut off — a closed laptop or a proxy timeout. Whatever
            already completed is safe, and provisioning is idempotent, so re-running the
            same list is the fix.
          </AlertDescription>
        </Alert>
      )}

      <ul className="mt-3 max-h-72 space-y-1 overflow-auto text-xs">
        {data.people.map((p) => {
          const finished = p.phase === "DONE"
          const slow = !finished && p.inPhaseSec > SLOW_PHASE_SEC
          return (
            <li key={p.person} className="flex flex-wrap items-baseline gap-x-2">
              {finished ? (
                <span className={`w-16 shrink-0 font-mono ${STATE_STYLE[p.state ?? "ERROR"] ?? ""}`}>
                  {p.state ?? "?"}
                </span>
              ) : (
                <span className="w-16 shrink-0 font-mono text-muted-foreground">···</span>
              )}
              <span className="font-mono">{p.person}</span>
              <span className="text-muted-foreground">
                {PHASE_LABEL[p.phase] ?? p.phase.toLowerCase()}
              </span>
              {/* The in-phase timer is the thing that distinguishes slow from stuck. */}
              <span className={slow ? "text-orange-700 dark:text-orange-300" : "text-muted-foreground"}>
                {finished ? mmss(p.totalSec) : `${mmss(p.inPhaseSec)} in this step`}
              </span>
              {p.detail && finished && p.state !== "OK" && (
                <span className="text-muted-foreground">— {p.detail}</span>
              )}
            </li>
          )
        })}
      </ul>

      {!data.finishedAt && data.people.some((p) => p.phase !== "DONE") && (
        <p className="mt-2 text-[0.7rem] leading-snug text-muted-foreground">
          Roughly 90 seconds per person is normal — most of it is spent resolving the
          name and repairing object ownership. Leave this tab open; progress is saved
          in Snowflake, so reloading picks it back up.
        </p>
      )}
    </div>
  )
}

function ResultList({ results }: { results: ActionResult[] }) {
  // Four states, not a boolean. PARTIAL used to render as FAIL, which made a
  // learner whose defaults merely failed to apply look identical to one who was
  // never created -- different problems with different fixes.
  return (
    <ul className="mt-3 max-h-56 space-y-1 overflow-auto rounded-md border bg-muted/40 p-3 font-mono text-xs leading-relaxed">
      {results.map((r) => {
        const state = r.state ?? (r.ok ? "OK" : "ERROR")
        return (
          <li key={r.person} className="flex flex-wrap items-baseline gap-x-2">
            <span className={`w-16 shrink-0 ${STATE_STYLE[state] ?? ""}`}>{state}</span>
            <span>{r.person}</span>
            <span className="whitespace-pre-wrap text-muted-foreground">{r.result}</span>
          </li>
        )
      })}
    </ul>
  )
}

export function AdminConsole() {
  const qc = useQueryClient()
  const session = useQuery({ queryKey: ["session"], queryFn: () => getJson("/api/session") })
  const roster = useQuery({ queryKey: ["roster"], queryFn: () => getJson("/api/roster") })
  const health = useQuery({ queryKey: ["health"], queryFn: () => getJson("/api/health") })

  const [blob, setBlob] = useState("")
  const people = useMemo(() => parsePeople(blob), [blob])

  // Resolve the preview against Snowflake instead of guessing in the browser.
  //
  // Naming anchors on the role a learner already holds, then on their resolved
  // username, so an email cannot be turned into a build space name client-side:
  // samson.stubbs@snowflake.com becomes WS_SSTUBBS, not WS_SAMSON_STUBBS. Debounced
  // because `people` changes on every keystroke in the textarea.
  const [settled, setSettled] = useState<string[]>([])
  useEffect(() => {
    const t = setTimeout(() => setSettled(people), 400)
    return () => clearTimeout(t)
  }, [people])

  const resolved = useQuery({
    queryKey: ["resolve", settled],
    enabled: settled.length > 0,
    queryFn: async () => {
      const res = await fetch("/api/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ people: settled }),
      })
      if (!res.ok) throw new Error("could not resolve names")
      return (await res.json()) as { resolved: ResolvedName[] }
    },
  })

  const resolvedFor = useMemo(() => {
    const m = new Map<string, ResolvedName>()
    for (const r of resolved.data?.resolved ?? []) m.set(r.person, r)
    return m
  }, [resolved.data])

  const [chosen, setChosen] = useState<string[]>([])
  const [chosenOrphans, setChosenOrphans] = useState<OrphanTarget[]>([])
  const [dropSchema, setDropSchema] = useState(false)
  const [confirm, setConfirm] = useState("")

  // The browser mints the run id so polling can start in the same tick as the
  // POST, instead of waiting for a response that only arrives when the whole batch
  // is already finished.
  const [runId, setRunId] = useState<string | null>(null)

  const provision = useMutation({
    mutationFn: () => {
      const id = crypto.randomUUID()
      setRunId(id)
      return postJson("/api/provision", { people, runId: id })
    },
    onSuccess: () => {
      setBlob("")
      qc.invalidateQueries({ queryKey: ["roster"] })
      // Health is NOT invalidated here on purpose. That route runs a
      // database-wide ownership audit, so refetching it the instant
      // provisioning ended made the UI look frozen for half a minute AFTER the
      // work was done -- a large part of the "is it stuck?" problem. The Health
      // tab has its own Refresh button.
    },
  })

  // Poll the durable phase log while a run is in flight, and once more after it
  // ends so the final states land. Stops on its own when the run records a finish.
  const progress = useQuery<ProgressData>({
    queryKey: ["provision-progress", runId],
    enabled: !!runId,
    queryFn: () => getJson(`/api/provision/status?run=${encodeURIComponent(runId!)}`),
    refetchInterval: (q) =>
      q.state.data?.finishedAt || q.state.data?.stalled ? false : 2000,
  })

  const deprovision = useMutation({
    mutationFn: () =>
      postJson("/api/deprovision", {
        people: chosen,
        orphans: chosenOrphans,
        dropSchema,
        confirm,
      }),
    onSuccess: () => {
      setChosen([])
      setChosenOrphans([])
      setConfirm("")
      setDropSchema(false)
      qc.invalidateQueries({ queryKey: ["roster"] })
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })

  const labProgress = useQuery({
    queryKey: ["lab-progress"],
    queryFn: () => getJson("/api/lab-progress"),
  })

  // Per-row progress reset. Keyed on "participant:training" rather than just the
  // learner, because one learner has one row per training and a reset is scoped to
  // the row the facilitator clicked.
  const [resetTarget, setResetTarget] = useState<string | null>(null)
  const resetProgress = useMutation({
    mutationFn: (vars: { participant: string; training: string }) =>
      postJson("/api/reset-progress", vars),
    onSuccess: () => {
      setResetTarget(null)
      qc.invalidateQueries({ queryKey: ["lab-progress"] })
      // Completion stamps feed the health card's honesty gates, so re-read those too.
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })

  // Ownership repair. Kept separate from provisioning even though provisioning
  // also repairs, because mid-workshop the useful action is "fix this now"
  // without re-running role and user changes for someone already set up.
  const [repairConfirm, setRepairConfirm] = useState(false)
  const repairOwnership = useMutation({
    mutationFn: () => postJson("/api/repair-ownership", { participant: "" }),
    onSuccess: () => {
      setRepairConfirm(false)
      // Re-read rather than assume: the procedure reports PARTIAL when the caller
      // lacked privilege to transfer something, and the card must show that.
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })
  const labRows = labProgress.data?.rows ?? []

  // ---- Role mismatch: per-role grant audit, and its two repairs ---------------
  //
  // enabled:false. This is a per-role sweep -- two SHOW GRANTS per learner inside
  // the procedure -- so it runs when asked, not on every page load. The health
  // card above stays fast.
  const roleAudit = useQuery({
    queryKey: ["role-audit"],
    enabled: false,
    queryFn: () => getJson("/api/role-audit"),
  })

  const [repairRoleConfirm, setRepairRoleConfirm] = useState(false)
  const repairRole = useMutation({
    // Empty role means every learner role AND the account-level EXECUTE TASK
    // grant. The per-role form deliberately leaves that account grant alone, so
    // repairing everything is the action worth offering from the card.
    mutationFn: () => postJson("/api/repair-role", { role: "" }),
    onSuccess: () => {
      setRepairRoleConfirm(false)
      // Re-read rather than assume. The procedure reports what it ATTEMPTED; the
      // audit is what confirms the account.
      roleAudit.refetch()
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })

  // Rename is a two-step confirmation, and the second step is a typed literal
  // rather than another button. It moves a learner's build schema, and a rename
  // does not update references -- so an accidental click is expensive in a way
  // that a grant repair is not.
  const [renameFrom, setRenameFrom] = useState<RoleAuditRow | null>(null)
  const [renameAck, setRenameAck] = useState("")
  const renameLearner = useMutation({
    mutationFn: (vars: { from: string; to: string }) => postJson("/api/rename-learner", vars),
    onSuccess: () => {
      setRenameFrom(null)
      setRenameAck("")
      roleAudit.refetch()
      qc.invalidateQueries({ queryKey: ["roster"] })
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })

  const auditRows: RoleAuditRow[] = roleAudit.data?.audit ?? []
  const auditProblems = auditRows.filter((r) => r.verdict !== "PASS")
  // Only rows the audit itself proposed a new name for. Never derive a rename
  // target in the browser: the naming rule lives in RESOLVE_LEARNER, and a
  // client-side guess would propose a name provisioning then disagrees with.
  const renameable = auditRows.filter(
    (r) => r.scope === "ROLE" && r.suggestedRole && r.suggestedRole !== r.role,
  )

  const rosterRows: RosterRow[] = roster.data?.rows ?? []
  const problems = rosterRows.filter((r) => !r.schemaExists || !r.hasUser)

  // Every row is removable, but not in the same way: rows with learners are removed
  // by name, rows with nobody attached are removed by literal role/schema. See
  // removalTarget().
  const targets = useMemo(
    () => rosterRows.map((r) => ({ row: r, ...removalTarget(r) })),
    [rosterRows],
  )
  const allUsers = useMemo(
    () => [...new Set(targets.flatMap((t) => t.users))],
    [targets],
  )
  const allOrphans = useMemo(
    () => targets.map((t) => t.orphan).filter((o): o is OrphanTarget => o !== null),
    [targets],
  )
  const selectedCount = chosen.length + chosenOrphans.length
  const selectableCount = allUsers.length + allOrphans.length

  // A refresh can retire a row (removed elsewhere, role revoked, schema dropped).
  // Drop it from the selection so Remove never acts on something no longer there.
  useEffect(() => {
    if (!roster.data) return
    setChosen((prev) => {
      const next = prev.filter((u) => allUsers.includes(u))
      return next.length === prev.length ? prev : next
    })
    setChosenOrphans((prev) => {
      const live = new Set(allOrphans.map(orphanKey))
      const next = prev.filter((o) => live.has(orphanKey(o)))
      return next.length === prev.length ? prev : next
    })
  }, [roster.data, allUsers, allOrphans])

  return (
    <div className="space-y-6">
      {/* Session strip */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-1 text-sm text-muted-foreground">
        <span>
          Signed in as <strong className="text-foreground">{session.data?.user ?? "…"}</strong>
        </span>
        <span>
          Active role <strong className="text-foreground">{session.data?.activeRole ?? "…"}</strong>
        </span>
        {session.data?.authorizedVia && (
          <Badge variant="outline">authorized via {session.data.authorizedVia}</Badge>
        )}
      </div>

      {/* Authorized, but on a role they hold rather than their active one. Not a
          problem -- admin work runs as the app owner -- but say so out loud so the
          elevation is never silent. */}
      {session.data?.authorized && session.data.activeRoleQualifies === false && (
        <Alert>
          <ShieldCheck className="h-4 w-4" />
          <AlertTitle>Authorized via a role you hold</AlertTitle>
          <AlertDescription>
            Your active role is <strong>{session.data.activeRole}</strong>, which is not an admin
            role — but you hold <strong>{session.data.authorizedVia}</strong>, so this console is
            open to you. You do not need to switch roles: administrative work here runs as the
            app&apos;s owner, and every action is logged against your username.
          </AlertDescription>
        </Alert>
      )}

      {session.data && !session.data.authorized && (
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Not authorized — this is a permissions issue, not a broken app</AlertTitle>
          <AlertDescription className="space-y-3">
            <p>
              This console creates roles and drops schemas, so it is limited to{" "}
              {(session.data.adminRoles ?? ADMIN_ROLES_FALLBACK).map((r: string, i: number) => (
                <span key={r}>
                  {i > 0 && " and "}
                  <strong>{r}</strong>
                </span>
              ))}
              . Your Snowflake user <strong>{session.data.user}</strong> holds neither.
            </p>
            <p>
              To fix it, ask an administrator to run this once — then reload the page:
            </p>
            <pre className="overflow-x-auto rounded bg-muted/40 p-2 text-xs text-foreground">
              GRANT ROLE {session.data.grantableRole ?? "SNOWCUP_FACILITATOR"} TO USER{" "}
              {session.data.user};
            </pre>
            {(session.data.availableRoles?.length ?? 0) > 0 && (
              <details className="text-xs">
                <summary className="cursor-pointer">
                  Roles you do hold ({session.data.availableRoles.length}) — checked so you can rule
                  out a wrong-role mix-up
                </summary>
                <p className="mt-2 break-words font-mono">
                  {session.data.availableRoles.join(", ")}
                </p>
              </details>
            )}
            {session.data.roleDiscoveryDegraded && (
              <p className="text-xs">
                This session could not list the roles you hold, so only your active role was
                checked. If you know you hold one of the roles above, switching to it should also
                let you in.
              </p>
            )}
          </AlertDescription>
        </Alert>
      )}

      {(session.error || roster.error || health.error) && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Query problem</AlertTitle>
          <AlertDescription>
            {String(
              (session.error as Error)?.message ||
                (roster.error as Error)?.message ||
                (health.error as Error)?.message,
            )}
          </AlertDescription>
        </Alert>
      )}

      {session.data?.authorized !== false && (
      <Tabs defaultValue="add">
        <TabsList>
          <TabsTrigger value="add">Add learners</TabsTrigger>
          <TabsTrigger value="roster">Roster</TabsTrigger>
          <TabsTrigger value="progress">Lab progress</TabsTrigger>
          <TabsTrigger value="health">Environment health</TabsTrigger>
        </TabsList>

        {/* ---------------------------------------------------------- add */}
        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle>Add learners</CardTitle>
              <CardDescription>
                One per line, or comma separated. Snowflake usernames or email-style logins both
                work. Re-adding someone is harmless — provisioning is idempotent.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={blob}
                onChange={(e) => setBlob(e.target.value)}
                rows={6}
                placeholder={"ada.lovelace@example.com\ngrace.hopper@example.com\nBJONES"}
              />

              {people.length > 0 && (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Learner</TableHead>
                        <TableHead>Schema</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>How</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {people.map((p) => (
                        <TableRow key={p}>
                          <TableCell>{p}</TableCell>
                          <TableCell className="font-mono text-xs">
                            {resolvedFor.get(p)?.schema ??
                              `${BUILDS_DB}.${SCHEMA_PREFIX}${suffixFor(p)}`}
                          </TableCell>
                          <TableCell className="font-mono text-xs">
                            {resolvedFor.get(p)?.role ??
                              `${ROLE_PREFIX}${suffixFor(p)}`}
                          </TableCell>
                          <TableCell className="text-xs">
                            {resolveNote(resolvedFor.get(p), resolved.isFetching)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              <Button
                onClick={() => provision.mutate()}
                disabled={!people.length || provision.isPending}
              >
                {provision.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    Provisioning…
                  </>
                ) : (
                  `Provision ${people.length || ""}`.trim()
                )}
              </Button>

              {/* Live position within the run. Rendered from the durable phase log,
                  so it keeps working across a reload and shows where a killed
                  request stopped. */}
              <ProvisionProgress data={progress.data} pending={provision.isPending} />

              {provision.error && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{(provision.error as Error).message}</AlertDescription>
                </Alert>
              )}

              {provision.data && (
                <>
                  {/* One shared cause, stated once. A suspended warehouse or a missing
                      setup script fails every learner identically, and with four
                      running at a time it produces four cryptic rows at once -- so say
                      what is actually wrong instead of leaving the operator to diff
                      the list and conclude the NAMES were bad. */}
                  {provision.data.systemic && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>{provision.data.systemic.title}</AlertTitle>
                      <AlertDescription>
                        {provision.data.systemic.cause}{" "}
                        {provision.data.systemic.action && (
                          <strong>{provision.data.systemic.action}</strong>
                        )}
                        <span className="mt-1 block text-xs">
                          Affected {provision.data.systemic.affected} of {people.length}. These
                          are not name problems — fixing the cause above and re-running is
                          safe, because provisioning is idempotent.
                        </span>
                      </AlertDescription>
                    </Alert>
                  )}

                  <ResultList results={provision.data.results} />
                  {provision.data.failed === 0 ? (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>
                        Provisioned {provision.data.provisioned}. Send them the lab and their schema
                        name.
                        {provision.data.partial > 0 && (
                          <>
                            {" "}
                            {provision.data.partial} came back PARTIAL — their schema and role exist,
                            but something else did not finish, usually the session defaults. Those
                            learners will land in Cortex Code on the wrong role until it is fixed.
                          </>
                        )}
                        {provision.data.skipped > 0 && (
                          <> {provision.data.skipped} skipped (your own user, or a facilitator).</>
                        )}
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        {provision.data.failed} entr(y/ies) failed — see the output above.
                      </AlertDescription>
                    </Alert>
                  )}
                  {/* Result of the single batch-wide ownership sweep. Per-learner sweeps
                      are skipped for schemas that were just created, so this line is
                      where mis-ownership across ALL build schemas gets reported. */}
                  {provision.data.sweep && (
                    <p className="text-xs text-muted-foreground">
                      Ownership across all build schemas:{" "}
                      <span className="font-mono">{provision.data.sweep}</span>
                    </p>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ------------------------------------------------------- roster */}
        <TabsContent value="roster">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Roster</CardTitle>
                <CardDescription>
                  Who is set up, what is missing, and who to remove.
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => qc.invalidateQueries({ queryKey: ["roster"] })}
                disabled={roster.isFetching}
              >
                <RefreshCw className={`h-4 w-4 ${roster.isFetching ? "animate-spin" : ""}`} />
                Refresh
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {roster.isLoading ? (
                <p className="text-sm text-muted-foreground">Loading roster…</p>
              ) : rosterRows.length === 0 ? (
                <Alert>
                  <AlertDescription>
                    Nobody is provisioned yet. Use the <strong>Add learners</strong> tab.
                  </AlertDescription>
                </Alert>
              ) : (
                <>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-10">
                            <Checkbox
                              aria-label="Select all rows"
                              disabled={selectableCount === 0}
                              checked={
                                selectableCount > 0 && selectedCount === selectableCount
                              }
                              onCheckedChange={(v) => {
                                setChosen(v ? allUsers : [])
                                setChosenOrphans(v ? allOrphans : [])
                              }}
                            />
                          </TableHead>
                          <TableHead>Learner</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Schema</TableHead>
                          <TableHead>Schema exists</TableHead>
                          <TableHead>Has a user</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {targets.map(({ row: r, users, orphan }) => {
                          const selected = users.length
                            ? users.every((u) => chosen.includes(u))
                            : orphan
                              ? chosenOrphans.some((o) => orphanKey(o) === orphanKey(orphan))
                              : false
                          return (
                            <TableRow key={`${r.role}-${r.schema}`}>
                              <TableCell>
                                <Checkbox
                                  aria-label={`Select ${r.learner}`}
                                  disabled={!users.length && !orphan}
                                  checked={selected}
                                  onCheckedChange={(v) => {
                                    if (users.length) {
                                      setChosen((prev) =>
                                        v
                                          ? [...new Set([...prev, ...users])]
                                          : prev.filter((x) => !users.includes(x)),
                                      )
                                    } else if (orphan) {
                                      setChosenOrphans((prev) =>
                                        v
                                          ? [
                                              ...prev.filter(
                                                (o) => orphanKey(o) !== orphanKey(orphan),
                                              ),
                                              orphan,
                                            ]
                                          : prev.filter(
                                              (o) => orphanKey(o) !== orphanKey(orphan),
                                            ),
                                      )
                                    }
                                  }}
                                />
                              </TableCell>
                              <TableCell>
                                {r.hasUser ? (
                                  r.learner
                                ) : (
                                  <span className="text-muted-foreground">
                                    {r.learner} <Badge variant="outline">orphan</Badge>
                                  </span>
                                )}
                              </TableCell>
                              <TableCell className="font-mono text-xs">{r.role}</TableCell>
                              <TableCell className="font-mono text-xs">{r.schema}</TableCell>
                              <TableCell>
                                {r.schemaExists ? (
                                  "yes"
                                ) : (
                                  <Badge variant="destructive">MISSING</Badge>
                                )}
                              </TableCell>
                              <TableCell>
                                {r.hasUser ? "yes" : <Badge variant="destructive">NO</Badge>}
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>
                  {problems.length === 0 ? (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>
                        {rosterRows.length} learner(s), all complete.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        {problems.length} row(s) need attention — see MISSING / NO above.
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* ----------------------------------------------- removal */}
                  <div className="space-y-4 rounded-md border border-destructive/40 p-4">
                    <div>
                      <h3 className="text-sm font-semibold">Remove</h3>
                      <p className="text-xs text-muted-foreground">
                        Revoke access for the ticked learners, and delete build spaces
                        marked <strong>orphan</strong> — a role or schema with nobody
                        attached.
                      </p>
                    </div>

                    {selectedCount === 0 ? (
                      <p className="text-sm text-muted-foreground">
                        Tick a row above to remove it.
                      </p>
                    ) : (
                      <>
                        {chosen.length > 0 && (
                          <p className="text-sm">
                            {chosen.length} learner(s):{" "}
                            <span className="font-mono text-xs">{chosen.join(", ")}</span>
                          </p>
                        )}
                        {chosenOrphans.length > 0 && (
                          <p className="text-sm">
                            {chosenOrphans.length} orphan(s):{" "}
                            <span className="font-mono text-xs">
                              {chosenOrphans.map((o) => o.role ?? o.schema).join(", ")}
                            </span>
                          </p>
                        )}

                        {chosen.length > 0 && (
                          <label className="flex items-start gap-2 text-sm">
                            <Checkbox
                              checked={dropSchema}
                              onCheckedChange={(v) => setDropSchema(v === true)}
                            />
                            <span>
                              Also delete their build schema and role
                              <span className="block text-xs text-muted-foreground">
                                Leave unticked to revoke access but keep everything they
                                built. Applies to learners only — orphans have no access
                                to revoke, so they are always deleted outright.
                              </span>
                            </span>
                          </label>
                        )}

                        {(dropSchema || chosenOrphans.length > 0) && (
                          <Alert variant="destructive">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertTitle>This permanently deletes work</AlertTitle>
                            <AlertDescription>
                              {dropSchema && chosen.length > 0 && (
                                <>
                                  The build schema for {chosen.length} learner(s) will be
                                  dropped, including any semantic view, search service,
                                  custom tool and agent inside it.{" "}
                                </>
                              )}
                              {chosenOrphans.length > 0 && (
                                <>
                                  {chosenOrphans.length} orphan build space(s) will be
                                  dropped outright. A refusal here means someone was granted
                                  the role since this roster was read.
                                </>
                              )}
                            </AlertDescription>
                          </Alert>
                        )}

                        <div className="space-y-2">
                          <Label htmlFor="confirm">Type REMOVE to confirm</Label>
                          <Input
                            id="confirm"
                            value={confirm}
                            onChange={(e) => setConfirm(e.target.value)}
                            placeholder="REMOVE"
                            className="max-w-xs"
                          />
                        </div>

                        <Button
                          variant="destructive"
                          onClick={() => deprovision.mutate()}
                          disabled={
                            confirm.trim().toUpperCase() !== "REMOVE" || deprovision.isPending
                          }
                        >
                          {deprovision.isPending ? "Removing\u2026" : "Remove"}
                        </Button>
                      </>
                    )}

                    {deprovision.error && (
                      <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          {(deprovision.error as Error).message}
                        </AlertDescription>
                      </Alert>
                    )}

                    {deprovision.data && (
                      <>
                        <ResultList results={deprovision.data.results} />
                        <p className="text-xs text-muted-foreground">
                          Their challenge score is intentionally left in place. Clear it with{" "}
                          <code className="font-mono">
                            DELETE FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_PROGRESS WHERE
                            PARTICIPANT ILIKE &apos;…&apos;
                          </code>
                        </p>
                      </>
                    )}
                  </div>

                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ------------------------------------------------------- health */}
        <TabsContent value="progress">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Lab progress</CardTitle>
                <CardDescription>
                  One row per learner per training: checkpoints ticked, reinforcement quiz
                  answers and challenge answers, all three of which are required to complete.
                  Anyone who has opened the lab appears here, so a row with 0 done means they
                  started and stalled rather than never arrived. &ldquo;Awaiting answers&rdquo;
                  means every checkpoint is done and only a quiz or challenge answer is
                  holding them back.
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => qc.invalidateQueries({ queryKey: ["lab-progress"] })}
                disabled={labProgress.isFetching}
              >
                <RefreshCw className={`h-4 w-4 ${labProgress.isFetching ? "animate-spin" : ""}`} />
              </Button>
            </CardHeader>
            <CardContent>
              {labProgress.isLoading && <Skeleton className="h-24 w-full" />}
              {!labProgress.isLoading && labRows.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  Nobody has opened the lab app yet. Progress appears here as soon as a learner
                  loads it.
                </p>
              )}
              {labRows.length > 0 && (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Learner</TableHead>
                      <TableHead>Training</TableHead>
                      <TableHead>Checkpoints</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Questions</TableHead>
                      <TableHead>Quiz</TableHead>
                      <TableHead>Challenge</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Completed</TableHead>
                      <TableHead>Last active</TableHead>
                      <TableHead className="text-right">Reset</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {labRows.map((r: any) => (
                      // Keyed on learner AND training: one learner can appear
                      // once per training they have taken.
                      <TableRow key={`${r.participant}:${r.training}`}>
                        <TableCell className="font-medium">{r.participant}</TableCell>
                        <TableCell className="text-xs">{r.trainingTitle}</TableCell>
                        <TableCell>
                          {r.stepsDone}/{r.stepsTotal}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="h-1.5 w-24 overflow-hidden rounded-full bg-muted">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-sky-500 to-violet-500"
                                style={{ width: `${r.percentComplete}%` }}
                              />
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {r.percentComplete}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {r.questionsCorrect}/{r.questionsTotal}
                        </TableCell>
                        <TableCell>
                          {r.quizTotal > 0 ? `${r.quizCorrect}/${r.quizTotal}` : "—"}
                        </TableCell>
                        <TableCell>{r.challengePoints} pts</TableCell>
                        <TableCell>
                          {/* "awaiting answers" is called out rather than folded into
                              "in progress": these are the learners who have finished
                              every checkpoint and only need a question corrected, so
                              they are the ones worth chasing. */}
                          <Badge
                            variant={
                              r.status === "complete"
                                ? "default"
                                : r.status === "awaiting answers"
                                  ? "secondary"
                                  : "outline"
                            }
                            className={
                              r.status === "not started" ? "text-muted-foreground" : undefined
                            }
                          >
                            {r.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {r.completedAt ?? "—"}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {r.lastSeenAt ?? "—"}
                        </TableCell>
                        <TableCell className="text-right">
                          {/* Two-step rather than one click: this deletes their
                              scores. Not a type-to-confirm like Deprovision,
                              because nothing they BUILT is lost -- they can simply
                              work the lab again. */}
                          {resetTarget === `${r.participant}:${r.training}` ? (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() =>
                                  resetProgress.mutate({
                                    participant: r.participant,
                                    training: r.training,
                                  })
                                }
                                disabled={resetProgress.isPending}
                                className="rounded-md border border-destructive/50 px-2 py-1 text-xs font-medium text-destructive hover:bg-destructive/10 disabled:opacity-50"
                              >
                                {resetProgress.isPending ? "Resetting…" : "Confirm reset"}
                              </button>
                              <button
                                type="button"
                                onClick={() => setResetTarget(null)}
                                disabled={resetProgress.isPending}
                                className="rounded-md border border-border px-2 py-1 text-xs hover:bg-muted/60 disabled:opacity-50"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() =>
                                setResetTarget(`${r.participant}:${r.training}`)
                              }
                              className="rounded-md border border-border px-2 py-1 text-xs text-muted-foreground hover:bg-muted/60"
                            >
                              Reset scores
                            </button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="health">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Environment health</CardTitle>
                <CardDescription>Is the workshop actually ready to hand off?</CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => qc.invalidateQueries({ queryKey: ["health"] })}
                disabled={health.isFetching}
              >
                <RefreshCw className={`h-4 w-4 ${health.isFetching ? "animate-spin" : ""}`} />
                Re-check
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {health.isLoading ? (
                <p className="text-sm text-muted-foreground">Running checks…</p>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                    <Metric label="Learners" value={health.data?.metrics.learners} />
                    <Metric
                      label="Shared tables"
                      value={health.data?.metrics.tables}
                      note={health.data?.metrics.tables === 6 ? undefined : "expected 6"}
                    />
                    <Metric
                      label="Players"
                      value={health.data?.metrics.players}
                      note={health.data?.metrics.players === 48 ? undefined : "expected 48"}
                    />
                    <Metric
                      label="Answer key"
                      value={`${health.data?.metrics.keyRows} Q / ${health.data?.metrics.keyPts} pts`}
                    />
                  </div>

                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Check</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Detail</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(health.data?.checks ?? []).map((c: any) => (
                          <TableRow key={c.check}>
                            <TableCell>{c.check}</TableCell>
                            <TableCell>
                              {c.ok ? (
                                <span className="inline-flex items-center gap-1 text-sm font-medium text-emerald-600 dark:text-emerald-400">
                                  <CheckCircle2 className="h-4 w-4" /> PASS
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-sm font-medium text-destructive">
                                  <XCircle className="h-4 w-4" /> FAIL
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {c.detail}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {(health.data?.misOwned ?? []).length > 0 && (
                    <div className="space-y-3 rounded-md border border-destructive/40 p-4">
                      <div>
                        <p className="text-sm font-medium">
                          {(health.data?.misOwned ?? []).length} object(s) not owned by the
                          learner who needs them
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          These were created inside a learner&apos;s build schema by another
                          role — usually a facilitator on ACCOUNTADMIN. The learner holds no
                          privilege on them and gets no error explaining why: the schema just
                          looks empty, or their agent reports its search service does not
                          exist. Repairing hands each object to that learner&apos;s own role.
                        </p>
                      </div>

                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Kind</TableHead>
                              <TableHead>Object</TableHead>
                              <TableHead>Owned by</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {(health.data?.misOwned ?? []).map((o: any) => (
                              <TableRow key={`${o.kind}-${o.sch}-${o.obj}`}>
                                <TableCell className="text-sm">{o.kind}</TableCell>
                                <TableCell className="font-mono text-xs">
                                  {o.sch}.{o.obj}
                                </TableCell>
                                <TableCell className="text-sm text-muted-foreground">
                                  {o.owner}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>

                      {repairOwnership.data?.result && (
                        <Alert variant={repairOwnership.data.ok ? "default" : "destructive"}>
                          {repairOwnership.data.ok ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <XCircle className="h-4 w-4" />
                          )}
                          <AlertDescription className="text-xs">
                            {repairOwnership.data.result}
                          </AlertDescription>
                        </Alert>
                      )}
                      {repairOwnership.error && (
                        <Alert variant="destructive">
                          <XCircle className="h-4 w-4" />
                          <AlertDescription className="text-xs">
                            {(repairOwnership.error as Error).message}
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* Confirm step: this changes grants, so it is not a one-click
                          action even though it is a repair rather than a deletion. */}
                      {repairConfirm ? (
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm">
                            Transfer ownership of these objects to their learners?
                          </span>
                          <Button
                            size="sm"
                            onClick={() => repairOwnership.mutate()}
                            disabled={repairOwnership.isPending}
                          >
                            {repairOwnership.isPending ? "Repairing…" : "Yes, repair"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setRepairConfirm(false)}
                            disabled={repairOwnership.isPending}
                          >
                            Cancel
                          </Button>
                        </div>
                      ) : (
                        <Button size="sm" onClick={() => setRepairConfirm(true)}>
                          Repair ownership
                        </Button>
                      )}
                    </div>
                  )}

                  {health.data?.ready ? (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>Environment is ready to hand off.</AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <XCircle className="h-4 w-4" />
                      <AlertDescription>
                        One or more checks failed — see Detail above.
                      </AlertDescription>
                    </Alert>
                  )}

                  <p className="text-xs text-muted-foreground">
                    Learner progress lives in SNOWCUP_WORKSHOP.GRADING.BUILDER_PROGRESS (one row per
                    learner per module, with percent complete).
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          {/* Role mismatch. A SEPARATE CARD, not another health check, because the
              sweep costs two SHOW GRANTS per learner and the checks above run on
              every page load. It answers a different question too: health asks
              "is the environment ready", this asks "does each learner role still
              hold what the lab needs". */}
          <Card className="mt-6">
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Role mismatch</CardTitle>
                <CardDescription>
                  Does every learner role still hold the full lab contract, and is it named
                  the way provisioning would name it today?
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => roleAudit.refetch()}
                disabled={roleAudit.isFetching}
              >
                <RefreshCw className={`h-4 w-4 ${roleAudit.isFetching ? "animate-spin" : ""}`} />
                {roleAudit.isFetched ? "Re-scan" : "Scan roles"}
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {!roleAudit.isFetched && !roleAudit.isFetching ? (
                <p className="text-sm text-muted-foreground">
                  Not scanned yet. This checks every learner role individually — the twelve
                  privileges on their own build schema, the shared role nesting, Cortex access,
                  facilitator oversight, who holds it, and whether one person ended up with two
                  build spaces. Nothing is changed by scanning.
                </p>
              ) : roleAudit.isFetching ? (
                <p className="text-sm text-muted-foreground">Checking every learner role…</p>
              ) : roleAudit.error ? (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    {(roleAudit.error as Error).message}
                  </AlertDescription>
                </Alert>
              ) : (
                <>
                  {/* FOUR columns, and the detail on its own full-width sub-row.
                      It was a fifth column and that did not fit: the table's
                      intrinsic width was 928px inside a 791px card, so every PASS
                      row read "holds the f…" and a FAIL row's privilege list was
                      squashed into 219px and clipped -- the one thing you actually
                      need to read was the one thing you could not. A colSpan row
                      removes the width pressure instead of fighting it. */}
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Role</TableHead>
                          <TableHead>Holder</TableHead>
                          <TableHead>Named from</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {auditRows.map((r) => {
                          // A PASS row whose detail is just the default sentence
                          // says nothing worth a second line. Anything else -- a
                          // gap, or a note about a non-standard but valid shape --
                          // gets shown in full.
                          const showDetail = r.gaps !== "holds the full lab contract"
                          return (
                            <Fragment key={`${r.scope}-${r.role}-${r.holder ?? ""}`}>
                              <TableRow className={showDetail ? "border-b-0" : undefined}>
                                <TableCell className="font-mono text-xs">{r.role}</TableCell>
                                <TableCell className="text-sm">{r.holder ?? "—"}</TableCell>
                                <TableCell className="text-sm">
                                  {/* 'both' and 'username' are the correct states and
                                      get no emphasis. 'email' and 'login' mean the role
                                      predates the current naming rule, which is worth
                                      seeing but is NOT a fault on its own. */}
                                  {r.nameBasis === "email" || r.nameBasis === "login" ? (
                                    <Badge variant="secondary">{r.nameBasis}</Badge>
                                  ) : (
                                    <span className="text-muted-foreground">{r.nameBasis}</span>
                                  )}
                                </TableCell>
                                <TableCell className="whitespace-nowrap">
                                  {r.verdict === "PASS" ? (
                                    <span className="inline-flex items-center gap-1 text-sm font-medium text-emerald-600 dark:text-emerald-400">
                                      <CheckCircle2 className="h-4 w-4" /> PASS
                                    </span>
                                  ) : r.verdict === "UNVERIFIED" ? (
                                    /* Deliberately NOT green. A gate that could not
                                       be evaluated is not a gate that passed. */
                                    <span className="inline-flex items-center gap-1 text-sm font-medium text-amber-600 dark:text-amber-400">
                                      <AlertTriangle className="h-4 w-4" /> UNVERIFIED
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 text-sm font-medium text-destructive">
                                      <XCircle className="h-4 w-4" /> FAIL
                                    </span>
                                  )}
                                </TableCell>
                              </TableRow>
                              {showDetail && (
                                <TableRow>
                                  <TableCell
                                    colSpan={4}
                                    className="px-4 pb-4 pt-0 text-sm text-muted-foreground break-words"
                                  >
                                    {r.gaps}
                                  </TableCell>
                                </TableRow>
                              )}
                            </Fragment>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>

                  {roleAudit.data?.clean ? (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>
                        Every learner role holds the full lab contract.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <XCircle className="h-4 w-4" />
                      <AlertDescription>
                        {auditProblems.length} row(s) need attention — see Detail above.
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* ---- Repair grants: one confirmation ------------------- */}
                  {auditProblems.some((r) => r.scope !== "DUPLICATE") && (
                    <div className="space-y-3 rounded-md border p-4">
                      <div>
                        <p className="text-sm font-medium">Restore the missing grants</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          Re-grants the twelve build privileges, the shared role nesting, Cortex
                          access and facilitator oversight on every learner role, plus the
                          account-level EXECUTE TASK grant the Module 8 and 10 evaluations need.
                          Idempotent, and it changes nothing a role already holds. This does not
                          rename anything and does not touch anyone&apos;s work.
                        </p>
                      </div>

                      {repairRole.data?.result && (
                        <Alert variant={repairRole.data.ok ? "default" : "destructive"}>
                          {repairRole.data.ok ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <XCircle className="h-4 w-4" />
                          )}
                          <AlertDescription className="text-xs">
                            {repairRole.data.result}
                          </AlertDescription>
                        </Alert>
                      )}
                      {repairRole.error && (
                        <Alert variant="destructive">
                          <XCircle className="h-4 w-4" />
                          <AlertDescription className="text-xs">
                            {(repairRole.error as Error).message}
                          </AlertDescription>
                        </Alert>
                      )}

                      {repairRoleConfirm ? (
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm">
                            Re-grant the lab contract on every learner role?
                          </span>
                          <Button
                            size="sm"
                            onClick={() => repairRole.mutate()}
                            disabled={repairRole.isPending}
                          >
                            {repairRole.isPending ? "Repairing…" : "Yes, repair grants"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setRepairRoleConfirm(false)}
                            disabled={repairRole.isPending}
                          >
                            Cancel
                          </Button>
                        </div>
                      ) : (
                        <Button size="sm" onClick={() => setRepairRoleConfirm(true)}>
                          Repair grants
                        </Button>
                      )}
                    </div>
                  )}

                  {/* ---- Rename: two confirmations, and only when the audit
                          proposed a name. A rename moves a learner's build
                          schema and does NOT update references, so it is
                          deliberately harder to do than a grant repair. ---- */}
                  {renameable.length > 0 && (
                    <div className="space-y-3 rounded-md border border-amber-500/40 p-4">
                      <div>
                        <p className="text-sm font-medium">
                          {renameable.length} role(s) named under an older rule
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          These were named from the holder&apos;s email address; provisioning
                          today names them from their Snowflake username. They work as they are
                          — renaming is cosmetic, and the reason to do it is that re-running
                          provisioning for someone whose name no longer matches can mint them a
                          second build space. The role and its schema are renamed together and
                          in place, so the learner keeps everything they have built.
                        </p>
                      </div>

                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Current</TableHead>
                              <TableHead>Proposed</TableHead>
                              <TableHead>Objects at risk</TableHead>
                              <TableHead />
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {renameable.map((r) => (
                              <TableRow key={r.role}>
                                <TableCell className="font-mono text-xs">{r.role}</TableCell>
                                <TableCell className="font-mono text-xs">
                                  {r.suggestedRole}
                                </TableCell>
                                <TableCell className="text-sm text-muted-foreground">
                                  {r.objCount === 0
                                    ? "empty schema"
                                    : `${r.objCount} object(s) — references need re-pointing`}
                                </TableCell>
                                <TableCell>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setRenameFrom(r)
                                      setRenameAck("")
                                    }}
                                    disabled={renameLearner.isPending}
                                  >
                                    Rename…
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>

                      {renameLearner.data?.result && (
                        <Alert variant={renameLearner.data.ok ? "default" : "destructive"}>
                          {renameLearner.data.ok ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <XCircle className="h-4 w-4" />
                          )}
                          <AlertDescription className="text-xs">
                            {renameLearner.data.result}
                          </AlertDescription>
                        </Alert>
                      )}
                      {renameLearner.error && (
                        <Alert variant="destructive">
                          <XCircle className="h-4 w-4" />
                          <AlertDescription className="text-xs">
                            {(renameLearner.error as Error).message}
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* SECOND confirmation, and it is a typed literal rather
                          than a button. The schema moves with the role, and any
                          semantic view, search service or agent naming the old
                          schema in full stops resolving until it is re-pointed.
                          A row with objects in it must not be one click away. */}
                      {renameFrom && (
                        <div className="space-y-2 rounded-md border border-destructive/50 p-3">
                          <p className="text-sm">
                            Rename{" "}
                            <span className="font-mono text-xs">{renameFrom.role}</span> and its
                            build schema to{" "}
                            <span className="font-mono text-xs">{renameFrom.suggestedRole}</span>?
                          </p>
                          {renameFrom.objCount > 0 && (
                            <p className="text-xs text-destructive">
                              {renameFrom.objCount} object(s) live in that schema. A rename does
                              not update references, so any semantic view, Cortex Search Service
                              or agent that names the old schema in full must be re-pointed
                              afterwards. Their session defaults are moved automatically.
                            </p>
                          )}
                          <Label htmlFor="rename-ack" className="text-xs">
                            Type RENAME to confirm
                          </Label>
                          <Input
                            id="rename-ack"
                            value={renameAck}
                            onChange={(e) => setRenameAck(e.target.value)}
                            placeholder="RENAME"
                            className="max-w-40"
                          />
                          <div className="flex flex-wrap items-center gap-2">
                            <Button
                              size="sm"
                              variant="destructive"
                              disabled={renameAck.trim().toUpperCase() !== "RENAME" || renameLearner.isPending}
                              onClick={() =>
                                renameLearner.mutate({
                                  from: renameFrom.role,
                                  to: renameFrom.suggestedRole ?? "",
                                })
                              }
                            >
                              {renameLearner.isPending ? "Renaming…" : "Rename role and schema"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setRenameFrom(null)
                                setRenameAck("")
                              }}
                              disabled={renameLearner.isPending}
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {auditRows.some((r) => r.scope === "DUPLICATE") && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Someone holds two build spaces</AlertTitle>
                      <AlertDescription className="text-xs">
                        There is no button for this on purpose. Both schemas may contain work,
                        and only a human can decide which one survives — picking automatically
                        would strand the other half. Consolidate the work into one build space,
                        revoke the spare role, then re-scan.
                      </AlertDescription>
                    </Alert>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      )}
    </div>
  )
}

function Metric({
  label,
  value,
  note,
}: {
  label: string
  value: React.ReactNode
  note?: string
}) {
  return (
    <div className="rounded-lg border p-3">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value ?? "—"}</div>
      {note && <div className="text-xs text-destructive">{note}</div>}
    </div>
  )
}
