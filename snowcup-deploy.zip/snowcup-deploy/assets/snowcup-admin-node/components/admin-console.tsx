"use client"

import { useMemo, useState } from "react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import {
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  XCircle,
} from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

const BUILDS_DB = "SNOWCUP_BUILDS"
const ROLE_PREFIX = "SNOWCUP_WS_"
const SCHEMA_PREFIX = "WS_"
/** Only used if the session route somehow omits the list. */
const ADMIN_ROLES_FALLBACK = ["ACCOUNTADMIN", "SNOWCUP_FACILITATOR"]

function suffixFor(name: string) {
  return name.split("@")[0].toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "")
}

function parsePeople(blob: string) {
  const seen = new Set<string>()
  const out: string[] = []
  for (const raw of (blob ?? "").split(/[,;\n\r]+/)) {
    const p = raw.trim()
    if (p && !seen.has(p.toUpperCase())) {
      seen.add(p.toUpperCase())
      out.push(p)
    }
  }
  return out
}

async function getJson(url: string) {
  const res = await fetch(url)
  const body = await res.json()
  if (!res.ok) throw new Error(body?.error ?? `${url} failed`)
  return body
}

async function postJson(url: string, payload: unknown) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
  const body = await res.json()
  if (!res.ok) throw new Error(body?.error ?? `${url} failed`)
  return body
}

type ActionResult = { person: string; result: string; ok: boolean }

function ResultList({ results }: { results: ActionResult[] }) {
  return (
    <pre className="mt-3 max-h-56 overflow-auto rounded-md border bg-muted/40 p-3 text-xs leading-relaxed">
      {results.map((r) => `${r.ok ? "OK  " : "FAIL"}  ${r.person}  ${r.result}`).join("\n")}
    </pre>
  )
}

export function AdminConsole() {
  const qc = useQueryClient()
  const session = useQuery({ queryKey: ["session"], queryFn: () => getJson("/api/session") })
  const roster = useQuery({ queryKey: ["roster"], queryFn: () => getJson("/api/roster") })
  const health = useQuery({ queryKey: ["health"], queryFn: () => getJson("/api/health") })

  const [blob, setBlob] = useState("")
  const people = useMemo(() => parsePeople(blob), [blob])

  const [chosen, setChosen] = useState<string[]>([])
  const [dropSchema, setDropSchema] = useState(false)
  const [confirm, setConfirm] = useState("")

  const provision = useMutation({
    mutationFn: () => postJson("/api/provision", { people }),
    onSuccess: () => {
      setBlob("")
      qc.invalidateQueries({ queryKey: ["roster"] })
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })

  const deprovision = useMutation({
    mutationFn: () => postJson("/api/deprovision", { people: chosen, dropSchema, confirm }),
    onSuccess: () => {
      setChosen([])
      setConfirm("")
      setDropSchema(false)
      qc.invalidateQueries({ queryKey: ["roster"] })
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })

  const labProgress = useQuery({
    queryKey: ["lab-progress"],
    queryFn: () => getJson("/api/lab-progress"),
  })

  // Ownership repair. Kept separate from provisioning even though provisioning
  // also repairs, because mid-workshop the useful action is "fix this now"
  // without re-running role and user changes for someone already set up.
  const [repairConfirm, setRepairConfirm] = useState(false)
  const repairOwnership = useMutation({
    mutationFn: () => postJson("/api/repair-ownership", { participant: "" }),
    onSuccess: () => {
      setRepairConfirm(false)
      // Re-read rather than assume: the procedure reports PARTIAL when the caller
      // lacked privilege to transfer something, and the card must show that.
      qc.invalidateQueries({ queryKey: ["health"] })
    },
  })
  const labRows = labProgress.data?.rows ?? []

  const rosterRows = roster.data?.rows ?? []
  const everyone: string[] = roster.data?.everyone ?? []
  const problems = rosterRows.filter((r: any) => !r.schemaExists || !r.hasUser)

  return (
    <div className="space-y-6">
      {/* Session strip */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-1 text-sm text-muted-foreground">
        <span>
          Signed in as <strong className="text-foreground">{session.data?.user ?? "…"}</strong>
        </span>
        <span>
          Active role <strong className="text-foreground">{session.data?.activeRole ?? "…"}</strong>
        </span>
        {session.data?.authorizedVia && (
          <Badge variant="outline">authorized via {session.data.authorizedVia}</Badge>
        )}
      </div>

      {/* Authorized, but on a role they hold rather than their active one. Not a
          problem -- admin work runs as the app owner -- but say so out loud so the
          elevation is never silent. */}
      {session.data?.authorized && session.data.activeRoleQualifies === false && (
        <Alert>
          <ShieldCheck className="h-4 w-4" />
          <AlertTitle>Authorized via a role you hold</AlertTitle>
          <AlertDescription>
            Your active role is <strong>{session.data.activeRole}</strong>, which is not an admin
            role — but you hold <strong>{session.data.authorizedVia}</strong>, so this console is
            open to you. You do not need to switch roles: administrative work here runs as the
            app&apos;s owner, and every action is logged against your username.
          </AlertDescription>
        </Alert>
      )}

      {session.data && !session.data.authorized && (
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Not authorized — this is a permissions issue, not a broken app</AlertTitle>
          <AlertDescription className="space-y-3">
            <p>
              This console creates roles and drops schemas, so it is limited to{" "}
              {(session.data.adminRoles ?? ADMIN_ROLES_FALLBACK).map((r: string, i: number) => (
                <span key={r}>
                  {i > 0 && " and "}
                  <strong>{r}</strong>
                </span>
              ))}
              . Your Snowflake user <strong>{session.data.user}</strong> holds neither.
            </p>
            <p>
              To fix it, ask an administrator to run this once — then reload the page:
            </p>
            <pre className="overflow-x-auto rounded bg-muted/40 p-2 text-xs text-foreground">
              GRANT ROLE {session.data.grantableRole ?? "SNOWCUP_FACILITATOR"} TO USER{" "}
              {session.data.user};
            </pre>
            {(session.data.availableRoles?.length ?? 0) > 0 && (
              <details className="text-xs">
                <summary className="cursor-pointer">
                  Roles you do hold ({session.data.availableRoles.length}) — checked so you can rule
                  out a wrong-role mix-up
                </summary>
                <p className="mt-2 break-words font-mono">
                  {session.data.availableRoles.join(", ")}
                </p>
              </details>
            )}
            {session.data.roleDiscoveryDegraded && (
              <p className="text-xs">
                This session could not list the roles you hold, so only your active role was
                checked. If you know you hold one of the roles above, switching to it should also
                let you in.
              </p>
            )}
          </AlertDescription>
        </Alert>
      )}

      {(session.error || roster.error || health.error) && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Query problem</AlertTitle>
          <AlertDescription>
            {String(
              (session.error as Error)?.message ||
                (roster.error as Error)?.message ||
                (health.error as Error)?.message,
            )}
          </AlertDescription>
        </Alert>
      )}

      {session.data?.authorized !== false && (
      <Tabs defaultValue="add">
        <TabsList>
          <TabsTrigger value="add">Add learners</TabsTrigger>
          <TabsTrigger value="roster">Roster</TabsTrigger>
          <TabsTrigger value="remove">Remove</TabsTrigger>
          <TabsTrigger value="progress">Lab progress</TabsTrigger>
          <TabsTrigger value="health">Environment health</TabsTrigger>
        </TabsList>

        {/* ---------------------------------------------------------- add */}
        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle>Add learners</CardTitle>
              <CardDescription>
                One per line, or comma separated. Snowflake usernames or email-style logins both
                work. Re-adding someone is harmless — provisioning is idempotent.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={blob}
                onChange={(e) => setBlob(e.target.value)}
                rows={6}
                placeholder={"ada.lovelace@example.com\ngrace.hopper@example.com\nBJONES"}
              />

              {people.length > 0 && (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Learner</TableHead>
                        <TableHead>Schema</TableHead>
                        <TableHead>Role</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {people.map((p) => (
                        <TableRow key={p}>
                          <TableCell>{p}</TableCell>
                          <TableCell className="font-mono text-xs">
                            {BUILDS_DB}.{SCHEMA_PREFIX}
                            {suffixFor(p)}
                          </TableCell>
                          <TableCell className="font-mono text-xs">
                            {ROLE_PREFIX}
                            {suffixFor(p)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              <Button
                onClick={() => provision.mutate()}
                disabled={!people.length || provision.isPending}
              >
                {provision.isPending ? "Provisioning…" : `Provision ${people.length || ""}`.trim()}
              </Button>

              {provision.error && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{(provision.error as Error).message}</AlertDescription>
                </Alert>
              )}

              {provision.data && (
                <>
                  <ResultList results={provision.data.results} />
                  {provision.data.failed === 0 ? (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>
                        Provisioned {provision.data.provisioned}. Send them the lab and their schema
                        name.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        {provision.data.failed} entr(y/ies) failed — see the output above.
                      </AlertDescription>
                    </Alert>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ------------------------------------------------------- roster */}
        <TabsContent value="roster">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Roster</CardTitle>
                <CardDescription>Who is set up, and what is missing.</CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => qc.invalidateQueries({ queryKey: ["roster"] })}
                disabled={roster.isFetching}
              >
                <RefreshCw className={`h-4 w-4 ${roster.isFetching ? "animate-spin" : ""}`} />
                Refresh
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {roster.isLoading ? (
                <p className="text-sm text-muted-foreground">Loading roster…</p>
              ) : rosterRows.length === 0 ? (
                <Alert>
                  <AlertDescription>
                    Nobody is provisioned yet. Use the <strong>Add learners</strong> tab.
                  </AlertDescription>
                </Alert>
              ) : (
                <>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Learner</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Schema</TableHead>
                          <TableHead>Schema exists</TableHead>
                          <TableHead>Has a user</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rosterRows.map((r: any) => (
                          <TableRow key={`${r.role}-${r.schema}`}>
                            <TableCell>{r.learner}</TableCell>
                            <TableCell className="font-mono text-xs">{r.role}</TableCell>
                            <TableCell className="font-mono text-xs">{r.schema}</TableCell>
                            <TableCell>
                              {r.schemaExists ? (
                                "yes"
                              ) : (
                                <Badge variant="destructive">MISSING</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {r.hasUser ? "yes" : <Badge variant="destructive">NO</Badge>}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  {problems.length === 0 ? (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>
                        {rosterRows.length} learner(s), all complete.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        {problems.length} row(s) need attention — see MISSING / NO above.
                      </AlertDescription>
                    </Alert>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ------------------------------------------------------- remove */}
        <TabsContent value="remove">
          <Card>
            <CardHeader>
              <CardTitle>Remove learners</CardTitle>
              <CardDescription>
                Revoke access, and optionally delete everything they built.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {everyone.length === 0 ? (
                <Alert>
                  <AlertDescription>No learners to remove.</AlertDescription>
                </Alert>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label>Who to remove</Label>
                    <div className="grid gap-2 rounded-md border p-3 sm:grid-cols-2">
                      {everyone.map((u) => (
                        <label key={u} className="flex items-center gap-2 text-sm">
                          <Checkbox
                            checked={chosen.includes(u)}
                            onCheckedChange={(v) =>
                              setChosen((prev) => (v ? [...prev, u] : prev.filter((x) => x !== u)))
                            }
                          />
                          <span className="font-mono text-xs">{u}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <label className="flex items-start gap-2 text-sm">
                    <Checkbox
                      checked={dropSchema}
                      onCheckedChange={(v) => setDropSchema(v === true)}
                    />
                    <span>
                      Also delete their build schema and role
                      <span className="block text-xs text-muted-foreground">
                        Leave unticked to revoke access but keep everything they built.
                      </span>
                    </span>
                  </label>

                  {dropSchema && chosen.length > 0 && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>This permanently deletes work</AlertTitle>
                      <AlertDescription>
                        The build schema for {chosen.length} learner(s) will be dropped, including
                        any semantic view, search service, custom tool and agent inside it.
                      </AlertDescription>
                    </Alert>
                  )}

                  {chosen.length > 0 && (
                    <div className="space-y-2">
                      <Label htmlFor="confirm">Type REMOVE to confirm</Label>
                      <Input
                        id="confirm"
                        value={confirm}
                        onChange={(e) => setConfirm(e.target.value)}
                        placeholder="REMOVE"
                        className="max-w-xs"
                      />
                    </div>
                  )}

                  <Button
                    variant="destructive"
                    onClick={() => deprovision.mutate()}
                    disabled={
                      !chosen.length ||
                      confirm.trim().toUpperCase() !== "REMOVE" ||
                      deprovision.isPending
                    }
                  >
                    {deprovision.isPending ? "Removing…" : "Remove"}
                  </Button>

                  {deprovision.error && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{(deprovision.error as Error).message}</AlertDescription>
                    </Alert>
                  )}

                  {deprovision.data && (
                    <>
                      <ResultList results={deprovision.data.results} />
                      <p className="text-xs text-muted-foreground">
                        Their challenge score is intentionally left in place. Clear it with{" "}
                        <code className="font-mono">
                          DELETE FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_PROGRESS WHERE PARTICIPANT
                          ILIKE &apos;…&apos;
                        </code>
                      </p>
                    </>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ------------------------------------------------------- health */}
        <TabsContent value="progress">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Lab progress</CardTitle>
                <CardDescription>
                  One row per learner per training: checkpoints ticked, reinforcement quiz
                  answers and challenge answers, all three of which are required to complete.
                  Anyone who has opened the lab appears here, so a row with 0 done means they
                  started and stalled rather than never arrived. &ldquo;Awaiting answers&rdquo;
                  means every checkpoint is done and only a quiz or challenge answer is
                  holding them back.
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => qc.invalidateQueries({ queryKey: ["lab-progress"] })}
                disabled={labProgress.isFetching}
              >
                <RefreshCw className={`h-4 w-4 ${labProgress.isFetching ? "animate-spin" : ""}`} />
              </Button>
            </CardHeader>
            <CardContent>
              {labProgress.isLoading && <Skeleton className="h-24 w-full" />}
              {!labProgress.isLoading && labRows.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  Nobody has opened the lab app yet. Progress appears here as soon as a learner
                  loads it.
                </p>
              )}
              {labRows.length > 0 && (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Learner</TableHead>
                      <TableHead>Training</TableHead>
                      <TableHead>Checkpoints</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Questions</TableHead>
                      <TableHead>Quiz</TableHead>
                      <TableHead>Challenge</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Completed</TableHead>
                      <TableHead>Last active</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {labRows.map((r: any) => (
                      // Keyed on learner AND training: one learner can appear
                      // once per training they have taken.
                      <TableRow key={`${r.participant}:${r.training}`}>
                        <TableCell className="font-medium">{r.participant}</TableCell>
                        <TableCell className="text-xs">{r.trainingTitle}</TableCell>
                        <TableCell>
                          {r.stepsDone}/{r.stepsTotal}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="h-1.5 w-24 overflow-hidden rounded-full bg-muted">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-sky-500 to-violet-500"
                                style={{ width: `${r.percentComplete}%` }}
                              />
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {r.percentComplete}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {r.questionsCorrect}/{r.questionsTotal}
                        </TableCell>
                        <TableCell>
                          {r.quizTotal > 0 ? `${r.quizCorrect}/${r.quizTotal}` : "—"}
                        </TableCell>
                        <TableCell>{r.challengePoints} pts</TableCell>
                        <TableCell>
                          {/* "awaiting answers" is called out rather than folded into
                              "in progress": these are the learners who have finished
                              every checkpoint and only need a question corrected, so
                              they are the ones worth chasing. */}
                          <Badge
                            variant={
                              r.status === "complete"
                                ? "default"
                                : r.status === "awaiting answers"
                                  ? "secondary"
                                  : "outline"
                            }
                            className={
                              r.status === "not started" ? "text-muted-foreground" : undefined
                            }
                          >
                            {r.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {r.completedAt ?? "—"}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {r.lastSeenAt ?? "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="health">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Environment health</CardTitle>
                <CardDescription>Is the workshop actually ready to hand off?</CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => qc.invalidateQueries({ queryKey: ["health"] })}
                disabled={health.isFetching}
              >
                <RefreshCw className={`h-4 w-4 ${health.isFetching ? "animate-spin" : ""}`} />
                Re-check
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {health.isLoading ? (
                <p className="text-sm text-muted-foreground">Running checks…</p>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                    <Metric label="Learners" value={health.data?.metrics.learners} />
                    <Metric
                      label="Shared tables"
                      value={health.data?.metrics.tables}
                      note={health.data?.metrics.tables === 6 ? undefined : "expected 6"}
                    />
                    <Metric
                      label="Players"
                      value={health.data?.metrics.players}
                      note={health.data?.metrics.players === 48 ? undefined : "expected 48"}
                    />
                    <Metric
                      label="Answer key"
                      value={`${health.data?.metrics.keyRows} Q / ${health.data?.metrics.keyPts} pts`}
                    />
                  </div>

                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Check</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Detail</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(health.data?.checks ?? []).map((c: any) => (
                          <TableRow key={c.check}>
                            <TableCell>{c.check}</TableCell>
                            <TableCell>
                              {c.ok ? (
                                <span className="inline-flex items-center gap-1 text-sm font-medium text-emerald-600 dark:text-emerald-400">
                                  <CheckCircle2 className="h-4 w-4" /> PASS
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-sm font-medium text-destructive">
                                  <XCircle className="h-4 w-4" /> FAIL
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {c.detail}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {(health.data?.misOwned ?? []).length > 0 && (
                    <div className="space-y-3 rounded-md border border-destructive/40 p-4">
                      <div>
                        <p className="text-sm font-medium">
                          {(health.data?.misOwned ?? []).length} object(s) not owned by the
                          learner who needs them
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          These were created inside a learner&apos;s build schema by another
                          role — usually a facilitator on ACCOUNTADMIN. The learner holds no
                          privilege on them and gets no error explaining why: the schema just
                          looks empty, or their agent reports its search service does not
                          exist. Repairing hands each object to that learner&apos;s own role.
                        </p>
                      </div>

                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Kind</TableHead>
                              <TableHead>Object</TableHead>
                              <TableHead>Owned by</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {(health.data?.misOwned ?? []).map((o: any) => (
                              <TableRow key={`${o.kind}-${o.sch}-${o.obj}`}>
                                <TableCell className="text-sm">{o.kind}</TableCell>
                                <TableCell className="font-mono text-xs">
                                  {o.sch}.{o.obj}
                                </TableCell>
                                <TableCell className="text-sm text-muted-foreground">
                                  {o.owner}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>

                      {repairOwnership.data?.result && (
                        <Alert variant={repairOwnership.data.ok ? "default" : "destructive"}>
                          {repairOwnership.data.ok ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <XCircle className="h-4 w-4" />
                          )}
                          <AlertDescription className="text-xs">
                            {repairOwnership.data.result}
                          </AlertDescription>
                        </Alert>
                      )}
                      {repairOwnership.error && (
                        <Alert variant="destructive">
                          <XCircle className="h-4 w-4" />
                          <AlertDescription className="text-xs">
                            {(repairOwnership.error as Error).message}
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* Confirm step: this changes grants, so it is not a one-click
                          action even though it is a repair rather than a deletion. */}
                      {repairConfirm ? (
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm">
                            Transfer ownership of these objects to their learners?
                          </span>
                          <Button
                            size="sm"
                            onClick={() => repairOwnership.mutate()}
                            disabled={repairOwnership.isPending}
                          >
                            {repairOwnership.isPending ? "Repairing…" : "Yes, repair"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setRepairConfirm(false)}
                            disabled={repairOwnership.isPending}
                          >
                            Cancel
                          </Button>
                        </div>
                      ) : (
                        <Button size="sm" onClick={() => setRepairConfirm(true)}>
                          Repair ownership
                        </Button>
                      )}
                    </div>
                  )}

                  {health.data?.ready ? (
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>Environment is ready to hand off.</AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <XCircle className="h-4 w-4" />
                      <AlertDescription>
                        One or more checks failed — see Detail above.
                      </AlertDescription>
                    </Alert>
                  )}

                  <p className="text-xs text-muted-foreground">
                    Learner progress lives in SNOWCUP_WORKSHOP.GRADING.BUILDER_PROGRESS (one row per
                    learner per module, with percent complete).
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      )}
    </div>
  )
}

function Metric({
  label,
  value,
  note,
}: {
  label: string
  value: React.ReactNode
  note?: string
}) {
  return (
    <div className="rounded-lg border p-3">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value ?? "—"}</div>
      {note && <div className="text-xs text-destructive">{note}</div>}
    </div>
  )
}
