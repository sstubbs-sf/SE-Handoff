import { AdminConsole } from "@/components/admin-console"

// Required: Snowflake is not reachable during docker build.
export const dynamic = "force-dynamic"

export default function Home() {
  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold tracking-tight">SnowCup Admin</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Learner roster and environment health for the SnowCup Build-an-Agent Lab. Every query runs
          as the person signed in, so this console can only do what your own role already permits.
        </p>
      </div>
      <AdminConsole />
    </main>
  )
}
