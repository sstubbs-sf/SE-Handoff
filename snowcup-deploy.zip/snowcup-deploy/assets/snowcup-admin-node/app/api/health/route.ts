import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import {
  ADMIN,
  BUILDS_DB,
  ROLE_PREFIX,
  SCHEMA_PREFIX,
  firstValue,
  num,
  type HealthCheck,
} from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Health checks. Gated by authorize(); reads use OWNER's rights so a facilitator
 * without workshop privileges still gets a truthful answer.
 */
export async function GET() {
  try {
    await authorize()

    const one = async (sql: string) => {
      const rows = await querySnowflake(sql)
      return rows.length ? Object.values(rows[0])[0] : null
    }

    const tables = num(
      await one(
        `SELECT COUNT(*) FROM SNOWCUP_SHARED.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='TOURNAMENT'`,
      ),
    )
    const players = num(await one(`SELECT COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.PLAYERS`))
    const keyRows = num(
      await one(`SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY`),
    )
    const keyPts = num(await one(`SELECT SUM(POINTS) FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY`))
    const grading = num(
      await one(
        `SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME='GRADING'`,
      ),
    )
    // NICKNAME must not exist on PLAYERS: it is the table learners model, and a
    // nickname column there lets Cortex Analyst answer lore questions by string
    // match, which defeats the Module 6 lesson and challenge Tier 4.
    const nickLeak = num(
      await one(
        `SELECT COUNT(*) FROM SNOWCUP_SHARED.INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_SCHEMA='TOURNAMENT' AND TABLE_NAME='PLAYERS' AND COLUMN_NAME='NICKNAME'`,
      ),
    )

    const roleRows = await querySnowflake(`SHOW ROLES LIKE '${ROLE_PREFIX}%'`)
    const roles = roleRows.map((r) => String(r.name))
    const schemaRows = await querySnowflake(
      `SHOW SCHEMAS LIKE '${SCHEMA_PREFIX}%' IN DATABASE ${BUILDS_DB}`,
    )
    const schemas = new Set(schemaRows.map((r) => String(r.name)))

    const holders: Record<string, string[]> = {}
    for (const role of roles) {
      const grants = await querySnowflake(`SHOW GRANTS OF ROLE ${role}`)
      holders[role] = grants
        .filter((g) => String(g.granted_to) === "USER")
        .map((g) => String(g.grantee_name))
    }

    // The isolation gate: the shared participant role must hold NO schema-level
    // privileges on any build schema, or learners can read each other's work.
    // Deliberately narrow -- Module 7 has learners grant their own agent to
    // SNOWCUP_PARTICIPANT and that grant's name also contains "WS_", so matching
    // loosely would report a false failure every time someone finishes it.
    const shared = await querySnowflake("SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT")
    const leaked = shared.filter(
      (g) => String(g.granted_on) === "SCHEMA" && String(g.name ?? "").includes(`.${SCHEMA_PREFIX}`),
    ).length

    // Ownership: everything in WS_<NAME> must be owned by SNOWCUP_WS_<NAME>.
    // An object created there by a facilitator on ACCOUNTADMIN leaves the learner
    // with no privilege on it at all, so Snowsight shows them an empty schema and
    // nothing explains why.
    //
    // This delegates to ADMIN.AUDIT_BUILD_OWNERSHIP_JSON rather than reading owner
    // columns here. The previous version did the latter and was structurally
    // blind: SHOW CORTEX SEARCH SERVICES and SHOW PROCEDURES expose no "owner"
    // column, so those kinds could never appear and this card reported "all
    // owned by the right learner role" while a learner's agent was failing with
    // "the Cortex Search Service does not exist". One shared definition means the
    // console, the deploy gate and provisioning cannot drift apart again.
    //
    // The _JSON wrapper matters: the table-returning form needs CALL followed by
    // SELECT ... RESULT_SCAN(LAST_QUERY_ID()), and querySnowflake is POOLED, so
    // the second statement can execute on a different session where
    // LAST_QUERY_ID() means something else entirely. That failed as an "invalid
    // identifier" on the first column rather than anything that looked like a
    // session problem. One CALL, one round trip, no RESULT_SCAN out here.
    const misOwned: {
      kind: string
      sch: string
      obj: string
      owner: string
      fixSql: string
    }[] = []
    let ownershipReadable = true
    try {
      const rows = await querySnowflake(
        `CALL ${ADMIN}.AUDIT_BUILD_OWNERSHIP_JSON(NULL)`,
      )
      const raw = firstValue(rows, "[]")
      const parsed = typeof raw === "string" ? JSON.parse(raw) : raw
      for (const r of Array.isArray(parsed) ? parsed : []) {
        misOwned.push({
          kind: String(r.kind ?? ""),
          sch: String(r.sch ?? ""),
          obj: String(r.obj ?? ""),
          owner: String(r.owner ?? ""),
          fixSql: String(r.fix_sql ?? ""),
        })
      }
    } catch {
      // Failing to run the audit is NOT the same as a clean audit, and must never
      // be rendered as one -- that is exactly how the original bug hid.
      ownershipReadable = false
    }

    // Every training referenced by a checkpoint must exist and be active in the
    // MODULES registry. An orphan means learners can tick checkpoints that no
    // roll-up will ever attribute, and the failure is invisible until someone
    // asks why a cohort shows no progress.
    const orphanTrainings = num(
      await one(
        `SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.LAB_STEPS s
          WHERE s.IS_ACTIVE
            AND NOT EXISTS (SELECT 1 FROM SNOWCUP_WORKSHOP.GRADING.MODULES m
                             WHERE m.MODULE_ID = s.MODULE_ID AND m.IS_ACTIVE)`,
      ),
    )
    const trainings = num(
      await one(
        `SELECT COUNT(DISTINCT MODULE_ID) FROM SNOWCUP_WORKSHOP.GRADING.LAB_STEPS WHERE IS_ACTIVE`,
      ),
    )

    const checks: HealthCheck[] = [
      {
        check: "Shared data loaded",
        ok: tables === 6 && players === 48,
        detail: `${tables} tables, ${players} players`,
      },
      { check: "Grading schema present", ok: grading === 1, detail: "SNOWCUP_WORKSHOP.GRADING" },
      {
        check: "Answer key seeded",
        ok: keyRows === 8 && keyPts === 120,
        detail: `${keyRows} questions worth ${keyPts}`,
      },
      {
        check: "Search owns the lore",
        ok: nickLeak === 0,
        detail:
          nickLeak === 0
            ? "PLAYERS has no NICKNAME column, so Tier 4 needs Cortex Search"
            : "PLAYERS.NICKNAME exists - Analyst can shortcut Tier 4",
      },
      {
        check: "Learner isolation holds",
        ok: leaked === 0,
        detail:
          leaked === 0
            ? "shared role has no build-schema privileges"
            : `${leaked} privilege(s) leaked to SNOWCUP_PARTICIPANT`,
      },
      {
        check: "Every learner has a schema",
        ok: roles.every((r) => schemas.has(SCHEMA_PREFIX + r.slice(ROLE_PREFIX.length))),
        detail: "one build schema per role",
      },
      {
        check: "Every role has a user",
        ok: roles.every((r) => (holders[r] ?? []).length > 0),
        detail: "no orphaned roles",
      },
      {
        check: "Learners own their own work",
        ok: ownershipReadable && misOwned.length === 0,
        detail: !ownershipReadable
          ? "could not run ADMIN.AUDIT_BUILD_OWNERSHIP — ownership is UNVERIFIED, not clean"
          : misOwned.length === 0
            ? "every object in every build schema is owned by that learner's role"
            : misOwned
                .map((o) => `${o.kind} ${o.sch}.${o.obj} owned by ${o.owner}`)
                .join("; "),
      },
      {
        check: "Trainings are registered",
        ok: orphanTrainings === 0 && trainings > 0,
        detail:
          trainings === 0
            ? "no checkpoints seeded — the lab app has nothing to record"
            : orphanTrainings === 0
              ? `${trainings} training(s), each with an active MODULES row`
              : `${orphanTrainings} checkpoint(s) reference a training missing from MODULES`,
      },
    ]

    return Response.json({
      metrics: { learners: roles.length, tables, players, keyRows, keyPts },
      checks,
      // Surfaced separately from the check's detail string so the console can offer
      // a per-learner repair rather than only describing the problem.
      misOwned,
      ready: checks.every((c) => c.ok),
    })
  } catch (e) {
    return errorResponse(e, "health")
  }
}
