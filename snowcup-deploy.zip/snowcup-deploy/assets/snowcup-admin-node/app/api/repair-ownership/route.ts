import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeName, firstValue, sqlLiteral } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Hand mis-owned objects in a build schema back to that learner's role.
 *
 * WHY THIS IS A WRITE ENDPOINT AT ALL
 * An object created inside WS_<NAME> by an admin -- a facilitator helping someone
 * who is stuck, or whoever authored the reference solution -- leaves the learner
 * with no privilege on it, and nothing errors. They see an empty schema, or an
 * agent that reports its Cortex Search Service does not exist. Fixing it by hand
 * means writing a GRANT OWNERSHIP per object with the right kind keyword and, for
 * procedures, the right argument signature. That is exactly the sort of thing to
 * get wrong mid-workshop, so the console does it.
 *
 * Runs with OWNER's rights, like provisioning: transferring ownership needs
 * privileges the restricted caller's-rights context does not have. Access is
 * therefore decided by authorize() -- ACCOUNTADMIN or SNOWCUP_FACILITATOR only.
 *
 * Idempotent: FIX_BUILD_OWNERSHIP re-audits after acting and reports what it
 * could not fix rather than assuming its grants worked, so calling it twice is
 * harmless and a partial repair is never reported as success.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint transfers object ownership with the app
    // owner's privileges. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const raw = typeof body?.participant === "string" ? body.participant.trim() : ""

    // An empty participant means "every build schema", which is a legitimate
    // request from the health card. A non-empty one is validated the same way
    // provisioning validates it, so it can never be interpolated raw.
    const scope = raw ? assertSafeName(raw) : ""
    const arg = scope ? sqlLiteral(scope) : "NULL"

    const rows = await querySnowflake(`CALL ${ADMIN}.FIX_BUILD_OWNERSHIP(${arg})`)
    const result = String(firstValue(rows, "no result"))

    // "PARTIAL" is the interesting case: the caller lacked the privilege to
    // transfer something, which for a SNOWCUP_FACILITATOR is the common outcome
    // when the object is owned by ACCOUNTADMIN. Report it as not-ok so the UI
    // does not show a success state over a still-broken schema.
    const ok = !result.startsWith("PARTIAL")

    console.log(
      new Date().toISOString(),
      `[repair-ownership] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole})` +
        ` scope=${scope || "ALL"} -> ${result}`,
    )
    return Response.json({ result, ok, scope: scope || null })
  } catch (e) {
    return errorResponse(e, "repair-ownership")
  }
}
