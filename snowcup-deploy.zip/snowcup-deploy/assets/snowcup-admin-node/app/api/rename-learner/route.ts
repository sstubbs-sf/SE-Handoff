import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeSuffix, firstValue, sqlLiteral } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Rename a learner's role AND build schema in place, keeping their work.
 *
 * WHY A RENAME AND NOT A FRESH PROVISION
 * A role named from an email address when the current rule uses the username is
 * functionally fine, so this is never automatic. When it IS worth fixing, the only
 * repair that keeps the learner whole is to move the objects they already have --
 * creating a new role and schema strands their semantic view, search service and
 * agent in the old space.
 *
 * BOTH OBJECTS, ALWAYS. The ownership model pairs them by name: schema WS_X
 * belongs to role SNOWCUP_WS_X. Renaming one and not the other makes every object
 * in that schema read as mis-owned. The procedure rolls the role back if the
 * schema rename fails, and refuses up front when the schema is owned by a role
 * this session does not hold -- because ACCOUNTADMIN genuinely cannot rename a
 * schema owned by a learner's own role, which was measured, not assumed.
 *
 * REFERENCES ARE NOT UPDATED BY A RENAME. A learner's agent names its semantic
 * view and Cortex Search Service in full, so anything in a renamed schema needs
 * re-pointing. The procedure says so whenever the schema is not empty, and the
 * card warns using the audit's objCount BEFORE anyone clicks.
 *
 * Runs with OWNER's rights: ALTER ROLE ... RENAME TO also requires the global
 * CREATE ROLE privilege, which SNOWCUP_FACILITATOR does not hold. authorize()
 * decides who may ask.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint renames account-level objects with the app
    // owner's rights. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const from = typeof body?.from === "string" ? body.from.trim() : ""
    const to = typeof body?.to === "string" ? body.to.trim() : ""

    // Both are required. There is no "rename to the obvious thing" default here on
    // purpose: the obvious thing is computed by the audit, and having the client
    // send it back explicitly means the operator confirmed the value they saw.
    if (!from || !to) {
      return Response.json(
        { error: "Both from and to build-space names are required.", ok: false },
        { status: 400 },
      )
    }

    // Validated to the suffix shape, not the person-name shape: these reach DDL as
    // identifiers, which cannot be bound.
    const oldSuffix = assertSafeSuffix(from)
    const newSuffix = assertSafeSuffix(to)

    const rows = await querySnowflake(
      `CALL ${ADMIN}.RENAME_LEARNER_SPACE(${sqlLiteral(oldSuffix)}, ${sqlLiteral(newSuffix)})`,
    )
    const result = String(firstValue(rows, "no result"))

    // Only a clean OK counts. REFUSED means it declined before changing anything;
    // PARTIAL means the rename happened but the role does not hold the full
    // contract; FAILED means it rolled back; BROKEN means the rollback itself
    // failed and a human has to intervene. None of those may render as success.
    const ok = result.startsWith("OK")

    console.log(
      new Date().toISOString(),
      `[rename-learner] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole})` +
        ` ${oldSuffix} -> ${newSuffix} -> ${result}`,
    )
    return Response.json({ result, ok, from: oldSuffix, to: newSuffix })
  } catch (e) {
    return errorResponse(e, "rename-learner")
  }
}
