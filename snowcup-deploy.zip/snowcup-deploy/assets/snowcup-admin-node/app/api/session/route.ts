import {
  errorResponse,
  identifyCaller,
  ADMIN_ROLES,
  GRANTABLE_ADMIN_ROLE,
} from "@/lib/authz"

export const dynamic = "force-dynamic"

/**
 * Who is operating the app, and may they act? Deliberately NOT gated -- the UI
 * needs this to render an honest, self-diagnosing "not authorized" state instead
 * of a blank screen or a mystery error. It exposes only the caller's own identity
 * and their own role list.
 */
export async function GET() {
  try {
    const caller = await identifyCaller()
    return Response.json({
      user: caller.user,
      activeRole: caller.activeRole,
      authorized: caller.authorized,
      authorizedVia: caller.authorizedVia,
      // True when the active role already qualifies. When false but authorized,
      // the person holds a qualifying role that simply isn't their active one --
      // worth showing so the elevation is visible, not silent.
      activeRoleQualifies: caller.activeRoleQualifies,
      // True when held-role discovery was unavailable and we fell back to the
      // active role alone -- changes the advice we give on refusal.
      roleDiscoveryDegraded: caller.roleDiscoveryDegraded,
      qualifyingRoles: caller.qualifyingRoles,
      // Their own granted roles, so an unauthorized person can see at a glance
      // that this is a permissions matter rather than a broken app.
      availableRoles: caller.availableRoles,
      adminRoles: [...ADMIN_ROLES],
      // The role to ask for -- never ACCOUNTADMIN.
      grantableRole: GRANTABLE_ADMIN_ROLE,
    })
  } catch (e) {
    return errorResponse(e, "session")
  }
}
