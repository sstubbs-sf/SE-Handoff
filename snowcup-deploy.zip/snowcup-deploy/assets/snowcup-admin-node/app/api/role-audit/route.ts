import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, firstValue, type RoleAuditRow } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Per-role grant audit. Read-only.
 *
 * WHY THIS IS NOT PART OF /api/health
 * It is a per-role sweep -- two SHOW GRANTS per learner inside the procedure --
 * so folding it into the health card would slow every page load for a check that
 * only matters when something is actually suspected. The console calls this from
 * a button instead.
 *
 * WHY IT CALLS THE _JSON WRAPPER
 * The table-returning form needs CALL followed by SELECT ... RESULT_SCAN(
 * LAST_QUERY_ID()), and querySnowflake is POOLED -- the second statement can land
 * on a different session where LAST_QUERY_ID() refers to an unrelated query. That
 * surfaces as an "invalid identifier" on the first column, which looks nothing
 * like a session problem. One CALL, one round trip, no RESULT_SCAN out here.
 *
 * Reads use OWNER's rights so a SNOWCUP_FACILITATOR holding no privileges on the
 * workshop databases still gets a truthful answer; authorize() decides who may ask.
 */
export async function GET() {
  try {
    await authorize()

    const rows = await querySnowflake(`CALL ${ADMIN}.AUDIT_LEARNER_ROLES_JSON(NULL)`)
    const raw = firstValue(rows, "[]")
    const parsed = typeof raw === "string" ? JSON.parse(raw) : raw

    const audit: RoleAuditRow[] = (Array.isArray(parsed) ? parsed : []).map((r: any) => ({
      scope: String(r.scope ?? ""),
      role: String(r.role ?? ""),
      holder: r.holder ? String(r.holder) : null,
      nameBasis: String(r.name_basis ?? ""),
      verdict: String(r.verdict ?? ""),
      gaps: String(r.gaps ?? ""),
      suggestedRole: r.suggested_role ? String(r.suggested_role) : null,
      objCount: Number(r.obj_count ?? 0),
    }))

    // clean is deliberately NOT `every(verdict === 'PASS')` over a possibly empty
    // array: [].every() is true, so an audit that returned nothing would render as
    // a clean account. The procedure always emits at least the ACCOUNT row, so an
    // empty array here means the call itself went wrong.
    const clean = audit.length > 0 && audit.every((r) => r.verdict === "PASS")

    return Response.json({ audit, clean, ran: audit.length > 0 })
  } catch (e) {
    return errorResponse(e, "role-audit")
  }
}
