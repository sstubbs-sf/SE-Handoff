import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeRoleName, firstValue, sqlLiteral } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Restore the grants a learner role is missing.
 *
 * WHY THIS DOES NOT JUST RE-RUN PROVISIONING
 * Re-running PROVISION_LEARNER is the documented repair and is correct on an
 * account running the current setup script. It is useless on the accounts that
 * most need repairing: an account provisioned by an OLDER version has a
 * PROVISION_LEARNER that never granted CREATE STAGE / FILE FORMAT / TASK /
 * DATASET, so re-running that account's own provisioning cannot restore them --
 * the grants are missing from the procedure too. ADMIN.REPAIR_LEARNER_ROLE
 * carries the contract itself and depends on nothing else in the schema.
 *
 * An empty role means every learner role AND the account-level EXECUTE TASK grant
 * on SNOWCUP_PARTICIPANT. That grant is not a property of any one learner, so the
 * per-role form deliberately leaves it alone.
 *
 * Runs with OWNER's rights, like provisioning: granting on a schema owned by
 * ACCOUNTADMIN is not something the restricted caller's-rights context can do.
 * Access is therefore decided by authorize() -- ACCOUNTADMIN or
 * SNOWCUP_FACILITATOR only.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint grants privileges with the app owner's
    // rights. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const raw = typeof body?.role === "string" ? body.role.trim() : ""

    // Empty means "every role", which is a legitimate request from the card. A
    // named role is validated to the learner-role shape rather than the looser
    // person-name shape, because it reaches GRANT statements as an identifier.
    const scope = raw ? assertSafeRoleName(raw) : ""
    const arg = scope ? sqlLiteral(scope) : "NULL"

    const rows = await querySnowflake(`CALL ${ADMIN}.REPAIR_LEARNER_ROLE(${arg})`)
    const result = String(firstValue(rows, "no result"))

    // REFUSED is the procedure declining before it changed anything. Report it as
    // not-ok so the UI cannot show a success state over an unrepaired account.
    const ok = !result.startsWith("REFUSED")

    console.log(
      new Date().toISOString(),
      `[repair-role] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole})` +
        ` scope=${scope || "ALL"} -> ${result}`,
    )
    return Response.json({ result, ok, scope: scope || null })
  } catch (e) {
    return errorResponse(e, "repair-role")
  }
}
