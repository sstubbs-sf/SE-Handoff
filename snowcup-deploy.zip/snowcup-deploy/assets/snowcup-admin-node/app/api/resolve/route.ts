import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import {
  ADMIN,
  assertSafeName,
  parsePeople,
  sqlLiteral,
  type ResolvedName,
} from "@/lib/snowcup"

export const dynamic = "force-dynamic"


/**
 * Ask Snowflake what a typed name will ACTUALLY resolve to, before provisioning.
 *
 * The console used to predict the build space in the browser by sanitising the
 * string. That prediction is now wrong for any email address: naming anchors on the
 * role a learner already holds, then on their resolved username, so
 * samson.stubbs@snowflake.com lands in WS_SSTUBBS -- not the WS_SAMSON_STUBBS a
 * client-side guess produces. Showing a confidently wrong name is worse than showing
 * none, so the truth is fetched from the one procedure that decides it.
 *
 * Read-only: RESOLVE_LEARNER creates nothing.
 */
export async function POST(request: Request) {
  try {
    await authorize()

    const body = await request.json().catch(() => ({}))
    const people = Array.isArray(body?.people)
      ? body.people.map(String)
      : parsePeople(body?.blob ?? "")

    if (!people.length) return Response.json({ resolved: [] })
    if (people.length > 200) {
      return Response.json(
        { error: `Refusing to resolve ${people.length} at once.` },
        { status: 400 },
      )
    }

    const resolved: ResolvedName[] = []
    for (const person of people) {
      try {
        const safe = assertSafeName(person)
        const rows = await querySnowflake(
          `CALL ${ADMIN}.RESOLVE_LEARNER(${sqlLiteral(safe)})`,
        )
        // The procedure returns an OBJECT; drivers hand that back as a JSON string.
        const raw = Object.values(rows[0] ?? {})[0]
        const o = (typeof raw === "string" ? JSON.parse(raw) : raw) ?? {}
        resolved.push({
          person,
          schema: o.schema ?? null,
          role: o.role ?? null,
          username: o.username ?? null,
          anchored: o.anchored ?? null,
          heldCount: Number(o.held_count ?? 0),
        })
      } catch (e) {
        // One bad name must not blank the whole preview.
        resolved.push({
          person,
          schema: null,
          role: null,
          username: null,
          anchored: null,
          heldCount: 0,
          error: e instanceof Error ? e.message : "could not resolve",
        })
      }
    }

    return Response.json({ resolved })
  } catch (e) {
    return errorResponse(e, "resolve")
  }
}
