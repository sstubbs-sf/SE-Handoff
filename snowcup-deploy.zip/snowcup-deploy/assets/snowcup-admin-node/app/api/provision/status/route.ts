import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeRunId, num, sqlLiteral } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Live progress for one provisioning run.
 *
 * THIS ROUTE IS POLLED EVERY FEW SECONDS, so it must stay cheap: two small
 * SELECTs against ADMIN.PROVISION_RUN and ADMIN.PROVISION_EVENT and nothing else.
 * It deliberately does NOT touch roster or health -- /api/health is slow
 * because it runs a database-wide ownership audit, and polling anything like that
 * would be worse than the silence this endpoint replaces.
 *
 * Owner's rights, matching the provision route. The tables live in ADMIN, which
 * learners cannot see at all, and authorize() already restricts this app to
 * ACCOUNTADMIN and SNOWCUP_FACILITATOR.
 */
export async function GET(request: Request) {
  try {
    await authorize()

    const raw = new URL(request.url).searchParams.get("run") ?? ""
    if (!raw) {
      return Response.json({ error: "Missing run id." }, { status: 400 })
    }
    const runId = assertSafeRunId(raw)
    const lit = sqlLiteral(runId)

    const runRows = await querySnowflake(
      `SELECT TOTAL, STARTED_BY,
              TO_VARCHAR(STARTED_AT)  AS STARTED_AT,
              TO_VARCHAR(FINISHED_AT) AS FINISHED_AT,
              TIMESTAMPDIFF(second, STARTED_AT, CURRENT_TIMESTAMP()) AS ELAPSED_SEC
         FROM ${ADMIN}.PROVISION_RUN
        WHERE RUN_ID = ${lit}`,
    )

    // A run row can legitimately be missing for a moment: the browser starts
    // polling the instant it fires the POST, which may not have inserted it yet.
    // Report that as "not started" rather than an error so the UI stays quiet.
    if (!runRows.length) {
      return Response.json({ runId, found: false, people: [], done: 0, total: 0 })
    }
    const run = runRows[0]

    // One row per person: their newest phase, plus when they were first seen so a
    // per-person duration can be shown.
    const rows = await querySnowflake(
      `SELECT PERSON, PHASE, STATE, DETAIL,
              TIMESTAMPDIFF(second, FIRST_AT, CURRENT_TIMESTAMP())    AS TOTAL_SEC,
              TIMESTAMPDIFF(second, AT, CURRENT_TIMESTAMP())          AS IN_PHASE_SEC
         FROM (
           SELECT PERSON, PHASE, STATE, DETAIL, AT,
                  MIN(AT)      OVER (PARTITION BY PERSON) AS FIRST_AT,
                  ROW_NUMBER() OVER (PARTITION BY PERSON ORDER BY AT DESC) AS RN
             FROM ${ADMIN}.PROVISION_EVENT
            WHERE RUN_ID = ${lit}
         )
        WHERE RN = 1
        ORDER BY FIRST_AT`,
    )

    const people = rows.map((r) => ({
      person: String(r.PERSON ?? ""),
      phase: String(r.PHASE ?? ""),
      state: r.STATE ? String(r.STATE) : null,
      detail: r.DETAIL ? String(r.DETAIL) : null,
      // Seconds spent in the CURRENT phase. This is the number that answers "is it
      // stuck?" -- OWNERSHIP and RESOLVE each legitimately sit near 40s.
      inPhaseSec: num(r.IN_PHASE_SEC),
      totalSec: num(r.TOTAL_SEC),
    }))

    const finishedAt = run.FINISHED_AT ? String(run.FINISHED_AT) : null
    const done = people.filter((p) => p.phase === "DONE").length

    // STALL DETECTION. The long POST can die -- ingress timeout, closed laptop --
    // and when it does nothing ever writes FINISHED_AT, so "still running" would
    // otherwise be indistinguishable from "abandoned". No new event for 120s while
    // unfinished is the signal. The threshold stays well above the measured worst
    // case for one learner (22.7s before the ownership-sweep skip, ~9s after) so a
    // slow-but-healthy run is never called stalled.
    const quietest = people.filter((p) => p.phase !== "DONE").map((p) => p.inPhaseSec)
    const quietSec = quietest.length ? Math.min(...quietest) : 0
    const stalled = !finishedAt && people.length > 0 && quietest.length > 0 && quietSec > 120

    return Response.json({
      runId,
      found: true,
      total: num(run.TOTAL),
      startedBy: run.STARTED_BY ? String(run.STARTED_BY) : null,
      startedAt: run.STARTED_AT ? String(run.STARTED_AT) : null,
      finishedAt,
      elapsedSec: num(run.ELAPSED_SEC),
      done,
      running: people.filter((p) => p.phase !== "DONE").length,
      stalled,
      people,
    })
  } catch (e) {
    return errorResponse(e, "provision-status")
  }
}
