import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeName, firstValue, parsePeople } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Provision learners.
 *
 * Runs the procedure with OWNER's rights, because restricted caller's rights
 * forbids the GRANT statements provisioning needs. Access is therefore decided by
 * authorize() -- ACCOUNTADMIN or SNOWCUP_FACILITATOR only. PROVISION_LEARNER is
 * idempotent, so re-adding someone is harmless.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint creates roles and alters users with the
    // app owner's privileges. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const people = Array.isArray(body?.people) ? body.people.map(String) : parsePeople(body?.blob ?? "")

    if (!people.length) {
      return Response.json({ error: "No names supplied." }, { status: 400 })
    }
    if (people.length > 200) {
      return Response.json(
        { error: `Refusing to provision ${people.length} at once; do it in batches of 200 or fewer.` },
        { status: 400 },
      )
    }

    const results: { person: string; result: string; ok: boolean }[] = []
    for (const person of people) {
      try {
        const safe = assertSafeName(person)
        const rows = await querySnowflake(`CALL ${ADMIN}.PROVISION_LEARNER('${safe}')`)
        const result = String(firstValue(rows, "no result"))
        results.push({ person, result, ok: result.startsWith("OK") })
      } catch (e) {
        results.push({
          person,
          result: e instanceof Error ? e.message : "failed",
          ok: false,
        })
      }
    }

    console.log(
      new Date().toISOString(),
      `[provision] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole}) provisioned ${people.length}`,
    )
    return Response.json({
      results,
      provisioned: results.filter((r) => r.ok).length,
      failed: results.filter((r) => !r.ok).length,
    })
  } catch (e) {
    return errorResponse(e, "provision")
  }
}
