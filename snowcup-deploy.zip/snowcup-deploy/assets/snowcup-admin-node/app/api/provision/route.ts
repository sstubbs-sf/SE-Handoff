import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { classifyError, explainOneLine, systemicSummary, type Classified } from "@/lib/errors"
import { isCaptured, mapLimit } from "@/lib/concurrency"
import {
  ADMIN,
  assertSafeName,
  assertSafeRunId,
  firstValue,
  groupForConcurrency,
  parsePeople,
  provisionState,
  sqlLiteral,
} from "@/lib/snowcup"

export const dynamic = "force-dynamic"

// Provisioning a cohort takes minutes, so the absence of a duration declaration was
// previously a latent trap. Measured per learner: 22.7s before the ownership-sweep
// skip, ~9s after (see ADMIN.PROVISION_EVENT for the live numbers). The ceiling stays
// generous because a 200-name batch on a slow account is still legitimate.
export const maxDuration = 3600

/** Learners provisioned at once. Kept well under the connection pool's max of 10. */
const CONCURRENCY = 4

/**
 * Provision learners.
 *
 * Runs the procedure with OWNER's rights, because restricted caller's rights
 * forbids the GRANT statements provisioning needs. Access is therefore decided by
 * authorize() -- ACCOUNTADMIN or SNOWCUP_FACILITATOR only. PROVISION_LEARNER is
 * idempotent, so re-adding someone is harmless.
 *
 * CONCURRENCY. Learners are provisioned CONCURRENCY at a time, but not naively: see
 * groupForConcurrency() for why people who resolve to the same build space must be
 * serialised with respect to each other. Doing this wrong silently hands two people
 * the same schema, so the grouping is the load-bearing part of this route, not the
 * worker pool.
 *
 * PROGRESS. The whole batch runs inside this one request, so nothing can reach the
 * browser until it ends. Instead each phase is written to ADMIN.PROVISION_EVENT as
 * it happens and the UI reads it over a SEPARATE polling request (see
 * ./status/route.ts). The client supplies runId so it can start polling
 * immediately rather than waiting on this response.
 *
 * The run id is NOT trusted: it is validated, and PROVISION_RUN's primary key
 * means a replayed id collides rather than silently merging two runs together.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint creates roles and alters users with the
    // app owner's privileges. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const people: string[] = Array.isArray(body?.people)
      ? body.people.map((p: unknown) => String(p))
      : parsePeople(body?.blob ?? "")

    if (!people.length) {
      return Response.json({ error: "No names supplied." }, { status: 400 })
    }
    if (people.length > 200) {
      return Response.json(
        { error: `Refusing to provision ${people.length} at once; do it in batches of 200 or fewer.` },
        { status: 400 },
      )
    }

    // Progress tracking is optional. A caller that supplies no run id still gets
    // provisioned exactly as before -- this endpoint must not start depending on
    // its own observability.
    const runId = body?.runId ? assertSafeRunId(String(body.runId)) : null

    if (runId) {
      // Best-effort, like every other progress write. If the run row cannot be
      // created the UI simply shows no progress; provisioning still proceeds.
      try {
        await querySnowflake(
          `INSERT INTO ${ADMIN}.PROVISION_RUN (RUN_ID, STARTED_BY, TOTAL)
           VALUES (${sqlLiteral(runId)}, ${sqlLiteral(caller.user)}, ${people.length})`,
        )
      } catch (e) {
        console.warn(new Date().toISOString(), "[provision] could not open run row", e)
      }
    }

    // ---- Pass 1: resolve every name, so grouping can key on the REAL build space.
    // Read-only (RESOLVE_LEARNER creates nothing), so this pass is itself safe to run
    // concurrently. A name that fails to resolve yields role null and is grouped
    // conservatively rather than being dropped.
    const resolvedRoles = await mapLimit(people, CONCURRENCY, async (person) => {
      const safe = assertSafeName(person)
      const rows = await querySnowflake(`CALL ${ADMIN}.RESOLVE_LEARNER(${sqlLiteral(safe)})`)
      const raw = Object.values(rows[0] ?? {})[0]
      const o = (typeof raw === "string" ? JSON.parse(raw) : raw) ?? {}
      return (o.role as string | null) ?? null
    })

    const groups = groupForConcurrency(
      people.map((person, i) => {
        const r = resolvedRoles[i]
        return { person, role: isCaptured(r) ? null : r }
      }),
    )

    type Row = { person: string; result: string; state: string; ok: boolean }
    const byPerson = new Map<string, Row>()
    const classified: Classified[] = []

    /** One learner. Retries ONCE, and only for faults the classifier calls transient. */
    const provisionOne = async (person: string): Promise<Row> => {
      const safe = assertSafeName(person)
      const sql = `CALL ${ADMIN}.PROVISION_LEARNER(${sqlLiteral(safe)}, ${runId ? sqlLiteral(runId) : "NULL"})`
      for (let attempt = 1; ; attempt++) {
        try {
          const rows = await querySnowflake(sql)
          const result = String(firstValue(rows, "no result"))
          const state = provisionState(result)
          // Only OK counts as provisioned. PARTIAL is reported as its own state
          // rather than being flattened into failure, because the remedy differs.
          return { person, result, state, ok: state === "OK" }
        } catch (e) {
          const c = classifyError(e)
          if (c.retryable && attempt === 1) {
            console.warn(
              new Date().toISOString(),
              `[provision] retrying ${person} after ${c.klass}: ${c.raw}`,
            )
            continue
          }
          classified.push(c)
          // A thrown call never reached the procedure, so nothing logged a DONE row
          // for this person. Without this the UI would show them stuck mid-phase
          // forever, which is precisely the confusion this feature removes.
          if (runId) {
            try {
              await querySnowflake(
                `CALL ${ADMIN}.LOG_PROVISION_STEP(${sqlLiteral(runId)}, ${sqlLiteral(person)},` +
                  ` 'DONE', 'ERROR', ${sqlLiteral(c.title.slice(0, 500))})`,
              )
            } catch {
              // Best-effort by design.
            }
          }
          return { person, result: explainOneLine(c), state: "ERROR", ok: false }
        }
      }
    }

    // ---- Pass 2: groups in parallel, members of a group in sequence.
    await mapLimit(groups, CONCURRENCY, async (group) => {
      for (const person of group) {
        byPerson.set(person, await provisionOne(person))
      }
    })

    // Report in the order the operator typed, not the order workers finished.
    const results: Row[] = people.map(
      (person) =>
        byPerson.get(person) ?? {
          person,
          result: "no result recorded",
          state: "ERROR",
          ok: false,
        },
    )

    // ---- One ownership sweep for the whole batch.
    // PROVISION_LEARNER skips its own sweep for a schema it just created (nothing can
    // be mis-owned in a schema that did not exist), so the guarantee is paid here:
    // once, across EVERY build schema. Runs after the parallel phase so it never
    // competes with provisioning for the same objects.
    let sweep: string | null = null
    try {
      const rows = await querySnowflake(`CALL ${ADMIN}.FIX_BUILD_OWNERSHIP('')`)
      sweep = String(firstValue(rows, "no result"))
    } catch (e) {
      sweep = `ownership sweep could not run: ${classifyError(e).title}`
    }

    if (runId) {
      try {
        await querySnowflake(
          `UPDATE ${ADMIN}.PROVISION_RUN SET FINISHED_AT = CURRENT_TIMESTAMP()
            WHERE RUN_ID = ${sqlLiteral(runId)}`,
        )
      } catch (e) {
        console.warn(new Date().toISOString(), "[provision] could not close run row", e)
      }
    }

    // When several people failed for the SAME environmental reason, say so once.
    // Otherwise a suspended warehouse looks like N unrelated per-person problems.
    const systemic = systemicSummary(classified)

    console.log(
      new Date().toISOString(),
      `[provision] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole}) provisioned ${people.length} in ${groups.length} group(s), concurrency ${CONCURRENCY}`,
    )
    return Response.json({
      runId,
      results,
      sweep,
      systemic: systemic
        ? {
            title: systemic.title,
            cause: systemic.cause,
            action: systemic.action,
            affected: classified.filter((c) => c.klass === systemic.klass).length,
          }
        : null,
      provisioned: results.filter((r) => r.state === "OK").length,
      partial: results.filter((r) => r.state === "PARTIAL").length,
      skipped: results.filter((r) => r.state === "SKIPPED").length,
      failed: results.filter((r) => r.state === "ERROR").length,
    })
  } catch (e) {
    return errorResponse(e, "provision")
  }
}
