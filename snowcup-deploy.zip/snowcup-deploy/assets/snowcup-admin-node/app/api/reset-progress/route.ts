import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeName, firstValue, sqlLiteral } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Put one learner back to the start of ONE training.
 *
 * Clears their checkpoints, reinforcement quiz answers, challenge answers and
 * points, and the completion stamp. Deliberately does NOT touch their build schema
 * -- the semantic view, agent, search service and views they built are their work,
 * not their score, and deleting hours of building would be unrecoverable. It also
 * leaves their role, schema and user defaults alone; that is offboarding, which is
 * what /api/deprovision is for.
 *
 * Runs with OWNER's rights like the other admin writes, so access is decided by
 * authorize() -- ACCOUNTADMIN or SNOWCUP_FACILITATOR only.
 *
 * Idempotent: resetting an already-clean learner reports "NOTHING TO DO" rather
 * than failing, so a double-click cannot produce an error.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint deletes learner progress with the app
    // owner's privileges. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const rawParticipant = typeof body?.participant === "string" ? body.participant : ""
    const rawTraining = typeof body?.training === "string" ? body.training : ""

    // Both are required. Defaulting the training would silently widen the reset
    // across every training the learner has progress in, which is the one thing
    // this endpoint is scoped NOT to do.
    if (!rawParticipant.trim() || !rawTraining.trim()) {
      return Response.json(
        { error: "Both participant and training are required." },
        { status: 400 },
      )
    }

    const participant = assertSafeName(rawParticipant)
    const training = assertSafeName(rawTraining)

    const rows = await querySnowflake(
      `CALL ${ADMIN}.RESET_LEARNER_PROGRESS(${sqlLiteral(participant)}, ${sqlLiteral(training)})`,
    )
    const result = String(firstValue(rows, "no result"))
    const ok = result.startsWith("RESET") || result.startsWith("NOTHING TO DO")

    console.log(
      new Date().toISOString(),
      `[reset-progress] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole})` +
        ` reset ${participant}/${training} -> ${result}`,
    )
    return Response.json({ result, ok, participant, training })
  } catch (e) {
    return errorResponse(e, "reset-progress")
  }
}
