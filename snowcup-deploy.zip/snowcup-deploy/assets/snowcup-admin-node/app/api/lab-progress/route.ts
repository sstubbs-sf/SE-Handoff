import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { GRADING } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Lab progress roll-up: one row per learner PER TRAINING.
 *
 * Gated by authorize(), then read with OWNER's rights, so a facilitator who holds
 * no privileges on the workshop schema still gets a truthful answer. This is the
 * same shape as the roster and health routes.
 *
 * STEPS_TOTAL comes from the view per row rather than as one global count: with
 * more than one training a single total would make every percentage wrong.
 */
export async function GET() {
  try {
    await authorize()

    const rows = await querySnowflake(
      `SELECT PARTICIPANT, MODULE_ID, MODULE_TITLE, STEPS_DONE, STEPS_TOTAL,
              PERCENT_COMPLETE, FURTHEST_SECTION_SEQ, QUESTIONS_CORRECT,
              QUESTIONS_TOTAL, QUIZ_CORRECT, QUIZ_TOTAL, CHALLENGE_POINTS,
              POINTS_POSSIBLE, VISITS, FIRST_SEEN_AT, LAST_SEEN_AT, LAST_STEP_AT,
              COMPLETED_AT, STATUS
         FROM ${GRADING}.LAB_PROGRESS_BY_LEARNER
        ORDER BY MODULE_ID, PERCENT_COMPLETE DESC, PARTICIPANT`,
    )

    return Response.json({
      rows: rows.map((r) => ({
        participant: String(r.PARTICIPANT),
        training: String(r.MODULE_ID),
        trainingTitle: r.MODULE_TITLE ? String(r.MODULE_TITLE) : String(r.MODULE_ID),
        stepsDone: Number(r.STEPS_DONE ?? 0),
        stepsTotal: Number(r.STEPS_TOTAL ?? 0),
        percentComplete: Number(r.PERCENT_COMPLETE ?? 0),
        furthestSectionSeq:
          r.FURTHEST_SECTION_SEQ === null ? null : Number(r.FURTHEST_SECTION_SEQ),
        questionsCorrect: Number(r.QUESTIONS_CORRECT ?? 0),
        questionsTotal: Number(r.QUESTIONS_TOTAL ?? 0),
        quizCorrect: Number(r.QUIZ_CORRECT ?? 0),
        quizTotal: Number(r.QUIZ_TOTAL ?? 0),
        challengePoints: Number(r.CHALLENGE_POINTS ?? 0),
        pointsPossible: Number(r.POINTS_POSSIBLE ?? 0),
        visits: Number(r.VISITS ?? 0),
        firstSeenAt: r.FIRST_SEEN_AT ?? null,
        lastSeenAt: r.LAST_SEEN_AT ?? null,
        lastStepAt: r.LAST_STEP_AT ?? null,
        completedAt: r.COMPLETED_AT ?? null,
        status: String(r.STATUS ?? ""),
      })),
    })
  } catch (e) {
    return errorResponse(e, "lab-progress")
  }
}
