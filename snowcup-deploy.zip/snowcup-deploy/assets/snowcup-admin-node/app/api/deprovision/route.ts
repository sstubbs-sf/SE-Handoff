import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeName, firstValue } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * Offboard learners. `dropSchema` is destructive -- it deletes the build schema
 * and everything the learner created in it (semantic view, search service,
 * custom tool, agent). The UI requires typing REMOVE; this route independently
 * requires an explicit confirm flag so a stray fetch cannot delete work.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint can DROP a learner's build schema with the
    // app owner's privileges. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const people: string[] = Array.isArray(body?.people) ? body.people.map(String) : []
    const dropSchema = body?.dropSchema === true
    const confirm = String(body?.confirm ?? "").trim().toUpperCase()

    if (!people.length) {
      return Response.json({ error: "No learners selected." }, { status: 400 })
    }
    if (confirm !== "REMOVE") {
      return Response.json(
        { error: "Confirmation missing: send confirm:'REMOVE' to proceed." },
        { status: 400 },
      )
    }

    const results: { person: string; result: string; ok: boolean }[] = []
    for (const person of people) {
      try {
        const safe = assertSafeName(person)
        const rows = await querySnowflake(
          `CALL ${ADMIN}.DEPROVISION_LEARNER('${safe}', ${dropSchema ? "TRUE" : "FALSE"})`,
        )
        const result = String(firstValue(rows, "no result"))
        results.push({ person, result, ok: !/^ERROR/i.test(result) })
      } catch (e) {
        results.push({ person, result: e instanceof Error ? e.message : "failed", ok: false })
      }
    }

    console.log(
      new Date().toISOString(),
      `[deprovision] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole}) removed ${people.length} dropSchema=${dropSchema}`,
    )
    return Response.json({
      results,
      dropSchema,
      processed: results.length,
      failed: results.filter((r) => !r.ok).length,
    })
  } catch (e) {
    return errorResponse(e, "deprovision")
  }
}
