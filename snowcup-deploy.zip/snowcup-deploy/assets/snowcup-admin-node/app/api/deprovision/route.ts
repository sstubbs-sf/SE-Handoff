import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { ADMIN, assertSafeName, firstValue, sqlLiteral, type OrphanTarget } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/** Names this route will pass to DEPROVISION_ORPHAN. The procedure gates on this too. */
const ORPHAN_ROLE = /^SNOWCUP_WS_[A-Z0-9_]+$/
const ORPHAN_SCHEMA = /^WS_[A-Z0-9_]+$/

/**
 * Offboard learners. `dropSchema` is destructive -- it deletes the build schema
 * and everything the learner created in it (semantic view, search service,
 * custom tool, agent). The UI requires typing REMOVE; this route independently
 * requires an explicit confirm flag so a stray fetch cannot delete work.
 *
 * `orphans` removes build spaces with NOBODY attached, addressed by literal role
 * and schema name. It ignores `dropSchema` on purpose: with no user there is no
 * access to revoke, so "keep their work" would be a no-op that reported success.
 */
export async function POST(request: Request) {
  try {
    // SECURITY BOUNDARY: this endpoint can DROP a learner's build schema with the
    // app owner's privileges. Refuse before touching anything.
    const caller = await authorize()

    const body = await request.json().catch(() => ({}))
    const people: string[] = Array.isArray(body?.people) ? body.people.map(String) : []
    const orphansIn: OrphanTarget[] = Array.isArray(body?.orphans) ? body.orphans : []
    const dropSchema = body?.dropSchema === true
    const confirm = String(body?.confirm ?? "").trim().toUpperCase()

    if (!people.length && !orphansIn.length) {
      return Response.json({ error: "Nothing selected." }, { status: 400 })
    }
    if (confirm !== "REMOVE") {
      return Response.json(
        { error: "Confirmation missing: send confirm:'REMOVE' to proceed." },
        { status: 400 },
      )
    }

    const results: { person: string; result: string; ok: boolean }[] = []
    for (const person of people) {
      try {
        const safe = assertSafeName(person)
        const rows = await querySnowflake(
          `CALL ${ADMIN}.DEPROVISION_LEARNER(${sqlLiteral(safe)}, ${dropSchema ? "TRUE" : "FALSE"})`,
        )
        const result = String(firstValue(rows, "no result"))
        results.push({ person, result, ok: !/^ERROR/i.test(result) })
      } catch (e) {
        results.push({ person, result: e instanceof Error ? e.message : "failed", ok: false })
      }
    }

    for (const o of orphansIn) {
      const role = String(o?.role ?? "").trim().toUpperCase()
      const schema = String(o?.schema ?? "").trim().toUpperCase()
      const label = role || schema || "(empty)"
      // Validate HERE as well as in the procedure. The procedure is the real gate,
      // but a name that never reaches SQL cannot be misread by it either.
      if ((role && !ORPHAN_ROLE.test(role)) || (schema && !ORPHAN_SCHEMA.test(schema))) {
        results.push({ person: label, result: `SKIPPED  ${label} (not a workshop name)`, ok: false })
        continue
      }
      if (!role && !schema) {
        results.push({ person: label, result: "SKIPPED  (no role and no schema)", ok: false })
        continue
      }
      try {
        const rows = await querySnowflake(
          `CALL ${ADMIN}.DEPROVISION_ORPHAN(${sqlLiteral(role)}, ${sqlLiteral(schema)})`,
        )
        const result = String(firstValue(rows, "no result"))
        // A SKIPPED orphan is not a success: it means the space is still there, and
        // most often that someone was granted the role since the roster was read.
        results.push({ person: label, result, ok: /^REMOVED/i.test(result) })
      } catch (e) {
        results.push({ person: label, result: e instanceof Error ? e.message : "failed", ok: false })
      }
    }

    console.log(
      new Date().toISOString(),
      `[deprovision] ${caller.user} (via ${caller.authorizedVia}, active ${caller.activeRole}) removed ${people.length} learner(s) + ${orphansIn.length} orphan(s) dropSchema=${dropSchema}`,
    )
    return Response.json({
      results,
      dropSchema,
      processed: results.length,
      failed: results.filter((r) => !r.ok).length,
    })
  } catch (e) {
    return errorResponse(e, "deprovision")
  }
}
