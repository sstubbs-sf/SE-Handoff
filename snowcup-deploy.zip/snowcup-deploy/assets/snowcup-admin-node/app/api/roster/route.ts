import { querySnowflake } from "@/lib/snowflake"
import { authorize, errorResponse } from "@/lib/authz"
import { BUILDS_DB, ROLE_PREFIX, SCHEMA_PREFIX, type RosterRow } from "@/lib/snowcup"

export const dynamic = "force-dynamic"

/**
 * The roster. Gated by authorize(); the reads themselves use OWNER's rights so a
 * SNOWCUP_FACILITATOR who holds no privileges on the workshop databases can
 * still see it -- that delegation is the point of the facilitator role.
 */
export async function GET() {
  try {
    await authorize()

    const roleRows = await querySnowflake(`SHOW ROLES LIKE '${ROLE_PREFIX}%'`)
    const roles = roleRows.map((r) => String(r.name)).sort()

    const schemaRows = await querySnowflake(
      `SHOW SCHEMAS LIKE '${SCHEMA_PREFIX}%' IN DATABASE ${BUILDS_DB}`,
    )
    const schemas = new Set(schemaRows.map((r) => String(r.name)))

    const holders: Record<string, string[]> = {}
    for (const role of roles) {
      const grants = await querySnowflake(`SHOW GRANTS OF ROLE ${role}`)
      holders[role] = grants
        .filter((g) => String(g.granted_to) === "USER")
        .map((g) => String(g.grantee_name))
    }

    const rows: RosterRow[] = roles.map((role) => {
      const schema = SCHEMA_PREFIX + role.slice(ROLE_PREFIX.length)
      const users = holders[role] ?? []
      return {
        learner: users.length ? users.join(", ") : "(nobody)",
        role,
        schema,
        schemaExists: schemas.has(schema),
        hasUser: users.length > 0,
      }
    })

    for (const schema of [...schemas].sort()) {
      const expected = ROLE_PREFIX + schema.slice(SCHEMA_PREFIX.length)
      if (!roles.includes(expected)) {
        rows.push({
          learner: "(none)",
          role: "MISSING",
          schema,
          schemaExists: true,
          hasUser: false,
        })
      }
    }

    const everyone = [...new Set(Object.values(holders).flat())].sort()
    return Response.json({ rows, everyone })
  } catch (e) {
    return errorResponse(e, "roster")
  }
}
