# SnowCup Admin

Facilitator console for the **SnowCup Build-an-Agent Lab**: add learners, see who is set up,
offboard people, and check that the workshop environment is actually ready to hand off.

Deployed as a **Snowflake App** (Next.js on Snowpark Container Services via Snowflake App Runtime).
It replaces the earlier Streamlit version of this console.

## How authorization works

This console does privileged work — it creates roles, alters users, and can drop a learner's build
schema. Two things are worth understanding before you change anything here.

**1. The privileged work runs as the app's owner, not as you.**
Snowflake's *restricted* caller's rights (the only caller's-rights mode App Runtime offers) forbids
`GRANT` statements outright, so provisioning simply cannot run as the operator — it fails with a
`SQL access control error`. Provisioning therefore runs with **owner's rights** (the app owner,
`ACCOUNTADMIN`).

**2. Because of that, `lib/authz.ts` is the security boundary — not Snowflake.**
Every route calls `authorize()` before touching data. Two independent layers must both hold:

| Layer | Controls |
|-------|----------|
| `USAGE` on the application service, granted only to `ACCOUNTADMIN` and `SNOWCUP_FACILITATOR` | Who can reach the app at all |
| `authorize()` in `lib/authz.ts` | Whether the signed-in person may act, before any owner's-rights query runs |

`app.yml` keeps `executeAsCaller: true` so the app can still identify *who* is using it
(`CURRENT_USER`, `CURRENT_AVAILABLE_ROLES`) under caller's rights. Don't remove it — identity is what
the gate and the audit log depend on.

### Held roles, not the active role

A Snowflake session opens with the user's **default** role, which is usually not the privileged one.
If the gate only looked at the active role hierarchy (`IS_ROLE_IN_SESSION`), a real facilitator whose
default role is something else would get a 403 — and could not fix it from inside the app, because
restricted caller's rights also forbids `USE ROLE`. In practice people conclude the app is broken.

So the gate authorizes on roles the user **holds** (`CURRENT_AVAILABLE_ROLES()`, which does work
under restricted caller's rights), unioned with the active hierarchy to catch roles inherited through
a parent role. **Facilitators do not need to switch roles before opening the app.**

**Trade-off, stated plainly:** someone who holds `ACCOUNTADMIN` but has deliberately switched to a
low-privilege role is still authorized here — they cannot drop privileges by switching roles. That is
why the UI always displays which role authorized them, so the elevation is visible rather than
silent, and why every provisioning action is logged against the username.

When someone genuinely lacks a qualifying role, the UI says so explicitly — that it is a permissions
issue rather than an app fault — lists the roles they *do* hold so they can rule out a mix-up, and
shows the exact statement an administrator needs to run:

```sql
GRANT ROLE SNOWCUP_FACILITATOR TO USER <them>;
```

Note it asks for `SNOWCUP_FACILITATOR`, never `ACCOUNTADMIN`: the point of the facilitator role is
that running this workshop should not require account admin.

## Panels

| Tab | What it does |
|-----|--------------|
| **Add learners** | Paste usernames or email-style logins (newline / comma separated). Previews the exact schema and role each person will get, then calls `PROVISION_LEARNER` per person. Idempotent — re-adding someone is harmless. |
| **Roster** | One row per per-learner role: who holds it, their build schema, and whether either is missing. Also surfaces orphaned build schemas that have no matching role. |
| **Remove** | Offboard people. Optionally drop their build schema and role. Requires ticking the destructive option *and* typing `REMOVE`; the API independently requires a `confirm` flag. |
| **Environment health** | Metrics plus seven pass/fail checks, including the learner-isolation gate and the "search owns the lore" gate (that `PLAYERS` has no `NICKNAME` column, so challenge Tier 4 genuinely needs Cortex Search). |

## Snowflake objects it reads and calls

| Object | Use |
|--------|-----|
| `SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER(VARCHAR)` | Provision one learner |
| `SNOWCUP_WORKSHOP.ADMIN.DEPROVISION_LEARNER(VARCHAR, BOOLEAN)` | Offboard, optionally dropping the schema |
| `SNOWCUP_BUILDS` schemas `WS_*` | Per-learner build schemas |
| Roles `SNOWCUP_WS_*` | Per-learner roles, and who holds them |
| `SNOWCUP_SHARED.TOURNAMENT.*` | Shared data health (6 tables, 48 players, no `PLAYERS.NICKNAME`) |
| `SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY` | Answer key health (8 questions / 120 points) |
| `SNOWCUP_PARTICIPANT` grants | Isolation gate — the shared role must hold no build-schema privileges |

## Input validation

Learner names are interpolated into a `CALL`, so they are **validated, not merely escaped**: names
must match `^[A-Za-z0-9._@+-]{1,128}$` and anything else is rejected before touching SQL
(`lib/snowcup.ts`). Provisioning is capped at 200 names per request.

## Key files

| File | Purpose |
|------|---------|
| `app/page.tsx` | Server component shell |
| `components/admin-console.tsx` | The four-tab client UI |
| `app/api/session/route.ts` | Who the caller is, which roles they hold, and whether they may act. Intentionally ungated so the UI can render an honest "not authorized" state. |
| `app/api/roster/route.ts` | Roster and the list of removable people |
| `app/api/health/route.ts` | Metrics and the seven health checks |
| `app/api/provision/route.ts` | `PROVISION_LEARNER` per person |
| `app/api/deprovision/route.ts` | `DEPROVISION_LEARNER`, confirm-gated |
| `lib/snowcup.ts` | Shared constants, name validation, parsing |
| `app.yml` | `executeAsCaller: true` + app profile |
| `snowflake.yml` | Deploy target: `SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP` |

`lib/snowflake.ts` and `next.config.mjs` are template infrastructure — don't edit them.

## Local development

```bash
npm install
SNOWFLAKE_CONNECTION_NAME=<your-connection> npm run dev
```

Locally there is no SPCS, so there is no app-owner identity to borrow: the owner's-rights queries
fall back to your CLI connection. If your connection's default role can't see `SNOWCUP_BUILDS`, the
roster and health panels return a 500 (not a 403 — the gate passes, the query fails). Pin the role:

```bash
SNOWFLAKE_CONNECTION_NAME=<your-connection> \
SNOWFLAKE_ROLE=ACCOUNTADMIN \
SNOWFLAKE_WAREHOUSE=SNOWCUP_WH \
npm run dev
```

Never run `node .next/standalone/server.js` for local preview — it does not serve static assets, so
the UI loads unstyled and never hydrates. Use `npm run dev` or `npm run start`.

## Deploy

```bash
snow app deploy
snow app open          # or: snow app open --print-only
```

Grant access to whoever should open it:

```sql
GRANT USAGE ON APPLICATION SERVICE SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP TO ROLE <role>;
```

Granting `USAGE` only decides who can reach the app. `lib/authz.ts` independently checks that the
person holds `ACCOUNTADMIN` or `SNOWCUP_FACILITATOR`, so adding a role here does not by itself let
anyone administer learners.

## Logs

```bash
snow app events --last 200
```
