import { querySnowflake } from "@/lib/snowflake"

/**
 * Authorization for the SnowCup Admin app.
 *
 * WHY THIS FILE IS THE SECURITY BOUNDARY
 * --------------------------------------
 * This console must create roles, alter users and drop schemas. Snowflake's
 * restricted caller's rights (the only caller's-rights mode App Runtime offers)
 * deliberately FORBIDS GRANT statements, so provisioning cannot run as the
 * operator -- verified: it fails with "SQL access control error". The privileged
 * work therefore runs with OWNER's rights (the app owner, ACCOUNTADMIN).
 *
 * That means Snowflake is no longer the thing stopping an unauthorised person
 * from administering learners -- THIS CODE IS. Every route must call
 * `authorize()` first and refuse on failure.
 *
 * Two independent layers have to both hold:
 *   1. USAGE on the application service (granted only to ACCOUNTADMIN and
 *      SNOWCUP_FACILITATOR) -- controls who can reach the app at all.
 *   2. This check -- confirms the signed-in person holds one of those roles
 *      before any owner's-rights work happens.
 *
 * WHY WE CHECK HELD ROLES, NOT JUST THE ACTIVE ROLE
 * -------------------------------------------------
 * A session opens with the user's DEFAULT role, which is often not the
 * privileged one. If we only checked the active role hierarchy
 * (IS_ROLE_IN_SESSION), a genuine facilitator whose default role is something
 * else would get a 403 and reasonably conclude the app is broken -- and they
 * could not fix it from inside the app, because restricted caller's rights also
 * forbids USE ROLE.
 *
 * So we authorize on roles the user HOLDS (CURRENT_AVAILABLE_ROLES), unioned with
 * the active hierarchy (which additionally catches roles inherited through a
 * parent role). The privileged work runs as the app owner regardless, so the
 * active role would not have changed what the app could do anyway.
 *
 * TRADE-OFF, STATED PLAINLY: this means a person who holds ACCOUNTADMIN but has
 * deliberately switched to a low-privilege role is still authorized here -- they
 * cannot "drop privileges" by switching roles. That is why the UI always shows
 * which role authorized them, so the elevation is visible rather than silent.
 */

/** Roles permitted to administer learners. Membership is the permission. */
export const ADMIN_ROLES = ["ACCOUNTADMIN", "SNOWCUP_FACILITATOR"] as const

/**
 * The role we tell people to ask for. Never ACCOUNTADMIN -- the whole point of
 * the facilitator role is that running this workshop should not require it.
 */
export const GRANTABLE_ADMIN_ROLE = "SNOWCUP_FACILITATOR"

export interface Caller {
  user: string
  /** The session's active primary role. */
  activeRole: string
  /** Every account-level role granted to this user. */
  availableRoles: string[]
  /** Qualifying roles this person holds (may include ones not currently active). */
  qualifyingRoles: string[]
  /** The role we authorized on, or null. */
  authorizedVia: string | null
  /** True when the ACTIVE role already qualifies (no elevation needed). */
  activeRoleQualifies: boolean
  /**
   * True when we could not enumerate held roles, so the decision fell back to
   * the active role hierarchy alone. Surface this: it turns a confusing refusal
   * into an actionable one ("try switching role").
   */
  roleDiscoveryDegraded: boolean
  authorized: boolean
}

function truthy(v: unknown): boolean {
  return v === true || String(v).toLowerCase() === "true"
}

/** CURRENT_AVAILABLE_ROLES() returns a JSON array string. Parse defensively. */
function parseRoles(raw: unknown): string[] {
  if (!raw) return []
  try {
    const parsed = JSON.parse(String(raw))
    return Array.isArray(parsed) ? parsed.map((r) => String(r).toUpperCase()) : []
  } catch {
    return []
  }
}

/**
 * Identify the operator using CALLER's rights, then decide whether they may act.
 * This is the real Snowflake session of the person in the browser, not a
 * spoofable header.
 *
 * Written as two queries on purpose. `CURRENT_AVAILABLE_ROLES()` is verified to
 * work under restricted caller's rights, but if a future runtime ever blocks it,
 * a single combined query would throw and take the ENTIRE app down with a 500 --
 * which is precisely the "the app is broken" outcome this gate exists to avoid.
 * So role discovery is allowed to fail on its own and degrade to the active-role
 * check, which is the behaviour we had before and is never worse.
 */
export async function identifyCaller(): Promise<Caller> {
  // Baseline identity. If THIS fails there is nothing sensible to do but throw.
  const rows = await querySnowflake(
    `SELECT CURRENT_USER()                              AS USER_NAME,
            CURRENT_ROLE()                              AS ROLE_NAME,
            IS_ROLE_IN_SESSION('ACCOUNTADMIN')          AS IN_AA,
            IS_ROLE_IN_SESSION('SNOWCUP_FACILITATOR')   AS IN_FAC`,
    { callersRights: true },
  )
  const r = rows[0] ?? {}

  const activeRole = String(r.ROLE_NAME ?? "unknown")
  const inSession: Record<string, boolean> = {
    ACCOUNTADMIN: truthy(r.IN_AA),
    SNOWCUP_FACILITATOR: truthy(r.IN_FAC),
  }

  // Roles the user HOLDS, even if not active. Best-effort by design.
  let availableRoles: string[] = []
  let roleDiscoveryDegraded = false
  try {
    const avail = await querySnowflake(`SELECT CURRENT_AVAILABLE_ROLES() AS AVAIL`, {
      callersRights: true,
    })
    availableRoles = parseRoles(avail[0]?.AVAIL)
    if (availableRoles.length === 0) roleDiscoveryDegraded = true
  } catch (e) {
    roleDiscoveryDegraded = true
    console.warn(
      new Date().toISOString(),
      "[authz] role discovery unavailable, falling back to active role only:",
      e instanceof Error ? e.message : e,
    )
  }

  // Held (granted directly) OR present in the active role hierarchy (catches
  // roles inherited via a parent role).
  const qualifyingRoles = ADMIN_ROLES.filter(
    (role) => availableRoles.includes(role) || inSession[role],
  )

  const activeRoleQualifies = ADMIN_ROLES.some(
    (role) => activeRole.toUpperCase() === role || inSession[role],
  )

  return {
    user: String(r.USER_NAME ?? "unknown"),
    activeRole,
    availableRoles,
    qualifyingRoles: [...qualifyingRoles],
    authorizedVia: qualifyingRoles[0] ?? null,
    activeRoleQualifies,
    roleDiscoveryDegraded,
    authorized: qualifyingRoles.length > 0,
  }
}

/** Thrown when the operator is not permitted to use this console. */
export class NotAuthorized extends Error {
  constructor(public readonly caller: Caller) {
    // Derive the role names from ADMIN_ROLES rather than hardcoding them, so the
    // message can never drift out of step with the roles actually enforced.
    super(
      `Not authorized. ${caller.user} holds none of ${ADMIN_ROLES.join(", ")} ` +
        `(active role: ${caller.activeRole}). This is a permissions issue, not an ` +
        `app fault — ask an administrator to run: ` +
        `GRANT ROLE ${GRANTABLE_ADMIN_ROLE} TO USER ${caller.user};` +
        (caller.roleDiscoveryDegraded
          ? ` NOTE: this session could not list the roles you hold, so only your ` +
            `active role was checked — switching to a qualifying role may also fix it.`
          : ""),
    )
    this.name = "NotAuthorized"
  }
}

/**
 * Gate every route. Returns the caller when permitted; throws NotAuthorized
 * otherwise. Call this BEFORE any owner's-rights query.
 */
export async function authorize(): Promise<Caller> {
  const caller = await identifyCaller()
  if (!caller.authorized) {
    console.warn(
      new Date().toISOString(),
      `[authz] refused user=${caller.user} activeRole=${caller.activeRole} ` +
        `heldRoles=${caller.availableRoles.length}`,
    )
    throw new NotAuthorized(caller)
  }
  return caller
}

/** Map an error to a response, using 403 for authorization failures. */
export function errorResponse(e: unknown, context: string) {
  if (e instanceof NotAuthorized) {
    return Response.json(
      { error: e.message, authorized: false, caller: e.caller },
      { status: 403 },
    )
  }
  console.error(new Date().toISOString(), `[${context}] failed`, e)
  return Response.json(
    { error: e instanceof Error ? e.message : `Failed: ${context}` },
    { status: 500 },
  )
}
