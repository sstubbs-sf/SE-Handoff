/**
 * Shared server-side logic for the SnowCup Admin app.
 *
 * Every query here runs with caller's rights, so the operator's own privileges
 * decide what succeeds. Nothing in this file grants extra power.
 */

export const ADMIN = "SNOWCUP_WORKSHOP.ADMIN"
/** Grading schema: challenge progress and lab checkpoint progress. */
export const GRADING = "SNOWCUP_WORKSHOP.GRADING"
export const BUILDS_DB = "SNOWCUP_BUILDS"
export const ROLE_PREFIX = "SNOWCUP_WS_"
export const SCHEMA_PREFIX = "WS_"

/**
 * Learner names reach SQL inside a CALL, and this app runs privileged
 * provisioning, so validate rather than merely escape. A Snowflake username or
 * an email-style login only ever needs these characters; anything else is
 * rejected outright instead of being quoted and hoped for.
 */
const SAFE_NAME = /^[A-Za-z0-9._@+-]{1,128}$/

export function assertSafeName(name: string): string {
  const trimmed = (name ?? "").trim()
  if (!SAFE_NAME.test(trimmed)) {
    throw new Error(
      `Rejected name ${JSON.stringify(trimmed)}: expected only letters, digits and . _ @ + - (max 128 chars).`,
    )
  }
  return trimmed
}

/** Mirror the procedures' sanitiser so the UI predicts the same object names. */
export function suffixFor(name: string): string {
  const local = name.split("@")[0].toUpperCase()
  return local.replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "")
}

/** Split a pasted blob on commas, semicolons and newlines; de-duplicate. */
export function parsePeople(blob: string): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const raw of (blob ?? "").split(/[,;\n\r]+/)) {
    const p = raw.trim()
    if (p && !seen.has(p.toUpperCase())) {
      seen.add(p.toUpperCase())
      out.push(p)
    }
  }
  return out
}

export interface RosterRow {
  learner: string
  role: string
  schema: string
  schemaExists: boolean
  hasUser: boolean
}

export interface HealthCheck {
  check: string
  ok: boolean
  detail: string
}

/** Coerce Snowflake's numeric/string returns to a number for comparisons. */
export function num(v: unknown): number {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

/** First column of the first row, or a fallback. */
export function firstValue<T>(rows: Record<string, any>[], fallback: T): T | string {
  if (!rows.length) return fallback
  const values = Object.values(rows[0])
  return values.length ? (values[0] as string) : fallback
}
