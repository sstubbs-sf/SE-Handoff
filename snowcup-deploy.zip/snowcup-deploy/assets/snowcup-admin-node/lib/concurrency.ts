/**
 * Bounded-concurrency map that preserves input order.
 *
 * Exists because provisioning a cohort one learner at a time is dominated by
 * round-trip latency, not warehouse work -- but the naive fix (Promise.all over
 * everyone) would fire an unbounded number of concurrent DDL statements at the
 * account. A fixed worker count keeps the pool (max 10 connections, see
 * lib/snowflake.ts) from being exhausted and keeps contention on shared objects
 * bounded and predictable.
 *
 * Order matters: results are written back by INDEX, so the caller's list is
 * returned in the order it was supplied no matter which worker finished first. A
 * results list that reshuffled itself as workers completed would make the UI's
 * per-person rows jump around mid-run.
 *
 * `fn` is expected to handle its own failures. Anything it throws is captured
 * against that one item and never aborts its siblings, because a half-provisioned
 * cohort that stopped at the first bad name is the outcome this whole feature
 * exists to avoid.
 */
export async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T, index: number) => Promise<R>,
): Promise<(R | { __error: unknown })[]> {
  const out = new Array<R | { __error: unknown }>(items.length)
  let next = 0

  const worker = async () => {
    for (;;) {
      const i = next++
      if (i >= items.length) return
      try {
        out[i] = await fn(items[i], i)
      } catch (e) {
        out[i] = { __error: e }
      }
    }
  }

  const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, worker)
  await Promise.all(workers)
  return out
}

/** True when mapLimit captured a throw rather than a value. */
export function isCaptured<R>(v: R | { __error: unknown }): v is { __error: unknown } {
  return typeof v === "object" && v !== null && "__error" in v
}
