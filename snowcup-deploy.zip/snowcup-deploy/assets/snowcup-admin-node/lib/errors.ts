/**
 * Turn Snowflake and driver errors into something a facilitator can act on.
 *
 * WHY THIS EXISTS. Every failure used to reach the operator as
 * `Query failed: <raw driver text>`. "Object 'SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNER'
 * does not exist or not authorized" is a precise message to a Snowflake engineer and
 * useless to someone running a workshop, who needs to be told the setup script has not
 * been run in this account.
 *
 * WHAT THIS DELIBERATELY DOES NOT DO. It never replaces the raw text -- it adds to it.
 * A classifier is a guess about a string pattern, and a wrong guess that discarded the
 * original would make its own misclassification impossible to diagnose. Unrecognised
 * errors pass through verbatim rather than being forced into the nearest category, and
 * every classification carries the Snowflake query id when one is known, because that
 * is what makes a support conversation tractable.
 *
 * The stored procedures already explain themselves well (cause plus remedy, four
 * states). This layer is for INFRASTRUCTURE failures and for errors that never reached
 * a procedure at all.
 */

/**
 * Failure classes. `systemic` marks the ones that are a property of the ENVIRONMENT
 * rather than of the person being provisioned -- a dead warehouse fails every learner
 * in the batch identically, and telling the operator that once is far more useful than
 * repeating a cryptic line per person.
 */
export type ErrorClass =
  | "not_authorized"
  | "setup_missing"
  | "insufficient_privileges"
  | "warehouse_unavailable"
  | "timeout"
  | "contention"
  | "token_rotated"
  | "network"
  | "bad_name"
  | "unknown"

export interface Classified {
  klass: ErrorClass
  /** One-line summary suitable for a heading. */
  title: string
  /** What this actually means, in the operator's terms. */
  cause: string
  /** The concrete next step. Empty when there is nothing honest to suggest. */
  action: string
  /** True when the cause is the environment, not this particular person. */
  systemic: boolean
  /** Safe to try again unchanged: the operation is idempotent and the fault transient. */
  retryable: boolean
  /** The original message, never modified. */
  raw: string
  queryId?: string
}

/** Snowflake surfaces the query id in driver errors; keep it for support. */
function extractQueryId(raw: string): string | undefined {
  const m = raw.match(/queryId=([0-9a-f-]{16,})/i) ?? raw.match(/Query ID:\s*([0-9a-f-]{16,})/i)
  return m?.[1]
}

/**
 * Ordered most-specific first. Order matters: a lock-conflict message also contains
 * the word "timeout", so contention must be tested before the generic timeout rule or
 * a retryable contention error would be reported as an unrelated statement timeout.
 */
const RULES: {
  klass: ErrorClass
  match: RegExp
  title: string
  cause: string
  action: string
  systemic: boolean
  retryable: boolean
}[] = [
  {
    klass: "contention",
    match: /lock|deadlock|concurrent (?:ddl|operation)|transaction .* is locked|000041/i,
    title: "Two operations touched the same object at once",
    cause:
      "Provisioning runs several learners in parallel, and they briefly compete for objects they share -- the SNOWCUP_FACILITATOR role and the saved-defaults table.",
    action:
      "This was already retried once. Re-run the same list: provisioning is idempotent, so anyone already set up is left alone.",
    systemic: false,
    retryable: true,
  },
  {
    klass: "warehouse_unavailable",
    match: /warehouse .*(?:cannot be resumed|is suspended|does not exist|not authorized to use)|no active warehouse|resuming/i,
    title: "The warehouse is not usable right now",
    cause:
      "The query had no warehouse to run on. A warehouse stuck resuming is usually a regional Snowflake incident rather than anything misconfigured here.",
    action:
      "Check status.snowflake.com FIRST, before changing any settings. If it is green, confirm the app's query warehouse still exists and is grantable.",
    systemic: true,
    retryable: false,
  },
  {
    klass: "timeout",
    match: /statement reached its .*timeout|57014|execution time exceeded/i,
    title: "The statement ran out of time",
    cause:
      "Snowflake cancelled the statement at its timeout. During an incident this is often how an unavailable warehouse presents itself.",
    action: "Check status.snowflake.com, then re-run. Provisioning is idempotent.",
    systemic: true,
    retryable: true,
  },
  {
    klass: "setup_missing",
    match: /(?:object|procedure|function|table) '?SNOWCUP[A-Z0-9_.$]*'? does not exist|unknown function|does not exist or not authorized.*SNOWCUP/i,
    title: "The workshop objects are missing in this account",
    cause:
      "A SNOWCUP procedure or table could not be found. Either snowcup-data-setup.sql was never run in this account, or it ran under a role that did not create everything.",
    action:
      "Run snowcup-data-setup.sql as ACCOUNTADMIN, then retry. If it HAS been run, check GRANT USAGE ON PROCEDURE ... TO ROLE SNOWCUP_FACILITATOR.",
    systemic: true,
    retryable: false,
  },
  {
    klass: "insufficient_privileges",
    match: /insufficient privileges|not authorized to perform|requires .* privilege/i,
    title: "The active role is not allowed to do this",
    cause:
      "The operation needs a privilege the app's role does not hold. Transferring ownership of an object created by ACCOUNTADMIN is the usual case -- SNOWCUP_FACILITATOR cannot do it.",
    action: "Re-run this step as ACCOUNTADMIN. Provisioning itself is unaffected.",
    systemic: true,
    retryable: false,
  },
  {
    klass: "not_authorized",
    match: /does not exist or not authorized/i,
    title: "Object missing, or not visible to this role",
    cause:
      "Snowflake reports these two situations with one message, so this is either a genuinely absent object or one the current role cannot see.",
    action: "Confirm the object exists, then check the grants for the app's role.",
    systemic: true,
    retryable: false,
  },
  {
    klass: "token_rotated",
    match: /terminated connection|authentication token has expired|invalid.*token/i,
    title: "The app's Snowflake session expired mid-run",
    cause:
      "The SPCS service token rotated while the batch was running. One retry is already built in, so seeing this means the retry also failed.",
    action: "Re-run. If it keeps happening, restart the application service.",
    systemic: true,
    retryable: true,
  },
  {
    klass: "network",
    match: /getaddrinfo|ENOTFOUND|ECONNREFUSED|socket hang up|network error/i,
    title: "Could not reach Snowflake",
    cause:
      "A network-level failure. Inside SPCS this normally means the external account URL was used instead of the internal host.",
    action: "Confirm the app resolves Snowflake via SNOWFLAKE_HOST rather than the account URL.",
    systemic: true,
    retryable: false,
  },
  {
    klass: "bad_name",
    match: /Rejected name|expected only letters/i,
    title: "That name cannot be used",
    cause: "The name contains characters the workshop refuses to put into an identifier.",
    action: "Use the person's Snowflake username or email exactly as it appears in SHOW USERS.",
    systemic: false,
    retryable: false,
  },
]

/**
 * Classify a thrown error. Unrecognised input is returned as `unknown` with the raw
 * text preserved and no invented cause -- see the note at the top of this file.
 */
export function classifyError(e: unknown, queryId?: string): Classified {
  const raw = e instanceof Error ? e.message : String(e ?? "unknown error")
  const qid = queryId ?? extractQueryId(raw)

  for (const r of RULES) {
    if (r.match.test(raw)) {
      return {
        klass: r.klass,
        title: r.title,
        cause: r.cause,
        action: r.action,
        systemic: r.systemic,
        retryable: r.retryable,
        raw,
        queryId: qid,
      }
    }
  }

  return {
    klass: "unknown",
    title: "Provisioning failed",
    cause: "This error is not one the console recognises, so it is shown exactly as Snowflake reported it.",
    action: "",
    systemic: false,
    retryable: false,
    raw,
    queryId: qid,
  }
}

/**
 * One-line rendering for the per-person result list, which is a fixed-width log
 * rather than a place for paragraphs. The raw text is always included so the line
 * remains diagnosable.
 */
export function explainOneLine(c: Classified): string {
  const bits = [c.title]
  if (c.action) bits.push(c.action)
  bits.push(`[${c.raw}${c.queryId ? ` queryId=${c.queryId}` : ""}]`)
  return bits.join(" — ")
}

/**
 * The single systemic class to headline when a batch fails en masse, or null when the
 * failures are not a shared environmental cause. Returns null below two failures: one
 * failure is adequately explained by its own row.
 */
export function systemicSummary(classified: Classified[]): Classified | null {
  const systemic = classified.filter((c) => c.systemic)
  if (systemic.length < 2) return null
  const counts = new Map<ErrorClass, number>()
  for (const c of systemic) counts.set(c.klass, (counts.get(c.klass) ?? 0) + 1)
  let best: ErrorClass | null = null
  let bestN = 0
  for (const [k, n] of counts) {
    if (n > bestN) {
      best = k
      bestN = n
    }
  }
  if (!best || bestN < 2) return null
  return systemic.find((c) => c.klass === best) ?? null
}
