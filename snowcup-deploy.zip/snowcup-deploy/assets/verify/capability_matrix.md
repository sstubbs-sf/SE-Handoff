# SnowCup learner capability matrix

Every action the lab asks a learner to perform, the privilege it needs, and where
that privilege comes from. This is the specification `check_learner_capabilities.sh`
tests against — if you add a step to the lab, add a row here and a probe there.

Two role objects matter:

- `SNOWCUP_WS_<NAME>` — the learner's own role, and their `DEFAULT_ROLE`. Owns
  everything they build.
- `SNOWCUP_PARTICIPANT` — shared, **nested inside** the per-learner role. Supplies
  the shared data, grading access, and the three account-level privileges.

The nesting is load bearing. Module 8 and 10 evaluations run as **tasks**, and
tasks ignore secondary roles, so every privilege an evaluation needs must be
reachable from the single primary role. Inheritance satisfies that; a secondary
role would not.

## Legend

| Source | Meaning |
|---|---|
| `WS` | granted directly to `SNOWCUP_WS_<NAME>` |
| `PART` | granted to `SNOWCUP_PARTICIPANT`, reaching the learner by inheritance |
| `OWN` | conferred by ownership of an object the learner created |
| `FREE` | needs no grant |

## Module 0 — Meet Cortex Code

| Action | Object / privilege | Source |
|---|---|---|
| Read session context | `CURRENT_ROLE()` etc. | FREE |
| `CALL MY_LAB_DEFAULTS()` | USAGE on procedure | PART |
| `CALL MY_LAB_DEFAULTS_APPLY()` | USAGE on procedure | PART |
| `CALL MY_LAB_DEFAULTS_RESTORE()` | USAGE on procedure | PART |
| `ALTER USER SET` own defaults | self-alter | FREE |
| Resolve warehouse | USAGE, OPERATE on `SNOWCUP_WH` | PART |

## Modules 1-2 — Connect and Explore

| Action | Object / privilege | Source |
|---|---|---|
| List shared tables | USAGE on `SNOWCUP_SHARED` + `TOURNAMENT` | PART |
| Read all six shared tables | SELECT on ALL/FUTURE TABLES | PART |
| Multi-table knockout join | SELECT + warehouse | PART |
| Confirm own build space | USAGE on `SNOWCUP_BUILDS` + own schema | PART / WS |

## Module 3 — Model a semantic view

| Action | Object / privilege | Source |
|---|---|---|
| `CREATE VIEW` (enriched flags) | CREATE VIEW on own schema | WS |
| `CREATE SEMANTIC VIEW` | CREATE SEMANTIC VIEW on own schema | WS |
| `CREATE OR REPLACE` / add metrics | ownership of semantic view | OWN |
| Validate row counts | SELECT | PART |

## Module 4 — Cortex Search

| Action | Object / privilege | Source |
|---|---|---|
| `CREATE CORTEX SEARCH SERVICE` | CREATE CORTEX SEARCH SERVICE on own schema | WS |
| Index `PLAYER_PROFILES` in **another database** | SELECT on the source table | PART |
| Build on `SNOWCUP_WH` | USAGE on warehouse | PART |
| Query it (`SEARCH_PREVIEW`) | ownership of the service | OWN |

## Module 5 — Verified queries

| Action | Object / privilege | Source |
|---|---|---|
| Run SQL against the semantic view | SELECT on semantic view + base tables | OWN / PART |
| Save a verified query | ownership of semantic view | OWN |

## Module 6 — Assemble your agent

| Action | Object / privilege | Source |
|---|---|---|
| `CREATE AGENT` | CREATE AGENT on own schema | WS |
| Attach Analyst tool | SELECT on own semantic view | OWN |
| Attach Search tool | USAGE on own search service | OWN |
| `CREATE PROCEDURE SCOUTING_REPORT` | CREATE PROCEDURE on own schema | WS |
| `AI_COMPLETE` with `claude-sonnet-5` | `SNOWFLAKE.CORTEX_USER` + `USE AI FUNCTIONS` | WS + PART |
| Attach procedure as custom tool | USAGE on own procedure | OWN |
| Set `execution_environment` warehouse | USAGE on `SNOWCUP_WH` | PART |
| Run the agent | `CORTEX_AGENT_USER`, ownership | PART / OWN |
| `DESCRIBE AGENT`, `ALTER AGENT` | ownership | OWN |

## Module 7 — Publish

| Action | Object / privilege | Source |
|---|---|---|
| Set display name, avatar, samples | ownership of agent | OWN |
| Converse in CoWork Preview | ownership + `CORTEX_AGENT_USER` | OWN / PART |

Note: Module 7 teaches the three-layer grant chain but issues **no** GRANT. The
learner's agent stays private, which is the intended default.

## Module 8 — Evaluate

Cortex Analyst evaluations need all seven of the following, and per the docs they
must be reachable from a **single primary role** because runs execute as tasks.

| Requirement | Source |
|---|---|
| `SNOWFLAKE.CORTEX_USER` | WS (direct) + PART |
| `USE AI FUNCTIONS` on account | PART |
| `EXECUTE TASK` on account | PART |
| `CREATE TASK` on the semantic view's schema | WS |
| `CREATE DATASET` on the semantic view's schema | WS |
| SELECT on the semantic view and its tables | OWN + PART |
| **MONITOR on the semantic view** | OWN (implied by ownership) |

Plus, for the SQL path: `CREATE STAGE` and `CREATE FILE FORMAT` (both WS) to hold
the run-configuration YAML.

## Module 9 — Beat the challenge

| Action | Object / privilege | Source |
|---|---|---|
| Query own agent | ownership | OWN |
| Reach the Referee agent | USAGE on `SNOWCUP_WORKSHOP` + `GRADING` + agent | PART |
| `CALL SUBMIT_ANSWER` | USAGE on procedure | PART |
| Read own score / leaderboard | SELECT on `MY_SCORE`, `LEADERBOARD` | PART |

## Module 10 — Operate

| Action | Object / privilege | Source |
|---|---|---|
| Accept semantic view Suggestions | ownership + `CORTEX_USER` | OWN / PART |
| Re-run evaluations | as Module 8 | — |
| Save regression cases | ownership | OWN |
| **Read own query history** | `INFORMATION_SCHEMA.QUERY_HISTORY_BY_USER()` | FREE |
| **Agent usage history / thumbs-down feedback** | no grant exists | **GAP** |

`SNOWFLAKE.ACCOUNT_USAGE` is not readable by a learner and deliberately so —
it is account-wide. Whether Snowsight's own Suggestions and trace panels work for
an object owner through privileged internal paths is not determinable from SQL and
must be checked by a learner in the UI.

## Must be DENIED

Negative controls. If any of these succeed the isolation model is broken, and a
suite that only checks the positives would pass anyway.

| Object | Why it must fail |
|---|---|
| `GRADING.CHALLENGE_KEY` | the challenge answer key |
| `GRADING.QUIZ_KEY` | the quiz answer key |
| `GRADING.LAB_PROGRESS` | every learner's raw progress |
| `GRADING.QUIZ_PROGRESS` | every learner's quiz answers |
| `ADMIN.USER_DEFAULTS_BACKUP` | the whole ADMIN schema is facilitator-only |
| another learner's build schema | per-learner isolation |
| `SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY` | account-wide history |

## Grant durability

`GRANT USAGE ON ALL PROCEDURES IN SCHEMA` is a **point-in-time** grant. Replacing
a procedure with `CREATE OR REPLACE` drops its grants, and the bulk grant does not
come back on its own. Every `CREATE OR REPLACE PROCEDURE` must therefore be
followed by its own explicit `GRANT USAGE`, or the grant silently rots the next
time someone edits the procedure. Both live regressions found by the first audit
had exactly this cause.
