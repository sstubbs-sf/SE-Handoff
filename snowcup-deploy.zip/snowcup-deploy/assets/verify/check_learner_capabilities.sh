#!/usr/bin/env bash
# ============================================================================
#  SnowCup - learner capability audit
#
#      ./verify/check_learner_capabilities.sh <connection> [learner_role]
#
#  Proves, by EXECUTION, that a learner can do every single thing the lab asks
#  of them -- and cannot do any of the things it must deny them.
#
#  WHY THIS EXISTS AND check_roles.sql IS NOT ENOUGH
#  check_roles.sql reads grant metadata. Its own header admits check 6 cannot
#  see search services, procedures or functions because SHOW has no owner
#  column for them, so a PASS there is not proof. Worse, a grant row can exist
#  while the operation still fails (wrong schema, wrong role in the chain), and
#  an operation can succeed for a reason unrelated to the grant you think is
#  carrying it. The only trustworthy check is to run the statement as the
#  learner and look at what happens.
#
#  TESTING AS THE LEARNER, PROPERLY
#  Every probe runs with --role <learner_role> and NO secondary roles. That
#  matters because the person running this audit is usually ACCOUNTADMIN: with
#  secondary roles active you re-test ACCOUNTADMIN and everything passes.
#  The suite asserts CURRENT_SECONDARY_ROLES() is empty before it trusts a
#  single result.
#
#  NEGATIVE CONTROLS ARE NOT OPTIONAL
#  A suite of only positive checks passes just as happily against a role that
#  holds ACCOUNTADMIN. The DENY block is what proves the harness can detect a
#  failure at all. If a deny probe ever succeeds, that is a data leak, not a
#  test bug.
#
#  READ-ONLY BY DEFAULT. Probes create nothing. The Module 8 evaluation path
#  cannot be proven without writing, so it is reported as NOT PROVEN rather
#  than quietly assumed -- run with --write to include it.
# ============================================================================
set -uo pipefail
cd "$(dirname "$0")/.."

CONN="${1:-}"
ROLE="${2:-}"
WRITE=0
for a in "$@"; do [[ "$a" == "--write" ]] && WRITE=1; done

# Discovery and grant introspection must NOT run as the learner.
#
# THIS WAS A REAL BUG. These queries originally ran with no --role, which means
# they inherited the connection's default role -- and for anyone who has run the
# lab that default IS their own SNOWCUP_WS_ role. A learner cannot see another
# learner's schema, which is the whole point, so discovery found exactly one
# schema and the cross-learner isolation check SKIPPED itself with "only one
# learner exists" against an account holding 31 of them. A skip that reports
# success is worse than a failure.
ADMIN_ROLE="${SNOWCUP_AUDIT_ADMIN_ROLE:-ACCOUNTADMIN}"

run_as_admin() { snow sql -c "$CONN" --role "$ADMIN_ROLE" -q "$1" 2>/dev/null; }

if [[ -z "$CONN" ]]; then
  echo "usage: ./verify/check_learner_capabilities.sh <connection> [learner_role] [--write]" >&2
  exit 2
fi

pass=0; fail=0; skip=0

# Run SQL as the learner. Returns 0 when the statement succeeded.
run_as() {
  snow sql -c "$CONN" --role "$ROLE" -q "$1" 2>&1
}

# An authorization failure, as opposed to a genuine error in our own SQL.
# Snowflake hides objects you lack USAGE on, so "does not exist" is an
# authorization signal too -- that is exactly how a missing procedure grant
# surfaces.
#
# BOTH CONDITIONS ARE REQUIRED, and that is the whole point. Matching the phrase
# alone gave a false FAIL on DESCRIBE PROCEDURE: the procedure SOURCE that a
# successful describe returns contains the words "does not exist" in its own
# comments and error strings, so a successful probe was read as a denial. Demand
# an actual Snowflake error code (six digits and an SQLSTATE) as proof that the
# statement failed at all, THEN look at why.
denied() {
  grep -qE '[0-9]{6} \([0-9A-Z]{5}\)' <<<"$1" \
    && grep -qiE "not authorized|Insufficient privileges|Unknown user-defined function|does not exist" <<<"$1"
}

# ALLOW: the learner MUST be able to do this.
allow() {
  local label="$1" sql="$2" out
  out="$(run_as "$sql")"
  if denied "$out"; then
    printf '  FAIL  %-52s %s\n' "$label" "denied"
    printf '%s\n' "$out" | grep -iE "not authorized|does not exist|Insufficient" | head -1 | sed 's/^/           /'
    fail=$((fail + 1))
  elif grep -qiE "^\s*\|\s*Error|SQL compilation error|invalid identifier" <<<"$out"; then
    # A broken probe is not a provisioning failure. Say so instead of blaming
    # the grant model -- an earlier audit nearly filed a false gap this way,
    # when a quoting mistake in the probe read as a privilege denial.
    printf '  WARN  %-52s %s\n' "$label" "probe error, not a privilege problem"
    printf '%s\n' "$out" | grep -iE "SQL compilation error|invalid identifier" | head -1 | sed 's/^/           /'
    skip=$((skip + 1))
  else
    printf '  PASS  %-52s %s\n' "$label" "allowed"
    pass=$((pass + 1))
  fi
}

# DENY: the learner MUST NOT be able to do this.
deny() {
  local label="$1" sql="$2" out
  out="$(run_as "$sql")"
  if denied "$out"; then
    printf '  PASS  %-52s %s\n' "$label" "correctly denied"
    pass=$((pass + 1))
  else
    printf '  FAIL  %-52s %s\n' "$label" "*** ALLOWED - ISOLATION LEAK ***"
    fail=$((fail + 1))
  fi
}

# ---------------------------------------------------------------------------
# Resolve a learner role if the caller did not name one. Prefer a role that is
# actually assigned to a user, since an unassigned role is workshop debris and
# testing it proves nothing about a real learner.
# ---------------------------------------------------------------------------
if [[ -z "$ROLE" ]]; then
  ROLE="$(snow sql -c "$CONN" --role "$ADMIN_ROLE" -q "SHOW ROLES LIKE 'SNOWCUP_WS_%'" --format json 2>/dev/null \
    | python3 -c '
import json,sys
try: rows=json.load(sys.stdin)
except Exception: rows=[]
rows=[r for r in rows if str(r.get("assigned_to_users","0")) not in ("0","")]
print(rows[0]["name"] if rows else "")' 2>/dev/null)"
fi

if [[ -z "$ROLE" ]]; then
  echo "FAIL  no SNOWCUP_WS_* role assigned to any user -- nothing to audit." >&2
  echo "      An empty environment must not report success." >&2
  exit 1
fi

echo "==> Auditing learner capabilities as $ROLE"
echo

# ---------------------------------------------------------------------------
# Gate 0. Prove the harness is actually testing a learner.
# ---------------------------------------------------------------------------
ctx="$(run_as "SELECT CURRENT_ROLE() AS R, CURRENT_SECONDARY_ROLES() AS S")"
if ! grep -q "$ROLE" <<<"$ctx"; then
  echo "FAIL  could not assume $ROLE; every later result would be meaningless." >&2
  exit 1
fi
if ! grep -q '{"roles":"","value":""}' <<<"$ctx"; then
  echo "FAIL  secondary roles are ACTIVE. This would re-test the caller's own" >&2
  echo "      privileges (usually ACCOUNTADMIN) and pass vacuously." >&2
  exit 1
fi
echo "  PASS  harness runs as $ROLE with no secondary roles"
pass=$((pass + 1))

SCHEMA="SNOWCUP_BUILDS.WS_${ROLE#SNOWCUP_WS_}"

echo
echo "-- Module 0: session and self-service defaults"
allow "MY_LAB_DEFAULTS (report)"        "DESCRIBE PROCEDURE SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS()"
allow "MY_LAB_DEFAULTS_APPLY"           "DESCRIBE PROCEDURE SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS_APPLY()"
allow "MY_LAB_DEFAULTS_RESTORE"         "DESCRIBE PROCEDURE SNOWCUP_WORKSHOP.GRADING.MY_LAB_DEFAULTS_RESTORE()"
allow "warehouse resolves"              "SELECT CURRENT_WAREHOUSE()"

echo
echo "-- Modules 1-2: shared data"
for t in PLAYERS PLAYER_PROFILES MATCHES PLAYER_MATCH_STATS DISCIPLINE TOURNAMENTS; do
  allow "SELECT $t" "SELECT COUNT(*) FROM SNOWCUP_SHARED.TOURNAMENT.$t"
done
allow "multi-table knockout join" \
  "SELECT p.PLAYER_NAME FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_MATCH_STATS s JOIN SNOWCUP_SHARED.TOURNAMENT.MATCHES m ON m.MATCH_ID = s.MATCH_ID JOIN SNOWCUP_SHARED.TOURNAMENT.PLAYERS p ON p.PLAYER_ID = s.PLAYER_ID WHERE m.STAGE <> 'Group' GROUP BY p.PLAYER_NAME LIMIT 1"

echo
echo "-- Module 3-5: own build space, semantic view"
allow "USAGE on own build schema"       "SHOW TABLES IN SCHEMA $SCHEMA"
allow "own semantic view visible"       "SHOW SEMANTIC VIEWS IN SCHEMA $SCHEMA"

echo
echo "-- Module 4/6: search service and agent"
allow "own search services visible"     "SHOW CORTEX SEARCH SERVICES IN SCHEMA $SCHEMA"
allow "own agents visible"              "SHOW AGENTS IN SCHEMA $SCHEMA"
allow "AI_COMPLETE on pinned model"     "SELECT AI_COMPLETE('claude-sonnet-5','Reply with exactly: OK')"

echo
echo "-- Module 8 prerequisites (privileges, not a run)"
for p in "CREATE TASK" "CREATE DATASET" "CREATE STAGE" "CREATE FILE FORMAT"; do
  got="$(run_as_admin "SHOW GRANTS TO ROLE $ROLE" | grep -c "$p")"
  if [[ "$got" -gt 0 ]]; then
    printf '  PASS  %-52s %s\n' "$p on own schema" "granted"; pass=$((pass + 1))
  else
    printf '  FAIL  %-52s %s\n' "$p on own schema" "MISSING - blocks evaluations"; fail=$((fail + 1))
  fi
done
for p in "EXECUTE TASK" "USE AI FUNCTIONS"; do
  got="$(run_as_admin "SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT" | grep -c "$p")"
  if [[ "$got" -gt 0 ]]; then
    printf '  PASS  %-52s %s\n' "$p on account" "granted"; pass=$((pass + 1))
  else
    printf '  FAIL  %-52s %s\n' "$p on account" "MISSING - blocks evaluations"; fail=$((fail + 1))
  fi
done

echo
echo "-- Module 9: challenge and grading"
allow "Referee agent reachable"         "DESCRIBE AGENT SNOWCUP_WORKSHOP.GRADING.SNOWCUP_REFEREE"
allow "SUBMIT_ANSWER reachable"         "DESCRIBE PROCEDURE SNOWCUP_WORKSHOP.GRADING.SUBMIT_ANSWER(VARCHAR,VARCHAR)"
allow "GET_PROGRESS callable"           "CALL SNOWCUP_WORKSHOP.GRADING.GET_PROGRESS()"
allow "read MY_SCORE"                   "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.MY_SCORE"
allow "read LEADERBOARD"                "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.LEADERBOARD"
allow "read MY_LAB_PROGRESS"            "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.MY_LAB_PROGRESS"
allow "read LAB_STEPS"                  "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.LAB_STEPS"

echo
echo "-- Module 10: own query history"
allow "own query history"               "SELECT COUNT(*) FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY_BY_USER())"

echo
echo "-- MUST BE DENIED (isolation)"
deny "answer key CHALLENGE_KEY"         "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY"
deny "quiz key QUIZ_KEY"                "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.QUIZ_KEY"
deny "everyone's LAB_PROGRESS"          "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.LAB_PROGRESS"
deny "everyone's QUIZ_PROGRESS"         "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.GRADING.QUIZ_PROGRESS"
deny "ADMIN.USER_DEFAULTS_BACKUP"       "SELECT COUNT(*) FROM SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP"
deny "account-wide QUERY_HISTORY"       "SELECT COUNT(*) FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY"

# Cross-learner isolation needs a second learner to be meaningful. Skipping it
# loudly beats reporting a pass we did not earn.
OTHER="$(snow sql -c "$CONN" --role "$ADMIN_ROLE" -q "SHOW SCHEMAS IN DATABASE SNOWCUP_BUILDS" --format json 2>/dev/null \
  | python3 -c '
import json,sys
try: rows=json.load(sys.stdin)
except Exception: rows=[]
me="'"${SCHEMA#SNOWCUP_BUILDS.}"'"
o=[r["name"] for r in rows if str(r.get("name","")).startswith("WS_") and r["name"]!=me]
print(o[0] if o else "")' 2>/dev/null)"
if [[ -n "$OTHER" ]]; then
  deny "another learner's schema ($OTHER)" "SHOW TABLES IN SCHEMA SNOWCUP_BUILDS.$OTHER"
else
  printf '  SKIP  %-52s %s\n' "cross-learner isolation" "only one learner exists"
  skip=$((skip + 1))
fi

echo
if [[ "$WRITE" -eq 1 ]]; then
  echo "-- Module 8 evaluation run (--write)"
  echo "     Not implemented as an automated probe: a run creates a dataset and a"
  echo "     task, and needs a verified query on the semantic view. Drive it from"
  echo "     Snowsight (AI & ML > Cortex Analyst > Evaluations) as the learner and"
  echo "     confirm it reaches a completed state."
  skip=$((skip + 1))
else
  printf '  NOT PROVEN  %-46s %s\n' "Module 8 evaluation run" "needs --write"
  skip=$((skip + 1))
fi

echo
echo "  $pass passed, $fail failed, $skip skipped/unproven"
if [[ "$pass" -eq 0 ]]; then
  echo "FAIL  zero probes passed -- treat this as a broken harness, not a pass." >&2
  exit 1
fi
exit $(( fail > 0 ? 1 : 0 ))
