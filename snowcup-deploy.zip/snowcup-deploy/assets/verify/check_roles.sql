-- ============================================================================
--  SnowCup - role model verification
--  Run against a deployed environment:
--      snow sql -f verify/check_roles.sql -c default
-- ============================================================================
--  The workshop uses three kinds of role:
--
--    SNOWCUP_PARTICIPANT   shared read-only access. Must hold NO privileges on
--                          any build schema - that is what keeps one learner from
--                          reading another's work.
--    SNOWCUP_WS_<NAME>     one per learner. Build rights on that learner's own
--                          schema only, with SNOWCUP_PARTICIPANT nested inside so
--                          a single DEFAULT_ROLE covers the whole lab.
--    SNOWCUP_FACILITATOR   oversight. Every SNOWCUP_WS_ role granted to it.
--
--  Every check must report PASS. Checks are written with STARTSWITH / POSITION
--  rather than LIKE: an underscore is a LIKE wildcard, and backslash is NOT an
--  escape character in Snowflake unless you add an ESCAPE clause, so 'WS\_%'
--  silently matches nothing and every check passes vacuously.
-- ============================================================================
USE ROLE ACCOUNTADMIN;
USE WAREHOUSE SNOWCUP_WH;

-- ---------------------------------------------------------------------------
-- 1. THE ISOLATION GATE. The shared role must hold zero SCHEMA privileges on
--    any WS_ build schema.
--
--    Scoped to granted_on = 'SCHEMA' on purpose. The property that matters is
--    that the shared role cannot reach INTO a build schema, which is a
--    schema-level grant. Object-level grants inside a build schema are a
--    learner's own business: an agent or view they choose to share carries a
--    fully-qualified name that also contains "WS_", so a looser match would
--    fail on a legitimate action. Module 7 no longer asks learners to share
--    their agent (it now teaches the opposite -- your agent is yours alone),
--    but nothing stops one from doing it, so keep this scoped.
-- ---------------------------------------------------------------------------
SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT;
WITH g AS (SELECT "privilege" AS priv, "granted_on" AS go, "name" AS nm
             FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())))
SELECT 'isolation: shared role has no build-schema privileges' AS check_name,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                       AS verdict,
       COUNT(*)                                                AS offending,
       COALESCE(LISTAGG(priv || ' on ' || nm, ', '), '(none)')  AS detail
  FROM g
 WHERE go = 'SCHEMA' AND POSITION('.WS_' IN nm) > 0;

-- ---------------------------------------------------------------------------
-- 2. Structure: every build schema has a matching per-user role, and every
--    per-user role has a matching schema. A mismatch means a half-provisioned
--    learner. Also guards against the vacuous case of zero learners.
-- ---------------------------------------------------------------------------
SHOW ROLES LIKE 'SNOWCUP_WS_%';
WITH roles AS (
  SELECT SUBSTR("name", LENGTH('SNOWCUP_WS_') + 1) AS sfx
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
   WHERE STARTSWITH("name", 'SNOWCUP_WS_')
), schemas AS (
  SELECT SUBSTR(SCHEMA_NAME, LENGTH('WS_') + 1) AS sfx
    FROM SNOWCUP_BUILDS.INFORMATION_SCHEMA.SCHEMATA
   WHERE STARTSWITH(SCHEMA_NAME, 'WS_')
), mismatched AS (
  SELECT COALESCE(r.sfx, s.sfx) AS sfx,
         IFF(r.sfx IS NULL, 'schema with no role', 'role with no schema') AS problem
    FROM roles r FULL OUTER JOIN schemas s ON r.sfx = s.sfx
   WHERE r.sfx IS NULL OR s.sfx IS NULL
)
SELECT 'structure: schemas and per-user roles are paired' AS check_name,
       IFF((SELECT COUNT(*) FROM mismatched) = 0
           AND (SELECT COUNT(*) FROM roles) > 0, 'PASS', 'FAIL') AS verdict,
       (SELECT COUNT(*) FROM roles)                              AS roles_found,
       (SELECT COUNT(*) FROM schemas)                            AS schemas_found,
       COALESCE((SELECT LISTAGG(sfx || ': ' || problem, ', ') FROM mismatched),
                '(all paired)')                                 AS detail;

-- ---------------------------------------------------------------------------
-- 3. Scope: a per-user role must reach EXACTLY ONE build schema. More than one
--    would mean a learner can see somebody else's work. Sampled on the role
--    belonging to whoever is running this script.
-- ---------------------------------------------------------------------------
-- Derive the probe role from a role that actually EXISTS, preferring the current
-- user's own. Deriving it purely from CURRENT_USER() breaks in two real cases:
-- a fresh account where nobody is provisioned yet (the role does not exist, and
-- SHOW GRANTS TO ROLE then aborts this whole script), and the common case where
-- the facilitator deploying is not themselves enrolled as a learner.
--
-- REQUIRES AT LEAST ONE PROVISIONED LEARNER. With none, there is no role model to
-- verify -- provision first, then run this. deploy.sh enforces that ordering.
SHOW ROLES LIKE 'SNOWCUP_WS_%';
SET probe_role = (
  SELECT COALESCE(
           MAX(CASE WHEN "name" = 'SNOWCUP_WS_' ||
                 TRIM(REGEXP_REPLACE(UPPER(SPLIT_PART(CURRENT_USER(), '@', 1)),
                                     '[^A-Z0-9]+', '_'), '_')
                    THEN "name" END),
           MAX("name"))
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));
SHOW GRANTS TO ROLE IDENTIFIER($probe_role);
WITH g AS (SELECT "granted_on" AS go, "name" AS nm FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())))
SELECT 'scope: ' || $probe_role || ' reaches exactly one build schema' AS check_name,
       IFF(COUNT(DISTINCT nm) = 1, 'PASS', 'FAIL')       AS verdict,
       COUNT(DISTINCT nm)                               AS schemas_reached,
       COALESCE(LISTAGG(DISTINCT nm, ', '), '(none)')    AS detail
  FROM g
 WHERE go = 'SCHEMA' AND POSITION('.WS_' IN nm) > 0;

-- ---------------------------------------------------------------------------
-- 4. Facilitator coverage: every per-user role is granted to SNOWCUP_FACILITATOR
--    so an admin can reach every build schema. Explicitly fails when there are
--    no learners, so an empty account cannot report a false PASS.
-- ---------------------------------------------------------------------------
SHOW GRANTS TO ROLE SNOWCUP_FACILITATOR;
WITH held AS (
  SELECT "name" AS role_name FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
   WHERE "granted_on" = 'ROLE' AND STARTSWITH("name", 'SNOWCUP_WS_')
), expected AS (
  SELECT COUNT(*) AS n FROM SNOWCUP_BUILDS.INFORMATION_SCHEMA.SCHEMATA
   WHERE STARTSWITH(SCHEMA_NAME, 'WS_')
)
SELECT 'coverage: facilitator holds every per-user role' AS check_name,
       IFF((SELECT n FROM expected) > 0
           AND (SELECT COUNT(*) FROM held) = (SELECT n FROM expected),
           'PASS', 'FAIL')                    AS verdict,
       (SELECT n FROM expected)               AS learner_schemas,
       (SELECT COUNT(*) FROM held)            AS roles_held;

-- ---------------------------------------------------------------------------
-- 5. Nesting: every per-user role inherits SNOWCUP_PARTICIPANT (shared data,
--    Referee, score views) and holds CORTEX_USER. Cortex is granted directly as
--    well as inherited so the lab cannot break on inheritance subtleties.
-- ---------------------------------------------------------------------------
SHOW GRANTS TO ROLE IDENTIFIER($probe_role);
WITH g AS (SELECT "name" AS nm FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())))
SELECT 'nesting: per-user role inherits shared access and Cortex' AS check_name,
       IFF(SUM(IFF(nm = 'SNOWCUP_PARTICIPANT', 1, 0)) > 0
           AND SUM(IFF(nm ILIKE '%CORTEX_USER%', 1, 0)) > 0, 'PASS', 'FAIL') AS verdict,
       SUM(IFF(nm = 'SNOWCUP_PARTICIPANT', 1, 0)) AS has_participant,
       SUM(IFF(nm ILIKE '%CORTEX_USER%', 1, 0))   AS has_cortex
  FROM g;

-- ---------------------------------------------------------------------------
-- 6. Ownership: everything in a build schema is owned by that learner's role.
--
--    An object created in WS_<NAME> by any other role (ACCOUNTADMIN or
--    SNOWCUP_FACILITATOR, typically a facilitator helping someone who is stuck)
--    leaves the learner with NO privilege on it. Snowsight then shows them an
--    empty schema and the natural conclusion is "the lab is broken" -- there is
--    no error message anywhere to contradict that.
--
--    Covers the object kinds whose owner is discoverable in one query. Tables and
--    views come from INFORMATION_SCHEMA; semantic views and agents have no
--    INFORMATION_SCHEMA equivalent, so they are read back with RESULT_SCAN.
--    LAST_QUERY_ID(-N) is used rather than temp tables: this script sets no
--    current database, and a CREATE TEMP TABLE would fail with "session does not
--    have a current database".
--
--    NOT COVERED HERE: Cortex Search Services and procedures/functions, which
--    learners also create. SHOW CORTEX SEARCH SERVICES and SHOW PROCEDURES return
--    no "owner" column, so this owner-column approach cannot see them at all --
--    which is how a learner ended up blocked by an admin-owned search service
--    while this gate reported PASS.
--
--    The authoritative check for EVERY kind asks the question backwards ("what
--    exists, minus what the learner's role owns") and deploy.sh runs it:
--        ./verify/check_build_ownership.sh <connection>
--    A PASS here does NOT mean every object is correctly owned.
-- ---------------------------------------------------------------------------
SHOW SEMANTIC VIEWS IN DATABASE SNOWCUP_BUILDS;
SHOW AGENTS IN DATABASE SNOWCUP_BUILDS;

WITH sv AS (
  SELECT "schema_name" AS sch, "name" AS obj, 'SEMANTIC VIEW' AS kind, "owner" AS owner
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID(-2)))
), ag AS (
  SELECT "schema_name" AS sch, "name" AS obj, 'AGENT' AS kind, "owner" AS owner
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID(-1)))
), everything AS (
  SELECT TABLE_SCHEMA AS sch, TABLE_NAME AS obj,
         IFF(TABLE_TYPE = 'VIEW', 'VIEW', 'TABLE') AS kind, TABLE_OWNER AS owner
    FROM SNOWCUP_BUILDS.INFORMATION_SCHEMA.TABLES
   WHERE STARTSWITH(TABLE_SCHEMA, 'WS_')
  UNION ALL SELECT sch, obj, kind, owner FROM sv WHERE STARTSWITH(sch, 'WS_')
  UNION ALL SELECT sch, obj, kind, owner FROM ag WHERE STARTSWITH(sch, 'WS_')
), mis AS (
  -- Schema WS_SSTUBBS pairs with role SNOWCUP_WS_SSTUBBS.
  SELECT sch, obj, kind, owner FROM everything
   WHERE owner <> 'SNOWCUP_' || sch
)
SELECT 'ownership: learners own everything in their build schema' AS check_name,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                          AS verdict,
       COUNT(*)                                                   AS mis_owned,
       COALESCE(LISTAGG(kind || ' ' || sch || '.' || obj
                        || ' owned by ' || owner, '; '), '(none)') AS detail
  FROM mis;

-- Fix any row reported above by handing the object to the learner's role. Do NOT
-- add COPY CURRENT GRANTS: it would carry the admin's grants across and can widen
-- access beyond the one learner, defeating the isolation gate in check 1.
--   GRANT OWNERSHIP ON <KIND> SNOWCUP_BUILDS.WS_<NAME>.<OBJ>
--     TO ROLE SNOWCUP_WS_<NAME>;
