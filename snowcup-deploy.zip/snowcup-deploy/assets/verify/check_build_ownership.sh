#!/usr/bin/env bash
# ===========================================================================
# Ownership gate for learner build schemas, all object kinds.
#
#   ./verify/check_build_ownership.sh <connection> [role]
#
# WHY THIS IS A THIN WRAPPER
# It calls SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP rather than reimplementing
# the check. The bug this gate exists for was caused by three separate
# implementations of "who owns this" drifting apart -- the SQL gate, the admin
# console, and an earlier version of this script -- each reading an "owner" column
# that does not exist for every kind. One definition, used everywhere, is the
# actual fix. Covering a newly supported object kind now means editing one
# procedure.
#
# WHAT IT CATCHES
# An object created inside WS_<NAME> by any role other than SNOWCUP_WS_<NAME>:
# a facilitator helping someone who is stuck, or whoever authored the reference
# solution on ACCOUNTADMIN. The learner then holds no privilege on it and there is
# no error anywhere -- the schema simply looks empty, or an agent reports
# "the Cortex Search Service does not exist or access is not authorized".
#
# It stays hidden while DEFAULT_SECONDARY_ROLES = ALL keeps ACCOUNTADMIN active in
# the tester's session, because the object resolves through the admin role. Verify
# fixes with USE SECONDARY ROLES NONE, or you are testing the admin role.
# ===========================================================================
set -uo pipefail

CONN="${1:-}"
ROLE="${2:-ACCOUNTADMIN}"
if [[ -z "$CONN" ]]; then
  echo "usage: $0 <connection> [role]" >&2
  exit 2
fi

# The marker is assembled by concatenation so the literal string cannot appear in
# the query text. snow echoes the query it runs, so a plain marker would be
# matched in the echo and the gate would "find" rows that do not exist.
SQL="CALL SNOWCUP_WORKSHOP.ADMIN.AUDIT_BUILD_OWNERSHIP(NULL);
     SELECT 'VIOL' || 'ATION>' || KIND || ' | ' || SCH || '.' || OBJ
            || ' | owned by ' || OWNER AS V
       FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))"

OUT="$(snow sql -c "$CONN" --role "$ROLE" -q "$SQL" </dev/null 2>&1)"

# A hard failure must never read as "no violations". If the procedure is missing
# or errored, say so and fail -- an unverified schema is not a clean one.
if echo "$OUT" | tr -d '\n' | grep -qiE 'does not exist or not authorized|Unknown user-defined function|SQL compilation error|Insufficient privileges'; then
  echo "  FAIL  could not run ADMIN.AUDIT_BUILD_OWNERSHIP -- ownership is UNVERIFIED"
  echo "$OUT" | tail -6 | sed 's/^/        /'
  echo "        Re-run snowcup-data-setup.sql, which creates it."
  exit 1
fi

VIOLATIONS="$(echo "$OUT" | grep -oE 'VIOLATION>.*' | sed 's/VIOLATION>//' | sed 's/ *|$//')"
COUNT="$(printf '%s' "$VIOLATIONS" | grep -c . || true)"
COUNT="${COUNT:-0}"

if [[ "$COUNT" -eq 0 ]]; then
  echo "  PASS  every object in every build schema is owned by its learner's role"
  exit 0
fi

echo "  FAIL  $COUNT object(s) not owned by the learner who needs them:"
printf '%s\n' "$VIOLATIONS" | sed 's/^/          /'
echo
echo "  Repair from the admin console (Environment health -> Repair ownership), or:"
echo "      CALL SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP(NULL);   -- all learners"
echo "      CALL SNOWCUP_WORKSHOP.ADMIN.FIX_BUILD_OWNERSHIP('name'); -- just one"
echo "  Re-running provisioning repairs it too. Never add COPY CURRENT GRANTS to a"
echo "  manual fix: it carries the admin's grants across and widens access beyond"
echo "  that one learner."
exit 1
