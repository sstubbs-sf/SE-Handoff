-- ============================================================================
--  SnowCup - answer verification
--  Run AFTER deploying snowcup-data-setup.sql and snowcup-grader-setup.sql.
-- ============================================================================
--  Two questions this answers, both of which have caught real bugs:
--
--   1. Does the answer key still match what the data actually says?
--      The stats hash on PLAYER_ID || MATCH_ID, so a rebrand should not move any
--      answer. This re-derives all eight from the data, independently of the key,
--      and compares. A MISMATCH means an ID or a HASH() expression was touched.
--
--   2. Is any answer a TIE?
--      QUALIFY ROW_NUMBER() ... = 1 silently returns an arbitrary row when values
--      tie. That is how a lab demo once returned two different players on two
--      runs, one of them a scored answer. So every winner is counted at its max
--      value and TIED must be 1.
--
--  Expect: 8 rows, verdict MATCH, tied = 1 on every row.
-- ============================================================================
USE ROLE ACCOUNTADMIN;
USE WAREHOUSE SNOWCUP_WH;

WITH s AS (
  SELECT st.*, p.PLAYER_NAME, p.NATION, p.POSITION,
         m.EDITION_YEAR, m.STAGE, m.HOME_TEAM, m.AWAY_TEAM, m.HOME_SCORE, m.AWAY_SCORE
    FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_MATCH_STATS st
    JOIN SNOWCUP_SHARED.TOURNAMENT.PLAYERS  p ON p.PLAYER_ID = st.PLAYER_ID
    JOIN SNOWCUP_SHARED.TOURNAMENT.MATCHES  m ON m.MATCH_ID  = st.MATCH_ID
),
-- one row per question: the metric per candidate, so we can both rank and
-- count ties without a second pass
cand AS (
  SELECT 'Q1' AS qid, PLAYER_NAME AS who, SUM(GOALS)::FLOAT AS metric
    FROM s WHERE EDITION_YEAR = 2026 GROUP BY PLAYER_NAME
  UNION ALL
  SELECT 'Q2', CHAMPION, COUNT(*)::FLOAT
    FROM SNOWCUP_SHARED.TOURNAMENT.TOURNAMENTS GROUP BY CHAMPION
  UNION ALL
  SELECT 'Q3', PLAYER_NAME, SUM(ASSISTS)::FLOAT
    FROM s WHERE POSITION = 'Defender' AND STAGE <> 'Group'
   GROUP BY PLAYER_NAME HAVING SUM(SHOTS) = 0
  UNION ALL
  SELECT 'Q4', PLAYER_NAME, COUNT(*)::FLOAT
    FROM s
   WHERE POSITION = 'Goalkeeper' AND MINUTES > 0
     AND ((NATION = HOME_TEAM AND AWAY_SCORE = 0) OR (NATION = AWAY_TEAM AND HOME_SCORE = 0))
   GROUP BY PLAYER_NAME
  UNION ALL
  SELECT 'Q5', PLAYER_NAME, SUM(LATE_GOALS)::FLOAT
    FROM s WHERE STAGE <> 'Group' AND ABS(HOME_SCORE - AWAY_SCORE) = 1
   GROUP BY PLAYER_NAME
  UNION ALL
  SELECT 'Q6', NATION, (SUM(GOALS) - SUM(XG))::FLOAT
    FROM s GROUP BY NATION
  UNION ALL
  SELECT 'Q7', PLAYER_NAME, 1::FLOAT
    FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES WHERE NICKNAME = 'The Whiteout'
  UNION ALL
  SELECT 'Q8', p.PLAYER_NAME, SUM(d.YELLOW_CARDS + d.RED_CARDS)::FLOAT
    FROM SNOWCUP_SHARED.TOURNAMENT.DISCIPLINE d
    JOIN SNOWCUP_SHARED.TOURNAMENT.PLAYERS p ON p.PLAYER_ID = d.PLAYER_ID
   GROUP BY p.PLAYER_NAME
),
top AS (
  SELECT qid, MAX(metric) AS best FROM cand GROUP BY qid
),
winners AS (
  SELECT c.qid, c.who, c.metric, COUNT(*) OVER (PARTITION BY c.qid) AS tied
    FROM cand c JOIN top t ON t.qid = c.qid AND c.metric = t.best
)
SELECT
  k.QUESTION_ID,
  k.POINTS,
  k.CANONICAL_ANSWER          AS key_says,
  w.who                       AS data_says,
  w.metric,
  w.tied,
  CASE WHEN w.who IS NULL                        THEN '*** NO DATA ***'
       WHEN UPPER(k.CANONICAL_ANSWER) <> UPPER(w.who) THEN '*** MISMATCH ***'
       WHEN w.tied > 1                           THEN '*** TIED - AMBIGUOUS ***'
       ELSE 'MATCH' END       AS verdict
FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY k
LEFT JOIN winners w ON w.qid = k.QUESTION_ID
WHERE k.MODULE_ID = 'SNOWCUP'
ORDER BY k.QUESTION_ID;

-- ============================================================================
--  Demo safety: every lab demo must resolve to a NON-answer, and be tie-free.
--  Expect: 6 rows, all verdict 'safe', all tied = 1.
-- ============================================================================
WITH s AS (
  SELECT st.*, p.PLAYER_NAME, p.NATION, p.POSITION, m.EDITION_YEAR, m.STAGE
    FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_MATCH_STATS st
    JOIN SNOWCUP_SHARED.TOURNAMENT.PLAYERS  p ON p.PLAYER_ID = st.PLAYER_ID
    JOIN SNOWCUP_SHARED.TOURNAMENT.MATCHES  m ON m.MATCH_ID  = st.MATCH_ID
),
cand AS (
  SELECT 'M2 midfielder knockout tackles, never scored' AS demo, PLAYER_NAME AS who,
         SUM(TACKLES)::FLOAT AS metric
    FROM s WHERE POSITION = 'Midfielder' AND STAGE <> 'Group'
   GROUP BY PLAYER_NAME HAVING SUM(GOALS) = 0
  UNION ALL
  SELECT 'M5 xG overperformance by position', POSITION, (SUM(GOALS) - SUM(XG))::FLOAT
    FROM s GROUP BY POSITION
  UNION ALL
  SELECT 'M6 search: The Snowplow', PLAYER_NAME, 1::FLOAT
    FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES WHERE NICKNAME = 'The Snowplow'
  UNION ALL
  SELECT 'M7 turn 1: top scorer 2018', PLAYER_NAME, SUM(GOALS)::FLOAT
    FROM s WHERE EDITION_YEAR = 2018 GROUP BY PLAYER_NAME
  UNION ALL
  SELECT 'M7 turn 2: top scorer 2018 Cirrus', PLAYER_NAME, SUM(GOALS)::FLOAT
    FROM s WHERE EDITION_YEAR = 2018 AND NATION = 'Cirrus' GROUP BY PLAYER_NAME
  UNION ALL
  SELECT 'M7 turn 4: most distance', PLAYER_NAME, SUM(DISTANCE_KM)::FLOAT
    FROM s GROUP BY PLAYER_NAME
),
top AS (SELECT demo, MAX(metric) AS best FROM cand GROUP BY demo),
winners AS (
  SELECT c.demo, c.who, c.metric, COUNT(*) OVER (PARTITION BY c.demo) AS tied
    FROM cand c JOIN top t ON t.demo = c.demo AND c.metric = t.best
)
SELECT w.demo, w.who AS result, w.metric, w.tied,
       CASE WHEN EXISTS (SELECT 1 FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY k
                          WHERE k.MODULE_ID = 'SNOWCUP'
                            AND UPPER(k.CANONICAL_ANSWER) = UPPER(w.who))
                 THEN '*** LEAKS AN ANSWER ***'
            WHEN w.tied > 1 THEN '*** TIED - NON-DETERMINISTIC ***'
            ELSE 'safe' END AS verdict
FROM winners w
ORDER BY w.demo;

-- ============================================================================
--  Bio hygiene: a player bio must not STATE the superlative that its question
--  asks for. Learners need SELECT on PLAYER_PROFILES for Cortex Search to work,
--  so any "most / greatest / top scorer" claim in a bio hands over the answer to
--  anyone who reads the table - a leak the learner-file scanner cannot see
--  because it lives in the data, not the HTML.
--
--  The bios keep their nickname and personality so search still finds them;
--  proving the superlative is what the semantic view is for. That search-then-
--  confirm split is exactly the two-tool workflow the lab teaches.
--
--  Expect: 0 rows.
-- ============================================================================
SELECT k.QUESTION_ID, k.CANONICAL_ANSWER,
       REGEXP_SUBSTR(p.BIO, '[^.]*(most|greatest|top scorer|more [^.]* than)[^.]*') AS offending_clause
  FROM SNOWCUP_WORKSHOP.GRADING.CHALLENGE_KEY k
  JOIN SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES p
    ON UPPER(p.PLAYER_NAME) = UPPER(k.CANONICAL_ANSWER)
 WHERE k.MODULE_ID = 'SNOWCUP'
   AND REGEXP_LIKE(p.BIO, '.*(most|greatest|top scorer|more .* than).*', 'i')
 ORDER BY k.QUESTION_ID;

-- ---------------------------------------------------------------------------
-- GATE: PLAYERS must NOT expose NICKNAME.
-- PLAYERS is the table learners model into their semantic view. A nickname
-- column there lets Cortex Analyst answer lore questions by string match,
-- which defeats the Module 6 "wrong tool" lesson and makes challenge Tier 4
-- winnable without Cortex Search. Verified empirically: with a nickname
-- dimension exposed, an Analyst-only agent answered 3 of 4 description-only
-- lore questions correctly. NICKNAME belongs on PLAYER_PROFILES only.
-- ---------------------------------------------------------------------------
SELECT 'nickname isolation' AS check_name,
       IFF(COUNT(*) = 0, 'PASS', '*** FAIL - PLAYERS.NICKNAME defeats Tier 4 ***') AS verdict,
       COUNT(*) AS offending_columns
  FROM SNOWCUP_SHARED.INFORMATION_SCHEMA.COLUMNS
 WHERE TABLE_SCHEMA = 'TOURNAMENT' AND TABLE_NAME = 'PLAYERS'
   AND COLUMN_NAME = 'NICKNAME';

SELECT 'nickname available to search' AS check_name,
       IFF(COUNT(*) = 11, 'PASS', '*** FAIL - expected 11 nicknamed profiles ***') AS verdict,
       COUNT(*) AS nicknamed_profiles
  FROM SNOWCUP_SHARED.TOURNAMENT.PLAYER_PROFILES
 WHERE NICKNAME IS NOT NULL;
