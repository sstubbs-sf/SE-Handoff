#!/usr/bin/env bash
# Run every static check. Exits non-zero if any gate fails.
#
#   ./verify/run_all.sh
#
# The live-data checks are separate and need a deployed environment:
#   snow sql -f verify/verify_answers.sql -c default
set -uo pipefail
cd "$(dirname "$0")/.."

fails=0
for check in "check_names.py --all" "check_key.py" "check_roster.py" \
             "check_leaks.py" "check_html.py" "check_lab_steps.py" \
             "check_quizzes.py"; do
  # shellcheck disable=SC2086
  if python3 verify/$check >/tmp/verify_out.txt 2>&1; then
    printf '  PASS  %s\n' "$check"
  else
    printf '  FAIL  %s\n' "$check"
    sed 's/^/          /' /tmp/verify_out.txt | tail -20
    fails=$((fails + 1))
  fi
done

echo
if [ "$fails" -eq 0 ]; then
  echo "all static checks passed"
  echo
  echo "next, the LIVE checks (each needs a deployed environment):"
  echo "  snow sql -f verify/check_roles.sql -c default"
  echo "  ./verify/check_build_ownership.sh <connection>"
  echo "  ./verify/check_learner_capabilities.sh <connection>   <- run this before every workshop"
  echo
  echo "check_learner_capabilities.sh is the only gate that proves a learner can"
  echo "actually DO each step, by executing it as them. The static checks cannot"
  echo "see a dropped grant, and a dropped grant is the failure that has bitten"
  echo "this workshop twice. See verify/capability_matrix.md."
else
  echo "$fails check(s) failed"
fi
exit "$fails"
