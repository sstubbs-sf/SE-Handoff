#!/usr/bin/env bash
# Run every static check. Exits non-zero if any gate fails.
#
#   ./verify/run_all.sh
#
# The live-data checks are separate and need a deployed environment:
#   snow sql -f verify/verify_answers.sql -c default
set -uo pipefail
cd "$(dirname "$0")/.."

fails=0
for check in "check_names.py --all" "check_key.py" "check_roster.py" \
             "check_leaks.py" "check_html.py" "check_lab_steps.py" \
             "check_quizzes.py"; do
  # shellcheck disable=SC2086
  if python3 verify/$check >/tmp/verify_out.txt 2>&1; then
    printf '  PASS  %s\n' "$check"
  else
    printf '  FAIL  %s\n' "$check"
    sed 's/^/          /' /tmp/verify_out.txt | tail -20
    fails=$((fails + 1))
  fi
done

echo
if [ "$fails" -eq 0 ]; then
  echo "all static checks passed"
  echo "next: snow sql -f verify/verify_answers.sql -c default   (needs a deployed environment)"
else
  echo "$fails check(s) failed"
fi
exit "$fails"
