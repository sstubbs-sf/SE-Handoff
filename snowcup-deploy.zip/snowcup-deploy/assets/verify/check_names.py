#!/usr/bin/env python3
"""
Naming hygiene for the SnowCup rebrand.

Two independent gates:

  --constraints  (run BEFORE editing files)
      Verifies the mapping itself is sound: unique surnames, unique full names,
      unique nicknames, and that no accepted answer variant is a word-boundary
      substring of some other entity. This matters because accepted variants are
      surname-based, so a duplicate or a substring collision could let grading
      credit the wrong player.

  --files        (run AFTER editing files)
      Verifies no legacy token survived anywhere in the deliverables.

Exit code 1 on any failure so it can gate a build.
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mapping import (  # noqa: E402
    ANSWER_KEY, CLUBS, DEMO_PLAYERS, DEPTH_NATIONS, LEGACY_TOKENS,
    NATIONS, NICKNAMES, PLAYERS, VENUES,
)

FAIL, INFO = [], []


def fail(msg):
    FAIL.append(msg)


def info(msg):
    INFO.append(msg)


def norm(s):
    """Mirror the grader's _NORM: upper, strip punctuation, collapse spaces."""
    s = re.sub(r"[^A-Za-z0-9 ]", "", s or "")
    return re.sub(r"\s+", " ", s).strip().upper()


def word_in(needle, haystack):
    return re.search(r"\b" + re.escape(needle) + r"\b", haystack, re.I) is not None


# Which PLAYER_ID / nation each scored question must resolve to.
EXPECTED_SLOT = {
    "Q1": ("player", "P05"), "Q3": ("player", "P17"), "Q4": ("player", "P26"),
    "Q5": ("player", "P24"), "Q7": ("player", "P35"), "Q8": ("player", "P37"),
    "Q2": ("nation", "Valoria"), "Q6": ("nation", "Drakmoor"),
}


def check_constraints():
    new_names = [new for _, new in PLAYERS.values()]
    surnames = [n.split()[-1] for n in new_names]

    # 1. uniqueness
    for label, seq in (("full name", new_names), ("surname", surnames),
                       ("nickname", list(NICKNAMES.values())),
                       ("nation", list(NATIONS.values()))):
        seen = {}
        for v in seq:
            k = norm(v)
            if k in seen:
                fail("duplicate %s: %r collides with %r" % (label, v, seen[k]))
            seen[k] = v

    # 2. old names must all be distinct too (else a replace is ambiguous)
    old_names = [old for old, _ in PLAYERS.values()]
    if len(set(map(norm, old_names))) != len(old_names):
        fail("duplicate OLD player name - find/replace would be ambiguous")

    # 3. answer key resolves to the intended slot
    for qid, (canonical, variants) in ANSWER_KEY.items():
        kind, slot = EXPECTED_SLOT[qid]
        expected = PLAYERS[slot][1] if kind == "player" else NATIONS[slot]
        if norm(canonical) != norm(expected):
            fail("%s canonical %r != expected %s %r" % (qid, canonical, kind, expected))
        if norm(canonical) not in [norm(v) for v in variants]:
            fail("%s canonical %r missing from its own accepted variants" % (qid, canonical))

    # 4. Q7 / Q8 must NOT accept their nickname (the nickname IS the question)
    for qid, nick in (("Q7", "The Whiteout"), ("Q8", "The Iceman")):
        if norm(nick) in [norm(v) for v in ANSWER_KEY[qid][1]]:
            fail("%s accepts its own nickname %r - learners could skip the work" % (qid, nick))

    # 5. no accepted variant may be a word-boundary substring of another entity
    entities = {}
    for pid, (_, new) in PLAYERS.items():
        entities[new] = "player %s" % pid
        entities[new.split()[-1]] = "surname of %s" % pid
    for v in NATIONS.values():
        entities[v] = "nation"
    for v in NICKNAMES.values():
        entities[v] = "nickname"
    for v in CLUBS.values():
        entities[v] = "club"
    for v in VENUES.values():
        entities[v] = "venue"
    # nation-derived clubs/venues that convert automatically
    for v in NATIONS.values():
        entities[v + " City FC"] = "club"
        entities[v + " Arena"] = "venue"

    for qid, (canonical, variants) in ANSWER_KEY.items():
        own = {norm(canonical), norm(canonical.split()[-1]), norm(canonical.split()[0])}
        for var in variants:
            if norm(var) in (norm(n) for n in NICKNAMES.values()):
                continue  # nicknames are intentionally shared with their player
            for ent, kind in entities.items():
                if norm(ent) in own or norm(ent) == norm(var):
                    continue
                if word_in(var, ent):
                    msg = "%s variant %r appears inside %s %r" % (qid, var, kind, ent)
                    # a nation inside its own derived club/venue is harmless
                    if kind in ("club", "venue") and norm(var) in (norm(x) for x in NATIONS.values()):
                        info(msg + "  (nation-derived, harmless for grading)")
                    else:
                        fail(msg)

    # 6. demo players must not be scored answers
    answer_slots = {s for k, s in EXPECTED_SLOT.values() if k == "player"}
    for pid, where in DEMO_PLAYERS.items():
        if pid in answer_slots:
            fail("demo player %s (%s) is also a scored answer" % (pid, where))

    # 7. depth nations must stay out of the match schedule
    info("depth nations (must remain absent from MATCHES): %s"
         % ", ".join(sorted(DEPTH_NATIONS.values())))


def check_files():
    root = Path(__file__).resolve().parent.parent
    targets = sorted(
        [p for p in root.glob("*.html")] + [p for p in root.glob("*.sql")]
        + [p for p in root.glob("*.md")]
        # Lab app content and components. Without these, a legacy token could
        # reach learners through the React app while the root-level deliverables
        # stayed clean and this check still reported success.
        + [
            p
            for p in (root / "snowcup-lab-node").rglob("*")
            if p.is_file()
            and p.suffix in {".ts", ".tsx", ".mjs", ".js", ".jsx", ".md"}
            and not any(
                part in {"node_modules", ".next", ".git", "dist"} for part in p.parts
            )
        ]
    )
    if not targets:
        fail("no deliverable files found in %s" % root)
        return

    # Some old nicknames are ordinary English phrases ("The Wall" collides with
    # "hit the wall", "The Comet"/"The Fox" read naturally in prose). Blanket
    # matching those produces false positives, so for these we only flag the
    # QUOTED form, which is how a nickname is actually written.
    IDIOMATIC = {"The Wall", "The Comet", "The Fox", "The Vault", "The Hammer"}

    for path in targets:
        text = path.read_text(encoding="utf-8")
        for tok in sorted(set(LEGACY_TOKENS)):
            if tok in IDIOMATIC:
                pat = r"[\"'\u201c\u2018]\s*" + re.escape(tok) + r"\s*[\"'\u201d\u2019]"
            else:
                pat = r"\b" + re.escape(tok) + r"\b"
            hits = len(re.findall(pat, text, re.I))
            if hits:
                fail("%s: %d x legacy token %r" % (path.name, hits, tok))


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "--constraints"
    if mode == "--constraints":
        check_constraints()
    elif mode == "--files":
        check_files()
    elif mode == "--all":
        check_constraints()
        check_files()
    else:
        print("usage: check_names.py [--constraints|--files|--all]")
        return 2

    print("players %d  nations %d  nicknames %d  clubs %d  venues %d"
          % (len(PLAYERS), len(NATIONS), len(NICKNAMES), len(CLUBS), len(VENUES)))
    for m in INFO:
        print("  INFO  %s" % m)
    for m in FAIL:
        print("  FAIL  %s" % m)
    print("\n%s (%d failures)" % ("PASS" if not FAIL else "FAILED", len(FAIL)))
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
