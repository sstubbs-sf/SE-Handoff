#!/usr/bin/env python3
"""
Consistency gate: quiz questions in the content model vs the QUIZ_KEY seed.

WHY THIS EXISTS
A quiz question lives in two places by necessity. The prompt and its three
options are in the content model, because they are learner-visible and must be
scannable by check_leaks.py. The correct option is in the QUIZ_KEY seed, because
it must never reach a browser.

If those two drift, the failure is silent and now serious: quiz answers gate
training completion, so a question rendered with no key row can never be
answered correctly and the learner is stuck permanently -- with nothing erroring
anywhere. A key row with no question is the milder inverse: a requirement nobody
can see, which blocks completion just as effectively.

It also checks that the recorded correct option is a valid index into the options
that actually exist, since an out-of-range answer is unreachable.

Usage:
    python3 verify/check_quizzes.py
"""
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "snowcup-lab-node"
GRADER = ROOT / "snowcup-grader-setup.sql"


def content_quizzes():
    """Ask node for the content model, so extraction is exact."""
    proc = subprocess.run(
        ["node", "scripts/dump-content.mjs"],
        cwd=APP, capture_output=True, text=True,
    )
    if proc.returncode != 0:
        print("FAIL  could not read the content model")
        print(proc.stderr.strip()[:600])
        return None, None
    payload = json.loads(proc.stdout)
    training = str(payload["training"]["id"])
    out = {}
    for mod in payload["modules"]:
        for block in mod["blocks"]:
            if block.get("kind") != "quiz":
                continue
            out[block["ref"]] = {
                "section": mod["id"],
                "options": len(block.get("options") or []),
                "text": block.get("text") or "",
                "option_list": list(block.get("options") or []),
                # An answer in content would mean the answer is shipped to the
                # browser. validateBlock rejects it, so this is belt and braces.
                "leaked_answer": any(
                    k in block for k in ("correct", "answer", "correctOption")
                ),
            }
    return training, out


def author_table():
    """
    The reviewable table in tools/author_quizzes.py, or None if it is not present.

    WHY THIS IS COMPARED
    That table is the artifact a human reviews -- it is the only place all 22
    questions, their options and their correct answers sit together. But
    author_quizzes.py --write is insert-once (it skips a module that already has
    blocks), so editing the table does NOT update the shipped content. Nothing
    otherwise notices, which means a reviewer can approve wording that no learner
    will ever see. This check closes that gap.

    WHY MISSING IS A SKIP, NOT A FAILURE
    The authoring tool is deliberately not shipped in the deploy package, so when
    this check runs from the package there is no review table and nothing to drift
    from. That is genuinely not applicable rather than unverified -- but it is
    reported rather than passed over silently.
    """
    path = ROOT / "tools" / "author_quizzes.py"
    if not path.is_file():
        return None
    # Importing normally would leave a tools/__pycache__ behind on every run.
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("author_quizzes", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return {
        ref: {"text": text, "option_list": list(options), "correct": correct}
        for _module, qs in mod.QUESTIONS.items()
        for ref, text, options, correct, _why in qs
    }


def sql_quizzes():
    """Parse the MERGE INTO QUIZ_KEY seed block."""
    text = GRADER.read_text(encoding="utf-8")
    block = re.search(
        r"MERGE INTO QUIZ_KEY.*?AS s\(MODULE_ID, QUIZ_REF, SECTION_ID, "
        r"QUESTION_NO, CORRECT_OPTION, EXPLANATION\)",
        text, re.S,
    )
    if not block:
        print("FAIL  could not find the QUIZ_KEY seed block in snowcup-grader-setup.sql")
        return None, None

    rows = {}
    trainings = set()
    pattern = re.compile(
        r"\(\s*'([^']+)'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,"
        r"\s*'((?:[^']|'')*)'\s*\)"
    )
    for m in pattern.finditer(block.group(0)):
        training, ref, section, _no, correct, explanation = m.groups()
        trainings.add(training)
        rows[ref] = {
            "section": section,
            "correct": int(correct),
            "explanation": explanation.replace("''", "'"),
        }
    return trainings, rows


def main():
    training, content = content_quizzes()
    if content is None:
        return 1
    sql_trainings, sql = sql_quizzes()
    if sql is None:
        return 1

    failures = []

    if sql_trainings != {training}:
        failures.append(
            f"training mismatch: the content model declares {training!r} but the "
            f"QUIZ_KEY seed uses {sorted(sql_trainings)!r} -- every answer would be "
            f"refused as an unknown question"
        )

    for ref in sorted(set(content) - set(sql)):
        failures.append(
            f"{ref} is rendered to learners but has NO QUIZ_KEY row -- it can never "
            f"be answered correctly, so completion would be blocked permanently"
        )
    for ref in sorted(set(sql) - set(content)):
        failures.append(
            f"{ref} has a QUIZ_KEY row but no question in the content model -- an "
            f"invisible requirement that also blocks completion"
        )

    for ref in sorted(set(content) & set(sql)):
        c, s = content[ref], sql[ref]
        if c["section"] != s["section"]:
            failures.append(f"{ref} section: content={c['section']!r} sql={s['section']!r}")
        if not (0 <= s["correct"] < c["options"]):
            failures.append(
                f"{ref} correct option {s['correct']} is out of range for "
                f"{c['options']} options -- unreachable, so it can never be answered"
            )
        if c["leaked_answer"]:
            failures.append(f"{ref} carries the answer in the CONTENT model, which ships to the browser")
        if not s["explanation"].strip():
            failures.append(f"{ref} has no explanation, so a learner learns nothing from answering")

    # The reviewed wording must be the shipped wording.
    table = author_table()
    if table is None:
        print(
            "note: tools/author_quizzes.py is not present (running from the deploy "
            "package), so the reviewed-wording comparison is not applicable here"
        )
        table = {}
    for ref in sorted(set(table) - set(content)):
        failures.append(
            f"{ref} exists in the tools/author_quizzes.py review table but NOT in the "
            f"content model -- it was reviewed but never shipped"
        )
    for ref in sorted(set(table) & set(content)):
        if table[ref]["text"] != content[ref]["text"]:
            failures.append(
                f"{ref} WORDING DRIFT -- the reviewed question is not the shipped one:\n"
                f"        review table: {table[ref]['text']}\n"
                f"        shipped:      {content[ref]['text']}"
            )
        if table[ref]["option_list"] != content[ref]["option_list"]:
            failures.append(
                f"{ref} OPTION DRIFT -- reviewed options differ from shipped options:\n"
                f"        review table: {table[ref]['option_list']}\n"
                f"        shipped:      {content[ref]['option_list']}"
            )
        if ref in sql and table[ref]["correct"] != sql[ref]["correct"]:
            failures.append(
                f"{ref} CORRECT-ANSWER DRIFT -- review table says option "
                f"{table[ref]['correct']}, QUIZ_KEY says {sql[ref]['correct']}"
            )

    print(
        f"training {training!r}; content model: {len(content)} question(s); "
        f"QUIZ_KEY seed: {len(sql)} row(s)"
    )
    if failures:
        print("\nFAILED  the quiz content and the QUIZ_KEY seed disagree")
        for f in failures:
            print(f"   {f}")
        return 1

    print(
        f"PASS  all {len(content)} quiz questions have a key row, a reachable "
        f"correct option and an explanation, and no answer is in content"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
