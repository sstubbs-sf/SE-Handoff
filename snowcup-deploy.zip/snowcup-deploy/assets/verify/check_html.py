#!/usr/bin/env python3
"""
Structural checks for the two HTML deliverables.

Earns its place: an unclosed <div class="callout warn"> in the lab silently
swallowed the rest of Module 6 into an orange warning box. Nothing else caught
it - the page still rendered, just wrongly.

Checks per file:
  - <div> balance, reporting the line where depth first goes wrong
  - <section>, <table>, <ul>, <ol> balance
  - every href="#anchor" resolves to an id="anchor"
  - <script> blocks extracted and syntax-checked with `node --check` if node
    is available
"""
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# The learner lab is now a React app, not HTML, so there is no lab file to
# balance-check. That whole class of bug is gone too: unbalanced JSX does not
# compile, which is what this check was originally written to catch after an
# unclosed <div class="callout warn"> swallowed the rest of Module 6.
TARGETS = [
    ("snowcup-facilitator-guide.html", "worldcup-facilitator-guide.html"),
]


def balance(text, tag):
    """Return (final_depth, first_bad_line). Depth should end at 0."""
    depth, line, first_bad = 0, 1, None
    pat = re.compile(r"<%s\b|</%s>|\n" % (tag, tag))
    for m in pat.finditer(text):
        tok = m.group(0)
        if tok == "\n":
            line += 1
        elif tok.startswith("</"):
            depth -= 1
            if depth < 0 and first_bad is None:
                first_bad = line
        else:
            depth += 1
    return depth, first_bad


def unclosed_line(text, tag):
    """Line at which cumulative depth last increased and never came back."""
    depth, line, marks = 0, 1, []
    pat = re.compile(r"<%s\b|</%s>|\n" % (tag, tag))
    for m in pat.finditer(text):
        tok = m.group(0)
        if tok == "\n":
            line += 1
            continue
        depth += -1 if tok.startswith("</") else 1
        marks.append((line, depth))
    # walk back to the last point depth was 0
    for ln, d in reversed(marks):
        if d == 0:
            return ln
    return marks[0][0] if marks else None


def main():
    root = Path(__file__).resolve().parent.parent
    failures = []
    node = shutil.which("node")

    for names in TARGETS:
        path = next((root / n for n in names if (root / n).exists()), None)
        if not path:
            failures.append("missing: %s" % " / ".join(names))
            continue
        text = path.read_text(encoding="utf-8")
        print("\n%s" % path.name)

        for tag in ("div", "section", "table", "ul", "ol"):
            depth, first_bad = balance(text, tag)
            status = "OK" if depth == 0 and first_bad is None else "BAD"
            print("  <%-7s balance depth=%-3d %s" % (tag + ">", depth, status))
            if depth != 0:
                ln = unclosed_line(text, tag)
                failures.append("%s: <%s> unbalanced (depth %d); imbalance starts after line %s"
                                % (path.name, tag, depth, ln))
            if first_bad is not None:
                failures.append("%s: extra closing </%s> at line %d" % (path.name, tag, first_bad))

        # Anchor scan must ignore <script> blocks: the lab builds hrefs
        # dynamically (href="#'+ch.id+'"), which is not a real dangling anchor.
        markup = re.sub(r"<script[^>]*>.*?</script>", " ", text, flags=re.S)
        ids = set(re.findall(r'id="([^"]+)"', markup))
        hrefs = set(re.findall(r'href="#([^"]+)"', markup))
        dangling = sorted(hrefs - ids)
        print("  anchors: %d links, %d ids, %d dangling" % (len(hrefs), len(ids), len(dangling)))
        if dangling:
            failures.append("%s: dangling anchors %s" % (path.name, dangling))

        js = "\n".join(re.findall(r"<script[^>]*>(.*?)</script>", text, re.S))
        if js.strip() and node:
            with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                             encoding="utf-8") as fh:
                fh.write(js)
                tmp = fh.name
            proc = subprocess.run([node, "--check", tmp], capture_output=True, text=True)
            Path(tmp).unlink(missing_ok=True)
            print("  javascript: %d chars, %s" % (len(js), "syntax OK" if proc.returncode == 0 else "SYNTAX ERROR"))
            if proc.returncode != 0:
                failures.append("%s: JS syntax error: %s" % (path.name, proc.stderr.strip()[:200]))
        elif js.strip():
            print("  javascript: %d chars (node not found, skipped)" % len(js))

    for f in failures:
        print("\n  FAIL  %s" % f)
    print("\n%s (%d failures)" % ("PASS" if not failures else "FAILED", len(failures)))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
