#!/usr/bin/env python3
"""
Answer-leak scanner for the learner-facing lab.

WHAT IT PROTECTS
The workshop claims that no lab prompt yields a scored answer. This is the check
that backs that claim, and once the standalone HTML is retired it is the only
one. Content shipped to a browser is readable by the learner reading it, so this
is a real guarantee rather than a formality.

THREE CLASSES
  A  an answer value or accepted variant appears at all               -> FAIL
  B  wording that tells a learner to RUN a scored question, in a
     place where scored answers are not permitted                     -> FAIL
  C  the same wording where it IS permitted (the challenge itself,
     the tier previews)                                               -> reported

THREE SOURCES, because a leak can arrive by more than one route
  1. the content model (structured, so permission is an explicit field)
  2. the lab app's source, in case prose is hardcoded in a component or a
     comment rather than authored as content
  3. the legacy HTML lab, while it still exists

Signatures are built from the LIVE answer key in mapping.py, so the scanner
cannot go stale when questions change.
"""
import html
import json
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mapping import (  # noqa: E402
    ANSWER_KEY, EXPECTED_QUESTION_ZONES, NICKNAMES, QUESTION_SIGNATURES,
    SIGNATURE_WINDOW,
)

ROOT = Path(__file__).resolve().parent.parent
HTML_CANDIDATES = ["snowcup-agent-lab.html", "worldcup-agent-lab.html"]
APP = ROOT / "snowcup-lab-node"
APP_SOURCE_SUFFIXES = {".ts", ".tsx", ".mjs", ".js", ".jsx", ".md"}
APP_SOURCE_SKIP = {"node_modules", ".next", ".git", "dist", "__pycache__"}


# --------------------------------------------------------------------------- #
# shared matching helpers
# --------------------------------------------------------------------------- #

def normalise(text):
    """Lowercase and flatten hyphen variants so "most-carded" matches "most carded"."""
    return re.sub(r"[-\u2011\u2013\u2014]", " ", text).lower()


def answer_values():
    """
    Every value whose presence is a leak.

    A nickname that is not an accepted variant IS the question (Q7 asks which
    player the fans call something), so its appearance is by design.
    """
    nicks = {n.lower() for n in NICKNAMES.values()}
    for qid, (canonical, variants) in sorted(ANSWER_KEY.items()):
        for val in sorted(set([canonical] + variants), key=len, reverse=True):
            if val.lower() in nicks and val not in variants:
                continue
            yield qid, val


def find_class_a(text):
    """Answer values present in a blob of learner-visible text."""
    hits = []
    for qid, val in answer_values():
        m = re.search(r"\b" + re.escape(val) + r"\b", text, re.I)
        if m:
            ctx = text[max(0, m.start() - 60):m.start() + 60]
            hits.append((qid, val, re.sub(r"\s+", " ", ctx).strip()))
    return hits


def find_signatures(text):
    """
    Question wording present in a blob of text.

    A signature is either a phrase or a set of terms that must co-occur. For the
    term-set form the window is scoped to this blob, which is tighter than the
    character window the HTML scanner used across a whole document -- terms in
    two unrelated paragraphs no longer combine into a false positive.
    """
    hay = normalise(text)
    out = []
    for qid, sigs in sorted(QUESTION_SIGNATURES.items()):
        for sig in sigs:
            if isinstance(sig, str):
                needle = normalise(sig)
                if needle in hay:
                    out.append((qid, sig))
                continue
            first, rest = normalise(sig[0]), [normalise(t) for t in sig[1:]]
            for m in re.finditer(re.escape(first), hay):
                window = hay[max(0, m.start() - SIGNATURE_WINDOW):m.start() + SIGNATURE_WINDOW]
                if all(t in window for t in rest):
                    out.append((qid, " + ".join(sig)))
                    break
    return out


# --------------------------------------------------------------------------- #
# source 1: the content model
# --------------------------------------------------------------------------- #

def load_content():
    """Ask node for the content as JSON rather than parsing .mjs source."""
    if not (APP / "scripts" / "dump-content.mjs").exists():
        return None, "lab app content model not present yet"
    proc = subprocess.run(
        ["node", "scripts/dump-content.mjs", "--text"],
        cwd=APP, capture_output=True, text=True,
    )
    if proc.returncode != 0:
        return None, (proc.stderr.strip() or "dump-content.mjs failed")
    try:
        return json.loads(proc.stdout), None
    except json.JSONDecodeError as e:
        return None, f"content JSON did not parse: {e}"


def scan_content(modules):
    """
    Per block, so permission is a property of the block rather than a guess from
    surrounding markup. `allowScoredAnswers` replaces the HTML scanner's
    character-offset zones.
    """
    a, b, c = [], [], []
    blocks = 0
    for mod in modules:
        for block in mod["blocks"]:
            blocks += 1
            text = " ".join(block["text"])
            if not text.strip():
                continue
            where = f"{mod['id']} block {block['index']} ({block['kind']})"
            allowed = block["allowScoredAnswers"]
            for qid, val, ctx in find_class_a(text):
                # An answer value is a leak wherever it appears. The challenge
                # asks the questions; it never prints the answers.
                a.append((where, qid, val, ctx))
            for qid, sig in find_signatures(text):
                entry = (where, qid, sig, re.sub(r"\s+", " ", text)[:150])
                (c if allowed else b).append(entry)
    return a, b, c, blocks


# --------------------------------------------------------------------------- #
# source 2: the lab app's own source
# --------------------------------------------------------------------------- #

def scan_app_source():
    """
    Class A only, over app source.

    Rationale: the content model is the intended home for prose, but a component
    can hardcode a string and a comment can ship inside a client bundle. This is
    a cheap backstop against a leak that never passes through content/.
    """
    hits = []
    files = 0
    if not APP.exists():
        return hits, files
    for path in sorted(APP.rglob("*")):
        if not path.is_file() or path.suffix not in APP_SOURCE_SUFFIXES:
            continue
        if any(part in APP_SOURCE_SKIP for part in path.parts):
            continue
        files += 1
        text = path.read_text(encoding="utf-8", errors="replace")
        for qid, val, ctx in find_class_a(text):
            hits.append((str(path.relative_to(ROOT)), qid, val, ctx))
    return hits, files


# --------------------------------------------------------------------------- #
# source 3: the legacy HTML lab, while it exists
# --------------------------------------------------------------------------- #

def html_zones(raw):
    spans = []
    for start_marker, end_marker in EXPECTED_QUESTION_ZONES:
        pos = 0
        while True:
            i = raw.find(start_marker, pos)
            if i < 0:
                break
            j = raw.find(end_marker, i)
            spans.append((i, j if j > i else len(raw)))
            pos = i + 1
    return spans


def scan_html(path):
    raw = path.read_text(encoding="utf-8")
    text = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", raw)))
    zones = html_zones(raw)
    a = [(path.name, qid, val, ctx) for qid, val, ctx in find_class_a(text)]
    b, c = [], []
    hay = normalise(raw)
    for qid, sigs in sorted(QUESTION_SIGNATURES.items()):
        for sig in sigs:
            idxs = []
            if isinstance(sig, str):
                needle = normalise(sig)
                idxs = [m.start() for m in re.finditer(re.escape(needle), hay)]
                label = sig
            else:
                first, rest = normalise(sig[0]), [normalise(t) for t in sig[1:]]
                label = " + ".join(sig)
                for m in re.finditer(re.escape(first), hay):
                    window = hay[max(0, m.start() - SIGNATURE_WINDOW):m.start() + SIGNATURE_WINDOW]
                    if all(t in window for t in rest):
                        idxs.append(m.start())
            for idx in idxs:
                snippet = html.unescape(re.sub(r"<[^>]+>", " ", raw[max(0, idx - 90):idx + 110]))
                snippet = re.sub(r"\s+", " ", snippet).strip()
                line = raw[:idx].count("\n") + 1
                entry = (f"{path.name} L{line}", qid, label, snippet)
                (c if any(lo <= idx <= hi for lo, hi in zones) else b).append(entry)
                break
    return a, b, c


# --------------------------------------------------------------------------- #

def report(title, rows, formatter):
    print(f"\n{title}")
    if not rows:
        print("   none")
        return
    for row in rows:
        print(formatter(row))


def main():
    class_a, class_b, class_c = [], [], []
    scanned = []

    modules, err = load_content()
    if modules is not None:
        a, b, c, blocks = scan_content(modules)
        class_a += a
        class_b += b
        class_c += c
        scanned.append(f"content model: {len(modules)} module(s), {blocks} blocks")
    else:
        # Not fatal on its own -- the HTML may still be the live deliverable --
        # but if neither source is present there is nothing guarding anything.
        scanned.append(f"content model: SKIPPED ({err})")

    app_hits, app_files = scan_app_source()
    class_a += app_hits
    if app_files:
        scanned.append(f"lab app source: {app_files} file(s)")

    html_path = next((ROOT / c for c in HTML_CANDIDATES if (ROOT / c).exists()), None)
    if html_path:
        a, b, c = scan_html(html_path)
        class_a += a
        class_b += b
        class_c += c
        scanned.append(f"legacy HTML: {html_path.name}")

    if modules is None and html_path is None:
        print("FAIL  no learner-facing content found to scan")
        print("      neither the content model nor the HTML lab is present, so this")
        print("      check would pass while guaranteeing nothing.")
        return 1

    print("scanned -> " + "; ".join(scanned))

    report(
        "A. answer values / accepted variants present (must be empty)",
        class_a,
        lambda r: f"   LEAK {r[1]}  {r[2]!r}  in {r[0]}\n        ...{r[3][:110]}...",
    )
    report(
        "B. tells a learner to RUN a scored question, where answers are not permitted (must be empty)",
        class_b,
        lambda r: f"   LEAK {r[1]}  in {r[0]}  sig={r[2]!r}\n        {r[3][:150]}",
    )
    report(
        "C. scored questions where they are permitted (by design, reported only)",
        class_c,
        lambda r: f"   {r[1]}  in {r[0]}  {r[3][:90]}",
    )

    bad = len(class_a) + len(class_b)
    print(
        f"\n{'PASS' if not bad else 'FAILED'} "
        f"({len(class_a)} A + {len(class_b)} B failures, {len(class_c)} by-design)"
    )
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
