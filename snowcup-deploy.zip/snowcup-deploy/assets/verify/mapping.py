"""
SnowCup rebrand - the single source of truth for every rename.

Imported by check_names.py, check_leaks.py and the rename tooling so the mapping
is defined exactly once.

INVARIANT: PLAYER_ID and MATCH_ID values are never renamed, and no HASH()
expression is touched. The generated stats hash on PLAYER_ID || MATCH_ID, so
holding those fixed keeps every stat byte-identical and makes all eight answers
map 1:1 onto the same player slots.
"""

# --- Snowflake object identifiers -------------------------------------------
# Applied longest-first so AURORA_CUP_SHARED is not clipped by AURORA_CUP.

# --- Nations ----------------------------------------------------------------
# Adjective forms MUST be replaced before the bare nation name, or
# "Valorian" becomes "Driftlandn". These three are the only ones in use.
NATION_ADJECTIVES = {
    "Valorian":  "Driftland",
    "Novarian":  "Snowholt",
    "Kaelorian": "Rimeland",
}

# --- Filenames and paths referenced from inside the files --------------------
# Stem-based so "worldcup-agent-lab-my-progress.html" (the save-a-copy download
# name in the lab's JS) is covered by the same rule as the file itself.

COMPETING_NATIONS = {
    "Valoria":  "Driftland",
    "Meridia":  "Cirrus",
    "Drakmoor": "Flurria",
    "Borealia": "Powdermark",
    "Grandia":  "Glacia",
    "Ironhold": "Cornice",
    "Novaria":  "Snowholt",
    "Kaeloria": "Rimeland",
}
# Player pool only - deliberately absent from MATCHES. That property must hold.
DEPTH_NATIONS = {
    "Astoria":  "Sleetmoor",
    "Caldoria": "Frostmere",
    "Eldoria":  "Hailden",
    "Ferrovia": "Icemark",
    "Halcyon":  "Whitecap",
    "Jadeport": "Crystalia",
    "Lumenia":  "Shimmerfell",
    "Oreland":  "Tundrel",
}
NATIONS = {**COMPETING_NATIONS, **DEPTH_NATIONS}

# --- Players: PLAYER_ID -> (old name, new name) -----------------------------
PLAYERS = {
    "P01": ("Aldo Rennik",     "Aldo Drifden"),
    "P02": ("Marco Tessaro",   "Marco Whitlock"),
    "P03": ("Enzo Vitale",     "Enzo Snowdon"),
    "P04": ("Luca Brienne",    "Luca Frostwick"),
    "P05": ("Rico Delgado",    "Rico Glaze"),
    "P06": ("Sten Halvard",    "Sten Cirrane"),
    "P07": ("Ivar Lund",       "Ivar Nimbus"),
    "P08": ("Bjorn Aas",       "Bjorn Icefell"),
    "P09": ("Kai Osterlund",   "Kai Winterholm"),
    "P10": ("Nils Vagen",      "Nils Vane"),
    "P11": ("Gormar Thule",    "Gormar Hailstone"),
    "P12": ("Roderik Ashen",   "Roderik Rime"),
    "P13": ("Halvor Grimm",    "Halvor Grimsleet"),
    "P14": ("Sorin Blackwood", "Sorin Squall"),
    "P15": ("Dain Vulkar",     "Dain Thaw"),
    "P16": ("Frost Neval",     "Nevin Coldiron"),
    "P17": ("Tomas Vheer",     "Tomas Icewright"),
    "P18": ("Anders Kjell",    "Anders Snowfell"),
    "P19": ("Petar Voss",      "Petar Vossberg"),
    "P20": ("Emil Draco",      "Emil Sleet"),
    "P21": ("Paolo Ricci",     "Paolo Glacio"),
    "P22": ("Gino Serra",      "Gino Icebourne"),
    "P23": ("Marco Fenn",      "Marco Fennmoor"),
    "P24": ("Milo Farrenc",    "Milo Chill"),
    "P25": ("Dario Belle",     "Dario Snowbelle"),
    "P26": ("Kova Stribog",    "Kova Icevault"),
    "P27": ("Rurik Vane",      "Rurik Cornstone"),
    "P28": ("Torvald Kane",    "Torvald Snowkane"),
    "P29": ("Sigurd Roe",      "Sigurd Snowvale"),
    "P30": ("Alrik Stone",     "Alrik Snowstone"),
    "P31": ("Lucian Marr",     "Lucian Marrfell"),
    "P32": ("Viktor Sena",     "Viktor Icesen"),
    "P33": ("Adrian Cole",     "Adrian Coldwell"),
    "P34": ("Felix Aran",      "Felix Aranvale"),
    "P35": ("Silas Crow",      "Silas Flake"),
    "P36": ("Dmitri Sol",      "Dmitri Solrime"),
    "P37": ("Bruno Kastov",    "Bruno Kaltov"),
    "P38": ("Yuri Pavlic",     "Yuri Permafrost"),
    "P39": ("Andrei Lek",      "Andrei Lekvind"),
    "P40": ("Stefan Ozar",     "Stefan Icezar"),
    "P41": ("Owen Hale",       "Owen Hail"),
    "P42": ("Mateo Ruiz",      "Mateo Verglas"),
    "P43": ("Kenji Aoki",      "Kenji Yuki"),
    "P44": ("Hans Ulbrecht",   "Hans Firnbach"),
    "P45": ("Theo Marsh",      "Theo Icemarsh"),
    "P46": ("Wei Chen",        "Wei Xue"),
    "P47": ("Sami Rehn",       "Sami Lumi"),
    "P48": ("Pieter Vos",      "Pieter Vestergaard"),
}

# --- Nicknames --------------------------------------------------------------
# Q7 is answered BY nickname, so these must stay unique.
NICKNAMES = {
    "El Rey":         "The Blizzard",     # P05  Q1
    "The Hammer":     "The Snowplow",     # P10  Module 6 demo
    "The Volcano":    "The Avalanche",    # P15  Module 7 demo
    "The Architect":  "The Snowsmith",    # P17  Q3
    "The Clockmaker": "The Late Frost",   # P24  Q5
    "The Vault":      "The Deep Freeze",  # P26  Q4
    "The Ghost":      "The Whiteout",     # P35  Q7
    "The Enforcer":   "The Iceman",       # P37  Q8
    "The Comet":      "The Hailstorm",    # P41
    "The Fox":        "The Snow Fox",     # P43
    "The Wall":       "The Snowbank",     # P48
}

# --- Clubs and venues -------------------------------------------------------
# Nation-derived names convert automatically once NATIONS is applied
# (Valoria City FC -> Driftland City FC). Only the ones that do NOT follow a
# nation need an explicit rule.
CLUBS = {
    "Porto Azzurro":  "Port Glace",
    "Nordfjord BK":   "Nordfrost BK",
    "Ash Valley":     "Rime Valley",
    "Monteverde":     "Monteneve",
    "Anvil Town":     "Icicle Town",
    "Solport":        "Snowport",
    "Ironport":       "Frostport",
    # Frostgard IF intentionally unchanged - already on theme
}
VENUES = {
    "Ashfield Park":     "Rimefield Park",
    "Volcano Stadium":   "Glacier Stadium",
    "Nordfjord Stadium": "Nordfrost Stadium",
    "Harbor Ground":     "Frostharbour Ground",
    "Solport Field":     "Snowport Field",
    # Frostgard Dome intentionally unchanged
    # Meridia Arena / Novaria Grand convert via NATIONS
}

# --- Answer key -------------------------------------------------------------
# question_id -> (canonical answer, accepted variants, nickname accepted?)
# Q7/Q8 deliberately do NOT accept the nickname: the nickname is the question.
ANSWER_KEY = {
    "Q1": ("Rico Glaze",      ["Rico Glaze", "Glaze", "Rico", "The Blizzard"]),
    "Q2": ("Driftland",       ["Driftland"]),
    "Q3": ("Tomas Icewright", ["Tomas Icewright", "Icewright", "Tomas", "The Snowsmith"]),
    "Q4": ("Kova Icevault",   ["Kova Icevault", "Icevault", "Kova", "The Deep Freeze"]),
    "Q5": ("Milo Chill",      ["Milo Chill", "Chill", "Milo", "The Late Frost"]),
    "Q6": ("Flurria",         ["Flurria"]),
    "Q7": ("Silas Flake",     ["Silas Flake", "Flake", "Silas"]),
    "Q8": ("Bruno Kaltov",    ["Bruno Kaltov", "Kaltov", "Bruno"]),
}

# Lab demos must never resolve to a scored answer.
DEMO_PLAYERS = {
    "P34": "Module 2 raw-SQL drill",
    "P10": "Module 6 search reveal + scouting report",
    "P15": "Module 7 turn 1 (2018 top scorer)",
    "P04": "Module 7 turn 4 (most distance)",
}

# Distinguishing phrases for each scored question. These live next to the key on
# purpose: if a question is reworded, its signature is updated in the same edit,
# which is what stops the leak scanner going stale.
#
# A leak is NOT only "the answer is printed". Telling a learner to RUN one of
# these questions hands them the answer just as surely, so the scanner matches on
# the question wording too.
# Two signature forms:
#   "a phrase"        -> substring match, after hyphens are normalised to spaces
#   ["term", "term"]  -> ALL terms must appear within SIGNATURE_WINDOW chars of
#                        each other, in any order
#
# The term-set form exists because exact phrases proved brittle three separate
# times, each hiding a real 10-20 point leak in the lab:
#   "most carded"               missed "most-carded"                  (hyphen)
#   "top scorer in 2026"        missed "the 2026 top scorer"          (word order)
#   "nation had the highest xg" missed "top 5 nations by xG overperformance"
SIGNATURE_WINDOW = 130

QUESTION_SIGNATURES = {
    "Q1": [["2026", "top scorer"], ["2026", "most goals"], "won the golden boot"],
    "Q2": [["most", "titles"]],
    "Q3": ["set up the most goals in knockout", "most assists in knockout"],
    "Q4": [["most", "clean sheets"]],
    "Q5": [["biggest", "clutch"], ["best", "clutch"], ["most", "late goals"]],
    # must involve a NATION - "by position" is a different, non-scored question
    "Q6": [["nation", "xg overperformance"], ["nations", "xg overperformance"],
           ["nation", "highest xg"], ["nations", "highest xg"]],
    "Q7": ["the whiteout"],
    "Q8": ["the iceman", ["most", "carded"], ["most", "fouls"],
           ["most", "yellow and red cards"], "villain nicknamed"],
}

# Regions of the learner file where a scored question is SUPPOSED to appear.
# Module 9 is the challenge itself, and the Module 3 callout deliberately offers
# the question shapes as modelling targets ("Notice these are exactly the shapes
# the challenge will test"). Matched by content, not line number, so they survive
# edits that shift the file.
EXPECTED_QUESTION_ZONES = [
    ('<section class="module" id="m9"', "</section>"),   # the challenge itself
    ("A good starter set", "</div>"),                    # Module 3 modelling targets
    ("The four tiers:", "</div>"),                       # Module 1 tier preview
]

# Legacy tokens that must not survive anywhere in the deliverables.
LEGACY_TOKENS = (
    ["AURORA_CUP", "WORLDCUP", "Aurora Cup", "AURORA CUP", "aurora-cup", "worldcup"]
    + [old for old, _ in PLAYERS.values()]
    + list(NATIONS.keys())
    + list(NICKNAMES.keys())
    + list(CLUBS.keys())
    + list(VENUES.keys())
)
