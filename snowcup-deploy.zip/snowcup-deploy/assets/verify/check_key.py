#!/usr/bin/env python3
"""
Validate the answer key in the grader script against mapping.py.

Exists because of a real miss during the rebrand: the mechanical rename matched
player FULL names, so the surname-only accepted variants ('Delgado', 'Vheer',
'Crow'...) survived untouched and the key silently kept crediting names that no
longer existed. Nothing else caught it - the legacy-token scan only knew about
full names.

Checks, per question:
  - canonical answer matches mapping.ANSWER_KEY
  - the accepted-variant list matches exactly (order-insensitive)
  - every variant is either the full name, one of its two name parts, or the
    player's nickname - never a stale surname
  - Q7/Q8 do not accept their own nickname
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mapping import ANSWER_KEY, NICKNAMES  # noqa: E402

GRADER_CANDIDATES = ["snowcup-grader-setup.sql", "worldcup-grader-setup.sql"]

ROW = re.compile(
    r"SELECT\s+'(?P<module>[A-Z_]+)'\s*,\s*'(?P<qid>Q\d+)'\s*,\s*\d+\s*,\s*(?P<pts>\d+)\s*,"
    r"\s*'(?P<prompt>(?:[^']|'')*)'\s*,\s*'(?P<canon>(?:[^']|'')*)'\s*,"
    r"\s*ARRAY_CONSTRUCT\((?P<variants>[^)]*)\)",
    re.S,
)


def norm(s):
    s = re.sub(r"[^A-Za-z0-9 ]", "", s or "")
    return re.sub(r"\s+", " ", s).strip().upper()


def main():
    root = Path(__file__).resolve().parent.parent
    path = next((root / c for c in GRADER_CANDIDATES if (root / c).exists()), None)
    if not path:
        print("FAIL  grader script not found")
        return 1

    text = path.read_text(encoding="utf-8")
    rows = {m.group("qid"): m for m in ROW.finditer(text)}
    failures = []

    if len(rows) != len(ANSWER_KEY):
        failures.append("found %d key rows, expected %d" % (len(rows), len(ANSWER_KEY)))

    for qid, (canon, variants) in sorted(ANSWER_KEY.items()):
        m = rows.get(qid)
        if not m:
            failures.append("%s missing from %s" % (qid, path.name))
            continue

        if m.group("module") != "SNOWCUP":
            failures.append("%s has module %r, expected 'SNOWCUP'" % (qid, m.group("module")))

        if norm(m.group("canon")) != norm(canon):
            failures.append("%s canonical %r != expected %r" % (qid, m.group("canon"), canon))

        got = [norm(v.strip().strip("'")) for v in m.group("variants").split(",")]
        want = [norm(v) for v in variants]
        if sorted(got) != sorted(want):
            failures.append("%s variants %s != expected %s" % (qid, sorted(got), sorted(want)))

        # every variant must be derived from the canonical name or be its nickname
        parts = {norm(canon)} | {norm(p) for p in canon.split()}
        nicks = {norm(n) for n in NICKNAMES.values()}
        for g in got:
            if g not in parts and g not in nicks:
                failures.append("%s variant %r is not part of %r nor a known nickname "
                                "(likely a stale surname)" % (qid, g, canon))

    for qid, nick in (("Q7", "The Whiteout"), ("Q8", "The Iceman")):
        m = rows.get(qid)
        if m and norm(nick) in [norm(v.strip().strip("'")) for v in m.group("variants").split(",")]:
            failures.append("%s accepts its own nickname %r" % (qid, nick))

    total = sum(int(m.group("pts")) for m in rows.values())
    print("%s: %d questions, %d points" % (path.name, len(rows), total))
    for qid, m in sorted(rows.items()):
        print("  %s %3s pts  %-18s %s" % (qid, m.group("pts"), m.group("canon"),
                                          m.group("variants").replace("'", "")))
    if total != 120:
        failures.append("total points %d, expected 120" % total)

    for f in failures:
        print("  FAIL  %s" % f)
    print("\n%s (%d failures)" % ("PASS" if not failures else "FAILED", len(failures)))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
