#!/usr/bin/env python3
"""
Validate the roster in the data setup script against mapping.py.

Guards the invariant the whole rebrand rests on: the generated stats hash on
PLAYER_ID || MATCH_ID, so if a PLAYER_ID moved or a name landed on the wrong ID,
every answer would silently shift while the SQL still ran clean.

Checks:
  - exactly 48 rows, IDs P01..P48 contiguous
  - each PLAYER_ID carries the NEW name from mapping.py (right name, right ID)
  - 16 distinct nations, all from the mapping's new set
  - nicknames match the mapping and are unique
  - the 8 depth nations never appear in MATCHES
  - HASH() expressions still key on PLAYER_ID || MATCH_ID
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mapping import DEPTH_NATIONS, NATIONS, NICKNAMES, PLAYERS  # noqa: E402

CANDIDATES = ["snowcup-data-setup.sql", "worldcup-agent-setup.sql"]

ROW = re.compile(
    r"\('(?P<pid>P\d{2})'\s*,\s*'(?P<name>[^']+)'\s*,\s*'(?P<nation>[^']+)'\s*,"
    r"\s*'(?P<pos>[^']+)'\s*,\s*'(?P<club>[^']+)'\s*,\s*(?P<h>\d+)\s*,"
    r"\s*'(?P<foot>[^']+)'\s*,\s*(?P<nick>NULL|'[^']+')\s*\)"
)


def main():
    root = Path(__file__).resolve().parent.parent
    path = next((root / c for c in CANDIDATES if (root / c).exists()), None)
    if not path:
        print("FAIL  data setup script not found")
        return 1
    text = path.read_text(encoding="utf-8")

    rows = {m.group("pid"): m for m in ROW.finditer(text)}
    failures = []

    if len(rows) != 48:
        failures.append("found %d roster rows, expected 48" % len(rows))
    for i in range(1, 49):
        pid = "P%02d" % i
        if pid not in rows:
            failures.append("missing %s" % pid)
            continue
        want = PLAYERS[pid][1]
        got = rows[pid].group("name")
        if got != want:
            failures.append("%s is %r, mapping says %r" % (pid, got, want))

    nations = {m.group("nation") for m in rows.values()}
    if len(nations) != 16:
        failures.append("%d distinct nations, expected 16" % len(nations))
    unknown = nations - set(NATIONS.values())
    if unknown:
        failures.append("nations not in mapping: %s" % sorted(unknown))

    nicks = [m.group("nick").strip("'") for m in rows.values() if m.group("nick") != "NULL"]
    if len(nicks) != len(set(nicks)):
        failures.append("duplicate nickname in roster")
    unknown_nicks = set(nicks) - set(NICKNAMES.values())
    if unknown_nicks:
        failures.append("nicknames not in mapping: %s" % sorted(unknown_nicks))

    # depth nations must never be scheduled
    matches_block = text[text.find("INSERT INTO MATCHES"):text.find("STEP 6")]
    for depth in DEPTH_NATIONS.values():
        if re.search(r"\b" + re.escape(depth) + r"\b", matches_block):
            failures.append("depth nation %r appears in MATCHES" % depth)

    # the invariant. Prose references to "HASH()" appear in the header comments,
    # so only expressions with actual arguments are validated.
    hashes = [h for h in re.findall(r"HASH\(([^)]*)\)", text) if h.strip()]
    if len(hashes) != 2:
        failures.append("expected 2 substantive HASH() expressions, found %d" % len(hashes))
    for h in hashes:
        if "PLAYER_ID" not in h or "MATCH_ID" not in h:
            failures.append("HASH() no longer keys on PLAYER_ID and MATCH_ID: %r" % h)

    surnames = [PLAYERS[p][1].split()[-1] for p in rows]
    print("%s: %d players, %d nations, %d nicknames, %d HASH() expressions"
          % (path.name, len(rows), len(nations), len(nicks), len(hashes)))
    print("  surnames unique: %s" % (len(set(surnames)) == len(surnames)))
    for f in failures:
        print("  FAIL  %s" % f)
    print("\n%s (%d failures)" % ("PASS" if not failures else "FAILED", len(failures)))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
