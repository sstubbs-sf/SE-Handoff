-- ===========================================================================
-- Gates for the lab progress layer. Run after snowcup-grader-setup.sql.
--
--   snow sql -f verify/check_lab_progress.sql
--
-- Every row should read PASS. These are the invariants the lab app depends on:
-- the step registry is seeded, no progress row exists for a step that is not in
-- the registry, and learners cannot reach the raw tables or the writer
-- procedures.
-- ===========================================================================
USE ROLE ACCOUNTADMIN;
USE WAREHOUSE SNOWCUP_WH;
USE SCHEMA SNOWCUP_WORKSHOP.GRADING;

-- 1. Registry seeded: one checkpoint per section, m0..m10.
--
--    Scoped to SNOWCUP deliberately. Counting every active step in the table would
--    make this gate FAIL the moment a second training is added, even though
--    SnowCup's own 11 rows are perfectly intact -- a false failure that would stop
--    a deploy for no reason.
SELECT 'registry: 11 active SnowCup steps seeded'        AS CHECK_NAME,
       IFF(COUNT(*) = 11, 'PASS', 'FAIL')                AS VERDICT,
       COUNT(*)::VARCHAR                                 AS ACTIVE_STEPS
  FROM LAB_STEPS WHERE IS_ACTIVE AND MODULE_ID = 'SNOWCUP';

-- 2. Referential integrity. Matched on the PAIR, because a step key alone is not
--    unique once a second training exists -- two trainings may both have a step
--    called "m0.checkpoint", and comparing on the key alone would call a valid row
--    an orphan (or worse, miss a genuine one).
SELECT 'integrity: no progress for unknown steps'        AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COUNT(*)::VARCHAR                                 AS ORPHANS
  FROM LAB_PROGRESS p
 WHERE NOT EXISTS (SELECT 1 FROM LAB_STEPS s
                    WHERE s.STEP_KEY = p.STEP_KEY AND s.MODULE_ID = p.MODULE_ID);

-- 3. Progress can only ever be attributed to one participant per step per
--    training. Snowflake does NOT enforce primary keys -- they are metadata only --
--    so this is checked as data rather than assumed from the table definition.
SELECT 'integrity: one row per participant per step'     AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COUNT(*)::VARCHAR                                 AS DUPLICATES
  FROM (SELECT PARTICIPANT, MODULE_ID, STEP_KEY FROM LAB_PROGRESS
         GROUP BY 1, 2, 3 HAVING COUNT(*) > 1);

-- 4. Isolation: the shared learner role must hold nothing on the raw tables and
--    must not be able to call the writer procedures, which take a participant
--    argument and could otherwise be used to forge someone else's progress.
--
--    Match on the fully-qualified suffix, not a substring: '%LAB_PROGRESS%' also
--    matches MY_LAB_PROGRESS, which is the read path learners are SUPPOSED to
--    have, and would report a failure every time the grants were correct.
SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT;
SELECT 'isolation: learners cannot reach raw progress'   AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COALESCE(LISTAGG("name", ', '), 'none')           AS LEAKED
  FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
 WHERE "name" ILIKE '%.LAB_PROGRESS'
    OR "name" ILIKE '%.LAB_ACTIVITY'
    OR "name" ILIKE '%.SET_LAB_STEP%'
    OR "name" ILIKE '%.TOUCH_LAB_VISIT%';

-- 5. Learners DO need the two read paths, or the app shows an empty lab.
SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT;
SELECT 'access: learners can read steps and own progress' AS CHECK_NAME,
       IFF(COUNT(*) = 2, 'PASS', 'FAIL')                  AS VERDICT,
       COALESCE(LISTAGG("name", ', '), 'none')            AS GRANTED
  FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
 WHERE "privilege" = 'SELECT'
   AND ("name" ILIKE '%.MY_LAB_PROGRESS' OR "name" ILIKE '%.LAB_STEPS');

-- ---------------------------------------------------------------------------
-- Multi-training gates.
-- ---------------------------------------------------------------------------

-- 6. Every training referenced by a checkpoint is registered and active. An
--    orphan means learners tick checkpoints that no roll-up will attribute, and
--    nothing errors -- it just looks like the cohort did nothing.
SELECT 'trainings: every seeded step has a MODULES row'  AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COALESCE(LISTAGG(DISTINCT s.MODULE_ID, ', '), 'none') AS UNREGISTERED
  FROM LAB_STEPS s
 WHERE s.IS_ACTIVE
   AND NOT EXISTS (SELECT 1 FROM MODULES m
                    WHERE m.MODULE_ID = s.MODULE_ID AND m.IS_ACTIVE);

-- 7. No superseded procedure signature survives. Adding a parameter creates an
--    OVERLOAD rather than replacing, so without an explicit DROP the old
--    training-unaware versions stay callable and write rows with a NULL training
--    that no view can attribute. This is the gate for that specific mistake.
SHOW PROCEDURES LIKE '%LAB%' IN SCHEMA SNOWCUP_WORKSHOP.GRADING;
SELECT 'procedures: no training-unaware signature left'  AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COALESCE(LISTAGG("arguments", ' | '), 'none')      AS SUPERSEDED
  FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
 WHERE "arguments" ILIKE 'SET_LAB_STEP(VARCHAR, VARCHAR, BOOLEAN)%'
    OR "arguments" ILIKE 'TOUCH_LAB_VISIT(VARCHAR)%';

-- 8. COMPLETED_AT means what it claims: every stamped learner really has finished
--    both halves. A false stamp would sign somebody off who has questions wrong.
SELECT 'completion: no stamp without all steps and answers' AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                    AS VERDICT,
       COALESCE(LISTAGG(PARTICIPANT || '/' || MODULE_ID, ', '), 'none') AS FALSELY_COMPLETE
  FROM LAB_PROGRESS_BY_LEARNER
 WHERE COMPLETED_AT IS NOT NULL
   AND (STEPS_TOTAL = 0
     OR STEPS_DONE < STEPS_TOTAL
     OR QUESTIONS_CORRECT < QUESTIONS_TOTAL);

-- 9. The inverse, which is the failure mode that actually bites: someone who has
--    finished everything but was never stamped shows as "in progress" forever.
--    The sweep at the end of the setup script exists to keep this at zero.
--
--    Quizzes are part of "finished" now, so they belong in this condition too --
--    without them a learner who has done the checkpoints and the challenge but
--    not the quizzes would be reported as wrongly-unstamped when they are simply
--    not finished yet.
SELECT 'completion: no finished learner left unstamped'  AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COALESCE(LISTAGG(PARTICIPANT || '/' || MODULE_ID, ', '), 'none') AS UNSTAMPED
  FROM LAB_PROGRESS_BY_LEARNER
 WHERE COMPLETED_AT IS NULL
   AND STEPS_TOTAL > 0
   AND STEPS_DONE >= STEPS_TOTAL
   AND QUESTIONS_CORRECT >= QUESTIONS_TOTAL
   AND QUIZ_CORRECT >= QUIZ_TOTAL;

-- ---------------------------------------------------------------------------
-- Reinforcement quiz gates.
-- ---------------------------------------------------------------------------

-- 10. Registry seeded: two questions per section, 11 sections.
SELECT 'quiz: 22 active SnowCup questions seeded'        AS CHECK_NAME,
       IFF(COUNT(*) = 22, 'PASS', 'FAIL')                AS VERDICT,
       COUNT(*)::VARCHAR                                 AS ACTIVE_QUESTIONS
  FROM QUIZ_KEY WHERE IS_ACTIVE AND MODULE_ID = 'SNOWCUP';

-- 11. Referential integrity on the PAIR, since a ref is only unique within a
--     training.
SELECT 'quiz: no answers for unknown questions'          AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COUNT(*)::VARCHAR                                 AS ORPHANS
  FROM QUIZ_PROGRESS p
 WHERE NOT EXISTS (SELECT 1 FROM QUIZ_KEY k
                    WHERE k.MODULE_ID = p.MODULE_ID AND k.QUIZ_REF = p.QUIZ_REF);

-- 12. One row per participant per question. Snowflake does not enforce primary
--     keys, so this is checked as data.
SELECT 'quiz: one row per participant per question'      AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COUNT(*)::VARCHAR                                 AS DUPLICATES
  FROM (SELECT PARTICIPANT, MODULE_ID, QUIZ_REF FROM QUIZ_PROGRESS
         GROUP BY 1, 2, 3 HAVING COUNT(*) > 1);

-- 13. THE ANSWER MUST STAY HIDDEN. Learners get no privilege on the key or the
--     raw progress table, and cannot call the grading procedure -- which takes a
--     participant argument, so a learner able to call it could grade for someone
--     else. This is what allows quiz results to gate completion honestly.
SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT;
SELECT 'quiz: learners cannot reach the answer key'      AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COALESCE(LISTAGG("name", ', '), 'none')           AS LEAKED
  FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
 WHERE "name" ILIKE '%.QUIZ_KEY'
    OR "name" ILIKE '%.QUIZ_PROGRESS'
    OR "name" ILIKE '%.SUBMIT_QUIZ_ANSWER%';

-- 14. Every seeded question is actually answerable: the correct option must be a
--     valid index into the three options the content model renders, and there must
--     be an explanation, since the explanation IS the reinforcement.
--
--     Note what this does NOT assert: that nobody stamped complete has quizzes
--     outstanding. Learners stamped before quizzes existed keep their completion
--     by design -- EVALUATE_LAB_COMPLETION never clears a stamp, so completion is
--     a historical fact rather than something a later requirement can revoke.
--     Whether a NEW stamp respects the quiz requirement is a behavioural property
--     of the procedure, proved by the functional test rather than by counting rows.
SELECT 'quiz: every question is answerable'             AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                AS VERDICT,
       COALESCE(LISTAGG(QUIZ_REF, ', '), 'none')        AS UNANSWERABLE
  FROM QUIZ_KEY
 WHERE IS_ACTIVE
   AND (CORRECT_OPTION IS NULL OR CORRECT_OPTION < 0 OR CORRECT_OPTION > 2
     OR EXPLANATION IS NULL OR TRIM(EXPLANATION) = '');
