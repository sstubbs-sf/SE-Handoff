#!/usr/bin/env python3
"""
Consistency gate: the lab content model vs the LAB_STEPS seed in SQL.

WHY THIS EXISTS
Checkpoint keys live in two places by necessity: the content model (what the app
renders and binds checkboxes to) and the MERGE seed in snowcup-grader-setup.sql
(what the database will accept, since SET_LAB_STEP validates against LAB_STEPS).

If they drift, the failure is quiet and nasty: a learner ticks a checkpoint, the
procedure rejects the key as unknown, and the tick silently fails to save. Nothing
errors at deploy time. This compares them statically so an edit to one without the
other fails the suite instead of a cohort.

Usage:
    python3 verify/check_lab_steps.py
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "snowcup-lab-node"
GRADER = ROOT / "snowcup-grader-setup.sql"


def content_steps():
    """Ask node for the content model's checkpoint registry and its training id."""
    proc = subprocess.run(
        ["node", "scripts/dump-content.mjs", "--steps"],
        cwd=APP, capture_output=True, text=True,
    )
    if proc.returncode != 0:
        print("FAIL  could not read the content model")
        print(proc.stderr.strip()[:600])
        return None, None
    payload = json.loads(proc.stdout)
    training = str(payload["training"]["id"])
    rows = payload["steps"]
    return training, {
        r["step_key"]: (r["section_id"], int(r["section_seq"]), r["section_title"], r["phase"])
        for r in rows
    }


def sql_steps():
    """
    Parse the MERGE ... USING (SELECT * FROM VALUES (...)) seed block.

    Deliberately narrow: it only reads tuples that look like a step row, so
    unrelated VALUES blocks elsewhere in the script cannot be picked up.

    Returns (trainings, rows) where trainings is the set of MODULE_ID values seen,
    so a seed filed under the wrong training can be reported rather than silently
    compared field-by-field and passing.
    """
    text = GRADER.read_text(encoding="utf-8")
    block = re.search(
        r"MERGE INTO LAB_STEPS.*?AS s\(STEP_KEY, MODULE_ID, SECTION_ID, SECTION_SEQ, "
        r"SECTION_TITLE, PHASE\)",
        text, re.S,
    )
    if not block:
        print("FAIL  could not find the LAB_STEPS seed block in snowcup-grader-setup.sql")
        return None, None

    rows = {}
    trainings = set()
    pattern = re.compile(
        r"\(\s*'([^']+)'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*,\s*(\d+)\s*,"
        r"\s*'((?:[^']|'')*)'\s*,\s*'((?:[^']|'')*)'\s*\)"
    )
    for m in pattern.finditer(block.group(0)):
        key, training, section, seq, title, phase = m.groups()
        trainings.add(training)
        # SQL escapes a quote by doubling it; undo that before comparing.
        rows[key] = (section, int(seq), title.replace("''", "'"), phase.replace("''", "'"))
    return trainings, rows


def main():
    training, content = content_steps()
    if content is None:
        return 1
    sql_trainings, sql = sql_steps()
    if sql is None:
        return 1

    failures = []

    # The training id is what separates one training's progress from another's. If
    # the app writes SNOWCUP but the rows are seeded under COST_LAB, the pair check
    # inside SET_LAB_STEP rejects every tick as an unknown step -- and nothing
    # errors at deploy time.
    if sql_trainings != {training}:
        failures.append(
            f"training mismatch: the content model declares {training!r} but the "
            f"LAB_STEPS seed uses {sorted(sql_trainings)!r} -- every checkpoint tick "
            f"would be rejected as an unknown step"
        )

    only_content = sorted(set(content) - set(sql))
    only_sql = sorted(set(sql) - set(content))
    for key in only_content:
        failures.append(
            f"{key} is in the content model but NOT seeded in LAB_STEPS -- "
            f"ticking it would be rejected as an unknown step"
        )
    for key in only_sql:
        failures.append(
            f"{key} is seeded in LAB_STEPS but has no checkpoint in the content model -- "
            f"it will show as a step nobody can complete"
        )

    for key in sorted(set(content) & set(sql)):
        c, s = content[key], sql[key]
        for i, field in enumerate(("section_id", "section_seq", "section_title", "phase")):
            if c[i] != s[i]:
                failures.append(f"{key} {field}: content={c[i]!r} sql={s[i]!r}")

    print(
        f"training {training!r}; content model: {len(content)} checkpoint(s); "
        f"LAB_STEPS seed: {len(sql)} row(s)"
    )
    if failures:
        print("\nFAILED  the content model and the LAB_STEPS seed disagree")
        for f in failures:
            print(f"   {f}")
        return 1

    print(
        f"PASS  all {len(content)} checkpoints agree on training, key, section, "
        f"sequence, title and phase"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
