-- ============================================================================
-- PRE-FLIGHT: run this BEFORE deploying the updated package, and only if this
-- account was provisioned by an EARLIER version of the lab.
--
-- Older versions set DEFAULT_SECONDARY_ROLES = () on every learner and kept the
-- original value in ADMIN.USER_DEFAULTS_BACKUP.ORIG_DEFAULT_SECONDARY_ROLES.
-- The lab no longer manages that property, and snowcup-data-setup.sql now DROPS
-- that column -- so once you deploy, the record of the original values is gone
-- and any learner still sitting at () stays there permanently. Nothing errors;
-- they just quietly have no secondary roles.
--
-- This script is read-only. It prints one ALTER USER per affected learner for
-- you to review and run. On a fresh or already-migrated account it reports
-- NOTHING TO MIGRATE and does nothing.
--
-- Usage:
--   snow sql -c <connection> --role ACCOUNTADMIN -f verify/preflight_secondary_roles.sql
-- ============================================================================
EXECUTE IMMEDIATE $$
DECLARE
  has_col INT DEFAULT 0;
  stmt    VARCHAR;
BEGIN
  SELECT COUNT(*) INTO :has_col
    FROM SNOWCUP_WORKSHOP.INFORMATION_SCHEMA.COLUMNS
   WHERE TABLE_SCHEMA = 'ADMIN'
     AND TABLE_NAME   = 'USER_DEFAULTS_BACKUP'
     AND COLUMN_NAME  = 'ORIG_DEFAULT_SECONDARY_ROLES';

  IF (has_col = 0) THEN
    stmt := 'SELECT ''NOTHING TO MIGRATE'' AS VERDICT, NULL::VARCHAR AS USERNAME,'
         || ' NULL::VARCHAR AS ORIGINAL_VALUE, NULL::VARCHAR AS RESTORE_STATEMENT';
    LET ok RESULTSET := (EXECUTE IMMEDIATE :stmt);
    RETURN TABLE(ok);
  END IF;

  -- SHOW USERS gives the user's REAL name. The backup table stores an uppercased
  -- form, and a double-quoted identifier is case-sensitive, so building
  -- ALTER USER from the backup value fails with "does not exist or not
  -- authorized" for any SSO user whose name is lowercase. Join to get the truth.
  SHOW TERSE USERS;
  LET res RESULTSET := (EXECUTE IMMEDIATE
    'SELECT ''RESTORE BEFORE DEPLOYING'' AS VERDICT,
            u."name"                     AS USERNAME,
            b.ORIG_DEFAULT_SECONDARY_ROLES AS ORIGINAL_VALUE,
            ''ALTER USER "'' || u."name" || ''" UNSET DEFAULT_SECONDARY_ROLES;'' AS RESTORE_STATEMENT
       FROM SNOWCUP_WORKSHOP.ADMIN.USER_DEFAULTS_BACKUP b
       JOIN TABLE(RESULT_SCAN(LAST_QUERY_ID())) u
         ON UPPER(u."name") = UPPER(b.USERNAME)
      WHERE b.ORIG_DEFAULT_SECONDARY_ROLES IS NOT NULL
        AND b.ORIG_DEFAULT_SECONDARY_ROLES NOT IN (''[]'', '''')
      ORDER BY 2');
  RETURN TABLE(res);
END;
$$;
