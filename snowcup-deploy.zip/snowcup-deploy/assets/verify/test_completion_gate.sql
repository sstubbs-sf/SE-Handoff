-- ===========================================================================
-- Functional proof that a NEW completion stamp requires all three conditions:
-- checkpoints, challenge answers, AND reinforcement quizzes.
--
--   snow sql -f verify/test_completion_gate.sql
--
-- The 14 row-counting gates in check_lab_progress.sql cannot prove this. They
-- assert on state; this is a behavioural property of EVALUATE_LAB_COMPLETION,
-- so it has to be exercised. The test drives a synthetic participant through
-- four phases and asserts on COMPLETED_AT -- the stamp itself, not the return
-- string -- because the stamp is what LAB_PROGRESS_BY_LEARNER and the Referee
-- actually read.
--
-- Progress is seeded with set-based INSERTs rather than by calling SET_LAB_STEP
-- and SUBMIT_QUIZ_ANSWER in a loop. That is deliberate: the subject under test
-- is the completion rule, and the writers are covered elsewhere (the quiz
-- grader by its own wrong/right/sticky test, the checkpoint writer by gate 2's
-- referential integrity). Seeding directly also keeps the test free of cursor
-- loops, which is what the CLI and Snowflake Scripting disagree about.
--
-- Self-cleaning: the synthetic participant is removed at the end, so this is
-- safe to re-run and leaves no row that would skew the leaderboard.
-- ===========================================================================
USE ROLE ACCOUNTADMIN;
USE WAREHOUSE SNOWCUP_WH;
USE SCHEMA SNOWCUP_WORKSHOP.GRADING;

-- Wrapped in EXECUTE IMMEDIATE $$ ... $$ because the Snowflake CLI splits input
-- on semicolons and would tear a bare DECLARE ... END block apart at the first
-- statement inside it. Dollar-quoting keeps it a single statement.
EXECUTE IMMEDIATE $$
DECLARE
  p          VARCHAR DEFAULT 'ZZ_QUIZGATE_TEST';
  m          VARCHAR DEFAULT 'SNOWCUP';
  held_back  VARCHAR;
  stamp      TIMESTAMP_LTZ;
BEGIN
  -- Start from nothing, so a previous run cannot make this pass vacuously.
  DELETE FROM LAB_PROGRESS       WHERE PARTICIPANT = :p;
  DELETE FROM CHALLENGE_PROGRESS WHERE PARTICIPANT = :p;
  DELETE FROM QUIZ_PROGRESS      WHERE PARTICIPANT = :p;
  DELETE FROM LAB_ACTIVITY       WHERE PARTICIPANT = :p;

  CREATE OR REPLACE TEMPORARY TABLE ZZ_GATE_RESULT (
    SEQ INT, PHASE VARCHAR, EXPECTED VARCHAR, ACTUAL VARCHAR, VERDICT VARCHAR);

  -- LAB_ACTIVITY needs the row to exist for the stamp to land on it, which is
  -- what visiting the lab would have created.
  INSERT INTO LAB_ACTIVITY (PARTICIPANT, MODULE_ID, FIRST_SEEN_AT, LAST_SEEN_AT, VISITS)
  SELECT :p, :m, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 1;

  -- ---- Phase A: every checkpoint, nothing else. ------------------------
  INSERT INTO LAB_PROGRESS (PARTICIPANT, MODULE_ID, STEP_KEY, DONE, FIRST_DONE_AT, UPDATED_AT)
  SELECT :p, MODULE_ID, STEP_KEY, TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
    FROM LAB_STEPS WHERE IS_ACTIVE AND MODULE_ID = :m;
  CALL EVALUATE_LAB_COMPLETION(:p, :m);
  SELECT MAX(COMPLETED_AT) INTO :stamp FROM LAB_ACTIVITY
   WHERE PARTICIPANT = :p AND MODULE_ID = :m;
  INSERT INTO ZZ_GATE_RESULT SELECT 1, 'A: checkpoints only', 'no stamp',
    IFF(:stamp IS NULL, 'no stamp', 'STAMPED'), IFF(:stamp IS NULL, 'PASS', 'FAIL');

  -- ---- Phase B: + every challenge answer correct. ----------------------
  INSERT INTO CHALLENGE_PROGRESS
    (PARTICIPANT, MODULE_ID, QUESTION_ID, BEST_CORRECT, POINTS_AWARDED,
     ATTEMPTS, FIRST_SUBMITTED_AT, LAST_SUBMITTED_AT, LAST_ANSWER)
  SELECT :p, MODULE_ID, QUESTION_ID, TRUE, POINTS, 1,
         CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), CANONICAL_ANSWER
    FROM CHALLENGE_KEY WHERE MODULE_ID = :m;
  CALL EVALUATE_LAB_COMPLETION(:p, :m);
  SELECT MAX(COMPLETED_AT) INTO :stamp FROM LAB_ACTIVITY
   WHERE PARTICIPANT = :p AND MODULE_ID = :m;
  INSERT INTO ZZ_GATE_RESULT SELECT 2, 'B: + challenge answers', 'no stamp',
    IFF(:stamp IS NULL, 'no stamp', 'STAMPED'), IFF(:stamp IS NULL, 'PASS', 'FAIL');

  -- ---- Phase C: + every quiz but one. ---------------------------------
  --      Holding one back separates "quizzes are counted at all" from
  --      "quizzes are counted only when every one is correct". Without this
  --      phase, a rule that merely required one quiz would also pass.
  SELECT MAX(QUIZ_REF) INTO :held_back FROM QUIZ_KEY
   WHERE IS_ACTIVE AND MODULE_ID = :m;
  INSERT INTO QUIZ_PROGRESS
    (PARTICIPANT, MODULE_ID, QUIZ_REF, BEST_CORRECT, ATTEMPTS, LAST_CHOICE,
     FIRST_SUBMITTED_AT, LAST_SUBMITTED_AT)
  SELECT :p, MODULE_ID, QUIZ_REF, TRUE, 1, CORRECT_OPTION,
         CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
    FROM QUIZ_KEY
   WHERE IS_ACTIVE AND MODULE_ID = :m AND QUIZ_REF <> :held_back;
  CALL EVALUATE_LAB_COMPLETION(:p, :m);
  SELECT MAX(COMPLETED_AT) INTO :stamp FROM LAB_ACTIVITY
   WHERE PARTICIPANT = :p AND MODULE_ID = :m;
  INSERT INTO ZZ_GATE_RESULT SELECT 3, 'C: + all quizzes but one', 'no stamp',
    IFF(:stamp IS NULL, 'no stamp', 'STAMPED'), IFF(:stamp IS NULL, 'PASS', 'FAIL');

  -- ---- Phase D: + the last quiz. Now it must stamp. -------------------
  INSERT INTO QUIZ_PROGRESS
    (PARTICIPANT, MODULE_ID, QUIZ_REF, BEST_CORRECT, ATTEMPTS, LAST_CHOICE,
     FIRST_SUBMITTED_AT, LAST_SUBMITTED_AT)
  SELECT :p, MODULE_ID, QUIZ_REF, TRUE, 1, CORRECT_OPTION,
         CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
    FROM QUIZ_KEY
   WHERE IS_ACTIVE AND MODULE_ID = :m AND QUIZ_REF = :held_back;
  CALL EVALUATE_LAB_COMPLETION(:p, :m);
  SELECT MAX(COMPLETED_AT) INTO :stamp FROM LAB_ACTIVITY
   WHERE PARTICIPANT = :p AND MODULE_ID = :m;
  INSERT INTO ZZ_GATE_RESULT SELECT 4, 'D: + the last quiz', 'STAMPED',
    IFF(:stamp IS NULL, 'no stamp', 'STAMPED'), IFF(:stamp IS NOT NULL, 'PASS', 'FAIL');

  -- Leave no trace. The synthetic learner must not reach the leaderboard.
  DELETE FROM LAB_PROGRESS       WHERE PARTICIPANT = :p;
  DELETE FROM CHALLENGE_PROGRESS WHERE PARTICIPANT = :p;
  DELETE FROM QUIZ_PROGRESS      WHERE PARTICIPANT = :p;
  DELETE FROM LAB_ACTIVITY       WHERE PARTICIPANT = :p;

  RETURN 'ran';
END;
$$;

SELECT SEQ, PHASE, EXPECTED, ACTUAL, VERDICT FROM ZZ_GATE_RESULT ORDER BY SEQ;

-- Cleanup must have worked, or the next leaderboard read is wrong.
SELECT 'cleanup: no synthetic rows remain' AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')   AS VERDICT,
       COUNT(*)::VARCHAR                   AS LEFTOVER
  FROM (SELECT PARTICIPANT FROM LAB_PROGRESS       WHERE PARTICIPANT = 'ZZ_QUIZGATE_TEST'
        UNION ALL SELECT PARTICIPANT FROM CHALLENGE_PROGRESS WHERE PARTICIPANT = 'ZZ_QUIZGATE_TEST'
        UNION ALL SELECT PARTICIPANT FROM QUIZ_PROGRESS      WHERE PARTICIPANT = 'ZZ_QUIZGATE_TEST'
        UNION ALL SELECT PARTICIPANT FROM LAB_ACTIVITY       WHERE PARTICIPANT = 'ZZ_QUIZGATE_TEST');

-- Adding the quiz requirement must not have revoked anybody's existing stamp.
-- Completion is a historical fact: EVALUATE_LAB_COMPLETION only ever COALESCEs
-- a stamp in, never clears one, so a learner who finished before quizzes existed
-- stays finished.
SELECT 'pre-existing stamps survive the new requirement' AS CHECK_NAME,
       IFF(COUNT(*) = 0, 'PASS', 'FAIL')                 AS VERDICT,
       COALESCE(LISTAGG(PARTICIPANT, ', '), 'none')      AS DESTAMPED
  FROM LAB_PROGRESS_BY_LEARNER
 WHERE STATUS = 'complete' AND COMPLETED_AT IS NULL;
