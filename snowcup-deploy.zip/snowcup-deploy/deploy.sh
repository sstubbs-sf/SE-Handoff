#!/usr/bin/env bash
#
# One-command deploy of the SnowCup Build-an-Agent Lab into a Snowflake account.
#
#   ./deploy.sh --connection <name> [options]
#
# WHAT IT AUTOMATES
#   preflight capability probes, App Runtime account defaults, shared data, the
#   grader and Referee agent, verification gates, learner provisioning, both apps,
#   and every grant -- then prints the hand-off.
#
# WHAT IT DELIBERATELY WILL NOT DECIDE FOR YOU
#   * Gen2 unavailable in the region -> stops. The data setup requires it, and
#     silently dropping the clause would change the workshop's performance
#     profile without anyone knowing.
#   * A CoWork object already exists -> reports and continues WITHOUT touching it.
#     Creating one flips the account from "list every agent I can access" to "list
#     only what was added", which would hide every agent your learners build.
#   * ALTER ACCOUNT (App Runtime defaults) -> needs --yes, because it is an
#     account-wide change that affects other people's apps.
#
# Fails fast: any gate that does not pass stops the run, because a half-configured
# account is harder to diagnose than a clean stop.
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ASSETS="$HERE/assets"
CONN=""
LEARNERS=""
ALLOW_ACCOUNT_CHANGES=0
SKIP_APPS=0
ROLE="ACCOUNTADMIN"

usage() {
  cat <<'USAGE'
Usage: ./deploy.sh --connection <name> [options]

Required:
  --connection NAME     Snowflake CLI connection to deploy into

Options:
  --learners "a@x,b@x"  Provision these learners (comma or space separated)
  --yes                 Allow ALTER ACCOUNT for App Runtime defaults if unset
  --skip-apps           SQL only; skip both app deploys (no shell/npm needed)
  --role ROLE           Role to run as (default ACCOUNTADMIN)
  -h, --help            This message

Examples:
  ./deploy.sh --connection my_account --yes
  ./deploy.sh --connection my_account --yes --learners "jane@acme.com, JSMITH"
  ./deploy.sh --connection my_account --skip-apps      # Snowsight-style, SQL only
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --connection) CONN="${2:-}"; shift 2 ;;
    --learners)   LEARNERS="${2:-}"; shift 2 ;;
    --role)       ROLE="${2:-}"; shift 2 ;;
    --yes)        ALLOW_ACCOUNT_CHANGES=1; shift ;;
    --skip-apps)  SKIP_APPS=1; shift ;;
    -h|--help)    usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done

[[ -z "$CONN" ]] && { echo "ERROR: --connection is required" >&2; usage; exit 2; }
[[ -d "$ASSETS" ]] || { echo "ERROR: assets/ not found next to deploy.sh" >&2; exit 2; }

step=0
say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
ok()   { printf '    PASS  %s\n' "$*"; }
warn() { printf '    WARN  %s\n' "$*"; }
die()  { printf '\n    STOP  %s\n\n' "$*" >&2; exit 1; }

sf() { snow sql -c "$CONN" --role "$ROLE" -q "$1" 2>&1; }
sf_file() { snow sql -c "$CONN" --role "$ROLE" -f "$1" 2>&1; }

# Return a single scalar. $1 is a SQL expression.
#
# Uses --format json rather than parsing the table: snow ECHOES the query in
# table mode, so any in-query marker gets matched from the echo instead of the
# result -- which is exactly how the account URL came out as SQL fragments.
sf_value() {
  snow sql -c "$CONN" --role "$ROLE" -q "SELECT ($1)::VARCHAR AS V" --format json 2>/dev/null \
    | grep -oE '"V" *: *"[^"]*"' | head -1 | sed 's/.*: *"//;s/"$//'
}

# --------------------------------------------------------------------------- #
say "0. Checking tools and connection"
command -v snow >/dev/null || die "Snowflake CLI (snow) not found. See the README."
if [[ $SKIP_APPS -eq 0 ]]; then
  command -v npm >/dev/null || die "npm not found. Install Node 20+, or pass --skip-apps."
fi

WHOAMI="$(sf_value "CURRENT_USER() || ' / ' || CURRENT_ROLE()")"
[[ -z "$WHOAMI" ]] && die "Could not connect with --connection $CONN --role $ROLE."
ok "connected as $WHOAMI"

# --------------------------------------------------------------------------- #
say "1. Preflight (capability probes, zero credits)"
PRE="$(sf "$(cat <<'SQL'
EXECUTE IMMEDIATE $$
BEGIN
  LET gen2 VARCHAR := '';
  LET mc   VARCHAR := '';
  BEGIN
    CREATE OR REPLACE WAREHOUSE SNOWCUP_PROBE_WH
      WITH GENERATION = '2' WAREHOUSE_SIZE = 'XSMALL'
      INITIALLY_SUSPENDED = TRUE AUTO_SUSPEND = 60;
    gen2 := 'GEN2_OK';
  EXCEPTION WHEN OTHER THEN gen2 := 'GEN2_FAIL';
  END;
  BEGIN
    CREATE OR REPLACE WAREHOUSE SNOWCUP_PROBE_WH
      WAREHOUSE_SIZE = 'XSMALL' INITIALLY_SUSPENDED = TRUE
      AUTO_SUSPEND = 60 MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2;
    mc := 'MULTICLUSTER_OK';
  EXCEPTION WHEN OTHER THEN mc := 'MULTICLUSTER_NO';
  END;
  BEGIN DROP WAREHOUSE IF EXISTS SNOWCUP_PROBE_WH; EXCEPTION WHEN OTHER THEN NULL; END;
  RETURN gen2 || ' ' || mc;
END
$$;
SQL
)")"
# Read as a scalar, not by pattern-matching the shape. AWS regions look like
# "PUBLIC.AWS_US_EAST_2" but Azure returns "AZURE_EASTUS2" with no dot, so a
# dotted-pattern grep silently produced an empty region on every Azure account.
REGION="$(sf_value "CURRENT_REGION()")"
echo "$PRE" | grep -q GEN2_OK \
  || die "Gen2 warehouses are not available in this region ($REGION).
          snowcup-data-setup.sql sets GENERATION = '2' as a deliberate hard
          requirement. Deploy in another region, or consciously edit that clause
          in assets/snowcup-data-setup.sql before re-running."
ok "Gen2 supported ($REGION)"
if echo "$PRE" | grep -q MULTICLUSTER_OK; then
  ok "multi-cluster supported (Enterprise or higher)"
else
  warn "multi-cluster NOT supported (Standard edition). max_cluster_count stays 1,
          capping concurrency near 8 queries. Fine for a small cohort; above ~50
          concurrent learners raise WAREHOUSE_SIZE or run in waves."
fi

# --------------------------------------------------------------------------- #
say "2. App Runtime account defaults"
# SHOW PARAMETERS has no scalar form, so read the value out of RESULT_SCAN.
APPS_DB="$(snow sql -c "$CONN" --role "$ROLE" --format json 2>/dev/null -q \
  "SHOW PARAMETERS LIKE 'DEFAULT_SNOWFLAKE_APPS_DESTINATION_DATABASE' IN ACCOUNT;
   SELECT MAX(\"value\")::VARCHAR AS V FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));" \
  | grep -oE '"V" *: *"[^"]*"' | head -1 | sed 's/.*: *"//;s/"$//')"
if [[ -z "$APPS_DB" ]]; then
  if [[ $ALLOW_ACCOUNT_CHANGES -eq 0 ]]; then
    die "App Runtime defaults are not set, and setting them is an account-wide change.
          Without them, 'snow app deploy' SUCCEEDS but lands in your personal
          database, where an Application Service CANNOT be granted to any role --
          so nobody but you could ever open the apps.
          Re-run with --yes to let this script set them, or run manually:
            CREATE DATABASE IF NOT EXISTS SNOWFLAKE_APPS;
            CREATE WAREHOUSE IF NOT EXISTS SNOWFLAKE_APPS_QUERY_WH
              WAREHOUSE_SIZE='XSMALL' AUTO_SUSPEND=60 AUTO_RESUME=TRUE;
            ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_DATABASE='SNOWFLAKE_APPS';
            ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_SCHEMA='PUBLIC';
            ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_QUERY_WAREHOUSE='SNOWFLAKE_APPS_QUERY_WH';"
  fi
  sf "CREATE DATABASE IF NOT EXISTS SNOWFLAKE_APPS;
      CREATE WAREHOUSE IF NOT EXISTS SNOWFLAKE_APPS_QUERY_WH
        WAREHOUSE_SIZE='XSMALL' AUTO_SUSPEND=60 AUTO_RESUME=TRUE;
      ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_DATABASE='SNOWFLAKE_APPS';
      ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_DESTINATION_SCHEMA='PUBLIC';
      ALTER ACCOUNT SET DEFAULT_SNOWFLAKE_APPS_QUERY_WAREHOUSE='SNOWFLAKE_APPS_QUERY_WH';" >/dev/null
  ok "App Runtime defaults set (SNOWFLAKE_APPS / PUBLIC / SNOWFLAKE_APPS_QUERY_WH)"
else
  ok "App Runtime defaults already set ($APPS_DB)"
fi

# --------------------------------------------------------------------------- #
say "3. Shared data, roles and warehouse"
OUT="$(sf_file "$ASSETS/snowcup-data-setup.sql")"
echo "$OUT" | grep -qiE "^\| *[0-9]+ *\|.*error|SQL compilation error|SQL execution error" \
  && { echo "$OUT" | tail -25; die "snowcup-data-setup.sql failed."; }
echo "$OUT" | grep -oE "multi-cluster[^|]*" | head -1 | sed 's/^/    /'
# Surface anything the setup script says about ACCOUNT-LEVEL changes. Reporting an
# account-wide change loudly is the whole point of making it conditional -- a
# facilitator must not discover later that a workshop widened a Cortex setting.
#
# The markers (ACCTCHANGE> / ACCTFAIL>) are assembled by concatenation inside the
# SQL, so the literals never appear in the file that snow echoes back. Matching a
# plain phrase here would fire on the echoed source on EVERY run, including runs
# that changed nothing.
if echo "$OUT" | grep -q 'ACCTCHANGE>'; then
  warn "ACCOUNT-LEVEL CHANGE: $(echo "$OUT" | grep -oE 'ACCTCHANGE>[^|]*' | head -1 | sed 's/ACCTCHANGE> *//')"
fi
if echo "$OUT" | grep -q 'ACCTFAIL>'; then
  warn "$(echo "$OUT" | grep -oE 'ACCTFAIL>[^|]*' | head -1 | sed 's/ACCTFAIL> *//')"
fi
ok "SNOWCUP_SHARED loaded, roles and SNOWCUP_WH created"

say "4. Grader and Referee agent"
OUT="$(sf_file "$ASSETS/snowcup-grader-setup.sql")"
echo "$OUT" | grep -qE "SQL compilation error|SQL execution error" \
  && { echo "$OUT" | tail -25; die "snowcup-grader-setup.sql failed."; }
ok "grading schema, hidden key, procedures and SNOWCUP_REFEREE created"

# --------------------------------------------------------------------------- #
# Provisioning comes BEFORE verification on purpose. The role-model gates check
# per-learner roles and build schemas, so on a fresh account with nobody
# provisioned there is nothing to verify: gate 3 aborts because the probe role
# does not exist, and the pairing and coverage gates fail by design rather than
# report a vacuous pass. Verifying first made the whole deploy die at phase 5 on
# any fresh account, which is exactly the case this script exists for.
if [[ -n "$LEARNERS" ]]; then
  say "5. Provisioning learners"
  CLEAN="$(echo "$LEARNERS" | tr ',' ' ' | tr -s ' ' | sed 's/^ *//;s/ *$//' | tr ' ' ',')"
  PROV="$(sf "CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS('$CLEAN')")"
  echo "$PROV" | grep -oE "OK +[^|]+" | sed 's/^/    /'
  ok "provisioned: $CLEAN"
else
  say "5. Provisioning learners"
  warn "none given. Add them any time with:
          CALL SNOWCUP_WORKSHOP.ADMIN.PROVISION_LEARNERS('a@x.com, BJONES');"
fi

# ---------------------------------------------------------------------------
# INTEGRITY: a learner who also holds ACCOUNTADMIN can read CHALLENGE_KEY, so the
# whole 120-point challenge is decorative for them. Grants alone cannot prevent
# it and no gate catches it, because the grants ARE correct -- the privilege
# arrives through the user's other roles. Worse, with
# DEFAULT_SECONDARY_ROLES = ALL every session silently carries ACCOUNTADMIN even
# when the learner's primary role is their workshop role, so nothing looks wrong.
# Hit this on a hands-on-lab account whose single shared user held ACCOUNTADMIN.
#
# Uses live SHOW output, never SNOWFLAKE.ACCOUNT_USAGE: those views lag by hours
# and are empty on a fresh account, i.e. exactly when this check matters most.
admin_users() {
  snow sql -c "$CONN" --role "$ROLE" --format json 2>/dev/null \
    -q "SHOW GRANTS OF ROLE ACCOUNTADMIN" \
  | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(0)
rows = d[0] if d and isinstance(d[0], list) else d
for n in sorted({str(r.get('grantee_name')) for r in rows
                 if str(r.get('granted_to')) == 'USER'}):
    print(n)
" 2>/dev/null
}
OVERLAP=""
while read -r au; do
  [[ -z "$au" ]] && continue
  # Does this ACCOUNTADMIN also hold a workshop role? Checked per user because the
  # number of account admins is small, and SHOW GRANTS TO USER is immediate.
  #
  # </dev/null is load-bearing: snow reads stdin, and without it snow swallows the
  # remaining lines of the process substitution feeding this loop, so only the
  # FIRST admin user is ever examined.
  #
  # grep -c, not grep -q, is also load-bearing. grep -q exits on the first match,
  # snow gets SIGPIPE partway through ~200KB of output, and `set -o pipefail` then
  # reports the PIPELINE as failed even though the match succeeded -- so a real
  # finding read as "no problem". Counting consumes all output, so nothing is
  # killed early. `|| true` covers grep exiting 1 on zero matches.
  hits="$(snow sql -c "$CONN" --role "$ROLE" --format json 2>/dev/null \
            -q "SHOW GRANTS TO USER \"$au\"" </dev/null \
          | grep -c 'SNOWCUP_WS_' || true)"
  if [[ "${hits:-0}" -gt 0 ]]; then
    OVERLAP="$OVERLAP $au"
  fi
done < <(admin_users)
if [[ -n "${OVERLAP// /}" ]]; then
  warn "CHALLENGE INTEGRITY: these learners also hold ACCOUNTADMIN, so they can read
          the hidden answer key and the challenge is meaningless for them:$OVERLAP
          Give learners a user WITHOUT ACCOUNTADMIN. Note that
          DEFAULT_SECONDARY_ROLES = ALL keeps ACCOUNTADMIN active even when their
          primary role is SNOWCUP_WS_<name>, so this is invisible in normal use."
fi

# --------------------------------------------------------------------------- #
say "6. Verification gates (fail-fast)"
ANS="$(sf_file "$ASSETS/verify/verify_answers.sql")"
MATCHES="$(echo "$ANS" | grep -cE '\| MATCH')"
[[ "$MATCHES" -eq 8 ]] || { echo "$ANS" | grep -E '\| (MATCH|\*\*\*)' | head; die "expected 8 answers to MATCH, got $MATCHES."; }
echo "$ANS" | grep -qE 'nickname isolation *\| PASS' || die "nickname isolation gate FAILED -- PLAYERS still has a NICKNAME column, so Tier 4 can be shortcut."
ok "8/8 answers MATCH, nickname gates pass"

# Gates are judged on the ABSENCE OF FAILURE plus a completion marker, not on an
# exact count of PASS lines. Counting was brittle: adding a gate, or a gate that
# legitimately reports on more rows, silently broke the deploy even when nothing
# was actually wrong.
gate_file() {   # $1 = label, $2 = sql file, $3 = check_name of the LAST gate in the file
  local label="$1" file="$2" marker="$3" out fails passes
  out="$(sf_file "$file")"
  fails="$(echo "$out" | grep -cE '\| FAIL')"
  passes="$(echo "$out" | grep -cE '\| PASS')"
  if [[ "$fails" -gt 0 ]]; then
    echo "$out" | grep -E '\| (PASS|FAIL)' | sed 's/^/    /'
    die "$fails $label gate(s) FAILED."
  fi
  # A hard SQL error aborts the rest of the file, which would otherwise look like
  # "no failures at all". Prove the LAST gate actually produced a verdict ROW: the
  # marker and a verdict must appear on the SAME line, which only happens in a
  # result row. snow echoes the query text too, but there the marker and the
  # 'PASS'/'FAIL' literals land on different lines, so the echo cannot satisfy it.
  echo "$out" | grep -qE "${marker}.*\| *(PASS|FAIL)" \
    || { echo "$out" | tail -20; die "$label gates did not run to completion (last gate '$marker' produced no verdict)."; }
  ok "$passes/$passes $label gates pass"
}

# Skipped rather than failed when nobody is provisioned: a role model with no
# learners is genuinely unverifiable, not broken. Counted in SQL via RESULT_SCAN
# rather than by grepping SHOW output, whose table layout is not stable enough to
# parse -- a mis-parse here would silently SKIP gates that ought to run, which is
# worse than failing loudly.
WS_COUNT="$(snow sql -c "$CONN" --role "$ROLE" --format json 2>/dev/null -q \
  "SHOW ROLES LIKE 'SNOWCUP_WS_%';
   SELECT COUNT(*)::VARCHAR AS V FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));" \
  | grep -oE '"V" *: *"[^"]*"' | head -1 | sed 's/.*: *"//;s/"$//')"
# Keep digits only. A non-numeric value would make the test below error out and
# fall through to "skip", quietly dropping gates that should have run.
WS_COUNT="$(printf '%s' "${WS_COUNT:-}" | tr -cd '0-9')"
WS_COUNT="${WS_COUNT:-0}"
if [[ "$WS_COUNT" -gt 0 ]]; then
  ok "$WS_COUNT learner role(s) found; role-model gates apply"
  gate_file "role" "$ASSETS/verify/check_roles.sql" "ownership: learners own everything"
  # Ownership needs its own pass across ALL object kinds. check_roles.sql check 6
  # reads an "owner" column, and SHOW CORTEX SEARCH SERVICES / SHOW PROCEDURES do
  # not have one -- so those kinds were invisible to it and a learner could be
  # blocked with "the Cortex Search Service does not exist" while every gate
  # passed. This calls ADMIN.AUDIT_BUILD_OWNERSHIP, the same definition the admin
  # console uses, so the two cannot drift apart again.
  SS="$("$ASSETS/verify/check_build_ownership.sh" "$CONN" "$ROLE" 2>&1)"
  SS_RC=$?
  if [[ "$SS_RC" -ne 0 ]]; then
    echo "$SS" | sed 's/^/    /'
    die "build-schema ownership is wrong -- learners cannot use objects they do not own."
  fi
  # Strip the gate's own PASS prefix; ok() adds its own. -E because BSD sed (macOS)
  # does not support \| alternation in a basic regex.
  ok "$(echo "$SS" | tail -1 | sed -E 's/^ *(PASS|FAIL) *//')"
else
  warn "no learners provisioned, so the role-model gates are skipped -- there is no
          per-learner role or build schema to check yet. Provision, then re-run:
            snow sql -c $CONN --role $ROLE -f verify/check_roles.sql"
fi

# The marker MUST name the LAST gate in the file. When gates are appended, this
# has to move with them -- pointing it at an earlier gate silently defeats the
# completion proof, because a hard SQL error in the appended gates aborts the
# rest of the file and that looks identical to "no failures".
gate_file "lab-progress" "$ASSETS/verify/check_lab_progress.sql" "quiz: every question is answerable"

# The gates above assert on state. Whether a NEW completion stamp actually
# requires checkpoints AND challenge answers AND quizzes is behaviour, and no
# amount of row counting can prove it -- so it is exercised against a synthetic
# participant that the test removes again on the way out.
CT="$(sf_file "$ASSETS/verify/test_completion_gate.sql")"
CT_FAILS="$(echo "$CT" | grep -cE '\| FAIL')"
if [[ "$CT_FAILS" -gt 0 ]]; then
  echo "$CT" | grep -E '\| (PASS|FAIL)' | sed 's/^/    /'
  die "$CT_FAILS completion-rule test(s) FAILED -- a learner could be signed off early."
fi
echo "$CT" | grep -qE "pre-existing stamps survive.*\| *(PASS|FAIL)" \
  || { echo "$CT" | tail -20; die "completion-rule test did not run to completion."; }
ok "completion rule proven: checkpoints + answers + quizzes all required"

# --------------------------------------------------------------------------- #
say "7. CoWork visibility"
CW="$(sf "SHOW SNOWFLAKE INTELLIGENCES")"
if echo "$CW" | grep -qiE "^\| *SNOWFLAKE_INTELLIGENCE|OBJECT_DEFAULT"; then
  warn "This account HAS a CoWork object, so only agents added to it appear in the
          picker. Add the Referee and let learners add their own:
            ALTER SNOWFLAKE INTELLIGENCE SNOWFLAKE_INTELLIGENCE_OBJECT_DEFAULT
              ADD AGENT SNOWCUP_WORKSHOP.GRADING.SNOWCUP_REFEREE;
            GRANT USAGE, MODIFY ON <that object> TO ROLE SNOWCUP_PARTICIPANT;
          Not done automatically -- it is a shared object other agents depend on."
else
  ok "no CoWork object; every accessible agent is listed automatically (nothing to do)"
fi

# --------------------------------------------------------------------------- #
LAB_URL=""
ADMIN_URL=""
if [[ $SKIP_APPS -eq 1 ]]; then
  say "8. Apps (skipped)"
  warn "--skip-apps was set. The lab app IS the learner deliverable, so the training
          cannot be delivered until it is deployed from a machine with npm:
            cd assets/snowcup-lab-node && npm install && snow app deploy --role $ROLE"
else
  say "8. Deploying apps (cold build 15-20 min each; cached ~1 min)"
  for app in snowcup-lab-node snowcup-admin-node; do
    printf '    %s ... ' "$app"
    ( cd "$ASSETS/$app" && npm install >/dev/null 2>&1 ) || die "npm install failed in $app"
    DEP="$( cd "$ASSETS/$app" && snow app deploy -c "$CONN" --role "$ROLE" 2>&1 )"
    if echo "$DEP" | grep -q "App ready at"; then
      URL="$(echo "$DEP" | grep -oE 'https://[a-z0-9.-]+snowflakecomputing\.app' | head -1)"
      echo "ready"
      if [[ "$app" == "snowcup-lab-node" ]]; then LAB_URL="$URL"; else ADMIN_URL="$URL"; fi
    else
      echo "FAILED"
      # An expired login looks identical to a broken build here, and the two need
      # opposite responses: re-authenticate and re-run, versus actually debug the
      # app. App builds are slow enough that a token can easily expire part-way
      # through, so this is a likely failure rather than an exotic one -- and
      # everything up to this point has already succeeded and is idempotent.
      if echo "$DEP" | grep -qE 'Unable to receive the OAuth message|Invalid connection configuration|token is expired|Authentication token has expired'; then
        echo "$DEP" | tail -6
        die "the connection dropped part-way through the app build -- this is NOT a
          problem with $app. Two things look identical here:
            1. A REGIONAL INCIDENT. Check https://status.snowflake.com first. An
               incident affecting warehouse start/resume also degrades login and
               produces exactly this OAuth timeout. If warehouses are stuck in
               RESUMING (SHOW WAREHOUSES, started_clusters = 0), wait it out --
               there is usually no client-side workaround.
            2. An EXPIRED LOGIN. Re-authenticate and re-run.
          Either way, every phase before this one is idempotent and the app build is
          cached, so re-running once the platform is healthy is quick:
            snow sql -c $CONN --role $ROLE -q 'SELECT 1'   # re-triggers the browser login
            ./deploy.sh --connection $CONN --yes
          Use that query rather than 'snow connection test', which also tries the
          connection's default warehouse and reports a warehouse error even when
          authentication is perfectly fine.
          If it keeps expiring mid-deploy with no incident open, switch the connection
          to key-pair or PAT auth, which does not time out during a long build."
      fi
      echo "$DEP" | tail -20; die "$app deploy failed."
    fi
  done

  say "9. Granting app access"
  # All THREE object grants matter. The database and schema pair is the one that
  # gets forgotten, and without it the app simply will not open -- which presents
  # as a broken app rather than a missing grant.
  sf "GRANT USAGE ON DATABASE SNOWFLAKE_APPS        TO ROLE SNOWCUP_PARTICIPANT;
      GRANT USAGE ON SCHEMA   SNOWFLAKE_APPS.PUBLIC TO ROLE SNOWCUP_PARTICIPANT;
      GRANT USAGE ON WAREHOUSE SNOWFLAKE_APPS_QUERY_WH TO ROLE SNOWCUP_PARTICIPANT;
      GRANT USAGE ON APPLICATION SERVICE SNOWFLAKE_APPS.PUBLIC.SNOWCUP_LAB_APP
        TO ROLE SNOWCUP_PARTICIPANT;
      GRANT USAGE ON DATABASE SNOWFLAKE_APPS        TO ROLE SNOWCUP_FACILITATOR;
      GRANT USAGE ON SCHEMA   SNOWFLAKE_APPS.PUBLIC TO ROLE SNOWCUP_FACILITATOR;
      GRANT USAGE ON WAREHOUSE SNOWFLAKE_APPS_QUERY_WH TO ROLE SNOWCUP_FACILITATOR;
      GRANT USAGE, MONITOR ON APPLICATION SERVICE SNOWFLAKE_APPS.PUBLIC.SNOWCUP_ADMIN_APP
        TO ROLE SNOWCUP_FACILITATOR;
      GRANT USAGE, MONITOR ON APPLICATION SERVICE SNOWFLAKE_APPS.PUBLIC.SNOWCUP_LAB_APP
        TO ROLE SNOWCUP_FACILITATOR;" >/dev/null
  GR="$(sf "SHOW GRANTS TO ROLE SNOWCUP_PARTICIPANT" | grep -cE 'SNOWFLAKE_APPS')"
  [[ "$GR" -ge 4 ]] || die "participant app grants incomplete ($GR of 4)."
  ok "learners can open the lab app; facilitators can open both"
fi

# --------------------------------------------------------------------------- #
ORG="$(sf_value "LOWER(CURRENT_ORGANIZATION_NAME() || '/' || CURRENT_ACCOUNT_NAME())")"

cat <<EOF

────────────────────────────────────────────────────────────────────────────
 SnowCup is deployed.

 Send each learner:
   Sign in     https://app.snowflake.com/${ORG:-<org>/<account>}/
   The lab     ${LAB_URL:-<deploy the lab app to get its URL>}
   Their build schema  SNOWCUP_BUILDS.WS_<THEIRNAME>   (from the provisioning output)

 Tell them: work the modules in order, tick each checkpoint as you finish it
 (progress saves to your Snowflake user), then submit answers to the
 "SnowCup Referee" agent as  Q1: <answer>  for 120 points total. 3-4 hours.

 Your admin console (roster, environment health, leaderboard, lab progress):
   ${ADMIN_URL:-<deploy the admin app to get its URL>}

 Give another facilitator access without handing out ACCOUNTADMIN:
   GRANT ROLE SNOWCUP_FACILITATOR TO USER <person>;

 Never send learners this package, the guide, or the SQL -- they contain the
 answer key. The lab URL is the only thing they need.
────────────────────────────────────────────────────────────────────────────
EOF
